extends Node2D

const DIRECTIONS: Array[NpcWorker.Facing] = [
	NpcWorker.Facing.DOWN,
	NpcWorker.Facing.LEFT,
	NpcWorker.Facing.TOP,
	NpcWorker.Facing.RIGHT,
]

@onready var workers: Array[Node] = $Workers.get_children()

var _direction_index := 0
var _direction_elapsed := 0.0


func _ready() -> void:
	_set_preview_direction(DIRECTIONS[_direction_index])


func _process(delta: float) -> void:
	_direction_elapsed += delta
	if _direction_elapsed < 2.0:
		return

	_direction_elapsed = 0.0
	_direction_index = (_direction_index + 1) % DIRECTIONS.size()
	_set_preview_direction(DIRECTIONS[_direction_index])


func _set_preview_direction(direction: NpcWorker.Facing) -> void:
	for worker: NpcWorker in workers:
		worker.preview_walk(direction)
