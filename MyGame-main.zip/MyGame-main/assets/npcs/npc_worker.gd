class_name NpcWorker
extends CharacterBody2D

enum Facing {
	TOP,
	LEFT,
	DOWN,
	RIGHT,
}

@export var walk_speed := 70.0
@export_range(1.0, 12.0, 0.5) var animation_fps := 6.0
@export var facing := Facing.DOWN
@export var animate_in_place := false

@onready var sprite: Sprite2D = $Sprite2D

var _movement_direction := Vector2.ZERO
var _frame_index := 0
var _frame_elapsed := 0.0


func _ready() -> void:
	_apply_frame()


func _physics_process(delta: float) -> void:
	var is_moving := _movement_direction != Vector2.ZERO

	if is_moving:
		facing = _direction_to_facing(_movement_direction)
		velocity = _movement_direction.normalized() * walk_speed
		move_and_slide()
		global_position = global_position.round()
	else:
		velocity = Vector2.ZERO

	if is_moving or animate_in_place:
		_advance_animation(delta)
	else:
		_frame_index = 0
		_frame_elapsed = 0.0

	_apply_frame()


func walk(direction: Vector2) -> void:
	_movement_direction = _cardinal_direction(direction)


func stop() -> void:
	_movement_direction = Vector2.ZERO


func preview_walk(direction: Facing) -> void:
	facing = direction
	animate_in_place = true


func _advance_animation(delta: float) -> void:
	_frame_elapsed += delta
	var frame_duration := 1.0 / animation_fps

	while _frame_elapsed >= frame_duration:
		_frame_elapsed -= frame_duration
		_frame_index = (_frame_index + 1) % 8


func _apply_frame() -> void:
	if is_instance_valid(sprite):
		sprite.frame_coords = Vector2i(_frame_index, facing)


func _direction_to_facing(direction: Vector2) -> Facing:
	if absf(direction.x) > absf(direction.y):
		return Facing.RIGHT if direction.x > 0.0 else Facing.LEFT
	return Facing.DOWN if direction.y >= 0.0 else Facing.TOP


func _cardinal_direction(direction: Vector2) -> Vector2:
	if absf(direction.x) > absf(direction.y):
		return Vector2(signf(direction.x), 0.0)
	if direction.y != 0.0:
		return Vector2(0.0, signf(direction.y))
	return Vector2.ZERO
