extends Node2D

const CELL_SIZE := 32
const FLOOR_SIZE := Vector2i(40, 27)
const RACK_ROWS := [2, 7, 12, 17, 22]
const SEGMENT_STARTS := [2, 22]
const MODULES_PER_SEGMENT := 4
const MODULE_SIZE_CELLS := Vector2i(4, 3)
const MODULE_VISUAL_HEIGHT := 77.0
const RACK_ATLAS_STARTS := [0, 8, 16, 8, 0]

@onready var floor_layer: TileMapLayer = $MezzanineFloorLayer
@onready var rack_layer: TileMapLayer = $MezzanineRackLayer
@onready var rack_collisions: Node2D = $RackCollisions
@onready var boundary_collisions: Node2D = $BoundaryCollisions
@onready var player: CharacterBody2D = $Player


func _ready() -> void:
	_build_floor()
	_build_racks()
	_build_boundaries()
	_configure_player_camera()


func _build_floor() -> void:
	floor_layer.clear()
	for y in range(FLOOR_SIZE.y):
		for x in range(FLOOR_SIZE.x):
			var atlas_coords := _floor_atlas_coords(x, y)
			floor_layer.set_cell(Vector2i(x, y), 0, atlas_coords, 0)


func _floor_atlas_coords(x: int, y: int) -> Vector2i:
	if y == 0:
		return Vector2i(0, 1)
	if y == FLOOR_SIZE.y - 1:
		return Vector2i(1, 1)
	if x == 0:
		return Vector2i(2, 1)
	if x == FLOOR_SIZE.x - 1:
		return Vector2i(3, 1)

	var vertical_seam := x % 8 == 0
	var horizontal_seam := y % 8 == 0
	if vertical_seam and horizontal_seam:
		return Vector2i(3, 0)
	if vertical_seam:
		return Vector2i(1, 0)
	if horizontal_seam:
		return Vector2i(2, 0)
	return Vector2i(0, 0)


func _build_racks() -> void:
	rack_layer.clear()
	_clear_children(rack_collisions)

	for row_index in range(RACK_ROWS.size()):
		var row_y: int = RACK_ROWS[row_index]
		var row_atlas_x: int = RACK_ATLAS_STARTS[row_index]

		for segment_x in SEGMENT_STARTS:
			for module_index in range(MODULES_PER_SEGMENT):
				var cell := Vector2i(segment_x + module_index * MODULE_SIZE_CELLS.x, row_y)
				var atlas_x := row_atlas_x + 4 if module_index == MODULES_PER_SEGMENT - 1 else row_atlas_x
				var atlas_coords := Vector2i(atlas_x, 0)
				rack_layer.set_cell(cell, 0, atlas_coords, 0)
			_add_rack_collision(segment_x, row_y)


func _add_rack_collision(start_x: int, row_y: int) -> void:
	var width := MODULES_PER_SEGMENT * MODULE_SIZE_CELLS.x * CELL_SIZE
	var footprint_height := MODULE_SIZE_CELLS.y * CELL_SIZE
	var height := MODULE_VISUAL_HEIGHT
	var center := Vector2(
		start_x * CELL_SIZE + width * 0.5,
		row_y * CELL_SIZE + footprint_height - height * 0.5
	)
	_add_static_rectangle(rack_collisions, center, Vector2(width, height))


func _build_boundaries() -> void:
	_clear_children(boundary_collisions)
	var world_size := Vector2(FLOOR_SIZE * CELL_SIZE)
	var thickness := 32.0
	_add_static_rectangle(boundary_collisions, Vector2(world_size.x * 0.5, -thickness * 0.5), Vector2(world_size.x, thickness))
	_add_static_rectangle(boundary_collisions, Vector2(world_size.x * 0.5, world_size.y + thickness * 0.5), Vector2(world_size.x, thickness))
	_add_static_rectangle(boundary_collisions, Vector2(-thickness * 0.5, world_size.y * 0.5), Vector2(thickness, world_size.y))
	_add_static_rectangle(boundary_collisions, Vector2(world_size.x + thickness * 0.5, world_size.y * 0.5), Vector2(thickness, world_size.y))


func _add_static_rectangle(parent_node: Node2D, center: Vector2, size: Vector2) -> void:
	var body := StaticBody2D.new()
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = size
	collision.shape = shape
	body.position = center
	body.add_child(collision)
	parent_node.add_child(body)


func _clear_children(parent_node: Node) -> void:
	for child in parent_node.get_children():
		child.queue_free()


func _configure_player_camera() -> void:
	var camera := player.get_node_or_null("Camera2D") as Camera2D
	if camera == null:
		return
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = FLOOR_SIZE.x * CELL_SIZE
	camera.limit_bottom = FLOOR_SIZE.y * CELL_SIZE
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 8.0
