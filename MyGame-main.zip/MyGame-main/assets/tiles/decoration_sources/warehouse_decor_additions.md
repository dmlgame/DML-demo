# Warehouse Decorations

The original sprites were generated with the built-in ImageGen tool. The existing
`warehouse_decor_tileset_32.png` was a style reference, not a replacement target.
The new textures preserve alpha transparency and use nearest-neighbor resizing.

## Final Prompt Brief

One transparent pixel-art warehouse sprite atlas, matching the game's dark
outlines, restrained blue/gray/red/yellow palette and top-down front three-quarter
perspective. No text, people, floor or background. Separate sprites: a blue drum,
red toolbox, maintenance barrier, fire extinguisher on a stand, industrial fan,
nested gray crates, stretch-film rolls, spare conveyor rollers, flattened shipping
cartons, green packing strapping, and five differently shaped discarded clear
stretch-film scraps: crumpled, long torn strip, twisted ribbon, flat creased sheet
and loose spiral.

## In-Game Textures

- `../warehouse_decor_additions_32.png`: ten decorations in ObjectsLayer's existing
  TileSet, source ID 6. Each 64 x 64 sprite occupies a 2 x 2 tile region, with a
  collision footprint at its base and a matching Y-sort origin.
- `../warehouse_stretch_scraps_32.png`: five additional FloorLayer2 scraps in its
  existing TileSet, source ID 2. Each 64 x 32 sprite occupies a 2 x 1 tile region;
  these floor decorations have no collision.
- `warehouse_decor_additions_generated.png`: original generated source atlas.

Existing atlases, painted cells, source IDs and the original film scrap are kept.
