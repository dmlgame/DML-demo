@tool
extends Sprite2D


const PLAYER_FOOT_OFFSET := Vector2(0, 25)
const REAR_SUPPORT_HEIGHT := 55.0
const REAR_DIAGONAL_END_HEIGHT := 45.0
const LOWER_VISUAL_HEIGHT := 60.0
const PLATFORM_SUPPORT_HEIGHT := 50.0
const EDGE_X_MARGIN := 12.0
const PART_SHADER = preload("res://assets/objects/second_floor_staircase/staircase_parts.gdshader")
# Disjoint texture regions separate the supports without changing the original PNG.
const REAR_REGION := [Vector2(215, 190), Vector2(298, 196), Vector2(493, 391), Vector2(493, 542), Vector2(400, 563), Vector2(315, 640), Vector2(215, 640)]
const PLATFORM_REGION := [Vector2(748, 801), Vector2(1142, 615), Vector2(1165, 932), Vector2(827, 1098), Vector2(724, 1094), Vector2(724, 1011), Vector2(596, 940), Vector2(612, 915), Vector2(735, 985)]

@onready var foreground: Sprite2D = $Foreground
@onready var collision_body: StaticBody2D = $StaticBody2D

var _player: Node2D
var _front_edges: Array[PackedVector2Array] = []
var _edge_heights: Array[Vector2] = []
var _rear_edges: Array[PackedVector2Array] = []
var _rear_heights: Array[Vector2] = []
var _platform_edges: Array[PackedVector2Array] = []
var _platform_heights: Array[Vector2] = []
var _support_visuals: Array[Dictionary] = []


func _ready() -> void:
	_build_front_edges()
	if Engine.is_editor_hint():
		set_process(false)
		return
	_build_part_visuals()
	_player = get_node_or_null("../../Player") as Node2D
	set_process(_player != null)
	_update_occlusion()


func _process(_delta: float) -> void:
	_update_occlusion()


func _update_occlusion() -> void:
	if _player == null:
		return
	var feet := _player.global_position + PLAYER_FOOT_OFFSET
	var in_front := _in_front_of_marked_edge(feet)
	foreground.visible = not in_front
	self_modulate.a = 1.0 if in_front else 0.0
	for index in _support_visuals.size():
		var edges := _rear_edges if index == 0 else _platform_edges
		var heights := _rear_heights if index == 0 else _platform_heights
		var support_in_front := _in_front_of_edges(feet, edges, heights)
		_support_visuals[index].background.visible = support_in_front
		_support_visuals[index].foreground.visible = not support_in_front


func _part_material(part: int) -> ShaderMaterial:
	var result := ShaderMaterial.new()
	result.shader = PART_SHADER
	result.set_shader_parameter("part", part)
	result.set_shader_parameter("rear_region", PackedVector2Array(REAR_REGION))
	result.set_shader_parameter("platform_region", PackedVector2Array(PLATFORM_REGION))
	return result


func _build_part_visuals() -> void:
	material = _part_material(0)
	foreground.material = material
	for part in [1, 2]:
		var part_material := _part_material(part)
		var pair := {}
		for layer in ["background", "foreground"]:
			var visual := Sprite2D.new()
			visual.name = ("RearSupports" if part == 1 else "PlatformSupports") + layer.capitalize()
			visual.texture = texture
			visual.texture_filter = texture_filter
			visual.centered = centered
			visual.offset = offset
			visual.material = part_material
			visual.z_index = 1 if layer == "foreground" else 0
			visual.visible = layer == "foreground"
			add_child(visual, false, Node.INTERNAL_MODE_FRONT)
			pair[layer] = visual
		_support_visuals.append(pair)


func _build_front_edges() -> void:
	_front_edges.clear()
	_edge_heights.clear()
	_rear_edges.clear()
	_rear_heights.clear()
	_platform_edges.clear()
	_platform_heights.clear()
	var lower: CollisionPolygon2D = collision_body.get_node("CollisionPolygon2D")
	var platform: CollisionPolygon2D = collision_body.get_node("CollisionPolygon2D2")
	var rear: CollisionPolygon2D = collision_body.get_node("CollisionPolygon2D4")
	_add_edge(rear, 3, 0, REAR_SUPPORT_HEIGHT, 0.0, 1.0, -1.0, 1)
	_add_edge(rear, 0, 1, REAR_SUPPORT_HEIGHT, 0.0, 1.0, REAR_DIAGONAL_END_HEIGHT, 1)
	_add_edge(lower, 0, 1, LOWER_VISUAL_HEIGHT)
	_add_edge(lower, 1, 2, LOWER_VISUAL_HEIGHT, 0.0, 0.68)
	_add_edge(platform, 3, 0, PLATFORM_SUPPORT_HEIGHT, 0.4, 1.0, -1.0, 2)
	_add_edge(platform, 0, 1, PLATFORM_SUPPORT_HEIGHT, 0.0, 1.0, -1.0, 2)


func _add_edge(collider: CollisionPolygon2D, first: int, last: int, visual_height: float, start_fraction: float = 0.0, end_fraction: float = 1.0, end_visual_height: float = -1.0, part: int = 0) -> void:
	var polygon := collider.polygon
	var start: Vector2 = polygon[first].lerp(polygon[last], start_fraction)
	var end: Vector2 = polygon[first].lerp(polygon[last], end_fraction)
	var edges := _rear_edges if part == 1 else (_platform_edges if part == 2 else _front_edges)
	var heights := _rear_heights if part == 1 else (_platform_heights if part == 2 else _edge_heights)
	edges.append(PackedVector2Array([collider.to_global(start), collider.to_global(end)]))
	heights.append(Vector2(visual_height, visual_height if end_visual_height < 0.0 else end_visual_height))


func _in_front_of_marked_edge(point: Vector2) -> bool:
	return _in_front_of_edges(point, _front_edges, _edge_heights)


func _in_front_of_edges(point: Vector2, edges: Array[PackedVector2Array], heights: Array[Vector2]) -> bool:
	for index in edges.size():
		var edge := edges[index]
		var a := edge[0]
		var b := edge[1]
		if point.x < minf(a.x, b.x) - EDGE_X_MARGIN or point.x > maxf(a.x, b.x) + EDGE_X_MARGIN:
			continue
		var fraction := clampf((point.x - a.x) / (b.x - a.x), 0.0, 1.0)
		var edge_y := lerpf(a.y, b.y, fraction)
		var visual_height := lerpf(heights[index].x, heights[index].y, fraction)
		if point.y >= edge_y - 1.0 and point.y - visual_height <= edge_y:
			return true
	return false
