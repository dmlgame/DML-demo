extends Node2D

@export var frames_per_second := 6.0

@onready var preview_sprites: Array[Sprite2D] = [
	$Left,
	$Right,
	$Up,
	$Down,
]

var frame_index := 0
var frame_time := 0.0


func _process(delta: float) -> void:
	frame_time += delta
	var frame_duration := 1.0 / frames_per_second

	while frame_time >= frame_duration:
		frame_time -= frame_duration
		frame_index = (frame_index + 1) % 8

	for preview_sprite in preview_sprites:
		var coordinates := preview_sprite.frame_coords
		coordinates.x = frame_index
		preview_sprite.frame_coords = coordinates
