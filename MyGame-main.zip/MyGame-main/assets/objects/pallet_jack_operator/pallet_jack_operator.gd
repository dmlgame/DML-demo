extends CharacterBody2D

@export var move_speed := 85.0
@export var walk_frames_per_second := 6.0

@onready var equipment_sprite: Sprite2D = $EquipmentSprite
@onready var operator_sprite: Sprite2D = $OperatorSprite
@onready var combined_walk_sprite: Sprite2D = $CombinedWalkSprite
@onready var combined_vertical_walk_sprite: Sprite2D = $CombinedVerticalWalkSprite

const TEXTURE_LEFT := preload("res://assets/objects/pallet_jack_operator/pallet_jack_operator_left.png")
const TEXTURE_RIGHT := preload("res://assets/objects/pallet_jack_operator/pallet_jack_operator_right.png")
const TEXTURE_UP := preload("res://assets/objects/pallet_jack_operator/pallet_jack_operator_up.png")
const TEXTURE_DOWN := preload("res://assets/objects/pallet_jack_operator/pallet_jack_operator_down.png")

const WALK_FRAME_COUNT := 8
const WALK_ROWS := {
	"up": 8,
	"left": 9,
	"down": 10,
	"right": 11,
}
const COMBINED_WALK_ROWS := {
	"left": 0,
	"right": 1,
}
const COMBINED_WALK_POSITIONS := {
	"left": Vector2(30, -7),
	"right": Vector2(-33, -7),
}
const COMBINED_VERTICAL_WALK_ROWS := {
	"up": 0,
	"down": 1,
}
const COMBINED_VERTICAL_WALK_POSITIONS := {
	"up": Vector2(0, 43),
	"down": Vector2(0, -38),
}
const DIRECTION_TEXTURES := {
	"left": TEXTURE_LEFT,
	"right": TEXTURE_RIGHT,
	"up": TEXTURE_UP,
	"down": TEXTURE_DOWN,
}

# The equipment pictures keep only the approved pallet jack, handle and gripping arm.
# The rest of the old character is removed by the equipment shader.
const EQUIPMENT_ERASE_RECTS := {
	"left": Vector4(0.36, 0.24, 0.66, 0.72),
	"right": Vector4(0.34, 0.24, 0.64, 0.72),
	"up": Vector4(0.36, 0.23, 0.66, 0.72),
	"down": Vector4(0.36, 0.32, 0.66, 0.73),
}
const EQUIPMENT_KEEP_RECTS := {
	"left": Vector4(0.53, 0.39, 0.73, 0.62),
	"right": Vector4(0.27, 0.39, 0.47, 0.62),
	"up": Vector4(0.53, 0.54, 0.66, 0.77),
	"down": Vector4(0.38, 0.32, 0.47, 0.50),
}

# Only the arm that holds the handle is removed from the regular walk animation.
# Its fixed replacement is already present in the equipment picture above it.
const OPERATOR_ARM_RECTS := {
	"left": Vector4(0.546875, 0.484375, 0.765625, 0.8125),
	"right": Vector4(0.234375, 0.484375, 0.453125, 0.8125),
	"up": Vector4(0.640625, 0.59375, 0.75, 0.828125),
	"down": Vector4(0.265625, 0.59375, 0.375, 0.828125),
}

var last_direction := Vector2.DOWN
var current_direction_name := ""
var walk_frame := 0
var walk_frame_time := 0.0
var was_moving := false


func _ready() -> void:
	_apply_direction(last_direction)
	_show_idle_frame()


func _physics_process(delta: float) -> void:
	var direction := _read_direction()
	var is_moving := direction != Vector2.ZERO

	if is_moving:
		last_direction = direction
		velocity = direction * move_speed
		_apply_direction(direction)
		_advance_walk_animation(delta)
	else:
		velocity = Vector2.ZERO
		if was_moving:
			_show_idle_frame()

	was_moving = is_moving
	move_and_slide()
	global_position = global_position.round()


func _read_direction() -> Vector2:
	var x := 0.0
	var y := 0.0

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		y += 1.0

	if x != 0.0 and y != 0.0:
		if last_direction.x != 0.0:
			return Vector2(x, 0.0)
		return Vector2(0.0, y)
	if x != 0.0:
		return Vector2(x, 0.0)
	if y != 0.0:
		return Vector2(0.0, y)
	return Vector2.ZERO


func _advance_walk_animation(delta: float) -> void:
	walk_frame_time += delta
	var frame_duration := 1.0 / walk_frames_per_second

	while walk_frame_time >= frame_duration:
		walk_frame_time -= frame_duration
		walk_frame = (walk_frame + 1) % WALK_FRAME_COUNT

	_update_operator_frame()


func _show_idle_frame() -> void:
	walk_frame = 0
	walk_frame_time = 0.0
	_update_operator_frame()


func _apply_direction(direction: Vector2) -> void:
	var direction_name := _direction_name(direction)
	if direction_name == current_direction_name:
		return

	current_direction_name = direction_name
	walk_frame = 0
	walk_frame_time = 0.0

	var uses_horizontal_walk := COMBINED_WALK_ROWS.has(direction_name)
	var uses_vertical_walk := COMBINED_VERTICAL_WALK_ROWS.has(direction_name)
	var uses_combined_walk := uses_horizontal_walk or uses_vertical_walk
	combined_walk_sprite.visible = uses_horizontal_walk
	combined_vertical_walk_sprite.visible = uses_vertical_walk
	operator_sprite.visible = not uses_combined_walk
	equipment_sprite.visible = not uses_combined_walk

	if uses_horizontal_walk:
		combined_walk_sprite.position = COMBINED_WALK_POSITIONS[direction_name]
		_update_operator_frame()
		return

	if uses_vertical_walk:
		combined_vertical_walk_sprite.position = COMBINED_VERTICAL_WALK_POSITIONS[direction_name]
		_update_operator_frame()
		return

	equipment_sprite.texture = DIRECTION_TEXTURES[direction_name]
	equipment_sprite.material.set_shader_parameter(
		"erase_rect", EQUIPMENT_ERASE_RECTS[direction_name]
	)
	equipment_sprite.material.set_shader_parameter(
		"keep_rect", EQUIPMENT_KEEP_RECTS[direction_name]
	)
	operator_sprite.material.set_shader_parameter(
		"erase_local_rect", OPERATOR_ARM_RECTS[direction_name]
	)
	_update_operator_frame()


func _update_operator_frame() -> void:
	if current_direction_name.is_empty():
		return

	if COMBINED_WALK_ROWS.has(current_direction_name):
		combined_walk_sprite.frame_coords = Vector2i(
			walk_frame, COMBINED_WALK_ROWS[current_direction_name]
		)
		return

	if COMBINED_VERTICAL_WALK_ROWS.has(current_direction_name):
		combined_vertical_walk_sprite.frame_coords = Vector2i(
			walk_frame, COMBINED_VERTICAL_WALK_ROWS[current_direction_name]
		)
		return

	operator_sprite.frame_coords = Vector2i(walk_frame + 1, WALK_ROWS[current_direction_name])


func _direction_name(direction: Vector2) -> String:
	if absf(direction.x) > absf(direction.y):
		return "right" if direction.x > 0.0 else "left"
	return "down" if direction.y >= 0.0 else "up"
