extends CharacterBody2D

@export var move_speed := 110.0
@export var animation_frames_per_second := 6.0

@onready var sprite: Sprite2D = $Sprite2D

const FRAME_COUNT := 8
const DIRECTION_ROWS := {
	"left": 0,
	"right": 1,
	"up": 2,
	"down": 3,
}

var last_direction := Vector2.DOWN
var current_direction_name := "down"
var animation_frame := 0
var animation_time := 0.0
var was_moving := false


func _ready() -> void:
	_update_frame()


func _physics_process(delta: float) -> void:
	var direction := _read_direction()
	var is_moving := direction != Vector2.ZERO

	if is_moving:
		last_direction = direction
		velocity = direction * move_speed
		_set_direction(direction)
		_advance_animation(delta)
	else:
		velocity = Vector2.ZERO
		if was_moving:
			animation_frame = 0
			animation_time = 0.0
			_update_frame()

	was_moving = is_moving
	move_and_slide()
	global_position = global_position.round()


func _read_direction() -> Vector2:
	var x := 0.0
	var y := 0.0

	if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		x -= 1.0
	if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		x += 1.0
	if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		y -= 1.0
	if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		y += 1.0

	if x != 0.0 and y != 0.0:
		if last_direction.x != 0.0:
			return Vector2(x, 0.0)
		return Vector2(0.0, y)
	if x != 0.0:
		return Vector2(x, 0.0)
	if y != 0.0:
		return Vector2(0.0, y)
	return Vector2.ZERO


func _set_direction(direction: Vector2) -> void:
	var direction_name := _direction_name(direction)
	if direction_name == current_direction_name:
		return

	current_direction_name = direction_name
	animation_frame = 0
	animation_time = 0.0
	_update_frame()


func _advance_animation(delta: float) -> void:
	animation_time += delta
	var frame_duration := 1.0 / animation_frames_per_second

	while animation_time >= frame_duration:
		animation_time -= frame_duration
		animation_frame = (animation_frame + 1) % FRAME_COUNT

	_update_frame()


func _update_frame() -> void:
	sprite.frame_coords = Vector2i(
		animation_frame,
		DIRECTION_ROWS[current_direction_name]
	)


func _direction_name(direction: Vector2) -> String:
	if absf(direction.x) > absf(direction.y):
		return "right" if direction.x > 0.0 else "left"
	return "down" if direction.y >= 0.0 else "up"
