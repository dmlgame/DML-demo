extends Node

const TITLE := "Лестница"
const ACTION := "Нажмите E или Enter, чтобы подняться на второй этаж третьего блока"
const NOTICE := "Данное действие временно недоступно, ведутся строительные работы!"
const PLAYER_FOOT_OFFSET := Vector2(0, 25)
const SHAKE_STEPS := [Vector2(1, 0), Vector2(-1, 0.5), Vector2(0.7, -0.5), Vector2(-0.5, 0.3), Vector2(0.3, -0.2), Vector2.ZERO]
const SHAKE_STEP_DURATION := 0.035

@export_range(16, 128, 1) var proximity := 64.0
@export_range(0, 4, 0.1) var shake_strength := 1.5

@onready var lower_edge: CollisionPolygon2D = $"../YSortActors/SecondFloorStaircaseSort/SecondFloorStaircase/StaticBody2D/CollisionPolygon2D"
@onready var player: CharacterBody2D = $"../YSortActors/Player"
@onready var camera: Camera2D = $"../YSortActors/Player/Camera2D"

var _busy := false
var _notice_active := false
var _camera_origin := Vector2.ZERO
var _shake: Tween

func _ready() -> void:
	player.register_stair_interaction(self)

func _exit_tree() -> void:
	_cancel_feedback()
	if is_instance_valid(player):
		player.unregister_stair_interaction(self)

func _process(_delta: float) -> void:
	if not _near_entrance(player):
		_notice_active = false
		if _busy:
			_cancel_feedback()

func _near_entrance(actor: Node2D) -> bool:
	if not is_instance_valid(actor) or not is_instance_valid(lower_edge) or not actor.is_visible_in_tree():
		return false
	var feet := actor.global_position + PLAYER_FOOT_OFFSET
	var start := lower_edge.to_global(lower_edge.polygon[0])
	var end := lower_edge.to_global(lower_edge.polygon[1])
	var closest := Geometry2D.get_closest_point_to_segment(feet, start, end)
	return feet.distance_to(closest) <= proximity and feet.y >= closest.y - 6.0

func can_interact(actor: Node2D) -> bool:
	return not _busy and _near_entrance(actor)

func get_interaction_text(actor: Node2D) -> String:
	if not can_interact(actor):
		return ""
	return TITLE + "\n" + (NOTICE if _notice_active else ACTION)

func try_interact(actor: Node2D) -> bool:
	if not can_interact(actor):
		return false
	_busy = true
	_notice_active = false
	_camera_origin = camera.offset
	player.set_interaction_locked(true)
	_shake = create_tween()
	for step in SHAKE_STEPS:
		_shake.tween_property(camera, "offset", _camera_origin + step * shake_strength, SHAKE_STEP_DURATION)
	_shake.tween_callback(_finish_feedback)
	return true

func _finish_feedback() -> void:
	_restore_camera()
	_notice_active = _near_entrance(player)
	_busy = false
	_shake = null
	if is_instance_valid(player):
		player.set_interaction_locked(false)

func _cancel_feedback() -> void:
	if _shake != null and _shake.is_valid():
		_shake.kill()
	_shake = null
	if not _busy:
		return
	_restore_camera()
	_busy = false
	if is_instance_valid(player):
		player.set_interaction_locked(false)

func _restore_camera() -> void:
	if is_instance_valid(camera):
		camera.offset = _camera_origin
		camera.force_update_scroll()
