extends Node2D

const FOOT_OFFSET := Vector2(0, 25)
const TABLE_CELL := Vector2i(-48, -76)
const NO_SOURCE := Vector2i(2147483647, 2147483647)
const STOCK_ATLASES := [Vector2i(6, 10), Vector2i(3, 10), Vector2i(0, 10), Vector2i(2, 6)]
const STOCK_CELLS := [
	Vector2i(-134, -99), Vector2i(-130, -97), Vector2i(-134, -93),
	Vector2i(-135, -81), Vector2i(-132, -81),
	Vector2i(7, -76), Vector2i(5, -74), Vector2i(3, -76),
	Vector2i(3, -72), Vector2i(7, -72), Vector2i(5, -69),
	Vector2i(1, -74), Vector2i(1, -69),
]
const DELIVERY_ATLAS := Vector2i(1, 6)
const DELIVERY_SCALE := 1.0
const DELIVERY_ORIGIN := Vector2(0, 48)

var picked_source := NO_SOURCE
var delivered := false
var target_visible := false
var _world: Node2D
var _stock: TileMapLayer
var _objects: TileMapLayer
var _player: CharacterBody2D
var _originals := {}
var _delivery: StaticBody2D
var _footprint: ConvexPolygonShape2D
var _texture: AtlasTexture
var _exit_exception := false

func _ready() -> void:
	_world = get_parent().get_parent()
	_stock = _world.get_node("YSortActors/PalletLayer")
	_objects = _world.get_node("YSortActors/ObjectsLayer")
	_player = _world.get_node("YSortActors/Player")
	for cell in STOCK_CELLS:
		if _stock.get_cell_source_id(cell) == 0 and STOCK_ATLASES.find(_stock.get_cell_atlas_coords(cell)) > 0:
			_originals[cell] = {"atlas": _stock.get_cell_atlas_coords(cell), "alternative": _stock.get_cell_alternative_tile(cell)}
	var source := _stock.tile_set.get_source(0) as TileSetAtlasSource
	_texture = AtlasTexture.new()
	_texture.atlas = source.texture
	_texture.region = source.get_tile_texture_region(DELIVERY_ATLAS)
	var points := source.get_tile_data(DELIVERY_ATLAS, 0).get_collision_polygon_points(0, 0)
	for index in points.size():
		points[index] = points[index] * DELIVERY_SCALE - DELIVERY_ORIGIN
	_footprint = ConvexPolygonShape2D.new()
	_footprint.points = points

func _exit_tree() -> void:
	_remove_delivery()
	if is_instance_valid(_stock):
		for cell in _originals:
			_stock.set_cell(cell, 0, _originals[cell].atlas, _originals[cell].alternative)

func _physics_process(_delta: float) -> void:
	if _exit_exception and not _overlaps_player():
		_clear_exception()

func is_source_cell(cell: Vector2i) -> bool:
	return _originals.has(cell)

func source_point(cell: Vector2i) -> Vector2:
	return _stock.to_global(_stock.map_to_local(cell) + Vector2(0, 80))

func nearest_source(actor: Node2D) -> Variant:
	var nearest: Variant = null
	var distance := INF
	for cell in _originals:
		if STOCK_ATLASES.find(_stock.get_cell_atlas_coords(cell)) <= 0:
			continue
		var candidate := (actor.global_position + FOOT_OFFSET).distance_squared_to(source_point(cell))
		if candidate < distance:
			nearest = cell
			distance = candidate
	return nearest

func nearby_source(actor: Node2D) -> Variant:
	var cell: Variant = nearest_source(actor)
	if cell == null:
		return null
	var center := _stock.to_global(_stock.map_to_local(cell))
	var rect := Rect2(center + Vector2(-35, 42), Vector2(71, 22)).grow(48)
	return cell if rect.has_point(actor.global_position + FOOT_OFFSET) else null

func single_stack_hint(actor: Node2D) -> String:
	for cell in STOCK_CELLS:
		if _stock.get_cell_atlas_coords(cell) == STOCK_ATLASES[0] and (actor.global_position + FOOT_OFFSET).distance_to(source_point(cell)) <= 64:
			return "Запас тарников\nЭтот паллет сейчас недоступен для задания."
	return ""

func loose_tote_hint(actor: Node2D) -> String:
	var feet := actor.global_position + FOOT_OFFSET
	for cell in _stock.get_used_cells():
		var atlas := _stock.get_cell_atlas_coords(cell)
		if cell in STOCK_CELLS or atlas not in [Vector2i(0, 6), Vector2i(1, 6)] + STOCK_ATLASES:
			continue
		var point := _stock.to_global(_stock.map_to_local(cell) + Vector2(0, 16 if atlas == Vector2i(0, 6) else 48))
		if feet.distance_to(point) <= 56:
			return "Синие тарники\nНе берите отдельные тарники и стопки без паллеты: они могут быть заняты или находиться в работе."
	return ""

func delivery_point() -> Vector2:
	for table in _world.get_node("TableHints")._tables:
		if table.cell == TABLE_CELL and table.title == "Стол приемки":
			var bounds: Rect2 = table.footprint
			return _objects.to_global(Vector2(bounds.position.x - 64, bounds.end.y + 20))
	return Vector2.ZERO

func can_place(actor: Node2D) -> bool:
	if not actor.get("pallet_jack_loaded") or delivered or delivery_point() == Vector2.ZERO:
		return false
	if not Rect2(delivery_point() - Vector2(50, 40), Vector2(100, 80)).has_point(actor.global_position + FOOT_OFFSET):
		return false
	if actor._collision_profile_overlaps(actor._active_collision):
		return false
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = _footprint
	query.transform = Transform2D(0, delivery_point())
	query.collision_mask = 1
	query.exclude = [actor.get_rid()]
	return get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func set_progress(cell: Vector2i, placed: bool) -> void:
	picked_source = cell
	delivered = placed
	for original in _originals:
		var saved: Dictionary = _originals[original]
		var atlas: Vector2i = saved.atlas
		if original == cell:
			var index := STOCK_ATLASES.find(atlas)
			atlas = STOCK_ATLASES[index - 1]
		_stock.set_cell(original, 0, atlas, saved.alternative)
	_stock.update_internals()
	if placed and _delivery == null:
		_delivery = StaticBody2D.new()
		_delivery.name = "DemoTable5Totes"
		_delivery.collision_layer = 1
		_delivery.collision_mask = 0
		_world.get_node("YSortActors").add_child(_delivery)
		_delivery.global_position = delivery_point() - FOOT_OFFSET
		var sprite := Sprite2D.new()
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sprite.texture = _texture
		sprite.scale = Vector2.ONE * DELIVERY_SCALE
		sprite.position = FOOT_OFFSET - DELIVERY_ORIGIN
		_delivery.add_child(sprite)
		var collision := CollisionShape2D.new()
		collision.name = "Footprint"
		collision.shape = _footprint
		collision.position = FOOT_OFFSET
		_delivery.add_child(collision)
	if not placed:
		_remove_delivery()
	elif not _exit_exception and _overlaps_player():
		_delivery.add_collision_exception_with(_player)
		_player.add_collision_exception_with(_delivery)
		_exit_exception = true
	queue_redraw()

func _overlaps_player() -> bool:
	if not is_instance_valid(_delivery):
		return false
	var profiles: Array[Node2D] = [_player._active_collision, _player.collision_on_foot]
	for profile in profiles:
		for shape in _player._collision_profile_shapes(profile):
			if _footprint.collide(Transform2D(0, delivery_point()), shape, profile.global_transform):
				return true
	return false

func _clear_exception() -> void:
	if _exit_exception and is_instance_valid(_delivery) and is_instance_valid(_player):
		_delivery.remove_collision_exception_with(_player)
		_player.remove_collision_exception_with(_delivery)
	_exit_exception = false

func _remove_delivery() -> void:
	_clear_exception()
	if is_instance_valid(_delivery):
		_delivery.free()
	_delivery = null

func set_target_visible(enabled: bool) -> void:
	target_visible = enabled
	queue_redraw()

func _draw() -> void:
	if not target_visible or delivery_point() == Vector2.ZERO:
		return
	var point := to_local(delivery_point())
	var rect := Rect2(point - Vector2(34, 20), Vector2(68, 40))
	draw_rect(rect, Color(1, 0.88, 0.25, 0.12))
	draw_rect(rect, Color("ffe36b"), false, 2)
