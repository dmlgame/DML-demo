extends Control

signal pause_requested

const JOYSTICK_RADIUS := 52.0
const DEAD_ZONE := 12.0
const ACCENT := Color("f2cc45")
const PRIMARY_COLOR := Color("3b8ce8")
const SECONDARY_COLOR := Color("37c779")
const PRIMARY_SYMBOL := "[img=16x16]res://assets/ui/touch/primary.svg[/img]"
const SECONDARY_SYMBOL := "[img=16x16]res://assets/ui/touch/secondary.svg[/img]"
const Minimap = preload("res://warehouse_minimap.gd")
const MIN_ZOOM := 0.75
const MAX_ZOOM := 3.5
var available := DisplayServer.is_touchscreen_available()
var player: CharacterBody2D
var joystick_center := Vector2.ZERO
var _finger := -1
var _stick := Vector2.ZERO
var _sprinting := false
var _action_button: TouchScreenButton
var _secondary_action_button: TouchScreenButton
var _sprint_button: TouchScreenButton
var _pause_button: TouchScreenButton
var _zoom_in_button: TouchScreenButton
var _zoom_out_button: TouchScreenButton
var _minimap: Control
var _zoom_fingers := {}
var _pinch_distance := 0.0
var _pinch_zoom := 2.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_to_group("touch_controls")
	_action_button = _button("", "", PRIMARY_COLOR)
	_action_button.name = "PrimaryTouchButton"
	_action_button.get_child(0).tooltip_text = "Первое действие"
	_action_button.action = "interact"
	_secondary_action_button = _button("", "", SECONDARY_COLOR)
	_secondary_action_button.name = "SecondaryTouchButton"
	_secondary_action_button.get_child(0).tooltip_text = "Второе действие"
	_secondary_action_button.action = "interact_secondary"
	_sprint_button = _button("Ускорение", "zap")
	_sprint_button.pressed.connect(_set_sprinting.bind(true))
	_sprint_button.released.connect(_set_sprinting.bind(false))
	_pause_button = _button("", "pause")
	_pause_button.get_child(0).tooltip_text = "Пауза"
	_pause_button.pressed.connect(func(): pause_requested.emit())
	_zoom_in_button = _button("", "zoom-in")
	_zoom_in_button.get_child(0).tooltip_text = "Приблизить"
	_zoom_in_button.pressed.connect(_change_zoom.bind(1.2))
	_zoom_out_button = _button("", "zoom-out")
	_zoom_out_button.get_child(0).tooltip_text = "Отдалить"
	_zoom_out_button.pressed.connect(_change_zoom.bind(1.0 / 1.2))
	_minimap = Minimap.new()
	_minimap.name = "WarehouseMinimap"
	add_child(_minimap)
	resized.connect(_layout)
	visibility_changed.connect(func():
		if not visible:
			reset_input()
		if OS.has_feature("web"):
			var browser := JavaScriptBridge.get_interface("window")
			if browser != null and browser.demoFullscreen != null:
				browser.demoFullscreen.setControlsVisible(visible))
	_layout()
	hide()

func set_active(actor: CharacterBody2D, active: bool) -> void:
	if player != actor:
		reset_input()
		player = actor
		_minimap.bind_player(actor)
	visible = available and active and is_instance_valid(player) and not player._interaction_locked and not get_tree().paused
	if not visible:
		return
	# Sprint applies only to walking, just like Shift on a keyboard.
	_sprint_button.visible = player.move_mode == player.MoveMode.ON_FOOT
	if not _sprint_button.visible:
		_set_sprinting(false)

func reset_input() -> void:
	_finger = -1
	_stick = Vector2.ZERO
	_sprinting = false
	_zoom_fingers.clear()
	_pinch_distance = 0.0
	if is_instance_valid(player):
		player.set_touch_input(Vector2.ZERO, false)
	for button in [_action_button, _secondary_action_button, _sprint_button, _pause_button, _zoom_in_button, _zoom_out_button]:
		if is_instance_valid(button) and button.is_pressed():
			var was_visible: bool = button.visible
			button.hide()
			button.visible = was_visible
	queue_redraw()

func _notification(what: int) -> void:
	if what in [NOTIFICATION_APPLICATION_FOCUS_OUT, NOTIFICATION_WM_WINDOW_FOCUS_OUT]:
		reset_input()

func _input(event: InputEvent) -> void:
	if not visible or not is_instance_valid(player) or player._interaction_locked:
		return
	if event is InputEventScreenTouch:
		if event.pressed and _finger == -1 and event.position.distance_to(joystick_center) <= JOYSTICK_RADIUS + 18.0:
			_finger = event.index
			_move_stick(event.position)
			get_viewport().set_input_as_handled()
		elif not event.pressed and event.index == _finger:
			_finger = -1
			_stick = Vector2.ZERO
			_sync_player()
			queue_redraw()
			get_viewport().set_input_as_handled()
		elif not event.pressed and _zoom_fingers.has(event.index):
			_zoom_fingers.erase(event.index)
			_pinch_distance = 0.0
			get_viewport().set_input_as_handled()
		elif event.pressed and _finger == -1 and _zoom_fingers.size() < 2 and not _is_hud_point(event.position):
			_zoom_fingers[event.index] = event.position
			if _zoom_fingers.size() == 2:
				var points := _zoom_fingers.values()
				_pinch_distance = maxf(16.0, points[0].distance_to(points[1]))
				_pinch_zoom = player.get_node("Camera2D").zoom.x
				get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and event.index == _finger:
		_move_stick(event.position)
		get_viewport().set_input_as_handled()
	elif event is InputEventScreenDrag and _zoom_fingers.has(event.index):
		_zoom_fingers[event.index] = event.position
		if _zoom_fingers.size() == 2 and _pinch_distance > 0:
			var points := _zoom_fingers.values()
			_set_zoom(_pinch_zoom * points[0].distance_to(points[1]) / _pinch_distance)
			get_viewport().set_input_as_handled()
	elif event is InputEventMagnifyGesture and _zoom_fingers.is_empty() and _finger == -1 and not _is_hud_point(event.position):
		_change_zoom(event.factor)
		get_viewport().set_input_as_handled()

func _is_hud_point(point: Vector2) -> bool:
	if point.distance_to(joystick_center) <= JOYSTICK_RADIUS + 18.0 or _minimap.get_global_rect().has_point(point):
		return true
	for button in [_action_button, _secondary_action_button, _sprint_button, _pause_button, _zoom_in_button, _zoom_out_button]:
		if button.visible and Rect2(button.position - button.shape.size / 2.0, button.shape.size).has_point(point):
			return true
	var demo := player.get_parent().get_parent().get_node_or_null("DemoTasks")
	return (demo != null and demo.task_hud_rect().has_point(point)) or player.interaction_hud_rect().has_point(point)

func _change_zoom(factor: float) -> void:
	if visible and is_instance_valid(player) and not player._interaction_locked:
		_set_zoom(player.get_node("Camera2D").zoom.x * factor)

func _set_zoom(value: float) -> void:
	player.get_node("Camera2D").zoom = Vector2.ONE * clampf(value, MIN_ZOOM, MAX_ZOOM)
	_minimap._update_markers()

func _move_stick(point: Vector2) -> void:
	_stick = (point - joystick_center).limit_length(JOYSTICK_RADIUS)
	_sync_player()
	queue_redraw()

func _set_sprinting(pressed: bool) -> void:
	_sprinting = pressed
	_sync_player()

func _sync_player() -> void:
	if is_instance_valid(player):
		var direction := _stick.normalized() if _stick.length() >= DEAD_ZONE else Vector2.ZERO
		player.set_touch_input(direction, _sprinting)

static func format_hint(text: String) -> String:
	return text.replace("E или Enter", PRIMARY_SYMBOL + " или " + SECONDARY_SYMBOL).replace("Нажмите E,", "Нажмите " + PRIMARY_SYMBOL + ",").replace("Нажмите Enter,", "Нажмите " + SECONDARY_SYMBOL + ",")

func _button(text: String, icon: String, color := Color.TRANSPARENT) -> TouchScreenButton:
	var button := TouchScreenButton.new()
	button.name = icon.capitalize() + "TouchButton"
	button.shape = RectangleShape2D.new()
	button.shape_visible = false
	add_child(button)
	var panel := PanelContainer.new()
	panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	panel.tooltip_text = text
	button.add_child(panel)
	var box := HBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.add_theme_constant_override("separation", 8)
	panel.add_child(box)
	if not icon.is_empty():
		var image := TextureRect.new()
		image.mouse_filter = Control.MOUSE_FILTER_IGNORE
		image.texture = load("res://assets/ui/lucide/" + icon + ".svg")
		image.custom_minimum_size = Vector2(22, 22)
		image.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
		image.size_flags_vertical = Control.SIZE_SHRINK_CENTER
		box.add_child(image)
	if not text.is_empty():
		var label := Label.new()
		label.mouse_filter = Control.MOUSE_FILTER_IGNORE
		label.text = text
		label.add_theme_font_size_override("font_size", 14)
		label.add_theme_color_override("font_color", Color.WHITE)
		box.add_child(label)
	var paint := func():
		var style := StyleBoxFlat.new()
		style.bg_color = color.darkened(0.22) if color.a > 0 and button.is_pressed() else color if color.a > 0 else Color("46514b") if button.is_pressed() else Color(0.08, 0.11, 0.10, 0.94)
		style.border_color = color.lightened(0.25) if color.a > 0 else ACCENT if button.is_pressed() else Color("75817b")
		style.set_border_width_all(1)
		style.set_corner_radius_all(4)
		panel.add_theme_stylebox_override("panel", style)
	paint.call()
	button.pressed.connect(paint)
	button.released.connect(paint)
	return button

func _place_button(button: TouchScreenButton, rect: Rect2) -> void:
	button.position = rect.get_center()
	(button.shape as RectangleShape2D).size = rect.size
	var panel := button.get_child(0) as Control
	panel.position = -rect.size / 2.0
	panel.size = rect.size

func _layout() -> void:
	reset_input()
	joystick_center = Vector2(80, size.y - 80)
	_place_button(_action_button, Rect2(size.x - 144, size.y - 132, 52, 52))
	_place_button(_secondary_action_button, Rect2(size.x - 68, size.y - 132, 52, 52))
	_place_button(_sprint_button, Rect2(size.x - 144, size.y - 196, 128, 52))
	_place_button(_pause_button, Rect2(16, 16, 48, 48))
	_place_button(_zoom_in_button, Rect2(18, 80, 44, 44))
	_place_button(_zoom_out_button, Rect2(18, 132, 44, 44))
	_minimap.position = Vector2(80, 16)
	var map_width := minf(176.0, maxf(1.0, (size.x - 108.0) / 2.0)) if size.y > size.x else minf(176.0, maxf(1.0, size.x - 96.0))
	_minimap.size = Vector2(map_width, 80)
	queue_redraw()

func _draw() -> void:
	draw_circle(joystick_center, JOYSTICK_RADIUS + 10, Color(0.08, 0.11, 0.10, 0.78), true, -1, true)
	draw_arc(joystick_center, JOYSTICK_RADIUS + 10, 0, TAU, 64, Color("75817b"), 2, true)
	draw_line(joystick_center + Vector2(-32, 0), joystick_center + Vector2(32, 0), Color(1, 1, 1, 0.12), 2, true)
	draw_line(joystick_center + Vector2(0, -32), joystick_center + Vector2(0, 32), Color(1, 1, 1, 0.12), 2, true)
	draw_circle(joystick_center + _stick, 23, ACCENT if _finger != -1 else Color("c4cec8"), true, -1, true)
