@tool
extends TileMapLayer

signal cells_changed

const CHARGER_SOURCE := 5
const WORKSTATION_SOURCE := 0
const WORKSTATION_TILE := Vector2i(0, 13)
const WORKSTATION_BACK_HEIGHT := 32
const WORKSTATION_ROW_HEIGHT := 8
const PLAYER_FOOT_OFFSET := 25.0
const FootprintSortGeometry = preload("res://footprint_sort_geometry.gd")

var _rebuild_queued := false
var _visuals: Array[Dictionary] = []


func _ready() -> void:
	changed.connect(_queue_rebuild)
	_queue_rebuild()


func _process(_delta: float) -> void:
	if Engine.is_editor_hint():
		return
	var player := get_node_or_null("../Player") as Node2D
	if player == null:
		return
	var player_x := to_local(player.global_position).x
	for entry in _visuals:
		var center: Vector2 = entry.center
		var origin_y := FootprintSortGeometry.front_y(entry.polygons, player_x - center.x, entry.fallback) - PLAYER_FOOT_OFFSET
		if entry.get("charger", false):
			origin_y = _charger_sort_y(center, entry.size, origin_y)
		var visual: Node2D = entry.visual
		if not is_equal_approx(visual.position.y, center.y + origin_y):
			visual.position.y = center.y + origin_y
			var sprite: Sprite2D = entry.sprite
			sprite.position = entry.sprite_offset - Vector2(0, origin_y)


func _update_cells(_coords: Array[Vector2i], _forced_cleanup: bool) -> void:
	_queue_rebuild()
	cells_changed.emit()


func _use_tile_data_runtime_update(coords: Vector2i) -> bool:
	return _needs_footprint_sort(coords)


func _tile_data_runtime_update(_coords: Vector2i, tile_data: TileData) -> void:
	# Keep the tile's collision while generated visuals control its depth.
	var tint := tile_data.modulate
	tint.a = 0.0
	tile_data.modulate = tint


func _queue_rebuild() -> void:
	if not is_inside_tree() or _rebuild_queued:
		return
	_rebuild_queued = true
	call_deferred("_rebuild_visuals")


func _rebuild_visuals() -> void:
	_rebuild_queued = false
	_visuals.clear()
	for child in get_children(true):
		if child.is_in_group("object_footprint_visual"):
			remove_child(child)
			child.queue_free()
	if tile_set == null or not enabled:
		return
	for cell in get_used_cells():
		var source_id := get_cell_source_id(cell)
		if not _needs_footprint_sort(cell):
			continue
		var source := tile_set.get_source(source_id) as TileSetAtlasSource
		var atlas_coords := get_cell_atlas_coords(cell)
		var region := source.get_tile_texture_region(atlas_coords)
		var tile_data := get_cell_tile_data(cell)
		var tile_transform := _cell_transform(cell)
		var polygons: Array[PackedVector2Array] = []
		for polygon_index in tile_data.get_collision_polygons_count(0):
			polygons.append(tile_transform * tile_data.get_collision_polygon_points(0, polygon_index))
		var fallback := float(tile_data.y_sort_origin) + PLAYER_FOOT_OFFSET
		var origin_y := FootprintSortGeometry.front_y(polygons, 0.0, fallback) - PLAYER_FOOT_OFFSET
		var center := map_to_local(cell)
		if source_id == WORKSTATION_SOURCE and atlas_coords == WORKSTATION_TILE:
			var rear_y := FootprintSortGeometry.front_y(polygons, 0.0, origin_y + PLAYER_FOOT_OFFSET) - PLAYER_FOOT_OFFSET
			_add_visual(source.texture, Rect2i(region.position, Vector2i(region.size.x, WORKSTATION_BACK_HEIGHT)), center, region.size, 0, rear_y, tile_data, tile_transform)
			for crop_top in range(WORKSTATION_BACK_HEIGHT, region.size.y, WORKSTATION_ROW_HEIGHT):
				var row_height := mini(WORKSTATION_ROW_HEIGHT, region.size.y - crop_top)
				var row_y := float(crop_top + row_height) - region.size.y / 2.0 - PLAYER_FOOT_OFFSET
				_add_visual(source.texture, Rect2i(region.position + Vector2i(0, crop_top), Vector2i(region.size.x, row_height)), center, region.size, crop_top, row_y, tile_data, tile_transform)
			continue
		if source_id == CHARGER_SOURCE:
			origin_y = _charger_sort_y(center, region.size, origin_y)
		var entry := _add_visual(source.texture, region, center, region.size, 0, origin_y, tile_data, tile_transform)
		entry.merge({"cell": cell, "center": center, "size": region.size, "polygons": polygons, "fallback": fallback, "charger": source_id == CHARGER_SOURCE})
		_visuals.append(entry)


func _add_visual(texture: Texture2D, region: Rect2i, center: Vector2, full_size: Vector2i, crop_top: int, origin_y: float, tile_data: TileData, tile_transform: Transform2D) -> Dictionary:
	var visual := Node2D.new()
	visual.add_to_group("object_footprint_visual", true)
	visual.position = center + Vector2(0, origin_y)
	visual.z_index = tile_data.z_index
	visual.modulate = tile_data.modulate
	add_child(visual, false, Node.INTERNAL_MODE_BACK)
	var sprite := Sprite2D.new()
	sprite.texture = texture
	sprite.centered = false
	sprite.region_enabled = true
	sprite.region_rect = region
	sprite.material = tile_data.material
	sprite.transform = tile_transform
	var sprite_offset := tile_transform * (Vector2(-full_size.x / 2.0, -full_size.y / 2.0 + crop_top) - Vector2(tile_data.texture_origin))
	sprite.position = sprite_offset - Vector2(0, origin_y)
	visual.add_child(sprite, false, Node.INTERNAL_MODE_BACK)
	return {"visual": visual, "sprite": sprite, "sprite_offset": sprite_offset}


func _needs_footprint_sort(coords: Vector2i) -> bool:
	if tile_set == null or tile_set.get_physics_layers_count() == 0:
		return false
	var data := get_cell_tile_data(coords)
	return data != null and data.get_collision_polygons_count(0) > 0


func _cell_transform(coords: Vector2i) -> Transform2D:
	var x_sign := -1.0 if is_cell_flipped_h(coords) else 1.0
	var y_sign := -1.0 if is_cell_flipped_v(coords) else 1.0
	if is_cell_transposed(coords):
		return Transform2D(Vector2(0, y_sign), Vector2(x_sign, 0), Vector2.ZERO)
	return Transform2D(Vector2(x_sign, 0), Vector2(0, y_sign), Vector2.ZERO)


func _charger_sort_y(center: Vector2, size: Vector2i, origin_y: float) -> float:
	var bounds := global_transform * Rect2(center - Vector2(size) / 2.0, size)
	var player := get_node_or_null("../Player") as Node2D
	if player != null and player.has_node("Visuals/Transporter/Sprite") and player.get("move_mode") == PickupVehicle.VehicleMode.TRANSPORTER:
		var driven := player.get_node("Visuals/Transporter/Sprite") as Sprite2D
		if bounds.intersects(driven.global_transform * driven.get_rect()):
			origin_y = minf(origin_y, to_local(player.global_position).y - center.y - 1.0)
	var transporters := get_node_or_null("../TransporterSprites")
	if transporters == null:
		return origin_y
	for child in transporters.get_children():
		var vehicle := child as PickupVehicle
		if vehicle == null or vehicle.vehicle_mode != PickupVehicle.VehicleMode.TRANSPORTER or not vehicle.visible:
			continue
		if not Engine.is_editor_hint() and vehicle.is_carried:
			continue
		if not bounds.intersects(vehicle.global_transform * vehicle.get_rect()):
			continue
		var anchor := vehicle.get_node_or_null("SortVisual") as Node2D
		var depth := vehicle.global_position.y
		if anchor != null:
			depth = anchor.global_position.y
		else:
			var shape := vehicle.get_node("StaticBody2D/CollisionPolygon2D") as CollisionPolygon2D
			depth = -INF
			for point in shape.polygon:
				depth = maxf(depth, shape.to_global(point).y - PLAYER_FOOT_OFFSET)
		# Leave one tile of room for the transport's changing contact-point depth.
		origin_y = minf(origin_y, to_local(Vector2(vehicle.global_position.x, depth)).y - center.y - 32.0)
	return origin_y
