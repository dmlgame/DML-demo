extends "res://assets/npcs/npc_worker.gd"

const FOOT_OFFSET := Vector2(0, 25)
const NAV_STEP := 16.0
const TRAFFIC_CLEARANCE := Vector2(26, 14)
const TRAFFIC_LOOKAHEAD := 0.65

@export var skin: Texture2D = preload("res://assets/npcs/lpc_workers/worker_male_curly.png")
@export var pause_seconds := Vector2(2.5, 7.0)
var destinations: Array[Dictionary] = []
var completed_stops := 0
var travelled := 0.0
var resting := true
var _target_index := -1
var _rest_left := 0.0
var _blocked_elapsed := 0.0
var _blocked_total := 0.0
var _path := PackedVector2Array()
var _path_index := 0
var _grid := AStarGrid2D.new()
var _world: Node2D
var _activity: Node
var _player: CharacterBody2D
var _rng := RandomNumberGenerator.new()
var _animating := false
var _passing_worker: CharacterBody2D
var _passing_point := Vector2.ZERO
var _passing_origin := Vector2.ZERO
var _passing_forward := Vector2.ZERO
var _passing_elapsed := 0.0

func _ready() -> void:
	sprite.texture = skin
	sprite.hframes = 9
	facing = Facing.DOWN
	add_to_group("ambient_worker")
	_rng.randomize()
	_apply_frame()

func configure(world: Node2D, points: Array[Dictionary], initial_delay: float, roaming_area: Node = null) -> void:
	_world = world
	_activity = roaming_area if roaming_area != null else world.get_node("WarehouseActivity")
	_player = world.get_node("YSortActors/Player")
	destinations = points
	_rest_left = _rng.randf_range(pause_seconds.x, pause_seconds.y) + initial_delay
	_grid.cell_size = Vector2.ONE * NAV_STEP
	_grid.offset = Vector2.ONE * NAV_STEP * 0.5
	_grid.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES

func _physics_process(delta: float) -> void:
	if destinations.is_empty():
		return
	if resting:
		_stand()
		_rest_left -= delta
		if _rest_left <= 0:
			_choose_destination()
		return
	var feet := global_position + FOOT_OFFSET
	while _path_index < _path.size() and feet.distance_to(_path[_path_index]) < 2.0:
		_path_index += 1
	if _path_index >= _path.size() and not is_instance_valid(_passing_worker):
		if feet.distance_to(destinations[_target_index].point) < 5.0:
			completed_stops += 1
			var look: Vector2 = destinations[_target_index].look_at - feet
			if look.length() > 1:
				facing = _direction_to_facing(look)
			resting = true
			_rest_left = _rng.randf_range(pause_seconds.x, pause_seconds.y)
			_stand()
		else:
			_wait_and_repath(delta)
		return
	var direction := _route_direction()
	var toward_player := _player.global_position + FOOT_OFFSET - feet
	if toward_player.length() < 40 and toward_player.dot(direction.normalized()) > 0:
		_wait_and_repath(delta)
		return
	direction = _avoid_workers(direction, delta)
	if direction.is_zero_approx():
		_wait_and_repath(delta)
		return
	var previous := global_position
	# Keep a stable four-direction pose on a diagonal segment.
	if absf(absf(direction.x) - absf(direction.y)) > 0.5 or not _facing_matches(direction):
		facing = _direction_to_facing(direction)
	velocity = direction.normalized() * minf(walk_speed, direction.length() / delta)
	if not _activity.can_roam(feet + velocity * delta):
		_wait_and_repath(delta)
		return
	# Do not animate or inherit another body's motion while physically blocked.
	if test_move(global_transform, velocity * delta):
		_wait_and_repath(delta)
		return
	move_and_slide()
	var moved := global_position.distance_to(previous)
	travelled += moved
	if moved > 0.1:
		_blocked_elapsed = 0
		_blocked_total = 0
		_animating = true
		_advance_animation(delta)
	else:
		_wait_and_repath(delta)
	_apply_frame()

func _route_direction() -> Vector2:
	if resting:
		return Vector2.ZERO
	var feet := global_position + FOOT_OFFSET
	for index in range(_path_index, _path.size()):
		if feet.distance_to(_path[index]) >= 2:
			return _path[index] - feet
	return Vector2.ZERO

func _intended_velocity() -> Vector2:
	if resting:
		return Vector2.ZERO
	if is_instance_valid(_passing_worker):
		var offset := _passing_point - global_position - FOOT_OFFSET
		return offset.normalized() * walk_speed if offset.length() >= 2 else Vector2.ZERO
	return _route_direction().normalized() * walk_speed

func _traffic_ahead(other: CharacterBody2D, direction: Vector2) -> bool:
	var offset := other.global_position - global_position
	if offset.length() > (walk_speed + other.walk_speed) * TRAFFIC_LOOKAHEAD + 32:
		return false
	var relative: Vector2 = other._intended_velocity() - direction.normalized() * walk_speed
	if offset.dot(relative) >= 0:
		return false
	# Swept foot rectangles predict a meeting before either actor makes contact.
	var first := 0.0
	var last := TRAFFIC_LOOKAHEAD
	for axis in 2:
		if absf(relative[axis]) < 0.001:
			if absf(offset[axis]) > TRAFFIC_CLEARANCE[axis]:
				return false
		else:
			var enter: float = (-TRAFFIC_CLEARANCE[axis] - offset[axis]) / relative[axis]
			var leave: float = (TRAFFIC_CLEARANCE[axis] - offset[axis]) / relative[axis]
			first = maxf(first, minf(enter, leave))
			last = minf(last, maxf(enter, leave))
			if first > last:
				return false
	return true

func _avoid_workers(direction: Vector2, delta: float) -> Vector2:
	var feet := global_position + FOOT_OFFSET
	if is_instance_valid(_passing_worker):
		_passing_elapsed += delta
		if _passing_elapsed < 3:
			var offset := _passing_point - feet
			if offset.length() >= 2:
				return offset
			var passed := (_passing_worker.global_position + FOOT_OFFSET - _passing_origin).dot(_passing_forward) > 32
			if not _passing_worker.resting and not passed:
				if _traffic_ahead(_passing_worker, Vector2.ZERO):
					var clear_point := _find_passing_point(_passing_worker, _route_direction())
					if clear_point.is_finite():
						_passing_point = clear_point
						return clear_point - feet
				return Vector2.ZERO
		_passing_worker = null
		_blocked_elapsed = 0
		_blocked_total = 0
		_repath()
		return _route_direction()
	var nearest: CharacterBody2D
	var distance := INF
	for other in get_tree().get_nodes_in_group("ambient_worker"):
		if other == self or other.get_world_2d() != get_world_2d() or not _traffic_ahead(other, direction):
			continue
		var separation := global_position.distance_squared_to(other.global_position)
		if separation < distance:
			nearest = other
			distance = separation
	if nearest == null:
		return direction
	# A stable priority avoids both workers choosing the same escape repeatedly.
	if nearest._passing_worker == self:
		return Vector2.ZERO
	if not nearest.resting and get_instance_id() < nearest.get_instance_id():
		if is_instance_valid(nearest._passing_worker) or nearest._find_passing_point(self, nearest._route_direction()).is_finite():
			return Vector2.ZERO
	var point := _find_passing_point(nearest, direction)
	if not point.is_finite():
		return Vector2.ZERO
	_passing_worker = nearest
	_passing_point = point
	_passing_origin = feet
	_passing_forward = nearest._route_direction().normalized()
	_passing_elapsed = 0
	_blocked_elapsed = 0
	_blocked_total = 0
	return point - feet

func _find_passing_point(other: CharacterBody2D, direction: Vector2) -> Vector2:
	var forward: Vector2 = other._route_direction().normalized()
	if forward.is_zero_approx():
		forward = direction.normalized()
	var side := Vector2(-forward.y, forward.x)
	var feet := global_position + FOOT_OFFSET
	var lane_clearance := absf(side.x) * TRAFFIC_CLEARANCE.x + absf(side.y) * TRAFFIC_CLEARANCE.y + 6
	for sign_side in [1, -1]:
		for clearance in [36, 52]:
			for retreat in [0, 16, 32]:
				var point: Vector2 = feet + side * sign_side * clearance - direction.normalized() * retreat
				if absf((point - other.global_position - FOOT_OFFSET).dot(side)) < lane_clearance:
					continue
				if _can_step_to(point):
					return point
	return Vector2.INF

func _can_step_to(point: Vector2) -> bool:
	var feet := global_position + FOOT_OFFSET
	var motion := point - feet
	if test_move(global_transform, motion):
		return false
	var floor_layer := _world.get_node("FloorLayer") as TileMapLayer
	var steps := maxi(1, ceili(motion.length() / 8))
	for step in range(1, steps + 1):
		var ground := feet + motion * float(step) / steps
		if not _activity.can_roam(ground) or floor_layer.get_cell_source_id(floor_layer.local_to_map(floor_layer.to_local(ground))) == -1:
			return false
	return true

func _facing_matches(direction: Vector2) -> bool:
	match facing:
		Facing.TOP: return direction.y < 0
		Facing.DOWN: return direction.y > 0
		Facing.LEFT: return direction.x < 0
		Facing.RIGHT: return direction.x > 0
	return false

func _stand() -> void:
	velocity = Vector2.ZERO
	_animating = false
	_frame_index = 0
	_frame_elapsed = 0
	_apply_frame()

func _apply_frame() -> void:
	if is_instance_valid(sprite):
		# LPC column zero is the standing pose; columns 1-8 are the walk cycle.
		sprite.frame_coords = Vector2i(_frame_index + 1 if _animating else 0, facing)

func _choose_destination() -> void:
	_passing_worker = null
	var feet := global_position + FOOT_OFFSET
	var previous := _target_index
	var candidates: Array[int] = []
	for index in destinations.size():
		if index != previous and feet.distance_to(destinations[index].point) >= 48 and _activity.can_roam(destinations[index].point):
			candidates.append(index)
	for attempt in mini(5, candidates.size()):
		var chosen := _rng.randi_range(0, candidates.size() - 1)
		_target_index = candidates[chosen]
		candidates.remove_at(chosen)
		_repath()
		if not _path.is_empty():
			resting = false
			_blocked_elapsed = 0
			_blocked_total = 0
			return
	_target_index = previous
	resting = true
	_rest_left = _rng.randf_range(1, 3)
	_stand()

func _wait_and_repath(delta: float) -> void:
	_stand()
	if is_instance_valid(_passing_worker):
		return
	_blocked_elapsed += delta
	_blocked_total += delta
	if _blocked_total >= 4:
		_passing_worker = null
		resting = true
		_rest_left = _rng.randf_range(0.5, 1.5)
		return
	if _blocked_elapsed >= 1:
		_blocked_elapsed = 0
		_repath()

func _repath() -> void:
	var feet := global_position + FOOT_OFFSET
	var target: Vector2 = destinations[_target_index].point
	_path.clear()
	_path_index = 0
	if not _activity.can_roam(feet) or not _activity.can_roam(target):
		return
	var bounds := Rect2(feet, Vector2.ZERO).expand(target).grow(160)
	var first := Vector2i((bounds.position / NAV_STEP).floor())
	var last := Vector2i((bounds.end / NAV_STEP).ceil())
	_grid.region = Rect2i(first, last - first + Vector2i.ONE)
	_grid.update()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(24, 14)
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.collision_mask = 1
	query.exclude = [get_rid()]
	var floor_layer := _world.get_node("FloorLayer") as TileMapLayer
	var space := get_world_2d().direct_space_state
	for y in range(_grid.region.position.y, _grid.region.end.y):
		for x in range(_grid.region.position.x, _grid.region.end.x):
			var cell := Vector2i(x, y)
			var point := _grid.get_point_position(cell)
			query.transform = Transform2D(0, point)
			var ground := floor_layer.get_cell_source_id(floor_layer.local_to_map(floor_layer.to_local(point))) != -1
			_grid.set_point_solid(cell, not ground or not _activity.can_roam(point) or not space.intersect_shape(query, 1).is_empty())
	var from := Vector2i((feet / NAV_STEP).floor())
	var to := Vector2i((target / NAV_STEP).floor())
	if not _grid.is_in_boundsv(from) or not _grid.is_in_boundsv(to):
		return
	_grid.set_point_solid(from, false)
	# Connect exact stop positions through a clear neighboring grid cell.
	for offset in [Vector2i.ZERO, Vector2i.DOWN, Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i(-1, 1), Vector2i(1, 1), Vector2i(-1, -1), Vector2i(1, -1), Vector2i(0, 2), Vector2i(-2, 0), Vector2i(2, 0)]:
		var end: Vector2i = to + offset
		if not _grid.is_in_boundsv(end) or _grid.is_point_solid(end):
			continue
		query.transform = Transform2D(0, _grid.get_point_position(end))
		query.motion = target - query.transform.origin
		if space.cast_motion(query)[0] < 1:
			continue
		var route := _grid.get_point_path(from, end)
		if route.is_empty():
			continue
		_path = route
		_path.append(target)
		break
