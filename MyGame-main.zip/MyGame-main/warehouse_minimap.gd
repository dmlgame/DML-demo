extends Control

var player: CharacterBody2D
var display_bounds := Rect2()
var map_rect := Rect2(8, 8, 160, 44)
var marker := Vector2.ZERO
var _world: Node2D
var _zones: Node2D
var _viewport: SubViewport
var _camera: Camera2D
var _caption: Label
var _elapsed := 0.0

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	clip_contents = true
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_viewport = SubViewport.new()
	_viewport.disable_3d = true
	_viewport.gui_disable_input = true
	_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
	add_child(_viewport)
	_camera = Camera2D.new()
	_camera.position_smoothing_enabled = false
	_viewport.add_child(_camera)
	_caption = Label.new()
	_caption.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_caption.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_caption.add_theme_font_size_override("font_size", 12)
	_caption.add_theme_color_override("font_color", Color("f2cc45"))
	add_child(_caption)
	resized.connect(_resize_map)
	_resize_map()

func bind_player(actor: CharacterBody2D) -> void:
	player = actor
	_world = actor.get_parent().get_parent() if is_instance_valid(actor) else null
	_zones = _world.get_node("BlockNotifications") if is_instance_valid(_world) else null
	_viewport.world_2d = _world.get_world_2d() if is_instance_valid(_world) else World2D.new()
	if is_instance_valid(_world):
		_update_snapshot()
	else:
		_viewport.render_target_update_mode = SubViewport.UPDATE_DISABLED
		display_bounds = Rect2()
	queue_redraw()

func _resize_map() -> void:
	map_rect = Rect2(8, 8, maxf(1.0, size.x - 16.0), 44)
	_viewport.size = Vector2i(map_rect.size * 2.0)
	_caption.position = Vector2(8, 55)
	_caption.size = Vector2(map_rect.size.x, 18)
	if is_instance_valid(_world):
		_update_snapshot()
	queue_redraw()

func _update_snapshot() -> void:
	var bounds: Rect2 = _zones.warehouse_rect.grow(64.0)
	var scale_factor := minf(_viewport.size.x / bounds.size.x, _viewport.size.y / bounds.size.y)
	_camera.position = bounds.get_center()
	_camera.zoom = Vector2.ONE * scale_factor
	_camera.make_current()
	display_bounds = Rect2(bounds.get_center() - Vector2(_viewport.size) / scale_factor / 2.0, Vector2(_viewport.size) / scale_factor)
	# Keep a single scene snapshot; only the small markers redraw while playing.
	_viewport.render_target_update_mode = SubViewport.UPDATE_ONCE
	_update_markers()

func _process(delta: float) -> void:
	if not is_visible_in_tree() or not is_instance_valid(player):
		return
	_elapsed += delta
	if _elapsed >= 0.1:
		_elapsed = 0.0
		_update_markers()

func world_to_map(point: Vector2) -> Vector2:
	return map_rect.position + (point - display_bounds.position) / display_bounds.size * map_rect.size

func _update_markers() -> void:
	marker = world_to_map(player.global_position + Vector2(0, 25)).clamp(map_rect.position, map_rect.end)
	_caption.text = _zones.get_zone_name(player.global_position + Vector2(0, 25))
	queue_redraw()

func _draw() -> void:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.04, 0.06, 0.05, 0.95)
	style.border_color = Color("75817b")
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	draw_style_box(style, Rect2(Vector2.ZERO, size))
	if not display_bounds.has_area() or not is_instance_valid(player):
		return
	draw_texture_rect(_viewport.get_texture(), map_rect, false)
	var camera := player.get_node("Camera2D") as Camera2D
	var extent := player.get_viewport_rect().size / camera.zoom
	var visible_rect := Rect2(camera.get_screen_center_position() - extent / 2.0, extent)
	var frame := Rect2(world_to_map(visible_rect.position), visible_rect.size / display_bounds.size * map_rect.size).intersection(map_rect)
	if frame.has_area():
		draw_rect(frame, Color(1, 1, 1, 0.7), false, 1)
	if _world.has_node("DemoTasks"):
		var demo: Node = _world.get_node("DemoTasks")
		if demo.hint_enabled and demo._route.visible:
			var points := PackedVector2Array()
			for point in demo._route.points:
				points.append(world_to_map(point).clamp(map_rect.position, map_rect.end))
			if points.size() >= 2:
				draw_polyline(points, Color("3b8ce8"), 1.5, true)
				draw_circle(points[-1], 2.5, Color("3b8ce8"), true, -1, true)
	draw_circle(marker, 4, Color("111917"), true, -1, true)
	draw_circle(marker, 2.5, Color("f2cc45"), true, -1, true)
