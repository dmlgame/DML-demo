extends Node

const TITLE := "Грузовой лифт, лестница на мезонин"
const OPEN_ACTION := "Нажмите E, чтобы открыть лифт"
const CLOSE_ACTION := "Нажмите E, чтобы закрыть лифт"
const FLOOR_ACTION := "Нажмите Enter, чтобы подняться на нужный вам этаж мезонина"
const LOCKED_NOTICE := "Данный этаж временно недоступен, ведутся строительные работы!"
const OPEN_TEXTURE := preload("res://assets/objects/mezzanine_lift/freight_lift_ground_floor_open.png")
const CLOSED_TEXTURE := preload("res://assets/objects/mezzanine_lift/freight_lift_ground_floor.png")
const LOCK_ICON := preload("res://assets/ui/lucide/lock-keyhole.svg")
const CLOSE_ICON := preload("res://assets/ui/lucide/x.svg")
const FootprintSortGeometry = preload("res://footprint_sort_geometry.gd")
const PLAYER_FOOT_OFFSET := Vector2(0, 25)

@export var lift_names: Array[StringName] = [
	&"FreightLiftGroundFloor", &"FreightLiftGroundFloor2", &"FreightLiftGroundFloor3",
	&"FreightLiftGroundFloor4", &"FreightLiftGroundFloor5", &"FreightLiftGroundFloor6",
]
@export_range(16, 128, 1) var proximity := 64.0

@onready var sprites: Node2D = $"../YSortActors/MezzanineLayer/MezzanineAccessSprites"
@onready var player: CharacterBody2D = $"../YSortActors/Player"

var _lifts: Array[Dictionary] = []
var _busy := false
var _transition_lift: Dictionary = {}
var _selected: Dictionary = {}
var _transition: Tween
var _transition_layer: CanvasLayer
var _shade: ColorRect
var _picker_layer: CanvasLayer
var _picker_root: ColorRect
var _menu: PanelContainer
var _locked_hint: PanelContainer
var _floor_buttons: Array[Button] = []
var _close_button: Button

func _ready() -> void:
	for lift_name in lift_names:
		var sprite := sprites.get_node_or_null(NodePath(lift_name)) as Sprite2D
		if sprite == null:
			push_error("Block 2 freight lift is missing: " + str(lift_name))
			continue
		var shape := sprite.get_node("StaticBody2D/CollisionPolygon2D") as CollisionPolygon2D
		var closed_texture := sprite.texture if sprite.texture != OPEN_TEXTURE else CLOSED_TEXTURE
		_lifts.append({"sprite": sprite, "shape": shape, "closed_texture": closed_texture, "is_open": sprite.texture == OPEN_TEXTURE, "dismissed": false})
	_create_transition_layer()
	_create_floor_picker()
	get_viewport().size_changed.connect(_layout_picker)
	player.register_lift_interaction(self)

func _exit_tree() -> void:
	if _transition != null and _transition.is_valid():
		_transition.kill()
	if is_instance_valid(player):
		player.unregister_lift_interaction(self)
		if _busy or not _selected.is_empty():
			player.set_interaction_locked(false)

func _process(_delta: float) -> void:
	for lift in _lifts:
		if _approach_distance(lift, player) == INF:
			lift.dismissed = false
	if not _selected.is_empty() and _approach_distance(_selected, player) == INF:
		_close_picker()

func _input(event: InputEvent) -> void:
	if not _selected.is_empty() and event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_ESCAPE:
		_close_picker()
		get_viewport().set_input_as_handled()

func _approach_distance(lift: Dictionary, actor: Node2D) -> float:
	if not is_instance_valid(actor) or not actor.is_visible_in_tree() or not is_instance_valid(lift.sprite) or not lift.sprite.is_visible_in_tree():
		return INF
	var shape: CollisionPolygon2D = lift.shape
	var feet := actor.global_position + PLAYER_FOOT_OFFSET
	var local_feet := shape.to_local(feet)
	var left := INF
	var right := -INF
	var bottom := -INF
	for point in shape.polygon:
		left = minf(left, point.x)
		right = maxf(right, point.x)
		bottom = maxf(bottom, point.y)
	var polygons: Array[PackedVector2Array] = [shape.polygon]
	var front := FootprintSortGeometry.front_y(polygons, local_feet.x, bottom)
	var contact := shape.to_global(Vector2(clampf(local_feet.x, left, right), front))
	var distance := feet.distance_to(contact)
	return distance if distance <= proximity and feet.y >= contact.y - 6.0 else INF

func _nearest_lift(actor: Node2D) -> Dictionary:
	var nearest: Dictionary = {}
	var nearest_distance := INF
	for lift in _lifts:
		var distance := _approach_distance(lift, actor)
		if distance < nearest_distance:
			nearest = lift
			nearest_distance = distance
	return nearest

func get_interaction_text(actor: Node2D) -> String:
	if _busy or not _selected.is_empty():
		return ""
	var lift := _nearest_lift(actor)
	if lift.is_empty() or lift.dismissed:
		return ""
	var action := CLOSE_ACTION if lift.is_open else OPEN_ACTION
	var touch := get_tree().get_first_node_in_group("touch_controls")
	var mobile: bool = (touch != null and touch.available) or DisplayServer.is_touchscreen_available()
	return TITLE + "\n" + action + "\n" + ("Нажмите Enter, чтобы выбрать этаж" if mobile else FLOOR_ACTION)

func try_interact(actor: Node2D, event: InputEvent) -> bool:
	if _busy or not _selected.is_empty():
		return false
	var lift := _nearest_lift(actor)
	if lift.is_empty():
		return false
	if not lift.dismissed and event is InputEventAction:
		if event.is_action_pressed("interact_secondary"):
			_show_picker(lift)
		elif event.is_action_pressed("interact"):
			_start_transition(lift)
		return true
	# Keep lift input from also taking or dropping a nearby vehicle.
	if lift.dismissed or not event is InputEventKey:
		return true
	var keycode: Key = event.physical_keycode if event.physical_keycode != 0 else event.keycode
	if keycode == KEY_E:
		_start_transition(lift)
	elif keycode == KEY_ENTER or keycode == KEY_KP_ENTER:
		_show_picker(lift)
	return true

func _start_transition(lift: Dictionary) -> void:
	_busy = true
	_transition_lift = lift
	player.set_interaction_locked(true)
	_shade.color.a = 0.0
	_transition_layer.visible = true
	_transition = create_tween()
	_transition.tween_property(_shade, "color:a", 1.0, 0.12)
	_transition.tween_callback(_swap_lift_texture)
	_transition.tween_interval(0.04)
	_transition.tween_property(_shade, "color:a", 0.0, 0.12)
	_transition.tween_callback(_finish_transition)

func _swap_lift_texture() -> void:
	# Reuse the node so its scale, position, collision and depth stay unchanged.
	_transition_lift.is_open = not _transition_lift.is_open
	_transition_lift.sprite.texture = OPEN_TEXTURE if _transition_lift.is_open else _transition_lift.closed_texture

func _finish_transition() -> void:
	_transition_layer.visible = false
	_transition = null
	_transition_lift = {}
	_busy = false
	player.set_interaction_locked(false)

func get_save_state() -> Dictionary:
	var result := {}
	for lift in _lifts:
		result[str(lift.sprite.name)] = lift.is_open
	return result

func restore_save_state(state: Dictionary) -> void:
	for lift in _lifts:
		lift.is_open = state.get(str(lift.sprite.name), false)
		lift.dismissed = false
		lift.sprite.texture = OPEN_TEXTURE if lift.is_open else lift.closed_texture

func _show_picker(lift: Dictionary) -> void:
	_selected = lift
	_locked_hint.visible = false
	_picker_layer.visible = true
	_layout_picker()
	player.set_interaction_locked(true)
	_floor_buttons[0].grab_focus()

func _close_picker() -> void:
	_picker_layer.visible = false
	_locked_hint.visible = false
	_selected = {}
	if is_instance_valid(player):
		player.set_interaction_locked(false)

func _choose_floor(floor_number: int) -> void:
	if floor_number != 1 or _selected.is_empty():
		return
	_selected.dismissed = true
	_close_picker()

func _show_locked_hint() -> void:
	if not _selected.is_empty():
		_locked_hint.visible = true

func _hide_locked_hint() -> void:
	_locked_hint.visible = false

func _on_backdrop_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT and event.pressed:
		_close_picker()
		_picker_root.accept_event()

func _create_transition_layer() -> void:
	_transition_layer = CanvasLayer.new()
	_transition_layer.name = "LiftTransition"
	_transition_layer.layer = 100
	_transition_layer.visible = false
	add_child(_transition_layer, false, Node.INTERNAL_MODE_FRONT)
	_shade = ColorRect.new()
	_shade.color = Color(0, 0, 0, 0)
	_shade.mouse_filter = Control.MOUSE_FILTER_STOP
	_transition_layer.add_child(_shade)
	_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _create_floor_picker() -> void:
	_picker_layer = CanvasLayer.new()
	_picker_layer.name = "MezzanineFloorPicker"
	_picker_layer.layer = 90
	_picker_layer.visible = false
	add_child(_picker_layer, false, Node.INTERNAL_MODE_FRONT)
	_picker_root = ColorRect.new()
	_picker_root.color = Color(0, 0, 0, 0.3)
	_picker_root.gui_input.connect(_on_backdrop_input)
	_picker_layer.add_child(_picker_root)
	_picker_root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var theme := Theme.new()
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial"])
	font.font_weight = 600
	font.oversampling = 1.0
	theme.default_font = font
	theme.default_font_size = 16
	_picker_root.theme = theme
	_picker_root.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_menu = PanelContainer.new()
	_menu.name = "FloorMenu"
	_menu.mouse_filter = Control.MOUSE_FILTER_STOP
	_menu.add_theme_stylebox_override("panel", _panel_style())
	_picker_root.add_child(_menu)
	var content := VBoxContainer.new()
	content.add_theme_constant_override("separation", 12)
	_menu.add_child(content)
	var header := HBoxContainer.new()
	content.add_child(header)
	var title := Label.new()
	title.text = "Этаж мезонина"
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	header.add_child(title)
	_close_button = Button.new()
	_close_button.name = "CloseFloorMenu"
	_close_button.icon = CLOSE_ICON
	_close_button.expand_icon = true
	_close_button.add_theme_constant_override("icon_max_width", 16)
	_close_button.custom_minimum_size = Vector2(28, 28)
	_close_button.tooltip_text = "Закрыть"
	_close_button.flat = true
	_close_button.pressed.connect(_close_picker)
	header.add_child(_close_button)
	var floors := HBoxContainer.new()
	floors.add_theme_constant_override("separation", 6)
	content.add_child(floors)
	for floor_number in range(1, 6):
		var button := Button.new()
		button.name = "Floor" + str(floor_number)
		button.text = str(floor_number)
		button.custom_minimum_size = Vector2(44, 44)
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.add_theme_stylebox_override("normal", _button_style(Color(0.96, 0.8, 0.27)))
		button.add_theme_stylebox_override("hover", _button_style(Color(1, 0.88, 0.44)))
		button.add_theme_stylebox_override("pressed", _button_style(Color(0.84, 0.67, 0.18)))
		button.add_theme_stylebox_override("disabled", _button_style(Color(0.13, 0.145, 0.15)))
		button.add_theme_color_override("font_color", Color(0.06, 0.07, 0.075))
		button.add_theme_color_override("font_hover_color", Color(0.06, 0.07, 0.075))
		button.add_theme_color_override("font_pressed_color", Color(0.06, 0.07, 0.075))
		button.add_theme_color_override("font_focus_color", Color(0.06, 0.07, 0.075))
		button.add_theme_color_override("font_disabled_color", Color(0.48, 0.5, 0.51))
		if floor_number > 1:
			button.disabled = true
			button.icon = LOCK_ICON
			button.expand_icon = true
			button.icon_alignment = HORIZONTAL_ALIGNMENT_RIGHT
			button.add_theme_constant_override("icon_max_width", 12)
			button.add_theme_constant_override("h_separation", 4)
			button.add_theme_color_override("icon_disabled_color", Color(0.48, 0.5, 0.51))
			button.mouse_entered.connect(_show_locked_hint)
			button.mouse_exited.connect(_hide_locked_hint)
		else:
			button.pressed.connect(_choose_floor.bind(floor_number))
		floors.add_child(button)
		_floor_buttons.append(button)
	_locked_hint = PanelContainer.new()
	_locked_hint.name = "LockedFloorHint"
	_locked_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_locked_hint.size = Vector2(300, 80)
	_locked_hint.add_theme_stylebox_override("panel", _panel_style())
	_locked_hint.visible = false
	_picker_root.add_child(_locked_hint)
	var notice := Label.new()
	notice.custom_minimum_size.x = 276
	notice.size = Vector2(276, 56)
	notice.text = LOCKED_NOTICE
	notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	notice.mouse_filter = Control.MOUSE_FILTER_IGNORE
	notice.add_theme_font_size_override("font_size", 14)
	_locked_hint.add_child(notice)

func _layout_picker() -> void:
	var viewport_size := get_viewport().get_visible_rect().size
	var width := minf(300.0, viewport_size.x - 32.0)
	var origin := Vector2((viewport_size.x - width) / 2.0, maxf(16, (viewport_size.y - 208) / 2.0)).floor()
	_menu.position = origin
	_menu.size = Vector2(width, 112)
	# Reserve tooltip space so hovering cannot shift the floor buttons.
	_locked_hint.position = origin + Vector2(0, 120)
	(_locked_hint.get_child(0) as Label).custom_minimum_size.x = maxf(1, width - 24)
	_locked_hint.size = Vector2(width, 80)

func _panel_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.03, 0.035, 0.04, 0.98)
	style.border_color = Color(0.31, 0.34, 0.35)
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	return style

func _button_style(color: Color) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.set_corner_radius_all(3)
	style.content_margin_left = 5
	style.content_margin_right = 5
	return style
