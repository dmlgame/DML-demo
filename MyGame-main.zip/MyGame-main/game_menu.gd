extends Control

signal new_game_requested
signal load_requested(slot: String)
signal save_requested(slot: String)
signal resume_requested
signal main_menu_requested
signal quit_requested

const Background = preload("res://menu_warehouse_background.gd")
const BrandLogo = preload("res://menu_brand_logo.gd")
const ACCENT := Color("f2cc45")
const RED := Color("ec4b43")

var store: WarehouseSaveStore
var is_pause := false
var background: Control
var content: VBoxContainer
var scroller: ScrollContainer
var shade: Control
var status: Label
var _dialog: PanelContainer
var _modal: ColorRect
var _confirm_callback: Callable
var _page := "main"

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial"])
	font.font_weight = 600
	theme = Theme.new()
	theme.default_font = font
	theme.default_font_size = 18
	background = Background.new()
	add_child(background)
	background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade = Control.new()
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.draw.connect(_draw_shade)
	add_child(shade)
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	scroller = ScrollContainer.new()
	scroller.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	scroller.follow_focus = true
	add_child(scroller)
	content = VBoxContainer.new()
	content.add_theme_constant_override("separation", 8)
	content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroller.add_child(content)
	status = Label.new()
	status.name = "MenuStatus"
	status.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status.add_theme_font_size_override("font_size", 14)
	add_child(status)
	_modal = ColorRect.new()
	_modal.color = Color(0, 0, 0, 0.72)
	add_child(_modal)
	_modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal.hide()
	resized.connect(_layout)
	if store == null:
		store = WarehouseSaveStore.new()
	show_main()

func show_main(paused := false) -> void:
	is_pause = paused
	_page = "main"
	visible = true
	_modal.hide()
	_clear_content()
	_title()
	if is_pause:
		_button("Продолжить игру", "play", func(): resume_requested.emit(), true)
		_button("Сохранить игру", "save", _show_slots.bind(true))
	else:
		var latest := store.latest_slot()
		var button := _button("Продолжить игру", "play", _request_load.bind(latest), true)
		button.disabled = latest.is_empty()
		if latest.is_empty():
			button.tooltip_text = "Пока нет сохранений"
		_button("Новая игра", "rotate-ccw", _new_game, latest.is_empty())
	_button("Загрузить игру", "folder-open", _show_slots.bind(false))
	if is_pause:
		_button("В главное меню", "arrow-left", func(): main_menu_requested.emit())
	_button("Выйти из игры", "log-out", func(): quit_requested.emit())
	_layout()
	_focus_first()

func set_status(message: String, error := false) -> void:
	status.text = message
	status.add_theme_color_override("font_color", RED if error else Color("d0dbcf"))
	_layout()

func _new_game() -> void:
	if not store.read_slot("autosave").is_empty():
		_confirm("Начать новую игру?", "Автосохранение будет заменено. Ручные сохранения останутся.", func(): new_game_requested.emit())
	else:
		new_game_requested.emit()

func _show_slots(saving: bool) -> void:
	_page = "save" if saving else "load"
	_clear_content()
	_heading("Сохранить игру" if saving else "Загрузить игру")
	for entry in store.list_slots():
		if saving and entry.id == "autosave":
			continue
		var title: String = "Автосохранение" if entry.id == "autosave" else "Слот " + entry.id.trim_prefix("slot_")
		var detail: String = ("Повреждённая запись" if entry.exists else "Пусто") if entry.data.is_empty() else entry.data.saved_at.replace("T", " · ")
		if entry.recovered:
			detail += "\nРезервная копия"
		var slot: String = entry.id
		var callback := _request_save.bind(slot, not entry.data.is_empty()) if saving else _request_load.bind(slot)
		var row: HBoxContainer
		if not saving:
			row = HBoxContainer.new()
			row.name = "Record_" + slot
			row.add_theme_constant_override("separation", 8)
			content.add_child(row)
		var button := _button(title + "\n" + detail, "save" if saving else "folder-open", callback, false, row)
		button.name = "Slot_" + slot
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.custom_minimum_size.y = 98 if entry.recovered else 76
		button.add_theme_font_size_override("font_size", 16)
		button.disabled = not saving and entry.data.is_empty()
		if not saving:
			var delete := _button("", "trash", _request_delete.bind(slot, title), false, row)
			delete.name = "Delete_" + slot
			delete.tooltip_text = "Удалить запись: " + title
			delete.custom_minimum_size.x = 52
			delete.disabled = not entry.exists
			_style_delete(delete)
	_button("Назад", "arrow-left", func(): show_main(is_pause))
	_layout()
	_focus_first()

func _request_delete(slot: String, title: String) -> void:
	_confirm("Удалить запись?", title + " и его резервная копия будут удалены. Отменить удаление нельзя.", func():
		if store.delete_slot(slot):
			_show_slots(false)
			set_status("Запись удалена: " + title)
		else:
			set_status(store.last_error, true)
			_focus_first(), "Удалить запись", "trash")

func _request_save(slot: String, occupied: bool) -> void:
	if occupied:
		_confirm("Перезаписать сохранение?", "Предыдущая версия останется в резервной копии.", func(): save_requested.emit(slot))
	else:
		save_requested.emit(slot)

func _request_load(slot: String) -> void:
	if is_pause:
		_confirm("Загрузить сохранение?", "Текущая игра будет заменена выбранным сохранением.", func(): load_requested.emit(slot))
	else:
		load_requested.emit(slot)

func _confirm(title: String, message: String, callback: Callable, action := "Подтвердить", icon := "check") -> void:
	_confirm_callback = callback
	if is_instance_valid(_dialog):
		_dialog.free()
	_dialog = PanelContainer.new()
	_dialog.add_theme_stylebox_override("panel", _style(Color("202725"), Color("55605a"), 18))
	_modal.add_child(_dialog)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 14)
	_dialog.add_child(box)
	box.add_child(_label(title, 22))
	var notice := _label(message, 16)
	notice.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	notice.custom_minimum_size.x = minf(350, size.x - 76)
	box.add_child(notice)
	var confirm := _button(action, icon, func():
		_modal.hide()
		_confirm_callback.call(), true, box)
	if icon == "trash":
		_style_delete(confirm, true)
	var cancel := _button("Отмена", "x", func():
		_modal.hide()
		_focus_first(), false, box)
	_modal.show()
	_layout()
	cancel.grab_focus()

func _style_delete(button: Button, filled := false) -> void:
	for key in ["font_color", "font_focus_color", "icon_normal_color", "icon_focus_color"]:
		button.add_theme_color_override(key, Color.WHITE if filled else RED)
	for key in ["font_hover_color", "font_pressed_color", "icon_hover_color", "icon_pressed_color"]:
		button.add_theme_color_override(key, Color.WHITE)
	if filled:
		button.add_theme_stylebox_override("normal", _style(RED))
	button.add_theme_stylebox_override("hover", _style(Color("f2675e") if filled else RED))
	button.add_theme_stylebox_override("pressed", _style(Color("b83935")))
	button.add_theme_stylebox_override("focus", _style(Color.TRANSPARENT, RED))

func _title() -> void:
	var logo := BrandLogo.new()
	logo.compact = is_pause
	content.add_child(logo)
	if is_pause:
		var subtitle := _label("Игра приостановлена", 22)
		subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		content.add_child(subtitle)
	var space := Control.new()
	space.custom_minimum_size.y = 10
	content.add_child(space)

func _heading(text: String) -> void:
	content.add_child(_label("DML", 32))
	content.add_child(_label(text, 26))
	var spacer := Control.new()
	spacer.custom_minimum_size.y = 16
	content.add_child(spacer)

func _button(text: String, icon: String, callback: Callable, primary := false, target: Container = null) -> Button:
	var button := Button.new()
	button.text = text
	button.alignment = HORIZONTAL_ALIGNMENT_LEFT
	button.custom_minimum_size = Vector2(0, 50)
	button.clip_text = true
	button.add_theme_constant_override("h_separation", 14)
	if not icon.is_empty():
		button.icon = load("res://assets/ui/lucide/" + icon + ".svg")
		button.expand_icon = true
		button.add_theme_constant_override("icon_max_width", 20)
	var ink := Color("202725") if primary else Color("eef2ed")
	for key in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color", "icon_normal_color", "icon_hover_color", "icon_pressed_color", "icon_focus_color"]:
		button.add_theme_color_override(key, ink)
	button.add_theme_color_override("font_disabled_color", Color("929e9b"))
	button.add_theme_color_override("icon_disabled_color", Color("929e9b"))
	var secondary := Color(0.035, 0.055, 0.05, 0.8)
	button.add_theme_stylebox_override("normal", _style(ACCENT if primary else secondary, Color.TRANSPARENT if primary else Color(0.7, 0.75, 0.7, 0.18)))
	button.add_theme_stylebox_override("hover", _style(Color("ffe37d") if primary else Color(0.35, 0.4, 0.36, 0.85), ACCENT))
	button.add_theme_stylebox_override("pressed", _style(Color("d7b333") if primary else Color(0.45, 0.5, 0.46, 0.35)))
	button.add_theme_stylebox_override("disabled", _style(Color(0.04, 0.06, 0.05, 0.65)))
	button.add_theme_stylebox_override("focus", _style(Color.TRANSPARENT, ACCENT))
	button.pressed.connect(callback)
	(content if target == null else target).add_child(button)
	return button

func _label(text: String, font_size: int) -> Label:
	var label := Label.new()
	label.text = text
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", Color("edf2ed"))
	return label

func _style(color: Color, border := Color.TRANSPARENT, padding := 14) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(2 if border.a > 0 else 0)
	style.set_corner_radius_all(3)
	style.content_margin_left = padding
	style.content_margin_right = padding
	style.content_margin_top = 8
	style.content_margin_bottom = 8
	return style

func _clear_content() -> void:
	for child in content.get_children():
		content.remove_child(child)
		child.queue_free()
	status.text = ""
	scroller.scroll_vertical = 0

func _layout() -> void:
	background.visible = not is_pause
	var width := minf(360, size.x - 48)
	var left := maxf(24, (size.x - width) / 2)
	var compact_touch := DisplayServer.is_touchscreen_available() and size.y < 600
	content.add_theme_constant_override("separation", 6 if compact_touch else 8)
	for child in content.get_children():
		if child is BrandLogo:
			child.compact = is_pause or compact_touch
			child.custom_minimum_size.y = 64 if compact_touch else 112 if is_pause else 214
			child.queue_redraw()
		elif child.get_class() == "Control":
			child.custom_minimum_size.y = 4 if compact_touch else 10
	var top := 40.0 if is_pause or _page != "main" else (28.0 if size.y < 700 else 58.0)
	if compact_touch:
		top = 16.0
	content.custom_minimum_size.x = width - 14
	scroller.position = Vector2(left, top)
	scroller.size = Vector2(width, maxf(100, size.y - top - 78))
	if _page == "load":
		for row in content.get_children():
			if row is HBoxContainer:
				var slot_button: Button = row.get_child(0)
				slot_button.add_theme_font_size_override("font_size", 14 if width < 320 else 16)
				slot_button.icon = null if width < 320 else load("res://assets/ui/lucide/folder-open.svg")
	status.position = Vector2(left, size.y - 62)
	status.size = Vector2(width, 54)
	shade.queue_redraw()
	if is_instance_valid(_dialog):
		_dialog.size = Vector2(minf(410, size.x - 32), 0)
		_dialog.position = ((size - _dialog.size) * 0.5).floor()

func _draw_shade() -> void:
	if is_pause:
		shade.draw_rect(Rect2(Vector2.ZERO, size), Color(0.015, 0.025, 0.02, 0.87))
	else:
		shade.draw_rect(Rect2(Vector2.ZERO, size), Color(0.015, 0.025, 0.02, 0.48))

func _focus_first() -> void:
	for child in content.find_children("*", "Button", true, false):
		if not child.disabled:
			child.grab_focus()
			break

func handle_escape() -> void:
	if _modal.visible:
		_modal.hide()
		_focus_first()
	elif _page != "main":
		show_main(is_pause)
	elif is_pause:
		resume_requested.emit()
