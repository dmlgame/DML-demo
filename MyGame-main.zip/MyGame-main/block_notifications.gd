extends Node2D

const PLAYER_FOOT_OFFSET := Vector2(0, 25)
const BLOCK_NAMES := {
	1: "Первый блок (строительные работы)",
	2: "Второй блок",
	3: "Третий блок",
}

@export var player_path := NodePath("../YSortActors/Player")
@export_range(1, 6, 0.1) var notification_duration := 2.8

@onready var player: CharacterBody2D = get_node(player_path)

var current_block := 0
var warehouse_rect := Rect2()
var mezzanine_rect := Rect2()
var current_zone := ""
var _passages: Array[Area2D] = []
var _previous_feet := Vector2.ZERO
var _tracking_started := false
var _banner: RichTextLabel
var _remaining := 0.0

func _ready() -> void:
	var floor_layer := get_node("../FloorLayer") as TileMapLayer
	warehouse_rect = _layer_rect(floor_layer)
	var mezzanine := get_node("../YSortActors/MezzanineLayer") as TileMapLayer
	var shelves := _layer_rect(mezzanine)
	for lift in mezzanine.get_node("MezzanineAccessSprites").get_children():
		if lift is Sprite2D:
			shelves = shelves.merge(lift.get_global_transform() * lift.get_rect())
	mezzanine_rect = Rect2(warehouse_rect.position.x, shelves.position.y - 32.0, warehouse_rect.size.x, shelves.size.y + 64.0)
	for child in get_children():
		if child is Area2D:
			_passages.append(child)
	current_block = get_block_at(player.global_position + PLAYER_FOOT_OFFSET)
	_create_banner()

func _physics_process(_delta: float) -> void:
	var feet := player.global_position + PLAYER_FOOT_OFFSET
	if not _tracking_started:
		# The first tick observes the restored position rather than the scene's spawn point.
		current_block = get_block_at(feet)
		current_zone = get_zone_name(feet)
		_previous_feet = feet
		_tracking_started = true
		return
	var destination := 0
	var latest_crossing := -1.0
	for passage in _passages:
		var before := passage.to_local(_previous_feet)
		var after := passage.to_local(feet)
		var eastward := before.x < 0.0 and after.x >= 0.0
		var westward := before.x >= 0.0 and after.x < 0.0
		if not eastward and not westward:
			continue
		var fraction := -before.x / (after.x - before.x)
		var crossing := before.lerp(after, fraction)
		var shape := passage.get_node("CollisionShape2D") as CollisionShape2D
		if shape.disabled or not shape.shape.get_rect().has_point(shape.to_local(passage.to_global(crossing))):
			continue
		if fraction > latest_crossing:
			latest_crossing = fraction
			destination = int(passage.get_meta("east_block" if eastward else "west_block"))
	var zone := get_zone_name(feet)
	if zone != current_zone and (zone == "Мезонин" or current_zone == "Мезонин"):
		_show_title("Мезонин" if zone == "Мезонин" else BLOCK_NAMES[get_block_at(feet)])
	elif destination != 0 and destination != current_block:
		_show_notification(destination)
	current_block = get_block_at(feet)
	current_zone = zone
	_previous_feet = feet

func _process(delta: float) -> void:
	if _remaining <= 0.0:
		return
	_remaining = maxf(0.0, _remaining - delta)
	if _remaining <= 0.0:
		_banner.hide()
		return
	var elapsed := notification_duration - _remaining
	_banner.modulate.a = minf(clampf(elapsed / 0.15, 0.0, 1.0), clampf(_remaining / 0.35, 0.0, 1.0))
	_layout_banner()

func get_block_at(feet: Vector2) -> int:
	var block_number := 1
	for passage in _passages:
		if passage.to_local(feet).x >= 0.0:
			block_number = maxi(block_number, int(passage.get_meta("east_block")))
	return block_number

func _show_notification(block_number: int) -> void:
	_show_title(BLOCK_NAMES[block_number])

func get_zone_name(feet: Vector2) -> String:
	return "Мезонин" if mezzanine_rect.has_point(feet) else "Блок %d" % get_block_at(feet)

static func _layer_rect(layer: TileMapLayer) -> Rect2:
	var cells := layer.get_used_rect()
	var tile_size := Vector2(layer.tile_set.tile_size)
	return layer.get_global_transform() * Rect2(Vector2(cells.position) * tile_size, Vector2(cells.size) * tile_size)

func _show_title(title: String) -> void:
	_layout_banner()
	_banner.text = title
	_banner.reset_size()
	_remaining = notification_duration
	_banner.modulate.a = 0.0
	_banner.show()
	_layout_banner()

func _create_banner() -> void:
	var hud := CanvasLayer.new()
	hud.name = "BlockHUD"
	hud.layer = 30
	add_child(hud, false, Node.INTERNAL_MODE_FRONT)
	_banner = RichTextLabel.new()
	_banner.name = "BlockTitle"
	_banner.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_banner.focus_mode = Control.FOCUS_NONE
	_banner.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_banner.custom_minimum_size = Vector2(360, 0)
	_banner.fit_content = true
	_banner.scroll_active = false
	_banner.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial"])
	font.font_weight = 600
	font.oversampling = 1.0
	_banner.add_theme_font_override("normal_font", font)
	_banner.add_theme_font_size_override("normal_font_size", 18)
	var background := StyleBoxFlat.new()
	background.bg_color = Color(0.03, 0.035, 0.04, 0.9)
	background.content_margin_left = 12
	background.content_margin_right = 12
	background.content_margin_top = 8
	background.content_margin_bottom = 8
	_banner.add_theme_stylebox_override("normal", background)
	_banner.hide()
	hud.add_child(_banner)
	_layout_banner()

func _layout_banner() -> void:
	var touch := get_tree().get_first_node_in_group("touch_controls")
	if touch != null and touch.available:
		# The minimap keeps the current zone visible without a second mobile overlay.
		_banner.hide()
		return
	var viewport_size := get_viewport_rect().size
	var width := minf(360.0, maxf(1.0, viewport_size.x - 32.0))
	if not is_equal_approx(_banner.custom_minimum_size.x, width):
		_banner.custom_minimum_size.x = width
		_banner.reset_size()
	_banner.position.x = floorf((viewport_size.x - _banner.size.x) / 2.0)
	# Keep compact screens clear of the existing top-left interaction HUD.
	_banner.position.y = 16.0 if viewport_size.x >= 1024.0 else maxf(16.0, viewport_size.y - _banner.size.y - 16.0)
