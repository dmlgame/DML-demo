extends Node2D

const FOOT_OFFSET := Vector2(0, 25)
const ROUTE_COLOR := Color("73e0e9")

var player: CharacterBody2D
var destination: Callable
var enabled := false
var points := PackedVector2Array()

func _physics_process(_delta: float) -> void:
	if not enabled or player.get("_interaction_locked"):
		return
	_update_path()

func set_enabled(value: bool) -> void:
	enabled = value
	visible = value
	if enabled:
		_update_path()
	else:
		points.clear()
		queue_redraw()

func _update_path() -> void:
	if not enabled:
		return
	var feet := player.global_position + FOOT_OFFSET
	var target_point: Variant = destination.call()
	if not target_point is Vector2:
		if not points.is_empty():
			points.clear()
			queue_redraw()
		return
	var target: Vector2 = target_point
	if points.size() == 2 and points[0].is_equal_approx(feet) and points[1].is_equal_approx(target):
		return
	points = PackedVector2Array([feet, target])
	queue_redraw()

func _draw() -> void:
	if not enabled or points.size() != 2:
		return
	var start := to_local(points[0])
	var endpoint := to_local(points[1])
	draw_line(start, endpoint, Color(0, 0, 0, 0.75), 5.0, true)
	draw_line(start, endpoint, ROUTE_COLOR, 2.5, true)
	draw_circle(endpoint, 9.0, Color(0, 0, 0, 0.8))
	draw_arc(endpoint, 7.0, 0, TAU, 24, ROUTE_COLOR, 2.5, true)
