extends Control

const IMAGE := preload("res://assets/ui/dml-logo.png")
const SOURCE := Vector2(1672, 662)
var compact := false
var light := false
var _font: SystemFont

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_font = SystemFont.new()
	_font.font_names = PackedStringArray(["Impact", "Arial Narrow", "Arial"])
	_font.font_weight = 800
	custom_minimum_size.y = 112 if compact else 214
	resized.connect(queue_redraw)

func _draw() -> void:
	if _font == null:
		return
	var width := minf(220 if compact else 336, size.x)
	if compact:
		width = minf(width, size.y * SOURCE.x / SOURCE.y)
	var scale_factor := width / SOURCE.x
	var origin := Vector2((size.x - width) / 2, 0)
	draw_texture_rect_region(IMAGE, Rect2(origin, Vector2(width, SOURCE.y * scale_factor)), Rect2(Vector2.ZERO, SOURCE))
	# Match the site's reinforced black conveyor, wheels and yellow parcel outline.
	var conveyor := StyleBoxFlat.new()
	conveyor.bg_color = Color("050505")
	conveyor.set_corner_radius_all(7)
	draw_style_box(conveyor, Rect2(origin + Vector2(48, 524) * scale_factor, Vector2(1576, 68) * scale_factor))
	for x in [207, 621, 1042, 1462]:
		draw_arc(origin + Vector2(x, 605) * scale_factor, 38 * scale_factor, 0, TAU, 32, Color("050505"), 32 * scale_factor, true)
	var parcel := StyleBoxFlat.new()
	parcel.bg_color = Color("f3c849")
	parcel.border_color = Color("050505")
	parcel.set_border_width_all(3)
	parcel.set_corner_radius_all(3)
	draw_style_box(parcel, Rect2(origin + Vector2(1446, 355) * scale_factor, Vector2(177, 165) * scale_factor))
	draw_rect(Rect2(origin + Vector2(1516, 355) * scale_factor, Vector2(35, 73) * scale_factor), Color("202729"))
	if not compact:
		var color := Color("151919") if light else Color.WHITE
		var font_size := 32
		var y := SOURCE.y * scale_factor + 32
		for line in ["DEPARTMENT OF", "MINOR LOGISTICS"]:
			var x := (size.x - _font.get_string_size(line, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size).x) / 2
			if not light:
				draw_string_outline(_font, Vector2(x, y + 2), line, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, 3, Color(0, 0, 0, 0.55))
			draw_string(_font, Vector2(x, y), line, HORIZONTAL_ALIGNMENT_LEFT, -1, font_size, color)
			y += 32
