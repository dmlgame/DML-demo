extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	root.add_child(world)
	for path in ["FloorLayer", "FloorLayer2", "WallLayer", "YSortActors/MezzanineLayer"]:
		var layer := world.get_node(path) as TileMapLayer
		print(path + " tile=" + str(layer.tile_set.tile_size) + " cells=" + str(layer.get_used_rect()) + " origin=" + str(layer.global_position))
		print("global scale=" + str(layer.global_scale))
	var lifts := world.get_node("YSortActors/MezzanineLayer/MezzanineAccessSprites")
	for index in [0, 3, 6, 11]:
		var lift: Sprite2D = lifts.get_child(index)
		print(lift.name + " origin=" + str(lift.global_position) + " bounds=" + str(lift.get_global_transform() * lift.get_rect()))
	world.free()
	quit()
