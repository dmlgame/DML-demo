extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	await physics_frame
	var stock: TileMapLayer = world.get_node("YSortActors/PalletLayer")
	var zones: Node = world.get_node("BlockNotifications")
	print("Receiving lead: ", world.get_node("YSortActors/FurnitureSprites/ChairWithNpcRight/InteractionArea").global_position)
	for cell in stock.get_used_cells():
		var atlas := stock.get_cell_atlas_coords(cell)
		if atlas in [Vector2i(2, 0), Vector2i(4, 0), Vector2i(6, 0), Vector2i(2, 3), Vector2i(4, 3), Vector2i(6, 3)]:
			var point := stock.to_global(stock.map_to_local(cell))
			print("Pallet ", cell, " atlas ", atlas, " world ", point, " block ", zones.get_block_at(point))
	world.free()
	quit()
