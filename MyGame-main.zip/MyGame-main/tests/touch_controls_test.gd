extends SceneTree

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(390, 844)
	var session: Node = load("res://game_session.tscn").instantiate()
	session.animation_test_mode = false
	session.save_store.directory = "res://tmp/decor_rc_qa/touch_test"
	root.add_child(session)
	var controls: Control = session.touch_controls
	controls.available = true
	_check(not controls.visible, "Touch controls are hidden in the main menu")
	await session._start_world("")
	await _settle()
	var player: CharacterBody2D = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	var demo: Node = session.world.get_node("DemoTasks")
	_check(demo._objective.text == "Найдите директора, он введет вас в курс дела", "Director objective uses the requested explanation")
	_check_full_portrait_task(demo, "cold portrait start")
	_check(controls.visible and not session.controls_hint.visible, "Touch replaces the keyboard hint")
	_check(controls._action_button.action == "interact" and controls._secondary_action_button.action == "interact_secondary", "Blue and green buttons have distinct input actions")
	_check(controls._action_button.get_child(0).get_theme_stylebox("panel").bg_color == controls.PRIMARY_COLOR, "First action is blue")
	_check(controls._secondary_action_button.get_child(0).get_theme_stylebox("panel").bg_color == controls.SECONDARY_COLOR, "Second action is green")
	demo._director.set_physics_process(false)
	player.global_position = demo._director.global_position + Vector2(0, 40)
	var sprint_label: Label = controls._sprint_button.get_child(0).get_child(0).get_child(1)
	_check(sprint_label.text == "Ускорение", "Mobile sprint button uses the acceleration label")
	for viewport_size in [Vector2i(844, 390), Vector2i(640, 360), Vector2i(390, 844), Vector2i(346, 794), Vector2i(320, 640), Vector2i(812, 320)]:
		root.size = viewport_size
		await _settle()
		demo._layout()
		var task: Rect2 = demo._task_panel.get_global_rect()
		_check(root.get_visible_rect().encloses(task), "Objective fits " + str(viewport_size))
		_check(root.get_visible_rect().encloses(controls._minimap.get_global_rect()), "Minimap fits " + str(viewport_size))
		_check(not task.intersects(controls._minimap.get_global_rect()), "Minimap does not overlap the objective " + str(viewport_size))
		for button in [controls._action_button, controls._secondary_action_button, controls._sprint_button, controls._pause_button, controls._zoom_in_button, controls._zoom_out_button]:
			var rect := Rect2(button.position - button.shape.size / 2.0, button.shape.size)
			_check(root.get_visible_rect().encloses(rect), "Touch button fits " + str(viewport_size))
			_check(not task.intersects(rect), "Touch button does not overlap the objective " + str(viewport_size))
			_check(not controls._minimap.get_global_rect().intersects(rect), "Touch button does not overlap the minimap " + str(viewport_size))
			var panel: Control = button.get_child(0)
			_check(panel.size.is_equal_approx(button.shape.size), "Touch label does not resize its button " + str(viewport_size))
		var sprint_panel: Control = controls._sprint_button.get_child(0)
		_check(sprint_panel.get_global_rect().encloses(sprint_label.get_global_rect()), "Acceleration label fits " + str(viewport_size))
		var fullscreen_rect := Rect2(viewport_size.x - 64, viewport_size.y - 64, 48, 48)
		for button in [controls._action_button, controls._secondary_action_button, controls._sprint_button]:
			var rect := Rect2(button.position - button.shape.size / 2.0, button.shape.size)
			_check(not fullscreen_rect.intersects(rect), "Fullscreen space stays clear " + str(viewport_size))
		_check(controls._action_button.shape.size == Vector2(52, 52) and controls._secondary_action_button.shape.size == Vector2(52, 52), "Both actions are fixed-size squares")
		var hint: RichTextLabel = player._interaction_hint
		_check(hint.visible and hint.text.contains("Нажмите " + controls.PRIMARY_SYMBOL + " или " + controls.SECONDARY_SYMBOL), "Mobile prompt uses both square icons")
		_check(hint.text.contains(controls.PRIMARY_SYMBOL) and hint.text.contains(controls.SECONDARY_SYMBOL), "Prompt colors match the action buttons")
		_check(not hint.get_parsed_text().contains("Enter") and not hint.get_parsed_text().contains("Действие"), "Mobile prompt has no keyboard or removed action label")
		_check(root.get_visible_rect().encloses(hint.get_global_rect()), "Director prompt fits " + str(viewport_size))
		_check_top_hint(hint, controls, demo, viewport_size)
		_check(demo._task_title.get_theme_font_size("font_size") == 12 and demo._objective.get_theme_font_size("font_size") == 12, "Mobile objective uses compact type")
		_check(task.encloses(demo._task_hide.get_global_rect()) and task.encloses(demo._hint_button.get_global_rect()), "Objective icon buttons fit " + str(viewport_size))
		_check(player.get_node("InteractionHUD").get_child_count() == 1, "Explanation has no collapse button")
		_check(hint.get_theme_stylebox("normal").content_margin_bottom == 6, "Explanation has no empty button footer")
		var saved_stage: String = demo.stage
		demo._task_hide.pressed.emit()
		await _settle()
		_check(not demo._task_panel.visible and demo._task_restore.visible, "Objective collapses to a restore icon")
		_check(hint.visible, "Explanation stays visible when the objective is hidden")
		_check(root.get_visible_rect().encloses(demo.task_hud_rect()) and root.get_visible_rect().encloses(player.interaction_hud_rect()), "Collapsed controls fit " + str(viewport_size))
		_check(controls._is_hud_point(demo.task_hud_rect().get_center()) and controls._is_hud_point(player.interaction_hud_rect().get_center()), "Restore button and explanation cannot start a camera pinch")
		_check(demo._task_restore.position == Vector2(viewport_size.x - 60, 16), "Objective restore stays in the top-right corner")
		_check(demo.stage == saved_stage and not player._interaction_locked, "Collapsing does not change progress or lock movement")
		demo._task_restore.pressed.emit()
		await _settle()
		_check(demo._task_panel.visible and hint.visible, "Objective restores without changing the explanation")
		if viewport_size.y > viewport_size.x:
			_check_full_portrait_task(demo, str(viewport_size))
		_check(not hint.get_global_rect().intersects(task), "Director prompt does not overlap the objective " + str(viewport_size))
		_check(not hint.get_global_rect().intersects(controls._minimap.get_global_rect()), "Director prompt does not cover the minimap " + str(viewport_size))
		for button in [controls._action_button, controls._secondary_action_button, controls._sprint_button, controls._pause_button, controls._zoom_in_button, controls._zoom_out_button]:
			var rect := Rect2(button.position - button.shape.size / 2.0, button.shape.size)
			_check(not hint.get_global_rect().intersects(rect), "Director prompt does not cover a touch button " + str(viewport_size))
	for viewport_size in [Vector2i(390, 844), Vector2i(346, 794), Vector2i(320, 640)]:
		root.size = viewport_size
		for task_stage in ["find_director", "meet_shift_lead", "meet_receiving_lead", "orientation_complete"]:
			demo.stage = task_stage
			demo._refresh_task()
			await _settle()
			_check_full_portrait_task(demo, task_stage + " " + str(viewport_size))
			var task_rect: Rect2 = demo._task_panel.get_global_rect()
			_check(root.get_visible_rect().encloses(task_rect), "Full portrait task fits: " + task_stage)
			for button in [controls._action_button, controls._secondary_action_button, controls._sprint_button]:
				var rect := Rect2(button.position - button.shape.size / 2.0, button.shape.size)
				_check(not task_rect.intersects(rect), "Full portrait task leaves action controls clear: " + task_stage)
	demo.stage = "find_director"
	demo._refresh_task()
	player.global_position = Vector2(20000, 20000)
	await _settle()
	_check(not player._interaction_hint.visible and player.interaction_hud_rect() == Rect2(), "Explanation disappears automatically away from objects")
	player.global_position = demo._director.global_position + Vector2(0, 40)
	await _settle()
	_check(player._interaction_hint.visible, "Explanation returns automatically on approach")
	for vehicle in [demo.nearest_free_pallet_jack(), demo.nearest_free_transporter()]:
		player.global_position = vehicle.interaction_area.global_position
		player._nearby_vehicles.clear()
		player.register_pickup_vehicle(vehicle)
		print("Equipment hint test position: " + str(vehicle.vehicle_mode) + " " + str(player.global_position))
		for viewport_size in [Vector2i(844, 390), Vector2i(640, 360), Vector2i(390, 844), Vector2i(346, 794), Vector2i(320, 640), Vector2i(812, 320)]:
			root.size = viewport_size
			await _settle()
			var hint: RichTextLabel = player._interaction_hint
			_check(hint.visible and hint.get_parsed_text() == demo.get_vehicle_hint(vehicle), "Equipment hint displays the updated explanation")
			_check(root.get_visible_rect().encloses(hint.get_global_rect()), "Equipment hint fits " + str(viewport_size))
			_check_top_hint(hint, controls, demo, viewport_size)
			_check(not hint.get_global_rect().intersects(demo._task_panel.get_global_rect()), "Equipment hint does not overlap the objective")
			var joystick_rect := Rect2(controls.joystick_center - Vector2(62, 62), Vector2(124, 124))
			_check(not hint.get_global_rect().intersects(joystick_rect), "Equipment hint does not overlap the joystick")
			_check(not hint.get_global_rect().intersects(controls._minimap.get_global_rect()), "Equipment hint does not cover the minimap")
			for button in [controls._action_button, controls._secondary_action_button, controls._sprint_button, controls._pause_button, controls._zoom_in_button, controls._zoom_out_button]:
				var rect := Rect2(button.position - button.shape.size / 2.0, button.shape.size)
				_check(not hint.get_global_rect().intersects(rect), "Equipment hint does not cover a touch button")
	player._nearby_vehicles.clear()
	player.global_position = demo._director.global_position + Vector2(0, 40)
	demo._task_hide.pressed.emit()
	root.size = Vector2i(390, 844)
	await _settle()
	_check(not demo._task_panel.visible and demo._task_restore.visible and player._interaction_hint.visible, "Rotation keeps only the objective collapsed")
	session._pause()
	await _settle()
	session._resume()
	await _settle()
	_check(not demo._task_panel.visible and demo._task_restore.visible and player._interaction_hint.visible, "Pause and resume keep only the objective collapsed")
	demo._task_restore.pressed.emit()
	root.size = Vector2i(844, 390)
	await _settle()
	var center: Vector2 = controls.joystick_center
	_touch(0, center + Vector2(4, 0), true)
	_check(player._read_direction().is_zero_approx(), "Joystick dead zone avoids accidental movement")
	_drag(0, center + Vector2(160, 0))
	_check(player._read_direction() == Vector2.RIGHT, "Joystick drag remains clamped outside its ring")
	_touch(1, controls._sprint_button.position, true)
	_check(player._touch_sprinting and player._read_direction() == Vector2.RIGHT, "A second finger can sprint while the first steers")
	_touch(1, controls._sprint_button.position, false)
	_check(not player._touch_sprinting and player._read_direction() == Vector2.RIGHT, "Releasing sprint keeps steering")
	_touch(0, center, false)
	_check(player._read_direction().is_zero_approx(), "Lifting the steering finger stops movement")
	for mode in [player.MoveMode.ON_FOOT, player.MoveMode.PALLET_JACK, player.MoveMode.TRANSPORTER]:
		player.set_move_mode(mode)
		player.global_position = Vector2(20000, 20000)
		session._update_controls_hint_visibility()
		_check(controls._sprint_button.visible == (mode == player.MoveMode.ON_FOOT), "Sprint only appears on foot")
		_touch(0, center, true)
		_drag(0, center + Vector2(36, 36))
		var direction: Vector2 = player._read_direction()
		_check(direction.is_equal_approx(Vector2(1, 1).normalized()), "Diagonal steering is normalized in mode " + str(mode))
		player._physics_process(1.0 / 60.0)
		await physics_frame
		player._physics_process(1.0 / 60.0)
		_check(player.velocity.length() > 0, "Touch moves the existing controller in mode " + str(mode))
		_touch(0, center, false)
		player._physics_process(1.0 / 60.0)
		_check(player.velocity.is_zero_approx(), "Release stops the vehicle in mode " + str(mode))
	player.set_move_mode(player.MoveMode.ON_FOOT)
	session._update_controls_hint_visibility()
	_touch(0, center + Vector2(36, 0), true)
	_touch(1, controls._sprint_button.position, true)
	controls._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
	_check(player._read_direction().is_zero_approx() and not player._touch_sprinting, "Focus loss clears both held fingers")
	_touch(0, center, false)
	_touch(1, controls._sprint_button.position, false)
	_touch(0, center + Vector2(36, 0), true)
	_touch(1, controls._pause_button.position, true)
	await _settle()
	_check(paused and session.menu.visible and not controls.visible, "Touch pause opens the real menu and hides controls")
	_touch(0, center, false)
	_touch(1, Vector2(40, 40), false)
	session._resume()
	_check(controls.visible and player._read_direction().is_zero_approx(), "Resume restores controls without stale movement")
	_touch(0, center + Vector2(36, 0), true)
	root.size = Vector2i(390, 844)
	await _settle()
	_check(player._read_direction().is_zero_approx(), "Rotation cancels a held joystick")
	_touch(0, center, false)
	demo._director.set_physics_process(false)
	player.global_position = demo._director.global_position + Vector2(0, 40)
	await _settle()
	session._notify("Игра сохранена")
	_touch(0, controls.joystick_center + Vector2(30, 0), true)
	_touch(1, controls._action_button.position, true)
	await _settle()
	_check(demo._modal.visible and player._interaction_locked and not controls.visible, "Second-finger action opens the existing conversation")
	_check(not demo._task_restore.visible and not player._interaction_hint.visible, "Objective restore and explanation hide during conversation")
	_check(not session._toast.visible, "Save notifications cannot cover a mobile conversation")
	_check(player._touch_direction.is_zero_approx(), "Opening a conversation clears steering")
	_touch(0, controls.joystick_center, false)
	_touch(1, controls._action_button.position, false)
	demo.close_modal()
	await _settle()
	_check(controls.visible and player._read_direction().is_zero_approx(), "Closing a conversation restores idle controls")
	_touch(0, controls._secondary_action_button.position, true)
	_touch(0, controls._secondary_action_button.position, false)
	await _settle()
	_check(demo._modal.visible and player._interaction_locked, "Green also starts an ordinary conversation")
	_check(not Input.is_action_pressed("interact_secondary"), "Opening a modal releases the second action")
	demo.close_modal()
	await _settle()
	var lift_controller: Node = session.world.get_node("FreightLiftInteraction")
	var lift: Dictionary = lift_controller._lifts[0]
	var geometry = preload("res://footprint_sort_geometry.gd")
	var polygons: Array[PackedVector2Array] = [lift.shape.polygon]
	var front: float = geometry.front_y(polygons, 750, 704)
	player.global_position = lift.shape.to_global(Vector2(750, front)) + Vector2(0, 28) - Vector2(0, 25)
	await _settle()
	print("Mobile lift test position: " + str(player.global_position))
	for viewport_size in [Vector2i(844, 390), Vector2i(640, 360), Vector2i(390, 844), Vector2i(346, 794), Vector2i(320, 640), Vector2i(812, 320)]:
		root.size = viewport_size
		await _settle()
		var hint: RichTextLabel = player._interaction_hint
		_check(hint.text.contains(controls.PRIMARY_SYMBOL + ", чтобы открыть лифт") and hint.text.contains(controls.SECONDARY_SYMBOL + ", чтобы выбрать этаж"), "Lift prompt keeps the two actions separate")
		_check(root.get_visible_rect().encloses(hint.get_global_rect()), "Lift hint fits " + str(viewport_size))
		_check_top_hint(hint, controls, demo, viewport_size)
		var joystick_rect := Rect2(controls.joystick_center - Vector2(62, 62), Vector2(124, 124))
		_check(not hint.get_global_rect().intersects(joystick_rect), "Lift hint does not cover the joystick " + str(viewport_size))
		_check(not hint.get_global_rect().intersects(demo._task_panel.get_global_rect()), "Lift hint does not overlap the objective " + str(viewport_size))
		_check(not hint.get_global_rect().intersects(controls._minimap.get_global_rect()), "Lift hint does not cover the minimap " + str(viewport_size))
		for button in [controls._action_button, controls._secondary_action_button, controls._sprint_button, controls._pause_button, controls._zoom_in_button, controls._zoom_out_button]:
			var rect := Rect2(button.position - button.shape.size / 2.0, button.shape.size)
			_check(not hint.get_global_rect().intersects(rect), "Lift hint does not cover a touch button " + str(viewport_size))
	_touch(0, controls._secondary_action_button.position, true)
	_touch(0, controls._secondary_action_button.position, false)
	await _settle()
	_check(not lift.is_open and not lift_controller._selected.is_empty() and player._interaction_locked, "Green selects a floor even with closed doors")
	lift_controller._close_picker()
	await _settle()
	_touch(0, controls._action_button.position, true)
	_touch(0, controls._action_button.position, false)
	await create_timer(0.5).timeout
	_check(lift.is_open and not player._interaction_locked, "Blue opens a nearby lift")
	_touch(0, controls._secondary_action_button.position, true)
	_touch(0, controls._secondary_action_button.position, false)
	await _settle()
	_check(lift.is_open and not lift_controller._selected.is_empty() and player._interaction_locked, "Green selects a floor without closing the doors")
	lift_controller._close_picker()
	await _settle()
	_touch(0, controls._action_button.position, true)
	_touch(0, controls._action_button.position, false)
	await create_timer(0.5).timeout
	_check(not lift.is_open and not player._interaction_locked and lift_controller._selected.is_empty(), "Blue closes the lift instead of showing floor selection")
	controls.available = false
	root.size = Vector2i(1280, 720)
	session._update_controls_hint_visibility()
	await _settle()
	_check(player._interaction_hint.position == Vector2(16, 108), "Desktop interaction hints stay below the minimap")
	_check(player._interaction_hint.custom_minimum_size.x == 300.0, "Desktop interaction hints keep their original width")
	_check(player._interaction_hint.get_theme_font_size("normal_font_size") == 16 and not demo._task_hide.visible and not demo._task_restore.visible, "Desktop keeps the original type and no mobile collapse buttons")
	session.free()
	paused = false
	if not failed:
		print("Touch tests passed: layout, multi-touch, all vehicle modes, action, pause, focus, rotation, dialogs")
	quit(1 if failed else 0)

func _check_top_hint(hint: RichTextLabel, controls: Control, demo: Node, viewport_size: Vector2i) -> void:
	var minimap_rect: Rect2 = controls._minimap.get_global_rect()
	var task_rect: Rect2 = demo._task_panel.get_global_rect()
	var gap_width := task_rect.position.x - minimap_rect.end.x - 32.0
	if viewport_size.y > viewport_size.x:
		var rect := hint.get_global_rect()
		_check(task_rect.position == Vector2(viewport_size.x - task_rect.size.x - 16, 16) and is_equal_approx(task_rect.size.x, minimap_rect.size.x), "Portrait objective is in the top-right corner " + str(viewport_size))
		_check(task_rect.end.y <= viewport_size.y / 2.0 - 60.0, "Portrait objective leaves the avatar clear " + str(viewport_size))
		_check_full_portrait_task(demo, str(viewport_size))
		_check(rect.position == Vector2(minimap_rect.position.x, minimap_rect.end.y + 12) and is_equal_approx(rect.size.x, minimap_rect.size.x), "Portrait explanation is below the minimap " + str(viewport_size))
	_check(hint.get_theme_font_size("normal_font_size") == 12, "Mobile explanations use compact type")
	if viewport_size.x > viewport_size.y and gap_width >= 200.0:
		var rect := hint.get_global_rect()
		_check(is_equal_approx(rect.position.y, 16.0), "Mobile hint is at the top " + str(viewport_size))
		_check(rect.position.x >= minimap_rect.end.x + 16.0 and rect.end.x <= task_rect.position.x - 16.0, "Mobile hint stays between minimap and objective " + str(viewport_size))
		_check(is_equal_approx(rect.get_center().x, (minimap_rect.end.x + task_rect.position.x) / 2.0), "Mobile hint is centered in the upper gap " + str(viewport_size))
	_check(hint.get_content_height() <= ceili(hint.size.y), "Wrapped hint text is not clipped " + str(viewport_size))

func _check_full_portrait_task(demo: Node, context: String) -> void:
	_check(demo._task_panel.is_visible_in_tree() and demo._objective.is_visible_in_tree(), "Portrait shows the full objective: " + context)
	_check(demo._task_title.text == demo._task_heading(false), "Portrait shows the full task heading: " + context)
	var panel: Rect2 = demo._task_panel.get_global_rect()
	for label in [demo._task_title, demo._objective]:
		_check(panel.encloses(label.get_global_rect()), "Portrait task label fits: " + context)
		_check(label.get_combined_minimum_size().y <= label.size.y, "Portrait task text is not clipped: " + context)

func _touch(index: int, position: Vector2, pressed: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = position
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _drag(index: int, position: Vector2) -> void:
	var event := InputEventScreenDrag.new()
	event.index = index
	event.position = position
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _settle() -> void:
	for frame in range(4):
		await process_frame

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
