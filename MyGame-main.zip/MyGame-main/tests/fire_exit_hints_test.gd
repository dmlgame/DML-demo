extends SceneTree

const TITLE := "Пожарный выход"
const FOOT_OFFSET := Vector2(0, 25)
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var layer := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	var hints := world.get_node("TableHints")
	var hint: RichTextLabel = player._interaction_hint
	var source := layer.tile_set.get_source(4) as TileSetAtlasSource
	for atlas in [Vector2i(0, 0), Vector2i(2, 0), Vector2i(4, 0)]:
		var data := source.get_tile_data(atlas, 0)
		_check(data.get_custom_data("interaction_name") == TITLE, "All exit graphics carry the same informational name")
		_check(data.get_collision_polygons_count(0) == 0, "Labels do not add a new door collision")
	var exits: Array[Dictionary] = []
	for label in hints._labels:
		if layer.get_cell_source_id(label.cell) == 4:
			exits.append(label)
	_check(not exits.is_empty(), "Real map exits are discovered")
	_check(hints._tables.size() == 34 and hints._labels.size() == 34 + exits.size(), "Exit labels are not worktables or NPC homes")
	if exits.is_empty():
		world.free()
		viewport.free()
		quit(1)
		return
	var original: PackedByteArray = layer.tile_map_data
	var original_cells := _cells(layer)
	for label in exits:
		var footprint: Rect2 = label.footprint
		for feet in [footprint.get_center() + Vector2(0, 24), footprint.position + Vector2(-24, 0), footprint.end + Vector2(24, 0)]:
			player.global_position = layer.to_global(feet) - FOOT_OFFSET
			player._update_interaction_hint()
			_check(hints.get_interaction_text(player) == TITLE, "An exit is labelled when approaching from the front or sides")
			_check(hint.visible and hint.get_parsed_text() == TITLE, "The HUD displays only the exit name without a key or action button")
		var before := player.global_position
		for key in [KEY_E, KEY_ENTER]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			event.pressed = true
			player._unhandled_input(event)
		_check(player.global_position == before and layer.tile_map_data == original, "Informational exits have no interaction, teleport or map mutation")
	player.set_interaction_locked(true)
	_check(not hint.visible, "A modal lock hides the exit name")
	player.set_interaction_locked(false)
	_check(hint.get_parsed_text() == TITLE and hint.visible, "The nearby label returns after unlocking")
	var exit: Dictionary = exits[0]
	player.global_position = layer.to_global(exit.footprint.get_center() + Vector2(0, 24)) - FOOT_OFFSET
	player._update_interaction_hint()
	player.get_node("Camera2D").force_update_scroll()
	await _capture(viewport, "fire_exit")
	viewport.size = Vector2i(320, 240)
	player._update_interaction_hint()
	await _capture(viewport, "fire_exit_small")
	_check(Rect2(Vector2.ZERO, Vector2(viewport.size)).encloses(Rect2(hint.get_global_transform_with_canvas().origin, hint.size)), "The title fits a compact viewport")
	player.global_position = layer.to_global(exit.footprint.get_center() + Vector2(0, 100)) - FOOT_OFFSET
	player._update_interaction_hint()
	_check(hints.get_interaction_text(player).is_empty() and not hint.visible, "The label disappears after walking away")
	var cell: Vector2i = exit.cell
	var atlas := layer.get_cell_atlas_coords(cell)
	var count: int = hints._labels.size()
	layer.erase_cell(cell)
	await _settle()
	_check(hints._labels.size() == count - 1 and hints._tables.size() == 34, "Removing a door removes its label without affecting table destinations")
	for pose in [Vector2i(0, 0), Vector2i(2, 0), Vector2i(4, 0)]:
		layer.set_cell(cell, 4, pose)
		await _settle()
		_check(hints._labels.size() == count, "Changing the door graphic rebuilds a single zone")
		player.global_position = layer.to_global(exit.footprint.get_center() + Vector2(0, 24)) - FOOT_OFFSET
		_check(hints.get_interaction_text(player) == TITLE, "The name follows every door graphic")
	layer.set_cell(cell, 4, atlas)
	await _settle()
	_check(layer.get_cell_source_id(cell) == 4 and layer.get_cell_atlas_coords(cell) == atlas, "Restore the original door graphic")
	layer.tile_map_data = original
	await _settle()
	_check(_cells(layer) == original_cells, "Door checks restore every tile, variant and transform")
	world.free()
	viewport.free()
	if not failed:
		print("Fire exit hints passed: ", exits.size(), " map exits, three graphics, passive title only, no action or collision changes, approach/leave, locks, compact HUD and live tile updates")
	quit(1 if failed else 0)

func _settle() -> void:
	await process_frame
	await process_frame

func _cells(layer: TileMapLayer) -> Dictionary:
	var result := {}
	for cell in layer.get_used_cells():
		result[cell] = [layer.get_cell_source_id(cell), layer.get_cell_atlas_coords(cell), layer.get_cell_alternative_tile(cell)]
	return result

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		await _settle()
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var output := "res://tmp/decor_rc_qa/"
	DirAccess.make_dir_recursive_absolute(output)
	_check(viewport.get_texture().get_image().save_png(output + name + ".png") == OK, "Save the actual exit label preview")

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
