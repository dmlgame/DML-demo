extends SceneTree

const Activity = preload("res://warehouse_activity.gd")
const Worker = preload("res://warehouse_worker.gd")
const DemoTasks = preload("res://demo_tasks.gd")
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var activity := world.get_node("WarehouseActivity")
	await _wait_for_activity(activity)
	_check(activity.workers.size() == 20, "Twenty different workers populate receiving, packing and sorting")
	if activity.workers.size() != 20:
		quit(1)
		return
	_check(world.get_node("YSortActors/WarehouseWorkers").y_sort_enabled, "Workers share the existing actor Y-sort")
	var kinds := {}
	for point in activity.destinations:
		kinds[point.kind] = true
		_check(activity.can_roam(point.point), "All random destinations stay in active blocks")
	print("Destination types: ", kinds, "; count=", activity.destinations.size())
	_check(kinds.has("table") and kinds.has("decor") and kinds.has("gate"), "Workers can stop at tables, decor and gates")
	var map_before: PackedByteArray = world.get_node("YSortActors/ObjectsLayer").tile_map_data
	var store := WarehouseSaveStore.new()
	var original := store.capture(world)
	var gate_reachable := false
	var navigator = activity.workers[0]
	for index in navigator.destinations.size():
		if navigator.destinations[index].kind != "gate":
			continue
		navigator._target_index = index
		navigator._repath()
		if not navigator._path.is_empty():
			gate_reachable = true
			break
	_check(gate_reachable, "At least one gate has a clear route from receiving")
	navigator._target_index = -1
	navigator._path.clear()
	var appearances := {}
	var block_counts := {2: 0, 3: 0}
	for index in activity.workers.size():
		var worker = activity.workers[index]
		var block_number: int = world.get_node("BlockNotifications").get_block_at(worker.global_position + Worker.FOOT_OFFSET)
		_check(block_number in [2, 3], "Workers only spawn in the second and third blocks")
		if block_number in block_counts:
			block_counts[block_number] += 1
		appearances[worker.skin.resource_path] = true
		_check(worker.sprite.texture == worker.skin and worker.sprite.hframes == 9 and worker.sprite.vframes == 4, "Native LPC walking sheets use a standing pose and eight steps")
		_check(worker.sprite.material == null and worker.get_child_count() == 2, "Workers have no tools, totes or extra work animations")
		_check(worker.z_index == player.z_index and worker.collision_layer == 1 and worker.collision_mask == 1, "Workers match player depth and physical collisions")
		_check(worker.destinations.size() > 3, "Wandering is not a fixed two-stop work loop")
		for point in worker.destinations:
			_check(activity.can_roam(point.point), "Individual routes have no stops in the construction block")
		_check(not _overlaps(worker), "Workers spawn clear of scenery, vehicles and one another")
		_check_sheet(worker.skin)
		worker._rng.seed = index + 31
		worker.pause_seconds = Vector2(0.15, 0.35)
		worker._rest_left = index * 0.1
		worker.walk_speed = 180
		# Exercise repeated arrivals quickly without changing the real destination catalogue.
		var nearby: Array[Dictionary] = []
		var feet: Vector2 = worker.global_position + Worker.FOOT_OFFSET
		for point in worker.destinations:
			if feet.distance_to(point.point) <= 350:
				nearby.append(point)
		_check(nearby.size() >= 3, "Every worker has multiple reachable nearby stops")
		worker.destinations = nearby
	_check(appearances.size() == 20, "Every worker has an individual appearance")
	_check(block_counts[2] == 9 and block_counts[3] == 11, "Nine workers populate block two and eleven populate block three")
	var visited := {}
	var rested := {}
	var animated := {}
	for frame in 900:
		await physics_frame
		for worker in activity.workers:
			_check(not _overlaps(worker), "Movement never penetrates equipment or another worker")
			_check(activity.can_roam(worker.global_position + Worker.FOOT_OFFSET), "Real movement never leaves the active blocks")
			if worker.resting and worker.completed_stops > 0:
				rested[worker.name] = true
			if worker._animating:
				animated[worker.name] = true
				_check(worker.sprite.frame_coords.x >= 1 and worker.sprite.frame_coords.x <= 8, "Moving workers only use walk columns")
			else:
				_check(worker.sprite.frame_coords.x == 0, "Paused workers use the standing pose")
			if worker._target_index >= 0:
				var route_key := str(worker.name) + ":" + str(worker._target_index)
				if not visited.has(route_key):
					for point in worker._path:
						_check(activity.can_roam(point), "Obstacle detours cannot enter the first block")
				visited[route_key] = true
	for worker in activity.workers:
		print(worker.name, ": travelled=", worker.travelled, " stops=", worker.completed_stops)
		_check(worker.travelled > 100 and worker.completed_stops >= 2, "Every worker repeatedly walks to random stops")
		_check(rested.has(worker.name) and animated.has(worker.name), "Every worker alternates walking and standing")
		worker.set_physics_process(false)
	_check(visited.size() > 30, "Workers choose varied stops")
	await _captures(viewport, world, activity)
	await _check_block_boundary(world, activity)
	_check(world.get_node("YSortActors/ObjectsLayer").tile_map_data == map_before and store._valid(store.capture(world)) and original.vehicles == store.capture(world).vehicles, "Workers do not alter map tiles, vehicles or the save schema")
	_check(store.apply_state(world, original), "Existing warehouse saves still load")
	var demo := DemoTasks.new()
	demo.name = "DemoTasks"
	world.add_child(demo)
	demo.set_process(false)
	_check(demo.stage == "find_supervisor" and demo.free_time_remaining == 60 and demo.placed_count == 0, "Workers do not advance introduction or unloading tasks")
	var receiver: CharacterBody2D = activity.workers[0]
	player.global_position = receiver.global_position + Vector2(0, 24)
	player.set_move_mode(player.MoveMode.ON_FOOT)
	player._apply_collision_profile(Vector2.UP)
	await physics_frame
	await physics_frame
	var hit := KinematicCollision2D.new()
	_check(player.test_move(player.global_transform, Vector2(0, -24), hit) and hit.get_collider() == receiver, "The player cannot pass through a worker")
	receiver.resting = false
	receiver._path = PackedVector2Array([receiver.global_position + Worker.FOOT_OFFSET + Vector2(0, 64)])
	receiver._path_index = 0
	var waiting_position := receiver.global_position
	receiver._physics_process(0.1)
	_check(receiver.global_position == waiting_position and receiver.velocity == Vector2.ZERO and receiver.sprite.frame_coords.x == 0, "A worker waits before walking into the player")
	player.global_position = original.player.position[0] * Vector2.RIGHT + original.player.position[1] * Vector2.DOWN
	await physics_frame
	receiver._physics_process(0.1)
	_check(receiver.global_position.distance_to(waiting_position) > 0.1, "A worker resumes when the player has passed")
	var blocker := CharacterBody2D.new()
	blocker.name = "OtherWorkerProbe"
	var collision := CollisionShape2D.new()
	collision.shape = RectangleShape2D.new()
	collision.shape.size = Vector2(20, 8)
	collision.position = Worker.FOOT_OFFSET
	blocker.add_child(collision)
	world.get_node("YSortActors").add_child(blocker)
	blocker.global_position = receiver.global_position + Vector2(0, 16)
	await physics_frame
	await physics_frame
	hit = KinematicCollision2D.new()
	_check(receiver.test_move(receiver.global_transform, Vector2(0, 20), hit) and hit.get_collider() == blocker, "Workers collide with other workers")
	blocker.free()
	paused = true
	var paused_positions := []
	for worker in activity.workers:
		worker.set_physics_process(true)
		paused_positions.append(worker.global_position)
	await create_timer(0.1, true).timeout
	for index in activity.workers.size():
		_check(activity.workers[index].global_position == paused_positions[index], "Game pause stops ambient wandering")
	paused = false
	world.free()
	world = load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	player = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	player.global_position = receiver_position(world) - Worker.FOOT_OFFSET
	activity = world.get_node("WarehouseActivity")
	await _wait_for_activity(activity)
	_check(activity.workers.size() == 20, "A restored player at a workbench does not remove its worker")
	for worker in activity.workers:
		_check(not _overlaps(worker), "Fresh-world workers do not spawn inside the restored player")
	world.free()
	viewport.free()
	if not failed:
		print("Warehouse activity passed: twenty LPC appearances, nine/eleven workers in active blocks, restricted destinations/pathfinding/movement, random walks and pauses, clear collisions, Y-sort, safe loading, unchanged tasks and saves")
	quit(1 if failed else 0)

func _check_block_boundary(world: Node2D, activity: Node) -> void:
	var worker = activity.workers[0]
	var original_position: Vector2 = worker.global_position
	var original_destinations: Array[Dictionary] = worker.destinations
	var blocks := world.get_node("BlockNotifications")
	for name in ["Passage12Upper", "Passage12Lower"]:
		var passage := blocks.get_node(name) as Area2D
		var edge := passage.global_position
		_check(not activity.can_roam(edge - Vector2(32, 0)), "The first block is outside the roaming area at both openings")
		_check(not activity.can_roam(edge + Vector2(8, 0)) and activity.can_roam(edge + Vector2(20, 0)), "Block restriction includes the worker's foot clearance")
		worker.global_position = edge + Vector2(20, 0) - Worker.FOOT_OFFSET
		var points: Array[Dictionary] = [
			{"point": edge + Vector2(96, 0), "look_at": edge, "kind": "floor"},
			{"point": edge - Vector2(96, 0), "look_at": edge, "kind": "floor"},
		]
		worker.destinations = points
		await physics_frame
		worker._target_index = 0
		worker._repath()
		_check(not worker._path.is_empty(), "A valid route near the boundary is still available")
		for point in worker._path:
			_check(activity.can_roam(point), "Boundary routes keep every waypoint in an active block")
		var forbidden_cells := 0
		for y in range(worker._grid.region.position.y, worker._grid.region.end.y):
			for x in range(worker._grid.region.position.x, worker._grid.region.end.x):
				var cell := Vector2i(x, y)
				if blocks.get_block_at(worker._grid.get_point_position(cell)) == 1:
					forbidden_cells += 1
					_check(worker._grid.is_point_solid(cell), "The pathfinder cannot use the first block as a detour")
		_check(forbidden_cells > 0, "The boundary test covers real first-block navigation cells")
		worker._target_index = 1
		worker._repath()
		_check(worker._path.is_empty(), "Even an injected destination in block one is rejected")
		worker._target_index = 0
		worker.resting = false
		worker._path = PackedVector2Array([edge - Vector2(96, 0)])
		worker._path_index = 0
		var before: Vector2 = worker.global_position
		worker._physics_process(0.25)
		_check(worker.global_position == before and worker.velocity == Vector2.ZERO, "Actual movement refuses an injected route into the first block")
	worker.global_position = original_position
	worker.destinations = original_destinations
	worker._target_index = 0
	worker._path.clear()
	worker._path_index = 0
	worker.resting = true
	worker._rest_left = 3
	worker._blocked_elapsed = 0
	worker._blocked_total = 0
	worker._stand()
	await physics_frame

func _wait_for_activity(activity: Node) -> void:
	for frame in 120:
		if activity.initialized:
			return
		await physics_frame
	_check(false, "Ambient workers initialize within two seconds")

func _check_sheet(texture: Texture2D) -> void:
	var sheet := texture.get_image()
	_check(sheet.get_size() == Vector2i(576, 256), "LPC sheet preserves the original 64px frame grid")
	for row in 4:
		for column in 9:
			var opaque := 0
			var blue := 0
			var yellow := 0
			for y in range(row * 64, row * 64 + 64):
				for x in range(column * 64, column * 64 + 64):
					var color := sheet.get_pixel(x, y)
					if color.a > 0.5:
						opaque += 1
						if color.b > color.r * 1.3 and color.b > color.g * 1.1:
							blue += 1
						if color.r > 0.65 and color.g > 0.5 and color.b < 0.4:
							yellow += 1
			_check(opaque > 300 and blue > 50 and yellow > 20, "Every walk pose contains blue workwear and the yellow vest")

func receiver_position(world: Node2D) -> Vector2:
	var layer := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	for table in world.get_node("TableHints")._tables:
		if table.cell == Activity.WORKERS[0].cell:
			var bounds: Rect2 = table.footprint
			return layer.to_global(Vector2(bounds.get_center().x - 24, bounds.end.y + 20))
	return Vector2.ZERO

func _overlaps(worker: CharacterBody2D) -> bool:
	var shape := RectangleShape2D.new()
	shape.size = Vector2(18, 6)
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0, worker.global_position + Worker.FOOT_OFFSET)
	query.collision_mask = 1
	query.exclude = [worker.get_rid()]
	return not worker.get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func _captures(viewport: SubViewport, world: Node2D, activity: Node) -> void:
	var output := OS.get_environment("NPC_QA_DIR")
	if output.is_empty():
		output = "user://tmp/warehouse_activity_qa"
	DirAccess.make_dir_recursive_absolute(output)
	var count: int = activity.workers.size()
	var gallery := Image.create(400, ceili(count / 5.0) * 96, false, Image.FORMAT_RGBA8)
	gallery.fill(Color("#53595c"))
	var directions := Image.create(count * 64, 256, false, Image.FORMAT_RGBA8)
	directions.fill(Color("#53595c"))
	for index in activity.workers.size():
		var worker = activity.workers[index]
		var sheet: Image = worker.skin.get_image()
		gallery.blend_rect(sheet, Rect2i(0, 128, 64, 64), Vector2i((index % 5) * 80 + 8, floori(index / 5.0) * 96 + 16))
		for row in 4:
			directions.blend_rect(sheet, Rect2i(192, row * 64, 64, 64), Vector2i(index * 64, row * 64))
	gallery.resize(gallery.get_width() * 2, gallery.get_height() * 2, Image.INTERPOLATE_NEAREST)
	directions.resize(directions.get_width() * 2, directions.get_height() * 2, Image.INTERPOLATE_NEAREST)
	_check(gallery.save_png(output.path_join("lpc_workers_preview_%d.png" % count)) == OK, "Save all worker appearances")
	_check(directions.save_png(output.path_join("lpc_workers_directions_%d.png" % count)) == OK, "Save all four walking directions")
	if DisplayServer.get_name() == "headless":
		return
	var camera := world.get_node("YSortActors/Player/Camera2D") as Camera2D
	camera.enabled = false
	var preview := Camera2D.new()
	preview.zoom = Vector2(2, 2)
	world.add_child(preview)
	preview.make_current()
	for worker in activity.workers:
		worker._stand()
		worker.facing = worker.Facing.DOWN
		worker._apply_frame()
		preview.global_position = worker.global_position + Vector2(0, -20)
		preview.force_update_scroll()
		await process_frame
		# Offscreen captures must also complete when the test window is minimized.
		RenderingServer.force_draw(false)
		_check(viewport.get_texture().get_image().save_png(output.path_join(str(worker.name) + "_lpc.png")) == OK, "Save actual warehouse close-up")
	viewport.size = Vector2i(640, 360)
	preview.zoom = Vector2(1.5, 1.5)
	preview.global_position = activity.workers[2].global_position
	preview.force_update_scroll()
	await process_frame
	RenderingServer.force_draw(false)
	_check(viewport.get_texture().get_image().save_png(output.path_join("lpc_workers_640x360.png")) == OK, "Save compact warehouse preview")
	preview.free()
	camera.enabled = true

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
