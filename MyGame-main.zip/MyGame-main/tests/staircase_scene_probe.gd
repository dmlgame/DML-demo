extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1152, 648)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var scene: Node2D = load("res://warehouse_main.tscn").instantiate()
	viewport.add_child(scene)
	var player: Node2D = scene.get_node("YSortActors/Player")
	var stairs: Node2D = scene.get_node("YSortActors/SecondFloorStaircaseSort/SecondFloorStaircase")
	var points := {
		"upper_steps": Vector2(283, 969),
		"lower_steps": Vector2(335, 1007),
		"rail_contact": Vector2(476, 693),
		"latest_contact": Vector2(531, 667),
		"rear_support": Vector2(272, 826),
	}
	for label in points:
		player.global_position = stairs.to_global(points[label]) - Vector2(0, 25)
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		print(label, " front=", stairs._in_front_of_marked_edge(player.global_position + Vector2(0, 25)))
		viewport.get_texture().get_image().save_png("C:/Users/nikni/AppData/Local/Temp/staircase_probe_" + label + ".png")
	quit()
