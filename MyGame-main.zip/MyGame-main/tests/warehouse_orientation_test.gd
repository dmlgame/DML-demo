extends SceneTree

const Dialogue = preload("res://warehouse_orientation_dialogue.gd")
const DemoTasks = preload("res://demo_tasks.gd")
var failed := false
var session: Node
var demo: Node
var player: CharacterBody2D
var director: CharacterBody2D

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(1152, 648)
	session = load("res://game_session.tscn").instantiate()
	session.save_store.directory = "user://tmp/orientation_%d" % Time.get_ticks_usec()
	_check(session.orientation_only and not session.animation_test_mode, "Default demo is the tour")
	root.add_child(session)
	await session._start_world("")
	await _bind_world()
	_check(demo.stage == "find_director" and not demo.completed and not demo.hint_enabled, "Start with independent director search")
	_check(demo._task_title.text == "Познакомиться со складом", "The initial objective names the tour")
	_check(demo._objective.text == "Найдите директора, он введет вас в курс дела", "Exact requested director explanation")
	_check(director.initialized and director.visible and director._catalogue.size() > 20, "Director has clear floor destinations")
	_check(session.world.get_node("WarehouseActivity").workers.size() == 20, "All twenty existing workers remain")
	_check(director.sprite.hframes == 9 and director.sprite.vframes == 4 and director.skin.get_size() == Vector2(576, 256), "Director has a complete LPC walk cycle")
	var preset: Dictionary = JSON.parse_string(FileAccess.get_file_as_string("res://assets/npcs/lpc_workers/warehouse_director.json"))
	_check(preset.selectedAnimation == "walk" and preset.selections.clothes.recolor == "black" and preset.selections.legs.recolor == "black" and preset.selections.vest.variant == "orange" and preset.selections.has("facial_eyes"), "Director uses black clothing, an orange vest and glasses")
	var found_blocks := {}
	var blocks: Node = session.world.get_node("BlockNotifications")
	for point in director._catalogue:
		found_blocks[blocks.get_block_at(point.point)] = true
	_check(found_blocks.has(1) and found_blocks.has(2) and found_blocks.has(3), "Director can roam every block")
	var worker: CharacterBody2D = session.world.get_node("WarehouseActivity").workers[0]
	for point in director._catalogue:
		if blocks.get_block_at(point.point) == 1:
			_check(not worker._activity.can_roam(point.point) and director.can_roam(point.point), "Only the director enters block one")
			break
	var original_position: Vector2 = director.global_position
	var original_speed: float = director.walk_speed
	director.walk_speed = 320
	for passage_name in ["Passage12Upper", "Passage12Lower", "Passage23Upper", "Passage23Lower"]:
		var passage: Area2D = blocks.get_node(passage_name)
		var from := passage.global_position - Vector2(80, 0)
		var to := passage.global_position + Vector2(80, 0)
		director.global_position = from - Vector2(0, 25)
		var stops: Array[Dictionary] = [{"point": to, "look_at": to, "kind": "passage"}]
		director.destinations = stops
		director._target_index = 0
		director._repath()
		_check(not director._path.is_empty(), "Director routes through " + passage_name)
		director.resting = false
		for frame in range(120):
			await physics_frame
			if (director.global_position + Vector2(0, 25)).distance_to(to) < 5:
				break
		_check((director.global_position + Vector2(0, 25)).distance_to(to) < 5, "Director physically crosses " + passage_name)
	director.global_position = original_position
	director.walk_speed = original_speed
	director.destinations = director._catalogue.duplicate()
	director._target_index = -1
	director._path.clear()
	director.resting = true
	player.global_position = demo.supervisor_point() - Vector2(0, 25)
	_check(not demo.try_interact(player), "Old supervisor tasks are hidden before the director")
	demo._process(1000)
	_check(demo.stage == "find_director" and demo._modal_kind.is_empty(), "No old assignment timer starts")
	var vehicles: Array = session.save_store._vehicles(session.world)
	for vehicle in vehicles:
		player._nearby_vehicles.clear()
		player.register_pickup_vehicle(vehicle)
		_check(not demo.can_use_vehicle(vehicle), "Equipment requires an assignment")
		var expected_hint := "Рохля\nНа данный момент рохля доступна только по поручению старшего" if vehicle.vehicle_mode == PickupVehicle.VehicleMode.PALLET_JACK else "Паллетовоз\nНа данный момент техника доступна только по поручению старшего."
		_check(demo.get_vehicle_hint(vehicle) == expected_hint, "Exact equipment availability explanation")
		player._interact_with_vehicle()
		_check(player._carried_vehicle == null and not vehicle.is_carried, "Blocked equipment cannot be carried")
	player._nearby_vehicles.clear()
	player.global_position = Vector2(20000, 20000)
	demo.request_hint()
	_check(demo._modal_kind == "hint" and not demo.hint_enabled, "Guide is optional and confirmed")
	demo._decline_hint()
	_check(not demo.hint_enabled, "Declining does not enable the guide")
	demo.request_hint()
	demo._accept_hint()
	_check(demo._route.points.size() == 2 and demo._route.points[1].is_equal_approx(director.global_position + Vector2(0, 25)), "Guide targets director feet")
	director._rest_left = 0
	var start: Vector2 = director.global_position
	for frame in range(210):
		await physics_frame
	_check(director.travelled > 40 and start.distance_to(director.global_position) > 40, "Director actually walks autonomously")
	_check(demo._route.points[1].is_equal_approx(director.global_position + Vector2(0, 25)), "Guide follows his moving position")
	player.global_position = director.global_position + Vector2(0, 40)
	director.set_physics_process(false)
	player.get_node("Camera2D").reset_smoothing()
	for frame in range(4):
		await process_frame
	await _capture("director_search")
	_check(demo.get_interaction_text(player) == "Директор склада\nНажмите E или Enter, чтобы с ним поговорить", "Exact director prompt")
	_check(demo.try_interact(player), "Director starts the conversation")
	director.set_physics_process(true)
	var stationary: Vector2 = director.global_position
	for frame in range(40):
		await physics_frame
	_check(director.conversation_locked and director.global_position == stationary and director.velocity.is_zero_approx() and director.sprite.frame_coords.x == 0, "Director stands still during dialogue")
	_key(KEY_ESCAPE)
	_check(not director.conversation_locked and demo.stage == "find_director" and not player._interaction_locked and not paused, "Escape cancels without advancing and releases the director")
	director.set_physics_process(false)
	await _conversation("director_orientation", Dialogue.DIRECTOR, "meet_shift_lead")
	_check(not director.conversation_locked and not demo.hint_enabled, "Finishing releases him and resets the optional guide")
	_check(demo._current_target_point() == demo.supervisor_point(), "Next target is the shift lead")
	player.global_position = director.global_position + Vector2(0, 40)
	await _conversation("director_orientation", Dialogue.DIRECTOR, "meet_shift_lead", false)
	_check(demo.stage == "meet_shift_lead", "Repeating a conversation cannot skip a stage")
	player.global_position = demo.supervisor_point() - Vector2(0, 25)
	await _conversation("shift_orientation", Dialogue.SHIFT_LEAD, "meet_receiving_lead")
	_check(demo._current_target_point() == demo._receiving_lead.global_position, "Guide target switches to receiving lead")
	player.global_position = demo._receiving_lead.global_position - Vector2(0, 25)
	await _conversation("receiving_orientation", Dialogue.RECEIVING_LEAD, "open_gate_19")
	_check(Dialogue.RECEIVING_LEAD.size() == 8 and not Dialogue.RECEIVING_LEAD[6].contains("На сегодня") and Dialogue.RECEIVING_LEAD[7].contains("ЗПХшника"), "Receiving introduction has the new eighth assignment page")
	_check(demo.completed and demo._zph_assignment and not demo.hint_enabled and demo._hint_button.visible, "Tour starts the paired ZPH assignment")
	demo._process(1000)
	_check(demo.stage == "open_gate_19" and demo._modal_kind.is_empty(), "The assignment requires opening the gate before equipment")
	for vehicle in vehicles:
		_check(not demo.can_use_vehicle(vehicle), "Finishing information does not unlock equipment")
	var state: Dictionary = session.save_store.capture(session.world)
	_check(session.save_store._valid(state), "Completed tour can be saved")
	for stage in DemoTasks.ORIENTATION_STAGES:
		var fixture: Dictionary = state.duplicate(true)
		fixture.demo.erase("zph_assignment")
		fixture.demo.erase("gate17_checked")
		fixture.demo.stage = stage
		fixture.demo.completed = stage == "orientation_complete"
		fixture.demo.hint_enabled = stage != "orientation_complete"
		_check(session.save_store.write_state(fixture, "slot_1"), "Save stage " + stage)
		await session._start_world("slot_1")
		await _bind_world()
		_check(demo.stage == ("meet_receiving_lead" if stage == "orientation_complete" else stage) and demo.hint_enabled == fixture.demo.hint_enabled and player._carried_vehicle == null, "Continue restores tour stage " + stage)
		_check(director.initialized and get_nodes_in_group("warehouse_director").size() == 1, "Replacing worlds retains one initialized director")
	var malformed: Dictionary = demo.get_save_state().duplicate(true)
	malformed.stage = "orientation_complete"
	malformed.completed = true
	malformed.gate19_open = true
	_check(not DemoTasks.valid_save_state(malformed), "Tour cannot contain an active unloading gate")
	malformed.gate19_open = false
	malformed.hint_enabled = true
	_check(not DemoTasks.valid_save_state(malformed), "Completed tour cannot retain an active guide")
	var old: Dictionary = state.duplicate(true)
	var jack: PickupVehicle = demo.nearest_free_transporter()
	var path: String = str(session.world.get_path_to(jack))
	old.player.vehicle = path
	old.demo = {"stage": "unload_place", "completed": true, "hint_enabled": true, "gate19_open": true, "free_time_remaining": 0, "assigned_vehicle": path, "placed_count": 2}
	_check(session.save_store.write_state(old, "slot_2"), "Existing work save remains valid")
	var bytes := FileAccess.get_file_as_bytes(session.save_store._path("slot_2"))
	await session._start_world("slot_2")
	await _bind_world()
	_check(demo.stage == "find_director" and player._carried_vehicle == null and player.move_mode == 0, "Old assignments migrate to an on-foot tour")
	_check(not session.world.get_node(path).is_carried and not player.transporter_loaded and not demo._gate19.is_open, "Migration clears cargo and parks equipment")
	_check(FileAccess.get_file_as_bytes(session.save_store._path("slot_2")) == bytes, "Reading an old save leaves its bytes unchanged")
	director.set_physics_process(false)
	player.global_position = director.global_position + Vector2(0, 40)
	demo.try_interact(player)
	demo.close_modal()
	session._return_to_menu()
	await process_frame
	_check(session.world == null and get_nodes_in_group("warehouse_director").is_empty() and not paused, "Canceling a conversation and leaving safely removes the director")
	session.free()
	if not failed:
		print("Warehouse orientation passed: director roaming, moving guide, 20 dialogue pages, mobile/desktop layout, ZPH assignment, equipment restrictions, saves and legacy migration")
	quit(1 if failed else 0)

func _bind_world() -> void:
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	director = demo._director
	for frame in range(120):
		await physics_frame
		await process_frame
		if director.initialized and session.world.get_node("WarehouseActivity").initialized:
			break
	_check(director.initialized, "Director initializes within a bounded wait")

func _conversation(kind: String, pages: Array, expected_stage: String, screenshots: bool = true) -> void:
	_check(demo.try_interact(player), "Start " + kind)
	_check(demo._conversation_kind == kind, "Correct speaker " + kind)
	for page in pages.size():
		_check(demo._dialog_text.text == pages[page] and demo._dialogue_index == page, "Correct page order " + kind)
		if screenshots:
			for size in [Vector2i(1152, 648), Vector2i(844, 390), Vector2i(390, 844), Vector2i(320, 240)]:
				root.size = size
				for frame in range(4):
					await process_frame
				demo._layout()
				_check(root.get_visible_rect().encloses(demo._dialog.get_global_rect()), "Dialog fits " + str(size))
				_check(demo._dialog.get_global_rect().encloses(demo._buttons.get_global_rect()), "Buttons fit " + str(size))
				if page == 1 and size != Vector2i(320, 240):
					await _capture(kind + "_" + str(size.x) + "x" + str(size.y))
		_key(KEY_ENTER)
	_check(demo.stage == expected_stage and demo._modal_kind.is_empty() and not player._interaction_locked, "Complete " + kind)
	root.size = Vector2i(1152, 648)

func _capture(name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	var directory := "res://tmp/orientation_qa"
	DirAccess.make_dir_recursive_absolute(directory)
	await process_frame
	RenderingServer.force_draw(false)
	_check(root.get_texture().get_image().save_png(directory.path_join(name + ".png")) == OK, "Capture " + name)

func _key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	event = event.duplicate() as InputEventKey
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
