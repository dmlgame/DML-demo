extends SceneTree

const Tasks = preload("res://demo_tasks.gd")
const Dialogue = preload("res://warehouse_orientation_dialogue.gd")
const FOOT := Vector2(0, 25)
var failed := false
var session: Node
var demo: Node
var player: CharacterBody2D

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(390, 844)
	session = load("res://game_session.tscn").instantiate()
	session.save_store.directory = "user://tmp/zph_%d" % Time.get_ticks_usec()
	root.add_child(session)
	session.touch_controls.available = true
	await session._start_world("")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	demo._director.set_physics_process(false)
	demo.stage = "meet_receiving_lead"
	demo._refresh_task()
	player.global_position = demo._receiving_lead.global_position - FOOT
	_check(demo.try_interact(player), "Receiving lead starts the introduction")
	for index in 7:
		demo._advance_dialogue()
	_check(demo._dialog_counter.text == "8 / 8" and demo._dialog_text.text == Dialogue.RECEIVING_LEAD[7], "The new assignment is page eight")
	demo.close_modal()
	_check(demo.stage == "meet_receiving_lead" and not demo._zph_assignment, "Canceling page eight does not accept the assignment")
	demo.try_interact(player)
	for index in 8:
		demo._advance_dialogue()
	_check(demo.stage == "open_gate_19" and demo._zph_assignment and not demo.gate17_checked, "Finishing the dialogue starts both assignments")
	_check(demo._objective.text.contains("19") and demo._objective.text.contains("17"), "Both assignments are visible together")
	await _check_layout()
	var transporter: PickupVehicle = demo.nearest_free_transporter()
	_check(not demo.can_use_vehicle(transporter) and not demo.can_use_vehicle(demo.nearest_free_pallet_jack()), "Opening gate nineteen must precede taking equipment")
	var gate17: Node = demo._gate17
	player.global_position = _button_point(gate17) + Vector2(0, 35) - FOOT
	_check(gate17.try_interact(player), "Gate seventeen opens for inspection")
	gate17._transition.pause()
	gate17._transition.custom_step(0.13)
	_check(gate17.is_open and not demo.gate17_checked, "Inspection does not complete in the middle of a blackout")
	gate17._transition.custom_step(1.0)
	_check(demo.gate17_checked and demo.stage == "open_gate_19" and demo.placed_count == 0, "Checking seventeen first does not skip the nineteen assignment")
	_check(gate17.dock.get_cell_atlas_coords(gate17.gate_cell) == Tasks.DockGate.OPEN_GATE, "Seventeen visibly contains an empty truck")
	var inspected: Dictionary = session.save_store.capture(session.world)
	_check(session.save_store._valid(inspected) and session.save_store.apply_state(session.world, inspected), "Inspection before unloading survives save restore")
	_check(demo.gate17_checked, "Restoration preserves the independent check")
	player.global_position = _button_point(demo._gate19) + Vector2(0, 35) - FOOT
	_check(demo.try_interact(player), "Open nineteen with the regular interaction")
	demo._gate19._transition.pause()
	demo._gate19._transition.custom_step(1.0)
	_check(demo.stage == "find_free_transporter" and demo.can_use_vehicle(transporter), "The opened gate unlocks a transporter")
	player.global_position = transporter.interaction_area.global_position + Vector2(0, 35) - FOOT
	player._nearby_vehicles.clear()
	player.register_pickup_vehicle(transporter)
	player._interact_with_vehicle()
	_check(player._carried_vehicle == transporter and demo.stage == "bring_transporter_to_gate19", "Taking the transporter starts the delivery approach")
	for index in 12:
		player.global_position = demo.gate19_approach_point() - FOOT
		player.last_direction = Vector2.UP
		player._apply_collision_profile(Vector2.UP)
		await _settle()
		demo._process(0)
		_check(demo.try_interact(player), "Take pallet " + str(index + 1))
		var transition: Tween = demo._gate19._transition
		transition.pause()
		_check(player._interaction_locked and not player.transporter_loaded and demo.remaining_pallets() == 12 - index, "Cargo stays unchanged before the screen is black")
		_check(not session.save_store.save_world(session.world, "slot_1"), "A partial fade cannot be saved")
		_check(not demo.try_interact(player), "Repeated input cannot duplicate cargo during a fade")
		transition.custom_step(0.13)
		_check(demo._gate19._shade.color.a == 1.0 and player.transporter_loaded and demo.stage == "unload_place" and demo.remaining_pallets() == 11 - index, "Exactly one pallet moves at full blackout")
		transition.custom_step(1.0)
		_check(not player._interaction_locked and not demo._gate19._transition_layer.visible, "Pickup fade restores normal input")
		if index == 4:
			_check(session.save_store.save_world(session.world, "slot_2"), "A partial paired assignment with held cargo saves")
			_check(session.save_store.apply_state(session.world, session.save_store.read_slot("slot_2")), "A partial paired assignment restores from disk")
			_check(demo._zph_assignment and demo.gate17_checked and demo.placed_count == 4 and player.transporter_loaded, "Restoring the pair does not reset its cargo or inspection")
		if index == 0:
			player.global_position = _button_point(gate17) + Vector2(0, 35) - FOOT
			_check(demo.try_interact(player), "Gate seventeen remains usable while carrying a pallet")
			gate17._transition.pause()
			gate17._transition.custom_step(1.0)
			_check(player.transporter_loaded and demo.stage == "unload_place" and demo.remaining_pallets() == 11 and demo.gate17_checked, "Operating seventeen preserves held cargo and the completed inspection")
		await _settle()
		_check(_find_placement(), "A clear unloading position exists")
		if index == 11:
			print("ZPH final placement fixture: " + str(player.global_position) + " facing " + str(player.last_direction))
		await _settle()
		_check(demo.try_interact(player) and demo.placed_count == index + 1 and not player.transporter_loaded, "Place one pallet in its assigned marking")
		if failed:
			break
	_check(demo.stage == "report_receiving_lead" and demo.placed_count == 12 and demo.gate17_checked, "Report opens only after both tasks are complete")
	_check(demo._current_target_point() == demo._receiving_lead.global_position, "The return guide targets the section lead, not the shift lead")
	var return_position := player.global_position
	player.global_position = demo._receiving_lead.global_position - FOOT
	_check(not demo.try_interact(player) and demo.get_interaction_text(player).contains("оставить паллетовоз"), "Reporting requires leaving the vehicle first")
	player.global_position = return_position
	await _check_layout()
	var finished: Dictionary = session.save_store.capture(session.world)
	var unchecked: Dictionary = finished.duplicate(true)
	unchecked.demo.gate17_checked = false
	unchecked.demo.stage = "check_gate_17"
	unchecked.gate_open = false
	_check(session.save_store.apply_state(session.world, unchecked), "A completed unload with an unchecked truck is valid")
	player.global_position = demo._receiving_lead.global_position - FOOT
	demo.try_interact(player)
	_check(demo._conversation_kind == "zph_progress" and not demo._dialog_text.text.contains("Спасибо"), "Unloading alone cannot trigger a success report")
	demo._advance_dialogue()
	_check(demo.stage == "check_gate_17", "The reminder does not finish an incomplete pair")
	player.global_position = _button_point(gate17) + Vector2(0, 35) - FOOT
	gate17.try_interact(player)
	gate17._transition.pause()
	gate17._transition.custom_step(1.0)
	_check(demo.stage == "report_receiving_lead" and demo.gate17_checked, "Checking seventeen after unloading also completes the pair")
	for override in [{"gate17_checked": false}, {"placed_count": 11}, {"zph_assignment": false}, {"gate17_checked": "yes"}]:
		var invalid: Dictionary = finished.duplicate(true)
		invalid.demo.merge(override, true)
		_check(not session.save_store._valid(invalid), "Impossible completion flags cannot bypass the pair")
	player.global_position = demo.gate19_approach_point() + Vector2(0, 200) - FOOT
	player.last_direction = Vector2.UP
	player._apply_collision_profile(Vector2.UP)
	await _settle()
	player._interact_with_vehicle()
	_check(player._carried_vehicle == null, "Leave the transporter before reporting")
	player.global_position = demo.supervisor_point() - FOOT
	demo.try_interact(player)
	_check(demo._conversation_kind == "shift_orientation", "The shift lead cannot accept the section report")
	demo.close_modal()
	player.global_position = demo._receiving_lead.global_position - FOOT
	_check(demo.try_interact(player) and demo._conversation_kind == "zph_report" and demo._dialog_title.text == Tasks.RECEIVING_SPEAKER, "Report goes to the receiving section lead")
	_check(demo._dialog_text.text.contains("17") and demo._dialog_text.text.contains("19") and demo._dialog_text.text.contains("Спасибо"), "The section lead thanks the player for both tasks")
	for index in 3:
		demo._advance_dialogue()
	_check(demo.stage == "find_stock_jack" and demo._hint_button.visible and not demo.can_use_vehicle(transporter) and demo.can_use_vehicle(demo.nearest_free_pallet_jack()), "Reporting starts the empty-pallet assignment and unlocks only a jack")
	_check(session.save_store.save_world(session.world, "slot_1"), "Completed pair saves to disk")
	await session._start_world("slot_1")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	_check(demo.stage == "find_stock_jack" and demo.gate17_checked and demo.placed_count == 12 and demo._unloading._pallets.get_child_count() == 12, "Fresh-world continuation preserves the completed pair, next assignment and floor pallets")
	session.free()
	if not failed:
		print("ZPH assignment passed: eight pages, gate ordering, both completion orders, blackout atomicity, twelve pallets, receiving report, mobile HUD and saves")
	quit(1 if failed else 0)

func _button_point(gate: Node) -> Vector2:
	return gate.objects.to_global(gate.objects.map_to_local(gate.button_cell))

func _find_placement() -> bool:
	for direction in [Vector2.UP, Vector2.DOWN, Vector2.RIGHT, Vector2.LEFT]:
		for offset in [Vector2(64, 24), Vector2(-64, 24), Vector2(0, 56), Vector2(0, -56), Vector2(32, 56), Vector2(-32, 56)]:
			player.global_position = demo._unloading.target_point() + offset - FOOT
			var target: Node2D = player._collision_for_mode(direction)
			if player._collision_profile_overlaps(target):
				continue
			player.last_direction = direction
			player._apply_collision_profile(direction)
			if demo._unloading.can_place(player):
				return true
	return false

func _check_layout() -> void:
	for size in [Vector2i(390, 844), Vector2i(320, 640), Vector2i(844, 390)]:
		root.size = size
		await _settle()
		var task: Rect2 = demo._task_panel.get_global_rect()
		_check(root.get_visible_rect().encloses(task) and demo._objective.visible, "Both objective texts fit " + str(size))
		for button in [session.touch_controls._action_button, session.touch_controls._secondary_action_button, session.touch_controls._sprint_button]:
			_check(not task.intersects(Rect2(button.position - button.shape.size / 2, button.shape.size)), "Paired objective leaves controls clear " + str(size))
	root.size = Vector2i(390, 844)

func _settle() -> void:
	for frame in 4:
		await physics_frame
		await process_frame

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
