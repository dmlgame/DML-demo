extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	if DisplayServer.get_name() == "headless":
		print("Object Y-sort render test skipped without a renderer")
		quit()
		return
	var viewport := SubViewport.new()
	viewport.size = Vector2i(160, 160)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var objects := TileMapLayer.new()
	objects.tile_set = load("res://assets/tiles/warehouse_objects_tileset.tres")
	objects.y_sort_enabled = true
	actors.add_child(objects)
	objects.set_cell(Vector2i(2, 2), 0, Vector2i(0, 6))
	var marker := Node2D.new()
	actors.add_child(marker)
	var color := ColorRect.new()
	color.color = Color(1, 0, 1, 1)
	color.size = Vector2(16, 16)
	marker.add_child(color)
	marker.position = Vector2(80, 90)
	color.position = Vector2(-8, 0)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var behind := viewport.get_texture().get_image().get_pixel(80, 98)
	marker.position.y = 110
	color.position.y = -20
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var in_front := viewport.get_texture().get_image().get_pixel(80, 98)
	if behind.is_equal_approx(color.color) or not in_front.is_equal_approx(color.color):
		push_error("The desk does not Y-sort against the player marker at its collision base: %s, %s" % [behind, in_front])
		quit(1)
		return
	objects.erase_cell(Vector2i(2, 2))
	objects.set_cell(Vector2i(2, 2), 0, Vector2i(7, 0))
	marker.position.y = 80
	color.position.y = 10
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	behind = viewport.get_texture().get_image().get_pixel(80, 98)
	marker.position.y = 90
	color.position.y = 0
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	in_front = viewport.get_texture().get_image().get_pixel(80, 98)
	if behind.is_equal_approx(color.color) or not in_front.is_equal_approx(color.color):
		push_error("The water cooler does not Y-sort at its base: %s, %s" % [behind, in_front])
		quit(1)
		return
	print("Object Y-sort render test passed")
	quit()
