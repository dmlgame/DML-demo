extends SceneTree

const DirectorScene = preload("res://assets/npcs/warehouse_director.tscn")
const FOOT_OFFSET := Vector2(0, 25)
const CAGE_POCKET := Vector2(-978, 16)
const OPEN_AISLE := Vector2(-978, -240)
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	var player: CharacterBody2D = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	for frame in range(4):
		await physics_frame
		await process_frame
	for worker in world.get_node("WarehouseActivity").workers:
		worker.set_physics_process(false)
	var director := _create_director(world, 54321)
	_check(director.initialized, "Director initializes with a reachable spawn")
	_check(director._point_is_clear(CAGE_POCKET), "Regression fixture fits feet between cages")
	_check(not director._try_spawn_at(CAGE_POCKET), "A free but sealed cage pocket is rejected")
	_check(director._try_spawn_at(OPEN_AISLE), "Open warehouse aisle is a valid spawn")
	_check(director._can_step_to(director._path[0]), "First route segment is physically clear")
	director.set_physics_process(true)
	var start := director.global_position
	for frame in range(240):
		await physics_frame
	_check(director.travelled > 100 and director.global_position.distance_to(start) > 48, "Director leaves the clear aisle in actual physics")
	director.free()
	for seed_value in range(12):
		director = _create_director(world, seed_value)
		_check(director.initialized and director.visible, "Seed %d initializes" % seed_value)
		var feet := director.global_position + FOOT_OFFSET
		_check(feet != CAGE_POCKET and director._point_is_clear(feet), "Seed %d avoids a cage pocket" % seed_value)
		_check(director.resting and director._path.is_empty() and director._target_index == -1, "Spawn validation does not leak a temporary route")
		director._rest_left = 0
		director.set_physics_process(true)
		var travelled: float = director.travelled
		for frame in range(300):
			await physics_frame
			if director.travelled - travelled > 48:
				break
		_check(director.travelled - travelled > 48, "Seed %d starts walking instead of retrying forever" % seed_value)
		director.free()
		await physics_frame
	world.free()
	if not failed:
		print("Director roaming passed: sealed cage pocket rejected, clear route start, real aisle movement, twelve seeded spawns walk, validation route cleanup")
	quit(1 if failed else 0)

func _create_director(world: Node2D, seed_value: int) -> CharacterBody2D:
	var director: CharacterBody2D = DirectorScene.instantiate()
	world.get_node("YSortActors").add_child(director)
	director.configure_director(world)
	director.set_physics_process(false)
	director._rng.seed = seed_value
	director._initialize_roaming()
	return director

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
