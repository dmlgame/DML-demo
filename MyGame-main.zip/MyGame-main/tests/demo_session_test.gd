extends SceneTree

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var session := load("res://game_session.tscn").instantiate() as Node
	session.animation_test_mode = false
	session.orientation_only = false
	session.save_store.directory = "user://tmp/demo_session_test"
	root.add_child(session)
	await session._start_world("")
	_check(session.world.has_node("DemoTasks"), "New game activates the introduction")
	var demo: Node = session.world.get_node("DemoTasks")
	var player: Node = session.world.get_node("YSortActors/Player")
	_check(not demo.completed and not demo.hint_enabled, "New introduction starts with independent search")
	demo.request_hint()
	_key(KEY_ENTER)
	await process_frame
	_check(not demo.hint_enabled and not demo._modal.visible and not player._interaction_locked, "Enter defaults to No in the hint confirmation")
	demo.request_hint()
	_key(KEY_ESCAPE)
	await process_frame
	_check(not paused and not session.menu.visible and not player._interaction_locked and not demo._modal.visible, "Escape closes confirmation without opening pause")
	_key(KEY_ESCAPE)
	await process_frame
	_check(paused and session.menu.visible, "Escape outside dialogue still opens the pause menu")
	_key(KEY_ESCAPE)
	await process_frame
	_check(not paused and not session.menu.visible, "Pause resumes normally")
	player.global_position = demo.supervisor_point() - Vector2(0, 25)
	player.set_physics_process(false)
	var event := InputEventKey.new()
	event.physical_keycode = KEY_E
	event.pressed = true
	player._unhandled_input(event)
	_check(demo._modal_kind == "conversation", "Session allows supervisor dialogue")
	_key(KEY_ESCAPE)
	await process_frame
	_check(not paused and not player._interaction_locked and not demo.completed, "Escape cancels dialogue without completing the task")
	player._unhandled_input(event)
	_key(KEY_ENTER)
	_check(demo._dialogue_index == 1, "Enter advances dialogue exactly once")
	var physical := InputEventKey.new()
	physical.keycode = KEY_U
	physical.physical_keycode = KEY_E
	physical.pressed = true
	Input.parse_input_event(physical)
	Input.flush_buffered_events()
	var released := physical.duplicate() as InputEventKey
	released.pressed = false
	Input.parse_input_event(released)
	Input.flush_buffered_events()
	_check(demo._dialogue_index == 2, "Physical E advances dialogue regardless of keyboard layout")
	_key(KEY_ESCAPE)
	await process_frame
	_check(session.save_store.save_world(session.world, "slot_1"), "Searching introduction saves through the real store")
	await session._start_world("slot_1")
	demo = session.world.get_node("DemoTasks")
	_check(not demo.completed and not demo.hint_enabled, "Continue restores an unfinished introduction")
	demo.restore_save_state({"completed": true, "hint_enabled": false})
	_check(session.save_store.save_world(session.world, "slot_1"), "Completed introduction saves")
	await session._start_world("slot_1")
	demo = session.world.get_node("DemoTasks")
	_check(demo.completed and demo._hint_button.visible == not demo.FREE_TIME_ENABLED, "Continue restores completion and the next objective instead of repeating the search")
	var legacy: Dictionary = session.save_store.capture(session.world)
	legacy.erase("demo")
	_check(session.save_store.write_state(legacy, "slot_2"), "Legacy save fixture remains valid")
	await session._start_world("slot_2")
	_check(not session.world.has_node("DemoTasks") and session.world.get_node("YSortActors/Player")._demo_tasks == null, "Legacy saves retain their existing sandbox")
	await session._start_world("")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	demo.restore_save_state({"completed": true, "hint_enabled": false, "stage": "find_receiving_lead", "free_time_remaining": 0.0, "gate19_open": false})
	_check(demo.stage == "return_to_supervisor", "Earlier assignment stages migrate to the shift supervisor")
	player.global_position = demo.supervisor_point() - Vector2(0, 25)
	await process_frame
	await process_frame
	_check(demo._modal_kind == "assignment", "The real session opens the assignment on approach")
	_key(KEY_ESCAPE)
	await process_frame
	_check(not paused and not session.menu.visible and demo._modal_kind.is_empty(), "Escape cancels the assignment without opening the pause menu")
	_key(KEY_E)
	_check(demo._modal_kind == "assignment", "Real E reopens the assignment")
	_key(KEY_ENTER)
	_check(demo.stage == "open_gate_19" and demo._modal_kind.is_empty() and not demo._gate19._busy, "Enter acknowledges exactly once without leaking into a world interaction")
	_check(session.save_store.save_world(session.world, "slot_1"), "The active delivery objective saves through the session")
	await session._start_world("slot_1")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	_check(demo.stage == "open_gate_19" and not demo._gate19.is_open, "Continue restores the active assignment and closed gate")
	var button: Vector2 = demo._gate19.objects.to_global(demo._gate19.objects.map_to_local(demo.GATE_19_BUTTON_CELL))
	player.global_position = button + Vector2(0, 35)
	_key(KEY_ENTER)
	var gate_transition: Tween = demo._gate19._transition
	_check(gate_transition != null and player._interaction_locked, "Real Enter opens the assigned gate with a transition")
	gate_transition.pause()
	gate_transition.custom_step(1.0)
	_check(demo.stage == "find_free_transporter" and demo._gate19.is_open and demo._hint_button.visible and not demo.hint_enabled, "The real session starts the pallet jack search with an optional hint")
	demo.request_hint()
	demo._buttons.get_child(1).pressed.emit()
	_check(session.save_store.save_world(session.world, "slot_1"), "Cargo arrival saves through the session")
	await session._start_world("slot_1")
	demo = session.world.get_node("DemoTasks")
	_check(demo.stage == "find_free_transporter" and demo._gate19.is_open and demo._gate19.dock.get_cell_atlas_coords(demo.GATE_19_CELL) == demo.LOADED_GATE_ATLAS and demo._hint_button.visible and demo.hint_enabled and demo._route.enabled and demo._objective.text == "Найдите свободный паллетовоз", "Continue restores loaded cargo, the pallet jack assignment and its optional hint")
	player = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	var jack: PickupVehicle = demo.nearest_free_transporter()
	player.global_position = jack.interaction_area.global_position + Vector2(0, 35) - Vector2(0, 25)
	player._nearby_vehicles.clear()
	player.register_pickup_vehicle(jack)
	_key(KEY_E)
	_check(demo.stage == "bring_transporter_to_gate19" and player._carried_vehicle == jack and player.move_mode == player.MoveMode.TRANSPORTER, "Real E takes a free jack and starts the return task")
	var assigned: String = demo.assigned_vehicle
	_check(session.save_store.save_world(session.world, "slot_1"), "A mounted assigned jack saves through the real session")
	await session._start_world("slot_1")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	_check(demo.stage == "bring_transporter_to_gate19" and demo.assigned_vehicle == assigned and player._carried_vehicle == session.world.get_node(assigned) and player.move_mode == player.MoveMode.TRANSPORTER, "Continue restores the selected jack, animation mode and return objective in a new world")
	await session._start_world("")
	_check(session.world.has_node("DemoTasks") and not session.world.get_node("DemoTasks").completed, "A new game resets the introduction")
	demo = session.world.get_node("DemoTasks")
	demo.request_hint()
	demo._buttons.get_child(1).pressed.emit()
	await physics_frame
	await process_frame
	await session._start_world("")
	await process_frame
	await process_frame
	_check(not session.world.get_node("DemoTasks").hint_enabled, "Replacing a world safely removes the previous game's guide")
	session.free()
	paused = false
	if not failed:
		print("Demo session passed: new-game activation, modal/pause Escape priority, physical E/Enter, delivery assignment and loaded-gate save/continue, completed progress, legacy sandbox and new-game reset")
	quit(1 if failed else 0)

func _key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	event = InputEventKey.new()
	event.keycode = code
	event.physical_keycode = code
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
