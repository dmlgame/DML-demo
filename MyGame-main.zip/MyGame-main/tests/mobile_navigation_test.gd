extends SceneTree

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(844, 390)
	var session: Node = load("res://game_session.tscn").instantiate()
	session.animation_test_mode = false
	session.save_store.directory = "res://tmp/decor_rc_qa/navigation_test"
	root.add_child(session)
	var controls: Control = session.touch_controls
	controls.available = true
	await session._start_world("")
	await _settle()
	var player: CharacterBody2D = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	var camera: Camera2D = player.get_node("Camera2D")
	var zones: Node2D = session.world.get_node("BlockNotifications")
	var minimap: Control = controls._minimap
	_check(camera.is_current(), "Minimap camera does not replace the player's camera")
	_check(minimap._viewport.world_2d == session.world.get_world_2d(), "Minimap shares the world without duplicating its logic")
	_check(minimap.display_bounds.encloses(zones.warehouse_rect), "Map covers all warehouse blocks")
	_check(minimap._viewport.render_target_update_mode in [SubViewport.UPDATE_ONCE, SubViewport.UPDATE_DISABLED], "Map caches a single world snapshot")
	for x in [-6200.0, -2200.0, 2200.0]:
		_check(zones.get_zone_name(Vector2(x, -1300)) == "Мезонин", "Mezzanine band is named across the warehouse")
		_check(zones.get_zone_name(Vector2(x, -2400)).begins_with("Блок "), "Other operational areas keep block names")
	player.global_position = Vector2(-2200, -1325)
	minimap._update_markers()
	_check(minimap._caption.text == "Мезонин", "Mobile map displays the current mezzanine zone")
	await _settle()
	player._update_interaction_hint()
	_check(not player._interaction_hint.visible, "Mezzanine has no persistent interaction explanation")
	var first_marker: Vector2 = minimap.marker
	player.global_position = Vector2(2200, -2400)
	minimap._update_markers()
	_check(minimap.marker.x > first_marker.x + 40 and minimap._caption.text == "Блок 3", "Map tracks movement between blocks")
	player.global_position = Vector2(20000, 20000)
	for viewport_size in [Vector2i(844, 390), Vector2i(390, 844), Vector2i(812, 320)]:
		root.size = viewport_size
		await _settle()
		camera.zoom = Vector2(2, 2)
		var center := Vector2(viewport_size) / 2.0
		_touch(3, center - Vector2(40, 0), true)
		_touch(4, center + Vector2(40, 0), true)
		_drag(3, center - Vector2(80, 0))
		_drag(4, center + Vector2(80, 0))
		_check(camera.zoom.is_equal_approx(Vector2.ONE * controls.MAX_ZOOM), "Spreading fingers zooms in and respects its limit " + str(viewport_size))
		_drag(3, center - Vector2(10, 0))
		_drag(4, center + Vector2(10, 0))
		_check(camera.zoom.is_equal_approx(Vector2.ONE * controls.MIN_ZOOM), "Pinching zooms out and respects its limit " + str(viewport_size))
		_check(player._read_direction().is_zero_approx(), "Pinching does not move the character")
		_touch(3, center - Vector2(10, 0), false)
		_touch(4, center + Vector2(10, 0), false)
		_check(controls._zoom_fingers.is_empty(), "Releasing both fingers ends zoom")
		camera.zoom = Vector2(2, 2)
		_touch(0, controls._zoom_in_button.position, true)
		_touch(0, controls._zoom_in_button.position, false)
		_check(camera.zoom.is_equal_approx(Vector2(2.4, 2.4)), "Zoom-in icon changes the camera")
		_touch(0, controls._zoom_out_button.position, true)
		_touch(0, controls._zoom_out_button.position, false)
		_check(camera.zoom.is_equal_approx(Vector2(2, 2)), "Zoom-out icon reverses one step")
		_check(controls._zoom_fingers.is_empty(), "HUD touches never start a zoom gesture")
		_touch(0, controls.joystick_center + Vector2(30, 0), true)
		_touch(1, controls._sprint_button.position, true)
		_check(player._touch_sprinting and controls._zoom_fingers.is_empty() and camera.zoom == Vector2(2, 2), "Steering and sprint stay independent of camera zoom")
		controls.reset_input()
		_touch(0, controls.joystick_center, false)
		_touch(1, controls._sprint_button.position, false)
		_touch(3, center - Vector2(40, 0), true)
		_touch(4, center + Vector2(40, 0), true)
		controls._notification(Node.NOTIFICATION_APPLICATION_FOCUS_OUT)
		_drag(4, center + Vector2(140, 0))
		_check(controls._zoom_fingers.is_empty() and camera.zoom == Vector2(2, 2), "Focus loss cancels the held pinch")
		_touch(3, center - Vector2(40, 0), false)
		_touch(4, center + Vector2(140, 0), false)
	session._pause()
	_check(not controls.visible and not minimap.is_visible_in_tree(), "Map hides with the pause menu")
	session._resume()
	_check(minimap.is_visible_in_tree(), "Map returns on resume")
	controls.set_active(null, false)
	_check(minimap.player == null and not minimap.display_bounds.has_area(), "Unbinding the world clears the map and marker")
	session.free()
	paused = false
	if not failed:
		print("Mobile navigation tests passed: mezzanine, map, two-finger zoom, limits, buttons and lifecycle")
	quit(1 if failed else 0)

func _touch(index: int, position: Vector2, pressed: bool) -> void:
	var event := InputEventScreenTouch.new()
	event.index = index
	event.position = position
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _drag(index: int, position: Vector2) -> void:
	var event := InputEventScreenDrag.new()
	event.index = index
	event.position = position
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _settle() -> void:
	for frame in range(4):
		await process_frame

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
