extends SceneTree

const FOOT_OFFSET := Vector2(0, 25)
const PASSAGES := {
	"Passage12Upper": [Vector2(-4176, -2640), Vector2(192, 288), 1, 2],
	"Passage12Lower": [Vector2(-4176, -528), Vector2(192, 288), 1, 2],
	"Passage23Upper": [Vector2(496, -2576), Vector2(192, 416), 2, 3],
	"Passage23Lower": [Vector2(496, -368), Vector2(192, 224), 2, 3],
}
const TITLES := {
	1: "Первый блок (строительные работы)",
	2: "Второй блок",
	3: "Третий блок",
}

var failed := false
var player: CharacterBody2D
var notifications: Node2D
var banner: RichTextLabel

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	player = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	notifications = world.get_node("BlockNotifications")
	notifications.set_physics_process(false)
	notifications.set_process(false)
	banner = notifications.get("_banner")
	var camera := player.get_node("Camera2D") as Camera2D
	camera.position_smoothing_enabled = false
	var wall := world.get_node("WallLayer") as TileMapLayer
	var original_wall := wall.tile_map_data.duplicate()
	await _settle()
	_check(notifications._passages.size() == 4, "Four separate passages")
	_check(not banner.visible, "No block notification on scene start")
	_check(banner.mouse_filter == Control.MOUSE_FILTER_IGNORE and banner.focus_mode == Control.FOCUS_NONE, "Notification does not capture input")
	for block_number in TITLES:
		var feet := Vector2([-4300, 0, 620][block_number - 1], -2640)
		_seed(feet)
		_check(notifications.current_block == block_number and not banner.visible, "Restored position initializes silently in block %d" % block_number)
	for passage_name in PASSAGES:
		var passage := notifications.get_node(passage_name) as Area2D
		var expected: Array = PASSAGES[passage_name]
		var shape := passage.get_node("CollisionShape2D") as CollisionShape2D
		_check(passage.position == expected[0] and shape.shape.size == expected[1], "Zone matches the actual wall opening at " + passage_name)
		_check(passage.get_meta("west_block") == expected[2] and passage.get_meta("east_block") == expected[3], "Destination metadata at " + passage_name)
		_check(passage.collision_layer == 0 and passage.collision_mask == 0 and not passage.monitoring and not passage.monitorable, "Passage does not add a physics barrier")
		for direction in [-1, 1]:
			var destination: int = expected[2] if direction == -1 else expected[3]
			var before := passage.global_position - Vector2(direction * 72, 0)
			var after := passage.global_position + Vector2(direction * 72, 0)
			_cross(before, after)
			_check(notifications.current_block == destination and banner.text == TITLES[destination] and banner.visible, "Correct destination in both directions at " + passage_name)
			notifications._process(0.2)
			var remaining: float = notifications._remaining
			player.global_position += Vector2(direction * 8, 8)
			notifications._physics_process(0.016)
			_check(notifications._remaining == remaining, "Movement inside one block does not restart notification")
			camera.force_update_scroll()
			await _capture(viewport, passage_name + ("_west" if direction == -1 else "_east"))
		_seed(passage.global_position - Vector2(80, 0))
		player.global_position = passage.global_position - Vector2(8, 0) - FOOT_OFFSET
		notifications._physics_process(0.016)
		player.global_position = passage.global_position - Vector2(80, 0) - FOOT_OFFSET
		notifications._physics_process(0.016)
		_check(not banner.visible, "Approaching and turning back does not announce a transition")

	for edge in [notifications.mezzanine_rect.position.y, notifications.mezzanine_rect.end.y]:
		var direction := 1.0 if edge == notifications.mezzanine_rect.position.y else -1.0
		_cross(Vector2(-2200, edge - direction * 4), Vector2(-2200, edge + direction * 4))
		_check(banner.visible and banner.text == "Мезонин", "Entering mezzanine shows the existing temporary center banner")
		notifications._process(0.2)
		await _settle()
		player._update_interaction_hint()
		_check(not player._interaction_hint.visible, "Mezzanine does not add a permanent top-left explanation")
		_check(is_equal_approx(banner.get_global_rect().get_center().x, viewport.size.x / 2.0), "Mezzanine title uses the same horizontal center as block transitions")
		var remaining: float = notifications._remaining
		notifications._physics_process(0.016)
		_check(notifications._remaining == remaining, "Standing inside mezzanine does not restart the banner")
		notifications._process(notifications.notification_duration)
		_check(not banner.visible, "Mezzanine notification disappears on its own")
		notifications._physics_process(0.016)
		_check(not banner.visible, "Mezzanine notification remains hidden while standing inside")
		_seed(Vector2(-2200, edge + direction * 4))
		_check(not banner.visible, "Restoring a save inside mezzanine stays silent")

	var upper := notifications.get_node("Passage23Upper") as Area2D
	_cross(upper.global_position - Vector2(240, 60), upper.global_position + Vector2(240, 60))
	_check(banner.text == TITLES[3], "Fast diagonal movement cannot skip the passage")
	_cross(Vector2(-4450, -2640), Vector2(750, -2640))
	_check(banner.text == TITLES[3], "A segment crossing two boundaries selects the final destination")
	_cross(Vector2(750, -2640), Vector2(-4450, -2640))
	_check(banner.text == TITLES[1], "Two-boundary return selects the first block")
	_cross(upper.global_position + Vector2(-120, 500), upper.global_position + Vector2(120, 500))
	_check(not banner.visible, "Crossing a boundary outside the opening is not a passage transition")
	var upper_shape := upper.get_node("CollisionShape2D") as CollisionShape2D
	upper_shape.disabled = true
	_cross(upper.global_position - Vector2(72, 0), upper.global_position + Vector2(72, 0))
	_check(not banner.visible, "Disabled passage does not announce")
	upper_shape.disabled = false
	for mode in [player.MoveMode.ON_FOOT, player.MoveMode.PALLET_JACK, player.MoveMode.TRANSPORTER]:
		player.set_move_mode(mode)
		_cross(upper.global_position - Vector2(72, 0), upper.global_position + Vector2(72, 0))
		_check(banner.text == TITLES[3] and banner.visible, "Passage detection works in every movement mode")
	player.set_move_mode(player.MoveMode.ON_FOOT)
	var original_walk_speed: float = player.walk_speed
	player.walk_speed = 480.0
	for passage_name in PASSAGES:
		var passage := notifications.get_node(passage_name) as Area2D
		for direction in [-1, 1]:
			_seed(passage.global_position - Vector2(direction * 80, 0))
			await _settle()
			for step in 24:
				await physics_frame
				player._move_with_direction(Vector2(direction, 0), false, 1.0 / 60.0)
				notifications._physics_process(1.0 / 60.0)
			var destination := int(passage.get_meta("west_block" if direction == -1 else "east_block"))
			_check(notifications.current_block == destination and banner.visible and banner.text == TITLES[destination], "Real movement crosses the existing opening at " + passage_name)
	player.walk_speed = original_walk_speed

	_cross(upper.global_position - Vector2(72, 0), upper.global_position + Vector2(72, 0))
	_check(is_zero_approx(banner.modulate.a), "Notification fades in")
	notifications._process(0.075)
	_check(banner.modulate.a > 0.0 and banner.modulate.a < 1.0, "Fade-in has an intermediate opacity")
	notifications._process(0.2)
	_check(is_equal_approx(banner.modulate.a, 1.0), "Title becomes fully readable")
	notifications._process(notifications.notification_duration - 0.45)
	_check(banner.visible and banner.modulate.a > 0.0 and banner.modulate.a < 1.0, "Notification fades out")
	notifications._process(1.0)
	_check(not banner.visible, "Notification disappears after its duration")
	_cross(upper.global_position - Vector2(72, 0), upper.global_position + Vector2(72, 0))
	player.global_position = upper.global_position - Vector2(72, 0) - FOOT_OFFSET
	notifications._physics_process(0.016)
	_check(banner.text == TITLES[2] and notifications._remaining == notifications.notification_duration, "Rapid return replaces the previous title")

	var interaction: RichTextLabel = player.get("_interaction_hint")
	interaction.text = "[color=#ff6868]Стол приемки[/color]"
	interaction.show()
	for viewport_size in [Vector2i(1100, 619), Vector2i(320, 240)]:
		viewport.size = viewport_size
		for block_number in [1, 2, 3, 1, 2]:
			notifications._show_notification(block_number)
			notifications._process(0.2)
			await _settle()
			notifications._layout_banner()
			var banner_rect := Rect2(banner.get_global_transform_with_canvas().origin, banner.size)
			var interaction_rect := Rect2(interaction.get_global_transform_with_canvas().origin, interaction.size)
			_check(Rect2(Vector2.ZERO, Vector2(viewport_size)).encloses(banner_rect), "Block %d fits %s: %s" % [block_number, viewport_size, banner_rect])
			_check(not banner_rect.intersects(interaction_rect), "Block title does not cover interaction hints")
			await _capture(viewport, "layout_%dx%d_block_%d" % [viewport_size.x, viewport_size.y, block_number])
	_check(wall.tile_map_data == original_wall, "Block notifications leave existing wall data unchanged")
	world.free()
	viewport.free()
	if not failed:
		print("Block notifications passed: four openings, eight directions, silent startup/restore, no approach spam, fast diagonal crossings, latest destination, all movement modes, fades, rapid return, desktop/mobile layout and unchanged walls")
	quit(1 if failed else 0)

func _seed(feet: Vector2) -> void:
	player.global_position = feet - FOOT_OFFSET
	notifications._tracking_started = false
	notifications._remaining = 0.0
	banner.hide()
	notifications._physics_process(0.016)

func _cross(before: Vector2, after: Vector2) -> void:
	_seed(before)
	player.global_position = after - FOOT_OFFSET
	notifications._physics_process(0.016)

func _settle() -> void:
	await physics_frame
	await process_frame
	await process_frame

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var output := OS.get_environment("BLOCK_NOTIFICATION_QA_DIR")
	if output.is_empty():
		output = "user://tmp/block_notifications_qa"
	DirAccess.make_dir_recursive_absolute(output)
	_check(viewport.get_texture().get_image().save_png(output.path_join(name + ".png")) == OK, "Save block notification preview")

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
