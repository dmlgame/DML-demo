extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(320, 160)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	viewport.add_child(world)
	var actors: Node2D = world.get_node("YSortActors")
	var front_sort: Node2D = actors.get_node("FrontWallSort")
	var wall: TileMapLayer = front_sort.get_node("FrontWallLayer")
	var door: TileMapLayer = front_sort.get_node("FrontDoorLayer")
	var player: CharacterBody2D = actors.get_node("Player")
	var controller: Node = world.get_node("FrontOcclusion")
	player.set_physics_process(false)
	player.get_node("Camera2D").enabled = false
	for child in world.get_children():
		if child is CanvasItem and child != actors:
			child.visible = false
	actors.get_node("BackWallSort").visible = false
	player.visible = false
	player.global_position = Vector2(208, 160)
	controller._process(1.0)
	if wall.material == door.material:
		return _fail("Wall and door must use separate shader materials")
	if wall.material.get_shader_parameter("fade_amount") != 0.0:
		return _fail("Front wall faded while the player was in front")
	player.global_position = Vector2(208, 110)
	controller._process(1.0)
	if wall.material.get_shader_parameter("fade_amount") != 0.0:
		return _fail("Front wall faded before the player crossed its Y-sort origin")
	if DisplayServer.get_name() == "headless":
		player.global_position = Vector2(208, 88)
		controller._process(1.0)
		if wall.material.get_shader_parameter("fade_amount") != 1.0 or door.material.get_shader_parameter("fade_amount") != 1.0:
			return _fail("Front wall and door did not fade behind the player")
		player.global_position = Vector2(208, -128)
		controller._process(1.0)
		if wall.material.get_shader_parameter("fade_amount") != 0.0:
			return _fail("Front wall did not restore after the player passed it")
		print("Front wall occlusion state tests passed")
		quit()
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var before := viewport.get_texture().get_image()
	player.global_position = Vector2(208, 88)
	controller._process(1.0)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var after := viewport.get_texture().get_image()
	if before.get_pixel(48, 48).a < 0.99 or after.get_pixel(48, 48).a > 0.4:
		return _fail("Front wall upper section did not become translucent")
	if before.get_pixel(48, 124).a < 0.99 or after.get_pixel(48, 124).a < 0.99:
		return _fail("Front wall collision base became translucent")
	if before.get_pixel(180, 80).a < 0.99 or after.get_pixel(180, 80).a > 0.6:
		return _fail("Open door frame did not become translucent")
	if before.get_pixel(180, 124).a < 0.99 or after.get_pixel(180, 124).a < 0.99:
		return _fail("Open door collision base became translucent")
	world.position.x = -1500.0
	player.global_position = Vector2(100, 88)
	controller._process(1.0)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var shutter := viewport.get_texture().get_image()
	if shutter.get_pixel(80, 112).a > 0.4 or shutter.get_pixel(80, 114).a < 0.99:
		return _fail("Wide wall section faded below its collision base")
	player.global_position = Vector2(208, 160)
	controller._process(1.0)
	var sides: TileMapLayer = world.get_node("WallLayer")
	for x_offset in [7720.0, -4408.0]:
		world.position.x = x_offset
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var front_only := viewport.get_texture().get_image()
		sides.visible = true
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var with_sides := viewport.get_texture().get_image()
		var checked := 0
		for y in range(0, 128):
			for x in range(8, 40):
				var front_pixel := front_only.get_pixel(x, y)
				if front_pixel.a > 0.99:
					checked += 1
					if not front_pixel.is_equal_approx(with_sides.get_pixel(x, y)):
						return _fail("Side wall renders over the front wall")
		if checked == 0:
			return _fail("Wall junction was not visible in the render test")
		sides.visible = false
	print("Front wall occlusion render tests passed")
	quit()


func _fail(message: String) -> void:
	push_error(message)
	quit(1)
