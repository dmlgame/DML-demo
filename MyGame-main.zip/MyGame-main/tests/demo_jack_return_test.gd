extends SceneTree

const DemoTasks = preload("res://demo_tasks.gd")
const FOOT_OFFSET := Vector2(0, 25)
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var camera := player.get_node("Camera2D") as Camera2D
	camera.position_smoothing_enabled = false
	var demo := DemoTasks.new()
	demo.name = "DemoTasks"
	world.add_child(demo)
	demo.set_process(false)
	demo.restore_save_state({"completed": true, "hint_enabled": false, "stage": "find_free_transporter", "free_time_remaining": 0.0, "gate19_open": true})
	var jack := world.get_node("YSortActors/TransporterSprites").get_child(0) as PickupVehicle
	var other := world.get_node("YSortActors/TransporterSprites").get_child(1) as PickupVehicle
	var transporter := world.get_node("YSortActors/PalletJackAssets").get_child(0) as PickupVehicle
	var old_transporter := transporter.global_position
	jack.global_position = demo.gate19_approach_point() + Vector2(0, 240)
	player.global_position = jack.interaction_area.global_position + Vector2(0, 35) - FOOT_OFFSET
	camera.force_update_scroll()
	await _settle(demo)
	_check(not player._collision_profile_overlaps(player.collision_on_foot), "The parked jack is reachable on foot")
	_check(demo.can_use_vehicle(jack) and not demo.can_use_vehicle(transporter), "The search unlocks free jacks, not transporters")
	player._nearby_vehicles.clear()
	player.register_pickup_vehicle(transporter)
	_press(player, KEY_E)
	_check(player._carried_vehicle == null and not transporter.is_carried and demo.stage == "find_free_transporter", "A transporter remains unavailable during the jack task")
	transporter.global_position += player.global_position - transporter.interaction_area.global_position
	player.register_pickup_vehicle(jack)
	player._update_interaction_hint()
	_check(player._nearest_pickup_vehicle() == jack and player._interaction_hint.get_parsed_text() == "Паллетовоз\nНажмите E или Enter, чтобы сесть в транспорт", "The action and pickup select the assigned transporter even with a nearer blocked jack")
	await _capture(viewport, demo, "jack_pickup_action")
	_press(player, KEY_ENTER, true)
	_check(player._carried_vehicle == null, "Autorepeat cannot take the jack")
	_press(player, KEY_ENTER)
	transporter.global_position = old_transporter
	await _settle(demo)
	var assigned := str(world.get_path_to(jack))
	_check(player._carried_vehicle == jack and player.move_mode == player.MoveMode.TRANSPORTER and jack.is_carried and not jack.visible and jack.solid_shape.disabled, "Enter takes the jack and hides the parked duplicate")
	_check(player.transporter_visual.visible and not player.on_foot_visual.visible and not player.pallet_jack_visual.visible and player.transporter_sprite.texture == player.TRANSPORTER_EMPTY_TEXTURE, "Pickup uses the existing empty transporter animation")
	_check(demo.stage == "bring_transporter_to_gate19" and demo.assigned_vehicle == assigned and demo._objective.text == "Подъедьте к воротам №19 на паллетовозе", "Pickup starts the return-to-gate task with the selected jack")
	_check(demo.can_use_vehicle(jack) and not demo.can_use_vehicle(other) and not demo.can_use_vehicle(transporter), "Only the selected jack remains assigned")
	demo.request_hint()
	demo._buttons.get_child(1).pressed.emit()
	_check(demo._route.points.size() == 2 and demo._route.points[-1].is_equal_approx(demo.gate19_approach_point()), "The optional guide now points to the approach outside gate 19")
	await _capture(viewport, demo, "return_with_jack")
	var store := WarehouseSaveStore.new()
	store.directory = "user://tmp/demo_jack_return_test"
	_check(store.save_world(world, "slot_1"), "The assigned carried jack can be saved")
	var carrying := store.read_slot("slot_1")
	_check(carrying.player.vehicle == assigned and carrying.demo.assigned_vehicle == assigned and carrying.demo.stage == "bring_transporter_to_gate19", "Save contains the same carried and assigned jack identities")
	_press(player, KEY_E)
	await _settle(demo)
	_check(player._carried_vehicle == null and player.move_mode == player.MoveMode.ON_FOOT and not jack.is_carried and jack.visible and not jack.solid_shape.disabled, "E can leave the selected jack on the floor")
	_check(demo.stage == "bring_transporter_to_gate19" and demo.assigned_vehicle == assigned and demo._objective.text.contains("Сядьте в выбранный паллетовоз"), "Dropping keeps the reservation and explains how to continue")
	_check(demo._route.points.size() == 2 and demo._route.points[-1].is_equal_approx(jack.interaction_area.global_position), "After dropping, the guide leads back to the same jack")
	_check(store.save_world(world, "slot_2"), "A dropped assigned jack can be saved")
	var dropped := store.read_slot("slot_2")
	_check(dropped.player.vehicle.is_empty() and dropped.demo.assigned_vehicle == assigned, "Dropped save does not lose the reservation")
	_check(store.apply_state(world, carrying) and player._carried_vehicle == jack and player.move_mode == player.MoveMode.TRANSPORTER and demo.assigned_vehicle == assigned, "Loading the carried state restores mode and quest ownership")
	_check(store.apply_state(world, dropped) and player._carried_vehicle == null and jack.visible and demo.can_use_vehicle(jack) and not demo.can_use_vehicle(other), "Loading the dropped state restores only the assigned jack's permission")
	player._nearby_vehicles.clear()
	player.register_pickup_vehicle(other)
	player._update_interaction_hint()
	_press(player, KEY_E)
	_check(player._carried_vehicle == null and not other.is_carried, "The dropped jack cannot be substituted with another vehicle")
	player.register_pickup_vehicle(jack)
	_press(player, KEY_E)
	await _settle(demo)
	_check(player._carried_vehicle == jack and demo.stage == "bring_transporter_to_gate19", "E retakes the reserved jack")
	for override in [{"assigned_vehicle": ""}, {"assigned_vehicle": 7}, {"assigned_vehicle": "../bad"}, {"stage": "find_free_transporter"}, {"gate19_open": false}]:
		var invalid := carrying.duplicate(true)
		invalid.demo.merge(override, true)
		_check(not store.apply_state(world, invalid) and player._carried_vehicle == jack, "Invalid jack assignment is rejected before changing the world")
	var wrong_vehicle := carrying.duplicate(true)
	wrong_vehicle.player.vehicle = str(world.get_path_to(other))
	_check(not store.apply_state(world, wrong_vehicle) and player._carried_vehicle == jack, "A save cannot carry an unassigned jack")
	wrong_vehicle.player.vehicle = str(world.get_path_to(transporter))
	_check(not store.apply_state(world, wrong_vehicle) and player._carried_vehicle == jack, "A save cannot bypass the transporter restriction")
	var missing := carrying.duplicate(true)
	missing.demo.assigned_vehicle = "YSortActors/TransporterSprites/MissingJack"
	missing.player.vehicle = missing.demo.assigned_vehicle
	missing.vehicles[missing.demo.assigned_vehicle] = [0, 0]
	_check(not store.apply_state(world, missing) and player._carried_vehicle == jack, "A missing assigned jack is rejected before changing the world")
	jack.vehicle_mode = PickupVehicle.VehicleMode.PALLET_JACK
	_check(not store.apply_state(world, carrying) and player._carried_vehicle == jack, "A transporter in a jack path is rejected at runtime")
	jack.vehicle_mode = PickupVehicle.VehicleMode.TRANSPORTER
	player.global_position = demo.gate19_approach_point() + Vector2(512, 0) - FOOT_OFFSET
	demo._process(0.0)
	_check(demo.stage == "bring_transporter_to_gate19", "A neighboring gate does not complete the return task")
	player.global_position = demo.gate19_approach_point() + Vector2(0, 180) - FOOT_OFFSET
	player.last_direction = Vector2.UP
	player._apply_collision_profile(Vector2.UP)
	player._update_active_visual(false, false, 0.0)
	var before := player.global_position
	var animated_frames := {}
	for frame in 180:
		await physics_frame
		player._move_with_direction(Vector2.UP, false, 1.0 / 60.0, Vector2.UP)
		animated_frames[player._vehicle_frame] = true
		demo._process(0.0)
		if demo.stage == "at_gate19_with_transporter":
			break
	_check(player.global_position.y < before.y - 80.0 and animated_frames.size() > 1, "The existing jack animation moves and advances frames on the way to the gate")
	_check(demo.stage == "at_gate19_with_transporter" and player._carried_vehicle == jack and not player._interaction_locked, "Walking to gate 19 starts the unloading objective without automatically taking cargo")
	_check(not player._collision_profile_overlaps(player._active_collision), "The loaded approach is outside real collisions")
	_check(not demo._route.enabled and demo._hint_button.visible and demo._objective.text == "Подъедьте на паллетовозе к воротам №19 и заберите паллет. Выгрузите фуру полностью.", "Arrival asks for unloading the whole truck and retains an optional hint")
	camera.force_update_scroll()
	await _capture(viewport, demo, "jack_at_gate_19")
	_check(store.save_world(world, "slot_3"), "Arrival with the jack can be saved")
	var arrived := store.read_slot("slot_3")
	var no_jack := arrived.duplicate(true)
	no_jack.player.vehicle = ""
	_check(not store.apply_state(world, no_jack) and player._carried_vehicle == jack, "Arrival cannot be restored without the assigned carried jack")
	_press(player, KEY_ENTER)
	await _settle(demo)
	_check(demo.stage == "unload_place" and player._carried_vehicle == jack and player.transporter_loaded, "Enter at the gate takes the first pallet instead of dropping the jack")
	_check(store.apply_state(world, arrived) and demo.stage == "at_gate19_with_transporter" and player._carried_vehicle == jack, "Loading arrival restores the same jack at gate 19")
	for size in [Vector2i(640, 360), Vector2i(320, 240)]:
		viewport.size = size
		_check(store.apply_state(world, carrying), "Restore carrying state for compact UI")
		camera.force_update_scroll()
		await _capture(viewport, demo, "return_with_jack_%dx%d" % [size.x, size.y])
		_check_inside(viewport, demo._task_panel, "Return objective fits the compact viewport")
		_check(store.apply_state(world, arrived), "Restore arrival for compact UI")
		camera.force_update_scroll()
		await _capture(viewport, demo, "jack_at_gate_19_%dx%d" % [size.x, size.y])
		_check_inside(viewport, demo._task_panel, "Arrival confirmation fits the compact viewport")
	world.free()
	viewport.free()
	if not failed:
		print("Demo jack return passed: E/Enter pickup, allowed-vehicle priority, existing animation/movement, reserved identity, drop/retake, gate 19 arrival, disk restore, invalid/missing vehicle rejection and compact layouts")
	quit(1 if failed else 0)

func _press(player: Node, code: Key, echo := false) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	event.echo = echo
	player._unhandled_input(event)

func _settle(demo: Node) -> void:
	await physics_frame
	await physics_frame
	await process_frame
	await process_frame
	demo._process(0.0)

func _capture(viewport: SubViewport, demo: Node, name: String) -> void:
	await _settle(demo)
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var output := OS.get_environment("DEMO_QA_DIR")
	if output.is_empty():
		output = "user://tmp/demo_jack_return_qa"
	DirAccess.make_dir_recursive_absolute(output)
	_check(viewport.get_texture().get_image().save_png(output.path_join(name + ".png")) == OK, "Save jack return preview")

func _check_inside(viewport: SubViewport, control: Control, message: String) -> void:
	_check(Rect2(Vector2.ZERO, Vector2(viewport.size)).encloses(Rect2(control.global_position, control.size)), message)

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
