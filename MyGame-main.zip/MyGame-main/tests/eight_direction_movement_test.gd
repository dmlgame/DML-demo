extends SceneTree

const STEP := 1.0 / 60.0
const OUTPUT := "res://tmp/decor_rc_qa/eight_direction/"
const KEYS := [KEY_A, KEY_D, KEY_W, KEY_S, KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN]
var _failure := ""

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(640, 480)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var player := load("res://character_body_2d.tscn").instantiate() as CharacterBody2D
	player.position = Vector2(320, 240)
	viewport.add_child(player)
	player.set_physics_process(false)
	player.set_process(false)
	(player.get_node("Camera2D") as Camera2D).enabled = false
	await physics_frame
	await physics_frame
	for mode in [0, 1, 2]:
		player.call("set_move_mode", mode)
		for horizontal in [Vector2.LEFT, Vector2.RIGHT]:
			for vertical in [Vector2.UP, Vector2.DOWN]:
				for first in [Vector2.ZERO, horizontal, vertical]:
					player.position = Vector2(320, 240)
					_input(player, [])
					if first != Vector2.ZERO:
						_input(player, [first])
					var movement := _input(player, [vertical, horizontal])
					var facing: Vector2 = player.get("_input_facing_direction")
					var expected: Vector2 = horizontal if first == Vector2.ZERO else first
					if not movement.is_equal_approx((horizontal + vertical).normalized()) or facing != expected:
						return _fail("Diagonal direction/first-key priority is wrong in mode " + str(mode))
					player.call("_move_with_direction", movement, false, STEP, facing)
					await physics_frame
					player.call("_move_with_direction", movement, false, STEP, facing)
					if not _check_facing(player, mode, expected):
						return _fail(_failure)
					var speed: float = player.call("_movement_speed", false)
					if not player.velocity.is_equal_approx(movement * speed):
						return _fail("Diagonal movement must use the full normalized vector, independently of facing")
					var remaining: Vector2 = vertical if expected == horizontal else horizontal
					_input(player, [remaining])
					if player.get("_input_facing_direction") != remaining:
						return _fail("Releasing the first key must switch to the remaining direction")
		if not await _check_speed(player, mode):
			return _fail(_failure)
		if not await _check_keyboard(player, mode):
			return _fail(_failure)
		if not await _check_wall(viewport, player, mode):
			return _fail(_failure)
		player.position = Vector2(320, 240)
		var preview := _input(player, [Vector2.UP])
		preview = _input(player, [Vector2.UP, Vector2.RIGHT])
		var preview_facing: Vector2 = player.get("_input_facing_direction")
		player.call("_move_with_direction", preview, false, STEP, preview_facing)
		await physics_frame
		player.call("_move_with_direction", preview, false, STEP, preview_facing)
		await _capture(viewport, "vertical_first_mode_" + str(mode))
		_input(player, [])
		preview = _input(player, [Vector2.DOWN, Vector2.LEFT])
		preview_facing = player.get("_input_facing_direction")
		player.call("_move_with_direction", preview, false, STEP, preview_facing)
		await physics_frame
		player.call("_move_with_direction", preview, false, STEP, preview_facing)
		await _capture(viewport, "simultaneous_mode_" + str(mode))
	_key(KEY_S, true)
	_key(KEY_A, true)
	player.call("set_interaction_locked", true)
	var locked_position := player.global_position
	player._physics_process(STEP)
	if player.global_position != locked_position or player.velocity != Vector2.ZERO:
		return _fail("Interaction lock must still stop diagonal movement")
	_release_keys()
	print("Eight-direction movement: all modes, four diagonals, both key orders, simultaneous horizontal priority, unchanged animation/collision orientation, equal speed, real keyboard aliases and wall sliding passed")
	quit()

func _check_speed(player: CharacterBody2D, mode: int) -> bool:
	for running in [false, true]:
		var distances: Array[float] = []
		for movement in [Vector2.RIGHT, Vector2(1, 1).normalized()]:
			player.call("_move_with_direction", movement, running, STEP, Vector2.RIGHT)
			await physics_frame
			await physics_frame
			player.position = Vector2(320, 240)
			var start := player.global_position
			for frame in range(12):
				await physics_frame
				player.call("_move_with_direction", movement, running, STEP, Vector2.RIGHT)
			var speed: float = player.call("_movement_speed", running)
			var distance := player.global_position.distance_to(start)
			if absf(distance - speed * 12.0 / Engine.physics_ticks_per_second) > 0.01:
				_failure = "Actual movement distance must match speed without per-frame rounding, mode " + str(mode)
				return false
			distances.append(distance)
		if absf(distances[0] - distances[1]) > 0.01:
			_failure = "Diagonal movement must be as fast as straight movement"
			return false
	return true

func _check_keyboard(player: CharacterBody2D, mode: int) -> bool:
	for keys in [[KEY_W, KEY_D], [KEY_DOWN, KEY_LEFT]]:
		var vertical := Vector2.UP if keys[0] == KEY_W else Vector2.DOWN
		var horizontal := Vector2.RIGHT if keys[1] == KEY_D else Vector2.LEFT
		for first in [0, 1, 2]:
			_release_keys()
			player.call("_read_direction")
			if first != 2:
				_key(keys[first], true)
				player.call("_read_direction")
			_key(keys[0], true)
			_key(keys[1], true)
			player._physics_process(STEP)
			await physics_frame
			player._physics_process(STEP)
			var facing: Vector2 = vertical if first == 0 else horizontal
			if not _check_facing(player, mode, facing):
				return false
			if not player.velocity.normalized().is_equal_approx((vertical + horizontal).normalized()):
				_failure = "The actual keyboard input must move diagonally using WASD and arrows"
				return false
			_release_keys()
			player._physics_process(STEP)
			if player.velocity != Vector2.ZERO or player.get("last_direction") != facing:
				_failure = "Releasing all keys must stop and preserve the idle facing"
				return false
	_release_keys()
	player.call("_read_direction")
	_key(KEY_A, true)
	_key(KEY_LEFT, true)
	_key(KEY_W, true)
	var aliased: Vector2 = player.call("_read_direction")
	if not aliased.is_equal_approx(Vector2(-1, -1).normalized()):
		_failure = "Duplicate WASD/arrow keys must count as one direction"
		return false
	_key(KEY_A, false)
	player.call("_read_direction")
	if player.get("_input_facing_direction") != Vector2.LEFT:
		_failure = "Releasing one keyboard alias must not release the held direction"
		return false
	_key(KEY_D, true)
	var cancelled: Vector2 = player.call("_read_direction")
	if cancelled != Vector2.UP or player.get("_input_facing_direction") != Vector2.UP:
		_failure = "Opposite horizontal keys must cancel without overriding the vertical animation"
		return false
	_release_keys()
	player.call("_read_direction")
	for key in [[KEY_A, 0x0444, Vector2.LEFT], [KEY_D, 0x0432, Vector2.RIGHT], [KEY_W, 0x0446, Vector2.UP], [KEY_S, 0x044b, Vector2.DOWN]]:
		var event := InputEventKey.new()
		event.physical_keycode = key[0]
		event.keycode = key[1]
		event.pressed = true
		Input.parse_input_event(event)
		Input.flush_buffered_events()
		player._physics_process(STEP)
		await physics_frame
		player._physics_process(STEP)
		if not player.velocity.normalized().is_equal_approx(key[2]):
			_failure = "WASD must work with the Russian keyboard layout in mode " + str(mode)
			return false
		var released := event.duplicate() as InputEventKey
		released.pressed = false
		Input.parse_input_event(released)
		Input.flush_buffered_events()
		player._physics_process(STEP)
		if player.velocity != Vector2.ZERO:
			_failure = "Releasing a physical WASD key must stop movement"
			return false
	return true

func _check_wall(viewport: SubViewport, player: CharacterBody2D, mode: int) -> bool:
	var wall := StaticBody2D.new()
	wall.position = Vector2(400, 240)
	var shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size = Vector2(8, 1200)
	shape.shape = rectangle
	wall.add_child(shape)
	player.position = Vector2(320, 240)
	player.call("_move_with_direction", Vector2.DOWN, false, STEP)
	await physics_frame
	await physics_frame
	viewport.add_child(wall)
	await physics_frame
	await physics_frame
	var start_y := player.global_position.y
	var touched_wall := false
	for frame in range(90):
		await physics_frame
		player.call("_move_with_direction", Vector2(1, 1).normalized(), false, STEP, Vector2.DOWN)
		touched_wall = touched_wall or player.get_slide_collision_count() > 0
		if player.call("_collision_profile_overlaps", player.get("_active_collision")) or player.global_position.x >= 396:
			_failure = "Diagonal movement must not enter a wall in mode " + str(mode)
			return false
	if player.global_position.y <= start_y or not touched_wall:
		_failure = "Wall slide failed in mode %d at %s, start y %s, slides %s" % [mode, player.global_position, start_y, player.get_slide_collision_count()]
		return false
	if not _check_facing(player, mode, Vector2.DOWN):
		return false
	wall.queue_free()
	await physics_frame
	return true

func _check_facing(player: CharacterBody2D, mode: int, facing: Vector2) -> bool:
	if player.get("last_direction") != facing or player.get("_active_collision") != player.call("_collision_for_mode", facing):
		_failure = "Facing mismatch in mode %d: expected %s, actual %s, held %s" % [mode, facing, player.get("last_direction"), player.get("_held_movement_directions")]
		return false
	var name := "left" if facing == Vector2.LEFT else "right" if facing == Vector2.RIGHT else "top" if facing == Vector2.UP else "down"
	if mode == 0:
		var sprite := player.get_node("Visuals/OnFoot") as AnimatedSprite2D
		if not String(sprite.animation).begins_with("move_" + name):
			_failure = "The original walking/running animation must follow the selected cardinal direction"
			return false
	elif mode == 1:
		var horizontal := player.get_node("Visuals/PalletJack/Horizontal") as Sprite2D
		var vertical := player.get_node("Visuals/PalletJack/Vertical") as Sprite2D
		var is_horizontal := facing.x != 0
		var row := 0 if facing == Vector2.LEFT or facing == Vector2.UP else 1
		if horizontal.visible != is_horizontal or vertical.visible == is_horizontal or (horizontal if is_horizontal else vertical).frame_coords.y != row:
			_failure = "The original pallet jack animation must follow the selected cardinal direction"
			return false
	else:
		var sprite := player.get_node("Visuals/Transporter/Sprite") as Sprite2D
		var row := 0 if facing == Vector2.LEFT else 1 if facing == Vector2.RIGHT else 2 if facing == Vector2.UP else 3
		if sprite.frame_coords.y != row:
			_failure = "The original transporter animation must follow the selected cardinal direction"
			return false
	return true

func _input(player: CharacterBody2D, pressed: Array[Vector2]) -> Vector2:
	return player.call("_update_movement_input", pressed)

func _key(keycode: Key, pressed: bool) -> void:
	var event := InputEventKey.new()
	event.keycode = keycode
	event.physical_keycode = keycode
	event.pressed = pressed
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _release_keys() -> void:
	for keycode in KEYS:
		_key(keycode, false)

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	if viewport.get_texture().get_image().save_png(OUTPUT + name + ".png") != OK:
		_fail("Could not save diagonal movement preview")

func _fail(message: String) -> void:
	_release_keys()
	push_error(message)
	quit(1)
