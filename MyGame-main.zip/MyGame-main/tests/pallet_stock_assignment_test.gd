extends SceneTree

const Tasks = preload("res://demo_tasks.gd")
const Stock = preload("res://demo_pallet_stock.gd")
const FOOT := Vector2(0, 25)
var failed := false
var session: Node
var demo: Node
var player: CharacterBody2D

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	session = load("res://game_session.tscn").instantiate()
	session.save_store.directory = "user://tmp/pallet_stock_%d" % Time.get_ticks_usec()
	root.add_child(session)
	await session._start_world("")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	demo._director.set_physics_process(false)
	var old_complete: Dictionary = session.save_store.capture(session.world)
	old_complete.demo.merge({"stage": "zph_complete", "completed": true, "zph_assignment": true, "gate17_checked": true, "placed_count": 12, "gate19_open": true}, true)
	_check(session.save_store.apply_state(session.world, old_complete), "A previous release's completed pair still loads")
	player.global_position = demo._receiving_lead.global_position - FOOT
	_check(demo.try_interact(player) and demo._conversation_kind == "pallet_assignment", "Old completed saves can receive the new assignment")
	_check(demo._dialog_title.text == Tasks.RECEIVING_SPEAKER, "The receiving section lead issues the assignment")
	demo._advance_dialogue()
	_check(demo._dialog_text.text.contains("недопониманий") and demo._dialog_text.text.contains("в работе"), "Lead explains why scattered pallets are not for this assignment")
	demo.close_modal()
	_check(demo.stage == "zph_complete", "Canceling the briefing does not accept the new assignment")
	demo.try_interact(player)
	for index in 2:
		demo._advance_dialogue()
	_check(demo.stage == "find_stock_jack" and demo.assigned_vehicle.is_empty(), "Finishing the briefing starts jack search")
	var baseline: Dictionary = session.save_store.capture(session.world)
	_check(session.save_store._valid(baseline), "The new assignment has a valid save state")
	var stock: Node2D = demo._pallet_stock
	var layer: TileMapLayer = stock._stock
	_check(stock._originals.size() == 22, "Exactly the two marked storage areas are usable")
	for cell in Stock.STOCK_CELLS:
		var original: Vector2i = stock._originals[cell].atlas
		var count := Stock.PALLET_ATLASES.find(original) + 1
		stock.set_progress(cell, false)
		_check(layer.get_cell_source_id(cell) == -1 if count == 1 else layer.get_cell_atlas_coords(cell) == Stock.PALLET_ATLASES[count - 2], "Picking removes exactly one pallet " + str(cell))
		for other in Stock.STOCK_CELLS:
			if other != cell:
				_check(layer.get_cell_atlas_coords(other) == stock._originals[other].atlas, "Other stacks remain unchanged")
		stock.set_progress(Stock.NO_SOURCE, false)
	for cell in [Vector2i(12, -65), Vector2i(131, -38), Vector2i(17, -69), Vector2i(125, -38)]:
		_check(session.save_store.apply_state(session.world, baseline), "Reset assignment fixture")
		var jack: PickupVehicle = demo.nearest_free_pallet_jack()
		var transporter: PickupVehicle = demo.nearest_free_transporter()
		_check(demo.can_use_vehicle(jack) and not demo.can_use_vehicle(transporter), "Only a free pallet jack is unlocked")
		player.global_position = jack.interaction_area.global_position + Vector2(0, 35) - FOOT
		player._nearby_vehicles.clear()
		player.register_pickup_vehicle(jack)
		_check(player._interact_with_vehicle() and demo.stage == "find_pallet_stock", "Taking a jack advances the assignment")
		var loose := Vector2i(68, -39)
		player.global_position = layer.to_global(layer.map_to_local(loose)) + Vector2(0, 96) - FOOT
		_check(stock.nearby_source(player) == null and not stock.loose_pallet_hint(player).is_empty(), "Scattered block-three pallets remain unavailable")
		var loose_atlas := layer.get_cell_atlas_coords(loose)
		_check(demo.try_interact(player) and demo.stage == "find_pallet_stock" and layer.get_cell_atlas_coords(loose) == loose_atlas, "Interacting with a scattered pallet neither loads nor changes it")
		_check(_find_pickup(cell), "A collision-free pickup approach exists " + str(cell))
		print("Pallet pickup fixture: ", cell, " position ", player.global_position, " direction ", player.last_direction, " jack ", demo.assigned_vehicle)
		var original := layer.get_cell_atlas_coords(cell)
		var before: Dictionary = session.save_store.capture(session.world)
		_check(demo.try_interact(player), "Take one pallet through the normal interaction")
		var transition: Tween = demo._gate19._transition
		transition.pause()
		_check(player._interaction_locked and not player.pallet_jack_pallet_loaded and layer.get_cell_atlas_coords(cell) == original, "Cargo and stack stay unchanged before blackout")
		_check(not session.save_store.save_world(session.world, "slot_1") and not demo.try_interact(player), "Partial fades cannot be saved or repeated")
		transition.custom_step(0.13)
		_check(demo._gate19._shade.color.a == 1 and demo.stage == "deliver_empty_pallet" and player.pallet_jack_pallet_loaded and not player.pallet_jack_loaded and stock.picked_source == cell, "One empty pallet transfers while fully black")
		transition.custom_step(1.0)
		await _settle()
		_check(not player._interaction_locked and not player.pallet_jack_animation_test and player._pallet_test_sprite.texture == player.PALLET_JACK_PALLET_TEXTURE and not player._tote_collision.disabled, "Normal empty-pallet animation and collision are active")
		_check(not demo.can_use_vehicle(jack), "A loaded jack cannot be abandoned before delivery")
		_check(session.save_store.save_world(session.world, "slot_1"), "Held empty pallet saves")
		var held: Dictionary = session.save_store.read_slot("slot_1")
		_check(session.save_store.apply_state(session.world, held) and player.pallet_jack_pallet_loaded and stock.picked_source == cell, "Held cargo and decremented source restore without taking another pallet")
		for override in [{"pallet_source": [68, -39]}, {"pallet_source": [cell.x + 0.5, cell.y]}, {"pallet_delivered": true}, {"gate17_checked": false}, {"zph_assignment": false}]:
			var invalid: Dictionary = held.duplicate(true)
			invalid.demo.merge(override, true)
			_check(not session.save_store._valid(invalid), "Invalid pallet progress cannot bypass validation")
		var no_vehicle: Dictionary = held.duplicate(true)
		no_vehicle.player.vehicle = ""
		_check(not session.save_store._valid(no_vehicle), "Loaded pallet must have its assigned mounted jack")
		await _check_layout()
		_check(_find_delivery(), "A clear delivery approach exists beside the lead")
		print("Pallet delivery fixture: ", player.global_position, " direction ", player.last_direction)
		await _settle()
		_check(demo.try_interact(player) and demo.stage == "empty_pallet_complete" and stock.delivered and not player.pallet_jack_pallet_loaded and stock._delivery != null, "Pallet is placed in the marked receiving area")
		_check(demo._hint_button.visible and demo._current_target_point() == demo._receiving_lead.global_position and not stock.target_visible, "Completed delivery offers the preparation briefing and hides the marking")
		_check(session.save_store.save_world(session.world, "slot_2"), "Delivered pallet saves")
		var finished: Dictionary = session.save_store.read_slot("slot_2")
		_check(session.save_store.apply_state(session.world, finished) and stock.delivered and stock._delivery != null and not player.pallet_jack_pallet_loaded, "Delivered pallet restores without duplication")
		_check(session.save_store.apply_state(session.world, before) and stock.picked_source == Stock.NO_SOURCE and stock._delivery == null and layer.get_cell_atlas_coords(cell) == original, "Earlier save restores the original stack and removes delivery")
		if failed:
			break
	_check(session.save_store.apply_state(session.world, baseline), "Reset final scenario")
	await session._start_world("slot_2")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	_check(demo.stage == "empty_pallet_complete" and demo._pallet_stock.delivered and demo._pallet_stock._delivery != null and not player.pallet_jack_pallet_loaded and demo.placed_count == 12, "Fresh-world continuation keeps pallet delivery and earlier unload progress")
	session.free()
	if not failed:
		print("Pallet stock assignment passed: dialogue, two zones, all stack counts, single pallets, fade, cargo, delivery, validation and saves")
	quit(1 if failed else 0)

func _find_pickup(cell: Vector2i) -> bool:
	var center: Vector2 = demo._pallet_stock._stock.to_global(demo._pallet_stock._stock.map_to_local(cell))
	for direction in [Vector2.UP, Vector2.DOWN, Vector2.RIGHT, Vector2.LEFT]:
		for offset in [Vector2(0, 104), Vector2(-80, 40), Vector2(80, 40), Vector2(0, -40), Vector2(-64, 72), Vector2(64, 72)]:
			player.global_position = center + offset - FOOT
			player.last_direction = direction
			player._apply_collision_profile(direction)
			if not player._collision_profile_overlaps(player._active_collision) and player.can_load_pallet_jack_totes() and demo._pallet_stock.nearby_source(player) == cell:
				return true
	return false

func _find_delivery() -> bool:
	for direction in [Vector2.UP, Vector2.DOWN, Vector2.RIGHT, Vector2.LEFT]:
		for offset in [Vector2(0, 40), Vector2(0, -40), Vector2(48, 0), Vector2(-48, 0), Vector2(32, 40), Vector2(-32, 40)]:
			player.global_position = demo._pallet_stock.delivery_point() + offset - FOOT
			player.last_direction = direction
			player._apply_collision_profile(direction)
			if demo._pallet_stock.can_place(player):
				return true
	return false

func _check_layout() -> void:
	for mobile in [false, true]:
		session.touch_controls.available = mobile
		for size in [Vector2i(1280, 720), Vector2i(390, 844), Vector2i(320, 640), Vector2i(844, 390)]:
			root.size = size
			await _settle()
			_check(root.get_visible_rect().encloses(demo._task_panel.get_global_rect()), "Pallet objective fits " + str(size))
			_check(demo._objective.visible, "Pallet objective remains complete")
			if mobile:
				for button in [session.touch_controls._action_button, session.touch_controls._secondary_action_button, session.touch_controls._sprint_button]:
					_check(not demo._task_panel.get_global_rect().intersects(Rect2(button.position - button.shape.size / 2, button.shape.size)), "Pallet objective leaves controls clear")

func _settle() -> void:
	for frame in 4:
		await physics_frame
		await process_frame

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
