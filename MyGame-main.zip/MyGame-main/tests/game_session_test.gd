extends SceneTree

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var session: Node = load("res://game_session.tscn").instantiate()
	session.animation_test_mode = false
	session.save_store.directory = "res://tmp/decor_rc_qa/session_test"
	root.add_child(session)
	_check(session.menu.visible and session.world == null, "Starts in menu, not warehouse")
	_check(not session.controls_hint.visible, "Controls hint is hidden in the main menu")
	await session._start_world("")
	_check(session.world != null and not session.menu.visible and not paused, "New game starts")
	_check(session.controls_hint.visible and session.controls_hint.expanded, "New game shows the controls hint")
	for size in [Vector2i(1280, 720), Vector2i(960, 540), Vector2i(390, 844), Vector2i(360, 240)]:
		root.size = size
		await process_frame
		await process_frame
		await process_frame
		var hint_rect: Rect2 = session.controls_hint.hint_rect()
		_check(root.get_visible_rect().encloses(hint_rect), "Controls hint fits the viewport " + str(size))
		_check(hint_rect.position.y >= size.y - 160, "Controls hint stays at the bottom right " + str(size))
		if size.x < 1024:
			var task_rect: Rect2 = session.world.get_node("DemoTasks")._task_panel.get_global_rect()
			_check(not task_rect.intersects(hint_rect), "The objective does not overlap the controls hint " + str(size))
	root.size = Vector2i(1152, 648)
	await process_frame
	session.controls_hint._hide_button.pressed.emit()
	_check(not session.controls_hint.expanded and session.controls_hint._show_button.visible, "Controls hint can be hidden")
	session.controls_hint._show_button.pressed.emit()
	_check(session.controls_hint.expanded and session.controls_hint._panel.visible, "Controls hint can be reopened")
	var player: CharacterBody2D = session.world.get_node("YSortActors/Player")
	_check(player.walk_speed == 100 and player.run_speed == 150 and player.pallet_jack_speed == 100 and player.transporter_speed == 150, "The running warehouse uses the configured movement speeds")
	player.global_position = Vector2(160, 180)
	_key(KEY_ESCAPE)
	await process_frame
	_check(paused and session.menu.is_pause and session.menu.visible, "Escape opens actual pause")
	_check(not session.controls_hint.visible, "Pause hides the controls hint")
	var stationary: Vector2 = player.global_position
	await create_timer(0.1).timeout
	_check(player.global_position == stationary, "Player remains frozen during pause")
	session._save_manual("slot_1")
	_check(not session.save_store.read_slot("slot_1").is_empty(), "Manual save works while paused")
	_check(session.menu.status.text == "Игра сохранена", "Manual save uses game terminology")
	_key(KEY_ESCAPE)
	_key(KEY_ESCAPE)
	await process_frame
	_check(not paused and not session.menu.visible, "Escape backs out then resumes")
	_check(session.controls_hint.visible, "Resuming restores the controls hint")
	_key(KEY_F5)
	_check(not session.save_store.read_slot("autosave").is_empty(), "F5 quicksave")
	session._autosave_elapsed = 61.0
	session._process(0.01)
	_check(session._autosave_elapsed == 0, "Timed autosave")
	_key(KEY_ESCAPE)
	await process_frame
	session._return_to_menu()
	_check(session.world == null and session.menu.visible and not paused, "Return to menu saves and frees warehouse")
	_check(not session.controls_hint.visible, "Return to menu hides the controls hint")
	_check(session.menu.status.text == "Игра сохранена", "Return to menu uses game terminology")
	await session._start_world("slot_1")
	_check(session.world.get_node("YSortActors/Player").global_position == stationary, "Continue restores saved position")
	var lift: Node = session.world.get_node("FreightLiftInteraction")
	lift._show_picker(lift._lifts[0])
	_key(KEY_ESCAPE)
	await process_frame
	_check(not paused and not session.menu.visible and lift._selected.is_empty(), "Escape closes lift picker without opening pause")
	session.world.get_node("YSortActors/Player").set_interaction_locked(true)
	_key(KEY_F5)
	_check(session._toast.text.contains("Дождитесь"), "Quicksave gives feedback during busy transition")
	session.world.get_node("YSortActors/Player").set_interaction_locked(false)
	session.free()
	paused = false
	if not failed:
		print("Game session tests passed: new/continue, Esc pause, manual/F5/timed saves, return menu, lift modal input")
	quit(1 if failed else 0)

func _key(code: Key) -> void:
	var event := InputEventKey.new()
	event.keycode = code
	event.pressed = true
	Input.parse_input_event(event)
	Input.flush_buffered_events()
	event = InputEventKey.new()
	event.keycode = code
	event.pressed = false
	Input.parse_input_event(event)
	Input.flush_buffered_events()

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
