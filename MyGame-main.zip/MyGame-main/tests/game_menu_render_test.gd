extends SceneTree

const Menu = preload("res://game_menu.gd")
const DIR := "res://tmp/decor_rc_qa/menu"
var failed := false
var new_game_count := 0

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(DIR))
	root.size = Vector2i(1280, 720)
	var menu := Menu.new()
	menu.store = WarehouseSaveStore.new()
	menu.store.directory = DIR + "/empty_slots"
	root.add_child(menu)
	menu.new_game_requested.connect(func(): new_game_count += 1)
	await _frame()
	_check(menu.background.animated, "Background animation must be enabled by default")
	_check(not menu.has_method("_show_settings") and not menu.has_method("set_variant"), "Settings and alternate layouts are removed")
	_check_storage_scene(menu.background)
	_check_detail_style(menu.background)
	_check_layout(menu)
	var new_button: Button
	for child in menu.content.get_children():
		if child is Button and child.text == "Новая игра":
			new_button = child
			break
	var motion := InputEventMouseMotion.new()
	motion.position = new_button.get_global_rect().get_center()
	Input.parse_input_event(motion)
	for pressed in [true, false]:
		var click := InputEventMouseButton.new()
		click.button_index = MOUSE_BUTTON_LEFT
		click.position = motion.position
		click.pressed = pressed
		Input.parse_input_event(click)
		Input.flush_buffered_events()
	await _frame()
	_check(new_game_count == 1, "Real mouse click starts new game")
	new_button.grab_focus()
	for pressed in [true, false]:
		var key := InputEventKey.new()
		key.keycode = KEY_ENTER
		key.pressed = pressed
		Input.parse_input_event(key)
		Input.flush_buffered_events()
	await _frame()
	_check(new_game_count == 2, "Keyboard Enter activates focused menu action")
	_check_3d_render(menu.background)
	await _capture_conveyor(menu)
	var before := root.get_texture().get_image()
	var tote_position: Vector3 = menu.background.containers[0].position
	await create_timer(0.3).timeout
	await _frame()
	var after := root.get_texture().get_image()
	_check(before.get_data() != after.get_data(), "Background must animate")
	_check(menu.background.containers[0].position != tote_position, "Blue totes must move, not only the camera")
	menu.show_main(true)
	await _frame()
	_check_layout(menu)
	var hidden_time: float = menu.background.elapsed
	await create_timer(0.03).timeout
	_check(menu.background.elapsed == hidden_time, "Pause stops the separate menu animation")
	_check(menu.background.viewport.render_target_update_mode == SubViewport.UPDATE_DISABLED, "Hidden 3D background must not keep rendering")
	root.get_texture().get_image().save_png(DIR + "/pause.png")
	menu._request_load("slot_1")
	_check(menu._modal.visible, "Loading from pause requires confirmation")
	menu.handle_escape()
	menu.show_main()
	await _check_delete_buttons(menu)
	root.size = Vector2i(1920, 1080)
	await _frame()
	_check_3d_render(menu.background)
	root.get_texture().get_image().save_png(DIR + "/centered_1920.png")
	for viewport in [Vector2i(1152, 648), Vector2i(640, 360), Vector2i(420, 720), Vector2i(320, 640)]:
		root.size = viewport
		await _frame()
		_check_layout(menu)
		if viewport.y >= 648:
			var last_button: Button = menu.content.get_child(menu.content.get_child_count() - 1)
			_check(last_button.get_global_rect().end.y <= menu.scroller.get_global_rect().end.y, "Main actions should fit a standard desktop without scrolling")
		for saving in [false, true]:
			menu._show_slots(saving)
			await _frame()
			_check_layout(menu)
		menu._confirm("Перезаписать сохранение?", "Предыдущая версия останется в резервной копии.", func(): pass)
		await _frame()
		_check(Rect2(Vector2.ZERO, Vector2(viewport)).encloses(menu._dialog.get_global_rect()), "Confirmation overflows " + str(viewport))
		menu.handle_escape()
		menu.show_main()
		await _frame()
		_check_3d_render(menu.background)
		root.get_texture().get_image().save_png(DIR + "/centered_" + str(viewport.x) + ".png")
	menu.free()
	if not failed:
		print("Game menu render tests passed: mouse/Enter, centered layout, detailed pixel render/labels/open handles/service panels/workstation, nearest scaling/matte palette, fixed camera, no characters, static truck/pallet cargo, decor clearance, empty/sparse/full totes, conveyor motion, save deletion, desktop/small/portrait, pause rendering stops")
	quit(1 if failed else 0)

func _check_layout(menu: Control) -> void:
	_check(menu.get_rect().size == Vector2(root.size), "Menu does not fill viewport")
	_check(Rect2(Vector2.ZERO, Vector2(root.size)).encloses(menu.scroller.get_global_rect()), "Menu scroller overflows viewport")
	_check(absf(menu.scroller.get_global_rect().get_center().x - root.size.x * 0.5) < 1.0, "Menu must always be centered")
	for child in menu.content.get_children():
		if child is Label:
			_check(child.size.x <= menu.scroller.size.x + 1, "Label too wide: " + child.text)
		if child is Button:
			_check(child.size.x <= menu.scroller.size.x + 1, "Button too wide: " + child.text)
			_check(child.text != "Настройки", "Settings button must not be present")
		_check(not child is CheckButton, "Settings toggles must not be present")
	for button in menu.content.find_children("*", "Button", true, false):
		_check(button.get_global_rect().position.x >= menu.scroller.position.x, "Nested button overflows left")
		_check(button.get_global_rect().end.x <= menu.scroller.get_global_rect().end.x + 1, "Nested button overflows right")
		_check(not button.text.to_lower().contains("смен"), "Menu uses game terminology")

func _bounds(node: Node3D) -> AABB:
	var meshes := node.find_children("*", "MeshInstance3D", true, false)
	if node is MeshInstance3D:
		meshes.append(node)
	var result := AABB()
	var first := true
	for mesh in meshes:
		var box: AABB = mesh.global_transform * mesh.get_aabb()
		result = box if first else result.merge(box)
		first = false
	return result

func _penetrates(a: AABB, b: AABB) -> bool:
	return a.intersection(b).size.x > 0.02 and a.intersection(b).size.y > 0.02 and a.intersection(b).size.z > 0.02


func _oriented_boxes_penetrate(a_transform: Transform3D, a: AABB, b_transform: Transform3D, b: AABB, minimum_overlap: float = 0.02) -> bool:
	var a_center := a_transform * a.get_center()
	var b_center := b_transform * b.get_center()
	var a_extents: Array[Vector3] = []
	var b_extents: Array[Vector3] = []
	var axes: Array[Vector3] = []
	for i in range(3):
		a_extents.append(a_transform.basis[i] * a.size[i] * 0.5)
		b_extents.append(b_transform.basis[i] * b.size[i] * 0.5)
		axes.append(a_transform.basis[i].normalized())
		axes.append(b_transform.basis[i].normalized())
	for first in range(3):
		for second in range(3):
			var cross := a_extents[first].cross(b_extents[second])
			if cross.length_squared() > 0.00000001:
				axes.append(cross.normalized())
	# SAT excludes the empty corners of the AABB around a rotated block limb.
	for axis in axes:
		var radius := 0.0
		for i in range(3):
			radius += absf(a_extents[i].dot(axis)) + absf(b_extents[i].dot(axis))
		if radius - absf((b_center - a_center).dot(axis)) <= minimum_overlap:
			return false
	return true

func _check_storage_scene(background: Control) -> void:
	background.animated = false
	var scene: Node3D = background._scene
	_check(scene.find_children("UnloadingWorker_*", "Node3D", true, false).is_empty(), "Characters are removed from the background")
	_check(not background.has_method("_make_worker") and not background.has_method("_animate_carrier"), "Unused worker code must not remain")
	_check(background.containers.size() == 16, "The conveyor needs a steady stream of blue totes")
	_check_tote_contents(background)
	_check(background.truck.has_node("OpenRearDoor_-1") and background.truck.has_node("OpenRearDoor_1"), "Keep the open truck")
	for door in [background.truck.get_node("OpenRearDoor_-1"), background.truck.get_node("OpenRearDoor_1")]:
		_check(absf(absf(door.rotation.y) - deg_to_rad(102)) < 0.001, "Truck doors stay open")
	var cargo: Node3D = background.truck.get_node("PalletCargo")
	_check(cargo.get_child_count() == 6, "Truck contains six loaded pallets")
	for pallet in cargo.get_children():
		_check(absf(_bounds(pallet).position.y - 1.27) < 0.001, "Truck pallet rests on the trailer bed")
		_check(absf(_bounds(pallet.get_child(8)).position.y - 1.51) < 0.001, "Truck boxes rest on the pallet deck")
	var pallet := _bounds(scene.get_node("LoadedPallet"))
	var jack := _bounds(scene.get_node("ParkedPalletJack"))
	var conveyor := _bounds(scene.get_node("Conveyor"))
	_check(not pallet.intersects(jack) and not pallet.intersects(conveyor), "Loaded pallet must not overlap the jack or conveyor")
	_check(absf(pallet.position.y + 0.01) < 0.001, "Pallet rests on the floor")
	var desk: Node3D = scene.get_node("PackingWorkstation")
	_check(absf(_bounds(desk.get_node("WorkstationTote")).position.y - _bounds(desk.get_node("LowerShelf")).end.y) < 0.001, "Workstation tote rests on its shelf")
	var decor: Node3D = scene.get_node("WarehouseDecor")
	_check(decor.get_child_count() == 5, "Five additional warehouse decorations")
	for item in decor.get_children():
		_check(ResourceLoader.exists(item.get_meta("reference_asset")), "Decor references an existing warehouse asset")
		_check(absf(_bounds(item).position.y) < 0.015, "Decor rests on the floor: " + item.name)
		_check(not _penetrates(_bounds(item), conveyor), "Decor does not intersect conveyor: " + item.name)
		for other in decor.get_children():
			if item != other:
				_check(not _penetrates(_bounds(item), _bounds(other)), "Decor items do not intersect")
	var conveyor_parts: Array[Node] = scene.get_node("Conveyor").find_children("*", "MeshInstance3D", true, false)
	for part in background.truck.find_children("*", "MeshInstance3D", true, false):
		for obstacle in conveyor_parts:
			if _penetrates(part.global_transform * part.get_aabb(), obstacle.global_transform * obstacle.get_aabb()) and _oriented_boxes_penetrate(part.global_transform, part.get_aabb(), obstacle.global_transform, obstacle.get_aabb()):
				_check(false, "Open truck does not intersect the conveyor")
				break
	var truck_transform: Transform3D = background.truck.global_transform
	var camera_transform: Transform3D = background._camera.global_transform
	var front := _bounds(scene.get_node("Conveyor/FrontRail"))
	var back := _bounds(scene.get_node("Conveyor/BackRail"))
	var previous := []
	var wraps := 0
	for tick in range(2001):
		background.elapsed = tick * 0.1
		_check(background.truck.global_transform == truck_transform, "Truck remains static")
		_check(background._camera.global_transform == camera_transform, "Static pixel edges must not shimmer from camera drift")
		for i in background.containers.size():
			var tote: Node3D = background.containers[i]
			_check(tote.get_meta("cargo_kind") == "blue_tote" and tote.get_child(0).material_override == background._materials.tote, "Only blue plastic totes travel on the conveyor")
			var bounds := _bounds(tote)
			_check(absf(bounds.position.y - background.CONVEYOR_TOP) < 0.001, "Tote bottom rests on the rollers")
			_check(not _penetrates(bounds, front) and not _penetrates(bounds, back), "Totes do not clip through the rails")
			if tick > 0:
				var distance: float = tote.position.x - previous[i]
				_check(absf(wrapf(distance, -28, 28) - background.CONVEYOR_SPEED * 0.1) < 0.001, "Conveyor movement stays constant through wraps")
				if absf(distance) > 28:
					var visible_rect := Rect2(Vector2.ZERO, Vector2(background.viewport.size))
					_check(not visible_rect.has_point(background._camera.unproject_position(tote.global_position)), "Totes wrap outside the visible frame")
					wraps += 1
			if tick == 0:
				previous.append(tote.position.x)
			else:
				previous[i] = tote.position.x
	_check(wraps > 40, "Several complete conveyor loops were verified")
	background.elapsed = 4.0
	background.animated = true

func _check_tote_contents(background: Control) -> void:
	var levels := {"empty": 0, "sparse": 0, "full": 0}
	var kinds := {}
	for tote in background.containers:
		var level: String = tote.get_meta("fill_level")
		levels[level] += 1
		if level == "empty":
			_check(not tote.has_node("Goods"), "Empty totes contain no goods")
			continue
		var goods: Node3D = tote.get_node("Goods")
		_check(goods.get_child_count() == 3 if level == "sparse" else goods.get_child_count() >= 6, "Sparse and full totes have different quantities")
		var cargo_min := INF
		var cargo_max := -INF
		for product in goods.get_children():
			kinds[product.get_meta("goods_kind")] = true
			var bounds := AABB()
			var first := true
			for part in product.find_children("*", "MeshInstance3D", true, false):
				var box: AABB = tote.global_transform.affine_inverse() * part.global_transform * part.get_aabb()
				bounds = box if first else bounds.merge(box)
				first = false
			_check(bounds.position.x >= -0.4125 and bounds.end.x <= 0.4125 and bounds.position.z >= -0.4825 and bounds.end.z <= 0.4825, "Goods stay inside the tote walls")
			_check(bounds.position.y >= -0.1801 and bounds.end.y <= 0.2725, "Goods stay above the inner floor and below the rim")
			_check(absf(bounds.position.y - product.position.y) < 0.001, "Products rest on their assigned floor/stack layer")
			cargo_min = minf(cargo_min, bounds.position.y)
			cargo_max = maxf(cargo_max, bounds.end.y)
		_check(absf(cargo_min + 0.18) < 0.001, "The first goods layer rests on the tote floor")
		if level == "full":
			_check(cargo_max >= 0.22, "Full totes are filled close to the rim")
	for level in levels:
		_check(levels[level] >= 2, "The conveyor includes multiple " + level + " totes")
	_check(kinds.size() == 3, "Use three different types of goods")

func _check_detail_style(background: Control) -> void:
	_check(background.PIXEL_RENDER_WIDTH == 640.0, "Finer pixel rendering must retain object details")
	_check(background._label_materials.size() == 4, "Four printed label variants")
	for material in background._label_materials:
		_check(material.albedo_texture.get_size() == Vector2(32, 24) and material.texture_filter == BaseMaterial3D.TEXTURE_FILTER_NEAREST, "Printed labels use crisp pixel artwork")
		_check(material.specular_mode == BaseMaterial3D.SPECULAR_DISABLED, "Printed labels remain matte")
	_check(background._scene.get_node("Conveyor/ServiceDetails").get_child_count() >= 50, "Conveyor has fasteners, crossmembers, motor vents and stop control")
	_check(background._scene.get_node("PackingWorkstation/WorkstationDetails").get_child_count() >= 40, "Workstation has monitor rows, keyboard keys, mouse, tape and clipboard")
	for tote in background.containers:
		_check(tote.has_node("ShellDetails"), "Totes have reinforcing ribs, rims and printed identification")
		var opening := AABB(Vector3(-0.13, 0.065, 0.4825), Vector3(0.26, 0.12, 0.055))
		for mesh in tote.find_children("*", "MeshInstance3D", true, false):
			var bounds: AABB = tote.global_transform.affine_inverse() * mesh.global_transform * mesh.get_aabb()
			_check(not _penetrates(opening, bounds), "The tote handle is an opening, not a solid wall with a dark patch")

func _capture_conveyor(menu: Control) -> void:
	var background: Control = menu.background
	background.animated = false
	menu.scroller.hide()
	menu.shade.hide()
	menu.status.hide()
	for phase in [0.0, 4.0, 12.0, 32.0]:
		background.elapsed = phase
		await _frame()
		_check_pixel_grid(root.get_texture().get_image(), background.viewport.size)
		root.get_texture().get_image().save_png(DIR + "/conveyor_" + str(phase) + ".png")
	var camera: Camera3D = background._camera
	var original_transform := camera.transform
	var original_fov := camera.fov
	background.elapsed = 4.0
	var at: Vector3 = background.containers[9].global_position
	camera.position = at + Vector3(3.5, 2.4, 4.2)
	camera.look_at(at)
	camera.fov = 48
	background._request_frame()
	await _frame()
	root.get_texture().get_image().save_png(DIR + "/blue_totes_detail.png")
	camera.transform = original_transform
	camera.fov = original_fov
	background.elapsed = 4.0
	background.animated = true
	menu.scroller.show()
	menu.shade.show()
	menu.status.show()
	await _frame()

func _check_delete_buttons(menu: Control) -> void:
	var store := WarehouseSaveStore.new()
	store.directory = DIR + "/delete_slots"
	for slot in WarehouseSaveStore.SLOTS:
		_check(store.delete_slot(slot), "Clean test slot: " + slot)
	var state := {
		"version": 1, "scene": "res://warehouse_main.tscn", "saved_at": "2026-10-04T20:15:30", "timestamp": 100,
		"player": {"position": [0, 0], "direction": [0, 1], "pickup_offset": [0, 0], "vehicle": ""},
		"vehicles": {}, "door_open": false, "gate_open": false, "lifts": {},
	}
	_check(store.write_state(state, "slot_1") and store.write_state(state, "slot_1"), "Deletion fixture and backup")
	state.timestamp = 200
	_check(store.write_state(state, "slot_2"), "Other slot fixture")
	state.timestamp = 300
	_check(store.write_state(state, "autosave"), "Autosave fixture")
	var broken := FileAccess.open(store._path("slot_3"), FileAccess.WRITE)
	broken.store_string("{broken")
	broken.close()
	menu.store = store
	menu._show_slots(false)
	await _frame()
	_check_layout(menu)
	_check(menu.content.get_node("Record_slot_3/Slot_slot_3").disabled and not menu.content.get_node("Record_slot_3/Delete_slot_3").disabled, "Corrupt record cannot load but can be deleted")
	root.get_texture().get_image().save_png(DIR + "/load_with_delete.png")
	await _click(menu.content.get_node("Record_slot_1/Delete_slot_1"))
	_check(menu._modal.visible, "Delete requires confirmation")
	root.get_texture().get_image().save_png(DIR + "/delete_confirmation.png")
	await _click(_find_button(menu._dialog, "Отмена"))
	_check(store.has_slot_files("slot_1") and not menu._modal.visible, "Cancel keeps save and backup")
	for slot in ["slot_1", "slot_3", "autosave", "slot_2"]:
		await _click(menu.content.get_node("Record_" + slot + "/Delete_" + slot))
		await _click(_find_button(menu._dialog, "Удалить запись"))
		_check(not store.has_slot_files(slot), "Confirmed deletion removes record: " + slot)
		_check(menu.content.get_node("Record_" + slot + "/Delete_" + slot).disabled, "Deleted row refreshes to empty")
		if slot == "autosave":
			_check(store.latest_slot() == "slot_2", "Continue falls back to remaining latest save")
	await _click(_find_button(menu.content, "Назад"))
	_check(_find_button(menu.content, "Продолжить игру").disabled, "Continue disabled after all records removed")
	for slot in WarehouseSaveStore.SLOTS:
		_check(store.write_state(state, slot), "Recreate test previews")
	menu.show_main()
	await _frame()

func _find_button(parent: Node, label: String) -> Button:
	for button in parent.find_children("*", "Button", true, false):
		if button.text == label:
			return button
	return null

func _click(button: Button) -> void:
	_check(button != null, "Expected button for mouse test")
	if button == null:
		return
	for pressed in [true, false]:
		var click := InputEventMouseButton.new()
		click.position = button.get_global_rect().get_center()
		click.button_index = MOUSE_BUTTON_LEFT
		click.pressed = pressed
		Input.parse_input_event(click)
		Input.flush_buffered_events()
	await _frame()

func _check_3d_render(background: Control) -> void:
	var shrink := maxi(2, roundi(background.size.x / background.PIXEL_RENDER_WIDTH))
	_check(background._display.stretch_shrink == shrink, "Pixel scale adapts to the window width")
	_check(absf(background.viewport.size.x * shrink - background.size.x) < shrink and absf(background.viewport.size.y * shrink - background.size.y) < shrink, "Only the background renders at a lower resolution")
	_check(background._display.texture_filter == CanvasItem.TEXTURE_FILTER_NEAREST and background.viewport.msaa_3d == Viewport.MSAA_DISABLED, "Pixel edges remain sharp without blur or anti-aliasing")
	_check(background._materials.floor.albedo_texture.get_size() == Vector2(32, 32), "Use the warehouse's original concrete tile")
	for material in background._materials.values():
		_check(material.specular_mode == BaseMaterial3D.SPECULAR_DISABLED, "Warehouse materials use matte sprite-like shading")
	var scene_image: Image = background.viewport.get_texture().get_image()
	_check(scene_image != null and scene_image.get_width() > 2, "3D viewport must render an image")
	if scene_image == null:
		return
	var darkest := 1.0
	var brightest := 0.0
	var colors := {}
	for x in range(0, scene_image.get_width(), 6):
		for y in range(0, scene_image.get_height(), 6):
			var pixel := scene_image.get_pixel(x, y)
			darkest = minf(darkest, pixel.get_luminance())
			brightest = maxf(brightest, pixel.get_luminance())
			colors[pixel.to_html()] = true
	_check(brightest - darkest > 0.3 and colors.size() > 50, "3D background is blank or lacks rendered geometry")

func _check_pixel_grid(frame: Image, render_size: Vector2i) -> void:
	var scale := Vector2(frame.get_size()) / Vector2(render_size)
	var matched := 0
	var sampled := 0
	for x in range(4, render_size.x - 4, 7):
		for y in range(4, render_size.y - 4, 7):
			var first := Vector2i((Vector2(x, y) + Vector2(0.25, 0.25)) * scale)
			var last := Vector2i((Vector2(x, y) + Vector2(0.75, 0.75)) * scale)
			if frame.get_pixelv(first) == frame.get_pixelv(last):
				matched += 1
			sampled += 1
	_check(float(matched) / sampled > 0.95, "Native screenshot must show crisp uniform pixels, not an interpolated low-resolution blur")

func _frame() -> void:
	await process_frame
	await process_frame
	await RenderingServer.frame_post_draw

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
