extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/jack_depth/"
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("Jack depth validation needs a renderer")
		quit(1)
		return
	var viewport := SubViewport.new()
	viewport.size = Vector2i(640, 480)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var player := load("res://character_body_2d.tscn").instantiate() as CharacterBody2D
	player.position = Vector2(320, 240)
	actors.add_child(player)
	player.set_physics_process(false)
	player.set_process(false)
	player.get_node("Camera2D").enabled = false
	player.call("set_move_mode", 1)
	var depth: Node2D = player.get("_jack_depth")
	for cargo in ["empty", "totes", "pallet"]:
		var loaded: bool = cargo == "totes"
		player.call("set_pallet_jack_animation_test", cargo == "pallet")
		player.call("set_pallet_jack_totes", loaded, true)
		for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
			player.set("last_direction", direction)
			for frame in range(8):
				player.call("_update_vehicle_frame", direction, frame)
				var split := await _image(viewport)
				var source: Sprite2D = player.get("_pallet_test_sprite") if cargo == "pallet" else player.get("_tote_sprite") if loaded else player.get("pallet_jack_horizontal") if direction.x != 0 else player.get("pallet_jack_vertical")
				depth.hide()
				source.self_modulate.a = 1.0
				var original := await _image(viewport)
				source.self_modulate.a = 0.0
				depth.show()
				if split.get_data() != original.get_data():
					push_error("Splitting must preserve every original pixel: cargo=%s direction=%s frame=%d" % [cargo, direction, frame])
					quit(1)
					return
			print("Native pixels preserved: cargo=%s direction=%s all eight frames" % [cargo, direction])
			var operator: Node2D = depth.get("operator_anchor")
			var equipment: Node2D = depth.get("equipment_anchor")
			var blocker := Node2D.new()
			blocker.position.y = (operator.global_position.y + equipment.global_position.y) / 2.0
			var panel := ColorRect.new()
			panel.color = Color(0, 1, 0)
			panel.position = Vector2(0, -blocker.position.y)
			panel.size = Vector2(640, 480)
			blocker.add_child(panel)
			actors.add_child(blocker)
			var mixed := await _image(viewport)
			DirAccess.make_dir_recursive_absolute(OUTPUT)
			mixed.save_png(OUTPUT + "mixed_%s_%s.png" % [cargo, direction])
			blocker.hide()
			var behind := operator if operator.global_position.y < equipment.global_position.y else equipment
			behind.hide()
			var foreground := await _image(viewport)
			behind.show()
			var visible := 0
			var wrong := 0
			for y in range(120, 400):
				for x in range(180, 450):
					var expected := foreground.get_pixel(x, y)
					if expected.a > 0.99:
						visible += 1
						if mixed.get_pixel(x, y) != expected:
							wrong += 1
					elif expected.a < 0.01 and mixed.get_pixel(x, y) != panel.color:
						wrong += 1
			if visible < 20 or wrong > 0:
				push_error("The operator and equipment must sort independently: cargo=%s direction=%s visible=%d wrong=%d" % [cargo, direction, visible, wrong])
				failed = true
			blocker.queue_free()
			await process_frame
			DirAccess.make_dir_recursive_absolute(OUTPUT)
			(await _image(viewport)).save_png(OUTPUT + "loaded_%s_direction_%s.png" % [cargo, direction])
	await _real_pallet(viewport, actors, player)
	if failed:
		quit(1)
		return
	print("Pallet jack depth passed: 96 unchanged native frames, independent operator/equipment ordering in four directions, empty/totes/pallet and real tote pallet approach")
	quit()

func _real_pallet(viewport: SubViewport, actors: Node2D, player: CharacterBody2D) -> void:
	player.call("set_pallet_jack_animation_test", false)
	var pallets := TileMapLayer.new()
	pallets.tile_set = load("res://assets/tiles/warehouse_pallet_tileset.tres")
	pallets.y_sort_enabled = true
	pallets.y_sort_origin = 23
	actors.add_child(pallets)
	var cell := Vector2i(10, 6)
	pallets.set_cell(cell, 0, Vector2i(3, 10))
	var center := pallets.map_to_local(cell)
	player.call("set_pallet_jack_totes", false, true)
	player.global_position = center + Vector2(-78, 33)
	player.call("_update_vehicle_frame", Vector2.LEFT, 0)
	var start := player.global_position
	await physics_frame
	await physics_frame
	if player.call("_collision_profile_overlaps", player.get("collision_pallet_jack_left")):
		push_error("The pictured front-side approach must remain outside the pallet collision")
		failed = true
	var actual := await _image(viewport)
	pallets.hide()
	var unobstructed := await _image(viewport)
	pallets.show()
	var changed := 0
	var shared := 0
	for y in range(int(center.y + 52), int(center.y + 82)):
		for x in range(int(center.x - 34), int(center.x + 30)):
			var pixel := unobstructed.get_pixel(x, y)
			if pixel.a > 0.99:
				shared += 1
				if actual.get_pixel(x, y) != pixel:
					changed += 1
	if shared == 0 or changed > 0 or player.global_position != start:
		push_error("The pallet must not hide front-side jack pixels or move the body: shared=%d covered=%d" % [shared, changed])
		failed = true
	actual.save_png(OUTPUT + "pallet_front.png")
	var depth: Node2D = player.get("_jack_depth")
	depth.hide()
	var source: Sprite2D = player.get("pallet_jack_horizontal")
	source.self_modulate.a = 1.0
	var old_depth := await _image(viewport)
	old_depth.save_png(OUTPUT + "pallet_old_depth.png")
	var old_covered := 0
	for y in range(int(center.y + 52), int(center.y + 82)):
		for x in range(int(center.x - 34), int(center.x + 30)):
			if unobstructed.get_pixel(x, y).a > 0.99 and old_depth.get_pixel(x, y) != unobstructed.get_pixel(x, y):
				old_covered += 1
	if old_covered == 0:
		push_error("The pallet fixture must reproduce the old incorrect overlap")
		failed = true
	print("Real pallet overlap: previously covered=%d, now=%d" % [old_covered, changed])
	source.self_modulate.a = 0.0
	depth.show()

func _image(viewport: SubViewport) -> Image:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	return viewport.get_texture().get_image()
