extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	if not InputMap.has_action("interact"):
		_fail("Missing interact input action")
		return
	for keycode in [KEY_E, KEY_ENTER, KEY_KP_ENTER]:
		var key := InputEventKey.new()
		key.physical_keycode = keycode
		key.pressed = true
		if not InputMap.event_is_action(key, "interact"):
			_fail("Interaction key is missing: " + str(keycode))
			return

	if not await _check_vehicle("res://assets/objects/pallet_jack/pallet_jack_right.tscn", Vector2(50, 0), 0.7, 1):
		return
	if not await _check_vehicle("res://assets/objects/transporter/transporter_left_empty.tscn", Vector2(75, 0), 1.0, 2):
		return
	if not _check_map_instances():
		return

	print("Vehicle interaction tests passed")
	quit()


func _check_vehicle(scene_path: String, vehicle_position: Vector2, vehicle_scale: float, expected_mode: int) -> bool:
	var world := Node2D.new()
	root.add_child(world)

	var player: CharacterBody2D = load("res://character_body_2d.tscn").instantiate()
	world.add_child(player)

	var vehicle := load(scene_path).instantiate() as PickupVehicle
	vehicle.position = vehicle_position
	vehicle.scale = Vector2.ONE * vehicle_scale
	world.add_child(vehicle)

	await physics_frame
	await physics_frame
	await process_frame
	if not player._nearby_vehicles.has(vehicle):
		_fail("Player did not enter the interaction area: " + scene_path)
		return false

	var hint: RichTextLabel = player.get("_interaction_hint")
	var expected_text := "Паллетовоз\nНажмите E или Enter, чтобы сесть в транспорт" if expected_mode == 2 else "Рохля\nНажмите E или Enter, чтобы взять рохлю"
	player.call("_update_interaction_hint")
	if hint == null or not hint.visible or hint.get_parsed_text() != expected_text:
		_fail("Wrong vehicle name or approach hint: " + scene_path)
		return false
	if not hint.text.begins_with("[color=#ff6868]"):
		_fail("Vehicle name must be highlighted in red")
		return false
	_press_interact(player, KEY_ENTER, true)
	if vehicle.is_carried:
		_fail("Key autorepeat must not pick up a vehicle")
		return false
	_press_interact(player, KEY_ENTER)
	await physics_frame
	if player.move_mode != expected_mode or not vehicle.is_carried or vehicle.visible or not vehicle.solid_shape.disabled:
		_fail("Picking up did not switch mode and disable the parked vehicle: %s (mode=%d, carried=%s, visible=%s, disabled=%s)" % [scene_path, player.move_mode, vehicle.is_carried, vehicle.visible, vehicle.solid_shape.disabled])
		return false
	if hint.visible:
		_fail("Pickup instruction must hide while the vehicle is carried")
		return false

	player.global_position = Vector2(100, 0)
	_press_interact(player, KEY_KP_ENTER)
	await physics_frame
	if player.move_mode != 0 or vehicle.is_carried or not vehicle.visible or vehicle.solid_shape.disabled:
		_fail("Dropping did not restore the parked vehicle: " + scene_path)
		return false
	if vehicle.global_position != player.global_position + vehicle_position:
		_fail("Dropping did not preserve the approach offset: " + scene_path)
		return false
	player.global_position = Vector2(500, 500)
	await physics_frame
	await physics_frame
	player.call("_update_interaction_hint")
	if hint.visible:
		_fail("Pickup instruction must disappear away from the vehicle")
		return false

	world.queue_free()
	await process_frame
	return true


func _check_map_instances() -> bool:
	var scene: Node2D = load("res://warehouse_main.tscn").instantiate()
	var vehicles: Array[PickupVehicle] = []
	for parent_name in ["PalletJackAssets", "TransporterSprites"]:
		for child in scene.get_node("YSortActors/" + parent_name).get_children():
			if not child is PickupVehicle or not child.has_node("InteractionArea"):
				_fail("Parked vehicle has no interaction area: " + str(child.name))
				scene.free()
				return false
			vehicles.append(child)
	if vehicles.is_empty():
		_fail("The warehouse has no parked vehicles to test")
		scene.free()
		return false
	scene.free()
	return true


func _press_interact(player: CharacterBody2D, keycode: Key = KEY_E, echo := false) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	event.pressed = true
	event.echo = echo
	player._unhandled_input(event)


func _fail(message: String) -> void:
	push_error(message)
	quit(1)
