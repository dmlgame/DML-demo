extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var objects := load("res://assets/tiles/warehouse_objects_tileset.tres") as TileSet
	var additions := objects.get_source(6) as TileSetAtlasSource
	if additions == null or additions.get_tiles_count() != 10:
		return _fail("Ten new decorations must be available in ObjectsLayer")
	for index in additions.get_tiles_count():
		var atlas := additions.get_tile_id(index)
		var data := additions.get_tile_data(atlas, 0)
		if additions.get_tile_size_in_atlas(atlas) != Vector2i(2, 2) or data.get_collision_polygons_count(0) != 1 or data.y_sort_origin != 1:
			return _fail("Decoration is missing its footprint or contact-point sort origin")
	var floors := load("res://assets/tiles/warehouse_floor_markings_tileset.tres") as TileSet
	var scraps := floors.get_source(2) as TileSetAtlasSource
	if scraps == null or scraps.get_tiles_count() != 5 or floors.get_physics_layers_count() != 0:
		return _fail("Five stretch scraps must remain collision-free floor tiles")
	if not (floors.get_source(1) as TileSetAtlasSource).has_tile(Vector2i(4, 3)):
		return _fail("Existing stretch scrap was removed")
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	var original_floors: Array[Vector2i] = world.get_node("FloorLayer2").get_used_cells()
	var original_objects: Array[Vector2i] = world.get_node("YSortActors/ObjectsLayer").get_used_cells()
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.position = Vector2(1233, -436)
	viewport.add_child(world)
	player.set_physics_process(false)
	player.get_node("Camera2D").enabled = false
	var zone := world.get_node("RCMaintenanceZone") as Node2D
	var rect: Rect2 = zone.get("_zone_rect")
	var hint := player.get("_interaction_hint") as RichTextLabel
	if rect.position != Vector2(1265, -591) or rect.end != Vector2(4448, 128):
		return _fail("Darkness does not follow the actual L-shaped mesh boundary: " + str(rect))
	if hint == null or zone.has_node("ProximityHint") or player.get("_maintenance_zone") != zone:
		return _fail("RC notice must use the shared interaction HUD, not a world-space label")
	if (world.get_node("FloorLayer2") as TileMapLayer).get_used_cells() != original_floors or (world.get_node("YSortActors/ObjectsLayer") as TileMapLayer).get_used_cells() != original_objects:
		return _fail("Existing map placements changed")
	var fog: Color = zone.get("darkness")
	if fog.a < 0.35 or fog.a > 0.7:
		return _fail("RC fog must dim the floor without hiding it completely")
	for feet in [rect.position + Vector2(-32, 180), rect.position + Vector2(160, -32)]:
		player.position = feet - Vector2(0, 25)
		player.call("_update_interaction_hint")
		if not hint.visible or hint.get_parsed_text() != "Зона РЦ (технические работы)":
			return _fail("Notice must appear beside and above the fence")
		if hint.get_global_transform_with_canvas().origin != Vector2(16, 16) or hint.get_theme_font_size("normal_font_size") != 16:
			return _fail("RC notice must use the same top-left position and clear font as other hints")
	for feet in [rect.position + Vector2(-180, 180), rect.position + Vector2(160, -180), rect.position + Vector2(160, 180)]:
		player.position = feet - Vector2(0, 25)
		player.call("_update_interaction_hint")
		if not zone.get_interaction_text(player).is_empty() or hint.get_parsed_text() == "Зона РЦ (технические работы)":
			return _fail("Notice must disappear away from the accessible fence sides")
		var table_title: String = world.get_node("TableHints").get_interaction_text(player)
		if hint.visible != not table_title.is_empty() or hint.get_parsed_text() != table_title:
			return _fail("Away from the fence, show only a nearby table name or hide the HUD")
	player.position = rect.position + Vector2(-32, 180) - Vector2(0, 25)
	player.set_interaction_locked(true)
	if hint.visible:
		return _fail("RC notice must hide during an interaction blackout")
	player.set_interaction_locked(false)
	if not hint.visible:
		return _fail("RC notice must return when interactions are unlocked")
	var vehicle := load("res://assets/objects/pallet_jack/pallet_jack_right.tscn").instantiate() as PickupVehicle
	vehicle.position = player.position + Vector2(50, 0)
	world.add_child(vehicle)
	player.register_pickup_vehicle(vehicle)
	player.call("_update_interaction_hint")
	if hint.get_parsed_text() != vehicle.get_interaction_text() or not hint.text.begins_with("[color=#ff6868]"):
		return _fail("Vehicle instructions must take priority over the passive RC notice")
	player.unregister_pickup_vehicle(vehicle)
	vehicle.free()
	player.call("_update_interaction_hint")
	if hint.get_parsed_text() != "Зона РЦ (технические работы)":
		return _fail("RC notice must return after leaving the vehicle interaction area")
	await physics_frame
	await physics_frame
	player.position = rect.position + Vector2(-32, 180) - Vector2(0, 25)
	if not player.test_move(player.global_transform, Vector2(64, 0)):
		return _fail("Side fence collision was lost")
	player.position = rect.position + Vector2(160, -32) - Vector2(0, 25)
	if not player.test_move(player.global_transform, Vector2(0, 64)):
		return _fail("Top fence collision was lost")
	if DisplayServer.get_name() != "headless":
		DirAccess.make_dir_recursive_absolute(OUTPUT)
		var overview := Camera2D.new()
		overview.position = rect.position + Vector2(-50, 179.5)
		viewport.add_child(overview)
		overview.force_update_scroll()
		for entry in [["side", Vector2(-32, 180)], ["top", Vector2(160, -32)], ["far", Vector2(-180, 180)]]:
			player.position = rect.position + entry[1] - Vector2(0, 25)
			await physics_frame
			await physics_frame
			player.call("_update_interaction_hint")
			zone.visible = false
			await RenderingServer.frame_post_draw
			await RenderingServer.frame_post_draw
			var clear := viewport.get_texture().get_image()
			zone.visible = true
			await RenderingServer.frame_post_draw
			await RenderingServer.frame_post_draw
			var image := viewport.get_texture().get_image()
			var inside := image.get_pixel(800, 330)
			var outside := image.get_pixel(450, 330)
			var floor_inside := clear.get_pixel(800, 330)
			var brightness := maxf(inside.r, maxf(inside.g, inside.b))
			if brightness < 0.12 or brightness > maxf(floor_inside.r, maxf(floor_inside.g, floor_inside.b)) - 0.05 or not outside.is_equal_approx(clear.get_pixel(450, 330)):
				return _fail("Fog must dim the restricted floor while leaving the accessible floor unchanged")
			if image.save_png(OUTPUT + "warehouse_rc_" + entry[0] + ".png") != OK:
				return _fail("Could not save RC zone preview")
		overview.enabled = false
		player.position = rect.position + Vector2(-32, 180) - Vector2(0, 25)
		var camera := player.get_node("Camera2D") as Camera2D
		camera.enabled = true
		camera.zoom = Vector2(2, 2)
		camera.force_update_scroll()
		await physics_frame
		await physics_frame
		player.call("_update_interaction_hint")
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		if hint.get_parsed_text() != "Зона РЦ (технические работы)":
			return _fail("The zoom preview must show the RC notice, not a stale vehicle-area hint: " + hint.get_parsed_text())
		var original_hint_size := hint.size
		camera.zoom = Vector2(3, 3)
		player.position.y += 12
		camera.force_update_scroll()
		await physics_frame
		await physics_frame
		player.call("_update_interaction_hint")
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		if hint.get_global_transform_with_canvas().origin != Vector2(16, 16) or hint.get_global_transform_with_canvas().get_scale() != Vector2.ONE or hint.size != original_hint_size:
			return _fail("Camera movement and zoom must not move or enlarge the RC notice: position=%s scale=%s size=%s original=%s text=%s" % [hint.get_global_transform_with_canvas().origin, hint.get_global_transform_with_canvas().get_scale(), hint.size, original_hint_size, hint.get_parsed_text()])
		viewport.get_texture().get_image().save_png(OUTPUT + "warehouse_rc_hud_zoomed.png")
		viewport.size = Vector2i(360, 240)
		camera.force_update_scroll()
		await physics_frame
		await physics_frame
		player.call("_update_interaction_hint")
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		if hint.get_parsed_text() != "Зона РЦ (технические работы)" or not Rect2(Vector2.ZERO, viewport.size).encloses(Rect2(hint.get_global_transform_with_canvas().origin, hint.size)) or hint.size.x > 300 or hint.size.y > 96:
			return _fail("RC notice must remain compact and fit a small viewport")
		viewport.get_texture().get_image().save_png(OUTPUT + "warehouse_rc_hud_small.png")
		camera.enabled = false
		world.visible = false
		viewport.size = Vector2i(1100, 730)
		var backdrop := ColorRect.new()
		backdrop.size = viewport.size
		backdrop.color = Color(0.4, 0.425, 0.43)
		viewport.add_child(backdrop)
		var atlas := Sprite2D.new()
		atlas.texture = additions.texture
		atlas.centered = false
		atlas.scale = Vector2(3, 3)
		atlas.position = Vector2(30, 20)
		viewport.add_child(atlas)
		var film := Sprite2D.new()
		film.texture = scraps.texture
		film.centered = false
		film.scale = Vector2(3, 3)
		film.position = Vector2(30, 620)
		viewport.add_child(film)
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		viewport.get_texture().get_image().save_png(OUTPUT + "warehouse_decor_additions_preview.png")
	zone.free()
	player.call("_update_interaction_hint")
	if player.get("_maintenance_zone") != null:
		return _fail("Removing the RC zone must unregister its HUD explanation")
	print("Warehouse decorations, floor scraps, translucent RC fog, shared compact HUD, hint priority and fence collisions passed")
	quit()

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
