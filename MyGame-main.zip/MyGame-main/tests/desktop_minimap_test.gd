extends SceneTree

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	root.size = Vector2i(1280, 720)
	var session: Node = load("res://game_session.tscn").instantiate()
	session.save_store.directory = "user://tmp/desktop_minimap_%d" % Time.get_ticks_usec()
	root.add_child(session)
	session.touch_controls.available = false
	var minimap: Control = session.desktop_minimap
	_check(not minimap.visible and minimap.player == null, "Desktop map is hidden in the main menu")
	await session._start_world("")
	await _settle()
	var player: CharacterBody2D = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	var demo: Node = session.world.get_node("DemoTasks")
	_check(minimap.is_visible_in_tree() and minimap.player == player, "Desktop map binds to the active player")
	_check(not session.touch_controls.visible, "Desktop map does not enable mobile controls")
	_check(player.get_node("Camera2D").is_current(), "Map camera leaves the game camera active")
	_check(minimap._viewport.world_2d == session.world.get_world_2d(), "Desktop reuses the warehouse map renderer")
	_check(minimap.display_bounds.encloses(session.world.get_node("BlockNotifications").warehouse_rect), "Map covers all three blocks")
	session._notify("Игра сохранена")
	await _settle()
	_check(not minimap.get_global_rect().intersects(session._toast.get_global_rect()), "Save notification does not cover the map")
	var first_marker: Vector2
	for point in [Vector2(-2200, -1325), Vector2(2200, -2400)]:
		player.global_position = point
		minimap._update_markers()
		if first_marker.is_zero_approx():
			first_marker = minimap.marker
			_check(minimap._caption.text == "Мезонин", "Desktop map names the mezzanine")
		else:
			_check(minimap.marker.x > first_marker.x + 40 and minimap._caption.text == "Блок 3", "Marker and zone follow the player")
	for viewport_size in [Vector2i(1280, 720), Vector2i(960, 540), Vector2i(800, 600)]:
		root.size = viewport_size
		await _settle()
		_check(Rect2(Vector2.ZERO, Vector2(viewport_size)).encloses(minimap.get_global_rect()), "Desktop map fits " + str(viewport_size))
		_check(not minimap.get_global_rect().intersects(demo.task_hud_rect()), "Map does not overlap the objective " + str(viewport_size))
		player._update_interaction_hint()
		_check(player._interaction_hint.position == Vector2(16, 108), "Explanations stay below the map")
	demo._toggle_hint()
	demo._accept_hint()
	await _settle()
	_check(demo.hint_enabled and demo._route.visible and not demo._route.points.is_empty(), "Guidance route is available to the shared map")
	session._pause()
	_check(not minimap.is_visible_in_tree(), "Map hides on pause")
	session._resume()
	_check(minimap.is_visible_in_tree(), "Map returns on resume")
	player._interaction_locked = true
	session._update_controls_hint_visibility()
	_check(not minimap.visible, "Map hides during modal interactions")
	player._interaction_locked = false
	session.touch_controls.available = true
	session._update_controls_hint_visibility()
	_check(not minimap.visible and minimap.player == null and session.touch_controls._minimap.is_visible_in_tree(), "Mobile retains only its existing map")
	session.touch_controls.available = false
	session._update_controls_hint_visibility()
	_check(minimap.visible and minimap.player == player, "Desktop map rebinds when input mode changes")
	await session._start_world("")
	await _settle()
	_check(minimap.player == session.world.get_node("YSortActors/Player"), "New game replaces the map's player safely")
	session._return_to_menu()
	_check(not minimap.visible and minimap.player == null and not minimap.display_bounds.has_area(), "Returning to menu clears the map")
	session.free()
	paused = false
	if not failed:
		print("Desktop minimap tests passed: rendering, markers, layout, guidance and lifecycle")
	quit(1 if failed else 0)

func _settle() -> void:
	for frame in range(4):
		await process_frame

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
