extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	var actors: Node2D = world.get_node("YSortActors")
	var objects: TileMapLayer = actors.get_node("ObjectsLayer")
	var dock: TileMapLayer = actors.get_node("UnloadingDockLayer")
	var wall: Node2D = actors.get_node("BackWallSort")
	var player: CharacterBody2D = actors.get_node("Player")
	var staircase_sort: Node2D = actors.get_node("SecondFloorStaircaseSort")
	var staircase: Sprite2D = staircase_sort.get_node("SecondFloorStaircase")
	var saved_objects := objects.tile_map_data.duplicate()
	var saved_dock := dock.tile_map_data.duplicate()

	if not actors.y_sort_enabled or not objects.y_sort_enabled or not dock.y_sort_enabled:
		return _fail("Objects and dock gates must sort each tile with the player")
	if objects.z_index != player.z_index or dock.z_index != player.z_index or wall.z_index != player.z_index:
		return _fail("Y-sorted actors do not share a Z index")
	if objects.get_used_cells().is_empty() or dock.get_used_cells().size() != 19:
		return _fail("Object or dock tiles were lost")
	if objects.global_position != Vector2.ZERO or dock.global_position != Vector2(-16, 0):
		return _fail("Object or dock tile collisions shifted")
	if dock.y_sort_origin != 24 or dock.map_to_local(Vector2i(0, -106)).y + dock.y_sort_origin != wall.position.y + 1:
		return _fail("Dock gates are not sorted at the rear wall base")
	if staircase.global_position != Vector2(643, -793) or staircase.scale != Vector2(0.25, 0.25):
		return _fail("Staircase moved or changed size")
	if staircase_sort.global_position.y != -690.0:
		return _fail("Staircase does not sort near its collision base")
	var expected_origins := {
		"0:(1, 0)": 24,
		"0:(0, 1)": 54,
		"0:(1, 1)": 54,
		"0:(0, 6)": 20,
		"0:(4, 6)": 39,
		"0:(0, 13)": 39,
		"0:(7, 0)": 5,
		"1:(7, 0)": -11,
		"1:(0, 0)": 5,
		"1:(1, 0)": 5,
		"1:(2, 0)": 5,
		"1:(4, 0)": 21,
		"1:(0, 2)": -11,
		"1:(2, 2)": -11,
		"1:(0, 3)": 21,
		"1:(2, 3)": 5,
		"1:(4, 4)": -11,
		"1:(6, 4)": -11,
		"2:(0, 0)": 54,
		"3:(0, 0)": 29,
		"3:(5, 0)": 29,
		"3:(10, 0)": 29,
		"4:(4, 0)": 24,
		"5:(0, 0)": 18,
	}
	for cell in objects.get_used_cells():
		var source_id := objects.get_cell_source_id(cell)
		var atlas_coord := objects.get_cell_atlas_coords(cell)
		var key := "%d:%s" % [source_id, atlas_coord]
		var source := objects.tile_set.get_source(source_id) as TileSetAtlasSource
		if source == null or objects.get_cell_tile_data(cell) == null:
			return _fail("Invalid placed object tile: " + key)
		if expected_origins.has(key) and source.get_tile_data(atlas_coord, 0).y_sort_origin != expected_origins[key]:
			return _fail("Incorrect Y-sort origin for " + key)
	for cell in dock.get_used_cells():
		if cell.y != -106 or dock.get_cell_atlas_coords(cell) != Vector2i(4, 9):
			return _fail("Dock gate layout changed")
	await process_frame
	await process_frame
	var expected_visuals := 0
	for cell in objects.get_used_cells():
		var source_id := objects.get_cell_source_id(cell)
		var data := objects.get_cell_tile_data(cell)
		if data.get_collision_polygons_count(0) == 0:
			continue
		if source_id == 0 and objects.get_cell_atlas_coords(cell) == Vector2i(0, 13):
			expected_visuals += 13
		else:
			expected_visuals += 1
	var generated_visuals := 0
	for child in objects.get_children(true):
		if child.is_in_group("object_footprint_visual"):
			generated_visuals += 1
	if generated_visuals != expected_visuals or expected_visuals == 0:
		return _fail("Complex object visuals do not match the placed tiles")
	if objects.tile_map_data != saved_objects or dock.tile_map_data != saved_dock:
		return _fail("Sorting modified the current object/dock placements")

	print("Object and unloading dock Y-sort scene tests passed")
	quit()


func _fail(message: String) -> void:
	push_error(message)
	quit(1)
