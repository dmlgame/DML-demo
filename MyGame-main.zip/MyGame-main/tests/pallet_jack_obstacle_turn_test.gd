extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/pallet_jack/"
const CELL := Vector2i(8, 5)
const STEP := 1.0 / 60.0

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(640, 480)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var objects := TileMapLayer.new()
	objects.tile_set = load("res://assets/tiles/warehouse_objects_tileset.tres")
	objects.y_sort_enabled = true
	actors.add_child(objects)
	objects.set_cell(CELL, 0, Vector2i(0, 1))
	var center := objects.map_to_local(CELL)
	var front_y := center.y + 79
	var sort_y := center.y + 54
	var player := load("res://character_body_2d.tscn").instantiate() as CharacterBody2D
	player.position = center + Vector2(0, 160)
	actors.add_child(player)
	player.set_physics_process(false)
	player.set_process(false)
	(player.get_node("Camera2D") as Camera2D).enabled = false
	player.set("last_direction", Vector2.UP)
	player.call("set_move_mode", 1)
	await physics_frame
	await physics_frame
	for frame in range(150):
		await physics_frame
		player.call("_move_with_direction", Vector2.UP, false, STEP)
	await _capture(viewport, "pillar_approach")
	var feet := player.get_node("CollisionOnFoot") as CollisionShape2D
	var feet_shape := feet.shape as RectangleShape2D
	if feet.global_position.y - feet_shape.size.y / 2 < front_y - 0.1:
		return _fail("The operator's feet crossed the pillar's front edge while pulling the jack upward")
	if player.global_position.y <= sort_y:
		return _fail("The operator disappeared behind the pillar despite approaching from the front")
	if not await _body_visible(viewport, objects, player):
		return _fail("The pillar must not cover the operator's body on its front side")
	var start := player.global_position
	player.call("_move_with_direction", Vector2.DOWN, false, STEP)
	await physics_frame
	await _capture(viewport, "pillar_down_turn")
	if player.global_position.y < start.y or player.global_position.y <= sort_y:
		return _fail("Reversing downward must not push the operator behind the pillar")
	if player.get("last_direction") != Vector2.DOWN:
		return _fail("The pallet jack must be able to face down next to the pillar")
	if player.call("_collision_profile_overlaps", player.get("_active_collision")):
		return _fail("The reversed pallet jack must remain clear of the pillar")
	if not await _body_visible(viewport, objects, player):
		return _fail("Reversing must not hide the operator behind the pillar")
	var after_turn := player.global_position
	for frame in range(15):
		await physics_frame
		player.call("_move_with_direction", Vector2.DOWN, false, STEP)
	if player.global_position.y <= after_turn.y:
		return _fail("The operator must be able to walk away after reversing")
	await _capture(viewport, "pillar_walk_away")

	# All jack directions must retain the operator's footprint, not only the forks.
	for direction in [Vector2.UP, Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT]:
		player.global_position = Vector2(500, 350)
		player.call("_move_with_direction", direction, false, STEP)
		await physics_frame
		await physics_frame
		if feet.disabled or player.call("_collision_profile_overlaps", player.get("_active_collision")):
			return _fail("The operator's feet must remain solid for every pallet jack direction")
	var obstacle := StaticBody2D.new()
	obstacle.position = feet.global_position + Vector2(-6, 0)
	var obstacle_shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size = Vector2(2, 2)
	obstacle_shape.shape = rectangle
	obstacle.add_child(obstacle_shape)
	actors.add_child(obstacle)
	await physics_frame
	await physics_frame
	if not player.call("_collision_profile_overlaps", player.get("collision_pallet_jack_left")):
		return _fail("Turn clearance must detect an obstacle under the operator, outside the forks")
	obstacle.queue_free()
	await physics_frame
	await physics_frame
	player.call("set_move_mode", 0)
	player.call("_move_with_direction", Vector2.DOWN, false, STEP)
	await physics_frame
	await physics_frame
	if feet.disabled:
		return _fail("Releasing the pallet jack must keep the on-foot collision")
	player.call("set_move_mode", 2)
	player.call("_move_with_direction", Vector2.DOWN, false, STEP)
	await physics_frame
	await physics_frame
	if not feet.disabled:
		return _fail("The transporter's existing collision profile must remain unchanged")
	actors.queue_free()
	await process_frame
	if not await _real_map(viewport):
		return
	print("Pallet jack obstacle approach, visible operator, safe downward reversal, walk-away, feet in all directions and real warehouse pillars passed")
	quit()

func _real_map(viewport: SubViewport) -> bool:
	viewport.size = Vector2i(1100, 619)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var objects := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	var camera := player.get_node("Camera2D") as Camera2D
	player.set("last_direction", Vector2.UP)
	player.call("set_move_mode", 1)
	player.call("_try_face_direction", Vector2.UP)
	await physics_frame
	await physics_frame
	var checked := 0
	for cell in objects.get_used_cells():
		if objects.get_cell_source_id(cell) != 0 or objects.get_cell_atlas_coords(cell) != Vector2i(0, 1):
			continue
		var center := objects.to_global(objects.map_to_local(cell))
		player.global_position = center + Vector2(0, 160)
		player.call("_try_face_direction", Vector2.UP)
		await physics_frame
		await physics_frame
		if player.call("_collision_profile_overlaps", player.get("_active_collision")):
			continue
		for frame in range(150):
			await physics_frame
			player.call("_move_with_direction", Vector2.UP, false, STEP)
		if player.global_position.y <= center.y + 54:
			_fail("The operator must remain in front of real warehouse pillar " + str(cell))
			return false
		var approach := player.global_position
		player.call("_move_with_direction", Vector2.DOWN, false, STEP)
		await physics_frame
		if player.global_position.y < approach.y or player.call("_collision_profile_overlaps", player.get("_active_collision")):
			_fail("Reversing at a real pillar must not move behind it or overlap an obstacle")
			return false
		if player.get("last_direction") != Vector2.DOWN:
			_fail("The real warehouse pillar must leave room for the downward turn")
			return false
		for frame in range(12):
			await physics_frame
			player.call("_move_with_direction", Vector2.DOWN, false, STEP)
		if player.global_position.y <= approach.y:
			_fail("The pallet jack must move away from the real warehouse pillar")
			return false
		camera.force_update_scroll()
		await _capture(viewport, "warehouse_pillar_" + str(checked))
		checked += 1
		if checked == 2:
			return true
	_fail("Expected two unobstructed real warehouse pillars for the regression")
	return false

func _body_visible(viewport: SubViewport, objects: TileMapLayer, player: CharacterBody2D) -> bool:
	if DisplayServer.get_name() == "headless":
		return true
	var actual := await _image(viewport)
	objects.visible = false
	var reference := await _image(viewport)
	objects.visible = true
	var body := Rect2i(Vector2i(player.position) + Vector2i(-24, -32), Vector2i(48, 60))
	for y in range(body.position.y, body.end.y):
		for x in range(body.position.x, body.end.x):
			var expected := reference.get_pixel(x, y)
			if expected.a > 0.9 and actual.get_pixel(x, y) != expected:
				return false
	return true

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	var captured := await _image(viewport)
	if captured.save_png(OUTPUT + name + ".png") != OK:
		_fail("Could not save pallet jack regression preview")

func _image(viewport: SubViewport) -> Image:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	return viewport.get_texture().get_image()

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
