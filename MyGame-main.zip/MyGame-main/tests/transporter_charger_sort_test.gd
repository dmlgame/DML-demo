extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"
const Geometry = preload("res://footprint_sort_geometry.gd")

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(600, 360)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	player.visible = false
	player.get_node("Camera2D").enabled = false
	var camera := Camera2D.new()
	camera.position = Vector2(620, -1654)
	camera.zoom = Vector2(2, 2)
	viewport.add_child(camera)
	camera.make_current()
	var objects := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	var transporters := world.get_node("YSortActors/TransporterSprites") as Node2D
	await process_frame
	await process_frame
	var chargers: Array[Node2D] = []
	var entries: Array = objects.get("_visuals")
	for entry in entries:
		if entry.charger:
			chargers.append(entry.visual)
	if chargers.is_empty():
		return _fail("No charging station visuals were found")
	var checked_pairs := 0
	for player_x in [500.0, 600.0, 700.0]:
		player.position.x = player_x
		transporters.call("_process", 0.0)
		objects.call("_process", 0.0)
		for entry in entries:
			if not entry.charger:
				continue
			var bounds := objects.global_transform * Rect2(entry.center - Vector2(entry.size) / 2.0, entry.size)
			for vehicle in transporters.get_children():
				if not bounds.intersects(vehicle.global_transform * vehicle.get_rect()):
					continue
				var anchor := vehicle.get_node("SortVisual") as Node2D
				if entry.visual.global_position.y >= anchor.global_position.y:
					return _fail("Parked transport does not draw in front of its charger")
				checked_pairs += 1
	if checked_pairs < 6:
		return _fail("Not enough actual charging bays were checked")
	if DisplayServer.get_name() != "headless":
		_set_vehicles(transporters, false)
		_set_chargers(chargers, false)
		var floor := await _frame(viewport)
		_set_chargers(chargers, true)
		var charger_only := await _frame(viewport)
		_set_chargers(chargers, false)
		_set_vehicles(transporters, true)
		var vehicle_only := await _frame(viewport)
		_set_chargers(chargers, true)
		var together := await _frame(viewport)
		DirAccess.make_dir_recursive_absolute(OUTPUT)
		together.save_png(OUTPUT + "transporter_charger_priority.png")
		vehicle_only.save_png(OUTPUT + "transporter_only.png")
		charger_only.save_png(OUTPUT + "charger_only.png")
		var overlap := 0
		for y in viewport.size.y:
			for x in viewport.size.x:
				var base := floor.get_pixel(x, y)
				var vehicle_pixel := vehicle_only.get_pixel(x, y)
				var charger_pixel := charger_only.get_pixel(x, y)
				if vehicle_pixel.is_equal_approx(base) or charger_pixel.is_equal_approx(base) or vehicle_pixel.is_equal_approx(charger_pixel):
					continue
				if not _opaque_vehicle_pixel(transporters, Vector2(x + 0.5, y + 0.5)):
					continue
				overlap += 1
				if not together.get_pixel(x, y).is_equal_approx(vehicle_pixel):
					return _fail("Charging equipment covers transport at %s (vehicle=%s, charger=%s, together=%s)" % [Vector2i(x, y), vehicle_pixel, charger_pixel, together.get_pixel(x, y)])
		if overlap < 100:
			return _fail("Transport/charger pixel overlap was not exercised")
	_set_vehicles(transporters, false)
	var target: Dictionary
	for entry in entries:
		if entry.charger and entry.visual.global_position.distance_to(camera.position) < 80:
			target = entry
			break
	if target.is_empty():
		return _fail("Charging bay preview did not locate its station")
	player.visible = true
	player.position = objects.to_global(target.center)
	var carried := transporters.get_child(5) as PickupVehicle
	carried.set_carried(true)
	player.set("_carried_vehicle", carried)
	player.call("set_move_mode", 2)
	objects.call("_process", 0.0)
	if target.visual.global_position.y >= player.global_position.y:
		return _fail("Driven transport must draw in front of the charger")
	if DisplayServer.get_name() != "headless":
		(await _frame(viewport)).save_png(OUTPUT + "driven_transporter_charger_priority.png")
	for mode in [0, 2]:
		player.call("set_move_mode", mode)
		if mode == 2:
			player.position.y += 300
		objects.call("_process", 0.0)
		var local_x: float = objects.to_local(player.global_position).x - target.center.x
		var expected: float = target.center.y + Geometry.front_y(target.polygons, local_x, target.fallback) - 25
		if not is_equal_approx(target.visual.position.y, expected):
			return _fail("Normal charger depth must return on foot or after driving away")
	if player.z_index != 0 or transporters.z_index != 0:
		return _fail("Charging priority must not raise transport above unrelated walls and objects")
	print("Parked/driven transport covers chargers; pixel overlap and ordinary Y-sort restoration passed")
	quit()

func _set_vehicles(group: Node2D, shown: bool) -> void:
	for child in group.get_children():
		child.visible = shown

func _set_chargers(chargers: Array[Node2D], shown: bool) -> void:
	for charger in chargers:
		charger.visible = shown

func _opaque_vehicle_pixel(group: Node2D, screen_point: Vector2) -> bool:
	for child in group.get_children():
		var sprite := child as Sprite2D
		var local := sprite.get_global_transform_with_canvas().affine_inverse() * screen_point
		var rect := sprite.get_rect()
		if rect.has_point(local):
			var pixel := Vector2i((local - rect.position).floor())
			var texture := sprite.texture.get_image()
			var opaque := true
			for offset_y in range(-2, 3):
				for offset_x in range(-2, 3):
					var point := pixel + Vector2i(offset_x, offset_y)
					if point.x < 0 or point.y < 0 or point.x >= texture.get_width() or point.y >= texture.get_height() or texture.get_pixelv(point).a < 0.999:
						opaque = false
			if opaque:
				return true
	return false

func _frame(viewport: SubViewport) -> Image:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	return viewport.get_texture().get_image()

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
