extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"
const INTERIOR := Rect2(64, 128, 288, 96)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1152, 648)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	player.set_process(false)
	var boundary := world.get_node("EntranceBoundary") as StaticBody2D
	var feet := player.get_node("CollisionOnFoot") as CollisionShape2D
	var camera := player.get_node("Camera2D") as Camera2D
	var spawn := player.global_position
	await physics_frame
	await physics_frame
	if boundary.get_child_count() != 3 or (boundary.collision_layer & player.collision_mask) == 0:
		return _fail("The entrance must have three solid boundary segments matching the player mask")
	if not _inside(player, feet) or player.test_move(player.global_transform, Vector2.ZERO):
		return _fail("The existing spawn must remain inside the forecourt and clear of collisions")
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.DOWN, Vector2(-1, 1).normalized(), Vector2(1, 1).normalized()]:
		player.global_position = spawn
		var collision := KinematicCollision2D.new()
		if not player.test_move(player.global_transform, direction * 1000, collision):
			return _fail("A boundary sweep must stop before leaving the entrance: " + str(direction))
		if collision.get_collider() != boundary:
			return _fail("The invisible entrance boundary must stop the sweep: " + str(direction))

	var original_speed: float = player.get("run_speed")
	for speed in [original_speed, 78000.0]:
		player.set("run_speed", speed)
		for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.DOWN, Vector2(-1, 1).normalized(), Vector2(1, 1).normalized()]:
			player.global_position = spawn
			for frame in range(12):
				await physics_frame
				player.call("_move_with_direction", direction, true, 1.0 / 60.0)
				if not _inside(player, feet):
					return _fail("Running must not tunnel through a side or bottom corner: " + str(direction) + " at " + str(speed))
	player.set("run_speed", original_speed)
	player.global_position = Vector2(208, 139)
	await physics_frame
	await physics_frame
	var door := world.get_node("FrontDoorInteraction")
	if not player.test_move(player.global_transform, Vector2(0, -80)):
		return _fail("The closed door must still block entry")
	_press(player)
	await physics_frame
	await physics_frame
	if not door.get("is_open") or player.test_move(player.global_transform, Vector2(0, -80)):
		return _fail("The open door must remain an unobstructed upward passage")
	player.global_position = Vector2(208, 72)
	await physics_frame
	if player.test_move(player.global_transform, Vector2(0, 80)):
		return _fail("The open door must also allow returning to the forecourt")
	_press(player)
	await physics_frame
	await physics_frame
	if door.get("is_open") or not player.test_move(player.global_transform, Vector2(0, 80)):
		return _fail("Closing the door must restore its collision independently of the boundary")

	player.global_position = spawn
	player.velocity = Vector2.ZERO
	await create_timer(0.3).timeout
	for sprite in world.find_children("*", "AnimatedSprite2D", true, false):
		(sprite as AnimatedSprite2D).stop()
	if DisplayServer.get_name() != "headless":
		DirAccess.make_dir_recursive_absolute(OUTPUT)
		for size in [Vector2i(1152, 648), Vector2i(640, 360)]:
			viewport.size = size
			camera.force_update_scroll()
			var with_boundary := await _image(viewport)
			boundary.collision_layer = 0
			var without_boundary := await _image(viewport)
			boundary.collision_layer = 1
			if with_boundary.get_data() != without_boundary.get_data():
				return _fail("The physics boundary must not change any rendered pixels")
			if with_boundary.save_png(OUTPUT + "entrance_boundary_" + str(size.x) + ".png") != OK:
				return _fail("Could not save the entrance boundary preview")
	print("Invisible entrance boundary: spawn, three sides, corner sweeps, normal/extreme running, reversible door passage and unchanged render passed")
	quit()

func _inside(player: CharacterBody2D, feet: CollisionShape2D) -> bool:
	var shape := feet.shape as RectangleShape2D
	var rect := Rect2(feet.global_position - shape.size / 2, shape.size)
	return INTERIOR.grow(0.1).encloses(rect)

func _press(player: CharacterBody2D) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = KEY_E
	event.pressed = true
	player._unhandled_input(event)

func _image(viewport: SubViewport) -> Image:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	return viewport.get_texture().get_image()

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
