extends SceneTree

const DemoTasks = preload("res://demo_tasks.gd")
const Supplies = preload("res://demo_receiving_supplies.gd")
const FOOT := Vector2(0, 25)
var failed := false
var viewport: SubViewport
var world: Node2D
var player: CharacterBody2D
var demo: Node
var store := WarehouseSaveStore.new()

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	viewport = SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	_create_world()
	await _settle()
	store.directory = "user://tmp/demo_receiving_test"
	var initial := store.capture(world)
	var truck := world.get_node("YSortActors/TransporterSprites").get_child(0) as PickupVehicle
	var finished := initial.duplicate(true)
	finished.demo.merge({"completed": true, "stage": "unload_complete", "free_time_remaining": 0,
		"gate19_open": true, "assigned_vehicle": str(world.get_path_to(truck)), "placed_count": 12}, true)
	_check(store.apply_state(world, finished), "Existing twelve-pallet completion resumes with a report objective")
	await _settle()
	_check(demo._objective.text.contains("старшему смены") and demo._hint_button.visible and demo.remaining_pallets() == 0, "An empty truck offers the supervisor report and optional guide")
	_demo_hint()
	_check(demo._route.points[-1].is_equal_approx(demo.supervisor_point()), "Report guide ends at the original supervisor")
	player.register_pickup_vehicle(truck)
	player._interact_with_vehicle()
	player.global_position = demo.supervisor_point() - FOOT
	_check(demo.get_interaction_text(player).contains("оставить паллетовоз") and not demo.try_interact(player), "Park the transporter before the supervisor conversation")
	player.global_position = Vector2(-1900, -2700)
	player._interact_with_vehicle()
	player.global_position = demo.supervisor_point() - FOOT
	await _settle()
	_press(KEY_E, true)
	_check(demo._modal_kind.is_empty(), "Key repeat cannot start a report")
	_press(KEY_E)
	_check(demo._dialog_text.text == DemoTasks.REPORT_DIALOGUE[0], "Supervisor praises the completed unload")
	await _capture("supervisor_report")
	demo.close_modal()
	_check(demo.stage == "unload_complete", "Cancelling the report keeps the objective")
	_press(KEY_ENTER)
	_finish_conversation()
	_check(demo.stage == "find_receiving_supervisor" and demo.assigned_vehicle.is_empty(), "Finished report unlocks the receiving lead, not arbitrary equipment")
	var next_lead := store.capture(world)
	_check(store._valid(next_lead), "Lead search saves independently of the parked transporter")
	_press(KEY_E)
	_finish_conversation()
	_check(demo.stage == "find_receiving_supervisor", "Repeated supervisor conversation cannot reset the next assignment")
	_demo_hint()
	_check(demo._route.points[-1].is_equal_approx(demo._receiving_lead.global_position), "The next guide points to the upper right receiving lead")
	player.global_position = demo._receiving_lead.global_position - FOOT
	await _settle()
	player._update_interaction_hint()
	_check(player._interaction_hint.text.begins_with("[color=#ff6868]") and demo.get_interaction_text(player).contains(DemoTasks.RECEIVING_SPEAKER), "The correct lead has a red role and conversation action")
	_press(KEY_ENTER)
	_check(demo._dialog_title.text == DemoTasks.RECEIVING_SPEAKER, "Receiving dialogue names the section lead")
	await _capture("receiving_introduction")
	demo.close_modal()
	_check(demo.stage == "find_receiving_supervisor", "Cancelling the lead introduction keeps the objective")
	_press(KEY_E)
	_finish_conversation()
	_check(demo.stage == "find_receiving_jack" and demo._objective.text.contains("№5"), "Lead assigns one tote stack and table five")
	_check(not demo.can_use_vehicle(truck), "The new assignment does not permit a powered transporter")
	var jack := demo.nearest_free_pallet_jack() as PickupVehicle
	_check(jack != null and demo.can_use_vehicle(jack), "Only a free manual jack is available")
	_demo_hint()
	_check(demo._route.points[-1].is_equal_approx(jack.interaction_area.global_position), "Optional search guide points to the nearest free manual jack")
	jack.global_position = Vector2(-3850, -2700)
	player.global_position = jack.interaction_area.global_position - FOOT
	await _settle()
	player.register_pickup_vehicle(jack)
	_press(KEY_E)
	_check(demo.stage == "find_tote_stock" and player._carried_vehicle == jack and not player.pallet_jack_loaded, "Taking a free jack starts the stock search with the empty animation")
	var stock_search := store.capture(world)
	_check(store._valid(stock_search), "A reserved manual jack stock-search state saves")
	_check(demo._supplies._originals.size() == 12 and not demo._supplies.is_source_cell(Vector2i(1, -69)), "Only the two marked stock zones are sources; the one-stack pallet is excluded")
	_check(not demo._objective.text.contains("двумя") and not demo._objective.text.contains("более стопками"), "Stock objective omits the stack-count explanation")
	for page in demo.RECEIVING_DIALOGUE:
		_check(not page.contains("две или больше") and not page.contains("одной стопкой"), "Receiving introduction omits the stack-count restriction")
	player.global_position = demo._supplies.source_point(Vector2i(1, -69)) - FOOT
	await _settle()
	_press(KEY_E)
	_check(not player.pallet_jack_loaded and demo.stage == "find_tote_stock", "A one-stack stock pallet cannot be emptied")
	var stock := world.get_node("YSortActors/PalletLayer") as TileMapLayer
	var loose := Vector2i.ZERO
	for cell in stock.get_used_cells():
		if stock.get_cell_atlas_coords(cell) == Vector2i(1, 6):
			loose = cell
			break
	player.global_position = stock.to_global(stock.map_to_local(loose) + Vector2(0, 48)) - FOOT
	await _settle()
	_press(KEY_ENTER)
	_check(not player.pallet_jack_loaded and demo.stage == "find_tote_stock" and demo.get_interaction_text(player).contains("могут быть заняты"), "Loose stacks show the in-use explanation and cannot be taken")
	_check(store.apply_state(world, stock_search), "Restore the reserved jack before stock pickup")
	await _settle()
	for source in demo._supplies._originals:
		_check(_stock_approach(source), "Every permitted stock pallet has a clear pickup approach: " + str(source))
		if not failed:
			_press(KEY_E)
			await _settle()
			var previous: Vector2i = demo._supplies._originals[source].atlas
			_check(demo.stage == "deliver_totes" and stock.get_cell_atlas_coords(source) == Supplies.STOCK_ATLASES[Supplies.STOCK_ATLASES.find(previous) - 1], "Actual pickup decrements exactly one stack at " + str(source))
		_check(store.apply_state(world, stock_search), "Rewind each stock pickup without changing the other stock pallets")
		await _settle()
	var selected := Vector2i(-134, -93)
	_check(_stock_approach(selected), "There is a physically clear approach to a marked blue stock pallet")
	await _settle()
	var other_before := stock.get_cell_atlas_coords(Vector2i(-130, -97))
	_press(KEY_ENTER)
	await _settle()
	_check(player.pallet_jack_loaded and demo.stage == "deliver_totes" and demo._supplies.picked_source == selected, "One stock pickup starts delivery on the same jack")
	_check(stock.get_cell_atlas_coords(selected) == Vector2i(0, 10) and stock.get_cell_atlas_coords(Vector2i(-130, -97)) == other_before, "Four stacks become three in PalletLayer; other pallets do not change")
	_press(KEY_ENTER)
	_check(stock.get_cell_atlas_coords(selected) == Vector2i(0, 10) and player._carried_vehicle == jack, "Repeated interaction cannot remove extra stacks or drop a loaded jack")
	_check(store.save_world(world, "slot_1"), "Carried tote stack saves to disk")
	var loaded := store.read_slot("slot_1")
	_check(store.apply_state(world, loaded) and store.apply_state(world, loaded), "Loaded stock restore is idempotent")
	await _settle()
	_check(stock.get_cell_atlas_coords(selected) == Vector2i(0, 10) and player.pallet_jack_loaded, "Reload preserves exactly one removed stack and the original blue-tote animation")
	_demo_hint()
	_check(demo._route.points[-1].is_equal_approx(demo._supplies.delivery_point()), "Delivery guide targets receiving table five")
	var table5_found := false
	for table in world.get_node("TableHints")._tables:
		table5_found = table5_found or (table.cell == Supplies.TABLE_CELL and table.title == "Стол приемки")
	_check(table5_found and demo._supplies.delivery_point() != Vector2.ZERO, "Destination is derived from the actual receiving table five footprint")
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		player.global_position = Vector2(-3750, -2700)
		player._try_face_direction(direction)
		player._update_active_visual(false, false, 0)
		await _settle()
		_check(player._tote_sprite.texture == player.PALLET_JACK_TOTES_TEXTURE and player._tote_sprite.frame_coords.y == [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN].find(direction), "Loaded jack uses the existing eight-frame, four-direction hand-drawn sheet")
		_check(not player.pallet_jack_horizontal.visible and not player.pallet_jack_vertical.visible and not player._tote_collision.disabled, "Loaded tote sprite replaces, rather than overlays, the empty operator and has cargo collision")
		await _capture("blue_totes_" + player._collision_direction_name(direction))
		var loaded_position: Vector2 = player._tote_sprite.position
		player.set_pallet_jack_totes(false)
		var empty: Sprite2D = player.pallet_jack_horizontal if direction in [Vector2.LEFT, Vector2.RIGHT] else player.pallet_jack_vertical
		var pixel := Vector2(65, 150) if direction == Vector2.LEFT else Vector2(180, 150)
		var padding := Vector2(25, 25)
		var empty_center := Vector2(125, 125)
		if direction in [Vector2.UP, Vector2.DOWN]:
			pixel = Vector2(150, 100 if direction == Vector2.UP else 240)
			padding = Vector2.ZERO
			empty_center = Vector2(150, 150)
		_check((empty.position + (pixel - empty_center) * 0.5).is_equal_approx(loaded_position + (pixel + padding - Vector2(150, 150)) * 0.5), "The operator stays in the same position when cargo is taken or placed")
		player.set_pallet_jack_totes(true, true)
		var start := player.global_position
		var movement: Vector2 = (direction + Vector2(-direction.y, direction.x)).normalized()
		for frame in 15:
			await physics_frame
			player._move_with_direction(movement, false, 1.0 / 60, direction)
		_check(player.global_position.distance_to(start) > 10 and player.last_direction == direction, "Loaded diagonal movement keeps the selected cardinal animation")
	player.global_position = Vector2(-3750, -2700)
	player._try_face_direction(Vector2.LEFT)
	player._update_active_visual(false, false, 0)
	var obstacle := StaticBody2D.new()
	var obstacle_collision := CollisionShape2D.new()
	var tiny := RectangleShape2D.new()
	tiny.size = Vector2(2, 2)
	obstacle_collision.shape = tiny
	obstacle.add_child(obstacle_collision)
	world.add_child(obstacle)
	obstacle.global_position = player.global_position + player.TOTE_CARGO_BASES.right + Vector2(0, 8)
	await _settle()
	player.turn_knockback_limit = 0
	_check(not player._try_face_direction(Vector2.RIGHT) and player.last_direction == Vector2.LEFT, "Turning cannot put the loaded tote footprint through an obstacle outside the empty-jack footprint")
	obstacle.free()
	player.turn_knockback_limit = 128
	player.global_position = Vector2(-1520, -1960)
	await _settle()
	_press(KEY_E)
	_check(demo.stage == "deliver_totes" and not demo._supplies.delivered, "A different receiving table cannot accept the assigned stack")
	player.global_position = demo._supplies.delivery_point() + Vector2(70, 0) - FOOT
	player.last_direction = Vector2.RIGHT
	player._update_active_visual(false, false, 0)
	_check(not demo._supplies.can_place(player), "Cargo being near the target does not trigger placement while the operator is outside it")
	_check(_delivery_approach(), "Table five has a reachable placement approach based on the operator position")
	await _settle()
	_check(demo.get_interaction_text(player).contains("поставить стопку"), "Placement action appears beside receiving table five")
	await _capture("table5_before")
	_press(KEY_E)
	await _settle()
	_check(demo.stage == "totes_complete" and demo._supplies.delivered and not player.pallet_jack_loaded and not demo._hint_button.visible, "Placement finishes the first preparation phase and returns the empty jack")
	_check(demo._supplies._delivery != null and demo._supplies._delivery.collision_layer == 1, "Delivered stack stays as a solid, Y-sorted object beside table five")
	await _capture("table5_delivered")
	_check(store.save_world(world, "slot_2"), "Delivered stack state saves to disk")
	var delivered := store.read_slot("slot_2")
	await _drive_out_of_stack()
	_check(store.apply_state(world, delivered) and store.apply_state(world, delivered), "Repeated delivered restore does not duplicate stock or placed totes")
	await _settle()
	_check(stock.get_cell_atlas_coords(selected) == Vector2i(0, 10) and demo._supplies._delivery != null, "Source stays three stacks after placement and reload")
	_check(store.apply_state(world, stock_search), "An earlier stock-search save rewinds the tote assignment")
	await _settle()
	_check(stock.get_cell_atlas_coords(selected) == Vector2i(2, 6) and demo._supplies._delivery == null and not player.pallet_jack_loaded, "Rewind restores stock and removes later placed totes")
	for count in [2, 3]:
		var cell := Vector2i(1, -74) if count == 2 else selected
		var original: Dictionary = demo._supplies._originals[cell]
		var actual_atlas: Vector2i = original.atlas
		original.atlas = Supplies.STOCK_ATLASES[count - 1]
		demo._supplies.set_progress(cell, false)
		_check(stock.get_cell_atlas_coords(cell) == Supplies.STOCK_ATLASES[count - 2], "Stock state decrements two to one and three to two without an empty pallet")
		original.atlas = actual_atlas
		demo._supplies.set_progress(Supplies.NO_SOURCE, false)
	for changes in [{"tote_source": [1, -69]}, {"tote_source": [-9, -76]}, {"tote_source": [1.2, -74]}, {"totes_delivered": "yes"}, {"placed_count": 11}, {"gate19_open": false}, {"assigned_vehicle": str(world.get_path_to(truck))}]:
		var invalid := loaded.duplicate(true)
		invalid.demo.merge(changes, true)
		_check(not store.apply_state(world, invalid) and demo.stage == "find_tote_stock", "Invalid supply state is rejected before changing the world")
	var unmounted := loaded.duplicate(true)
	unmounted.player.vehicle = ""
	_check(not store._valid(unmounted), "A carried stack requires the assigned manual jack")
	_check(store.apply_state(world, delivered), "Restore completed preparation for reminder dialogue")
	player.global_position = demo._receiving_lead.global_position - FOOT
	await _settle()
	_press(KEY_E)
	_check(demo._dialog_text.text.contains("Следующим этапом"), "Cages are mentioned as a later assignment, not unlocked early")
	_finish_conversation()
	_check(demo.stage == "totes_complete" and demo._supplies.delivered, "Reminder does not repeat the supply pickup")
	for size in [Vector2i(640, 360), Vector2i(320, 240)]:
		viewport.size = size
		_check(store.apply_state(world, next_lead), "Compact lead-search restore succeeds")
		player.global_position = demo._receiving_lead.global_position - FOOT
		_press(KEY_ENTER)
		await _settle()
		_check(Rect2(Vector2.ZERO, Vector2(size)).encloses(Rect2(demo._dialog.global_position, demo._dialog.size)), "Receiving conversation fits compact viewports")
		await _capture("receiving_%dx%d" % [size.x, size.y])
		demo.close_modal()
	viewport.size = Vector2i(1100, 619)
	world.free()
	_create_world()
	await _settle()
	_check(store.apply_state(world, loaded), "Loaded assignment restores in a fresh scene")
	await _settle()
	_check(player.pallet_jack_loaded and demo.stage == "deliver_totes" and demo._supplies._stock.get_cell_atlas_coords(selected) == Vector2i(0, 10), "Fresh restore reconstructs the loaded sprite and reduced stock")
	_check(store.apply_state(world, delivered), "Completed preparation restores in a fresh scene")
	await _settle()
	_check(demo._supplies._delivery != null and not player.pallet_jack_loaded and demo.placed_count == 12, "Fresh restore reconstructs table-five supplies without resetting the unloaded truck")
	world.free()
	viewport.free()
	if not failed:
		print("Receiving preparation passed: report, section lead, reserved manual jack, marked stock only, one-stack exclusion, one-stack decrement, native blue tote animation in four facings, diagonal movement, table five, disk and fresh-scene restores, invalid-save rejection and compact UI")
	quit(1 if failed else 0)

func _create_world() -> void:
	world = load("res://warehouse_main.tscn").instantiate()
	viewport.add_child(world)
	player = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	player.get_node("Camera2D").position_smoothing_enabled = false
	demo = DemoTasks.new()
	demo.name = "DemoTasks"
	world.add_child(demo)
	demo.set_process(false)

func _stock_approach(cell: Vector2i) -> bool:
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		for offset in [Vector2.ZERO, Vector2(0, 16), Vector2(24, 16), Vector2(-24, 16), Vector2(40, 0), Vector2(-40, 0), Vector2(0, 32)]:
			player.global_position = demo._supplies.source_point(cell) + offset - FOOT
			player.last_direction = direction
			var profile: Node2D = player._collision_for_mode(direction)
			if player._collision_profile_overlaps(profile) or not player.can_load_pallet_jack_totes() or demo._supplies.nearby_source(player) != cell:
				continue
			player._apply_collision_profile(direction)
			player._update_active_visual(false, false, 0)
			return true
	return false

func _delivery_approach() -> bool:
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		for offset in [Vector2.ZERO, Vector2(0, 20), Vector2(0, -20), Vector2(-30, 0), Vector2(30, 0), Vector2(-40, 24), Vector2(40, 24)]:
			player.global_position = demo._supplies.delivery_point() + offset - FOOT
			player.last_direction = direction
			var profile: Node2D = player._collision_for_mode(direction)
			if player._collision_profile_overlaps(profile):
				continue
			player._apply_collision_profile(direction)
			player._update_active_visual(false, false, 0)
			if demo._supplies.can_place(player):
				return true
	return false

func _drive_out_of_stack() -> void:
	var body: StaticBody2D = demo._supplies._delivery
	var start := player.global_position
	var facing: Vector2 = player.last_direction
	var exit := Vector2.ZERO
	for direction in [Vector2.DOWN, Vector2.UP, Vector2.LEFT, Vector2.RIGHT]:
		var clear := true
		for step in range(1, 17):
			if player._collision_profile_overlaps(player._active_collision, direction * step * 10):
				clear = false
				break
		if clear:
			exit = direction
			break
	_check(exit != Vector2.ZERO, "A clear exit exists after placing the stack from inside the target")
	if exit == Vector2.ZERO:
		return
	for frame in 160:
		await physics_frame
		player._move_with_direction(exit, false, 1.0 / 60, facing)
	await _settle()
	_check(player.global_position.distance_to(start) > 150 and not demo._supplies._exit_exception and not player.get_collision_exceptions().has(body), "Real movement leaves the placed stack and clears its temporary operator-only exit exception")
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = demo._supplies._footprint
	query.transform = Transform2D(0, demo._supplies.delivery_point())
	query.exclude = [player.get_rid()]
	var solid := false
	for hit in player.get_world_2d().direct_space_state.intersect_shape(query):
		solid = solid or hit.collider == body
	_check(solid, "The delivered stack stays solid for the player and roaming workers after the exit")

func _demo_hint() -> void:
	if demo.hint_enabled:
		demo._clear_hint()
	demo.request_hint()
	demo._buttons.get_children().back().pressed.emit()

func _finish_conversation() -> void:
	while demo._modal_kind == "conversation":
		demo._advance_dialogue()

func _press(code: Key, echo := false) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	event.echo = echo
	player._unhandled_input(event)

func _settle() -> void:
	await physics_frame
	await physics_frame
	await process_frame
	await process_frame
	demo._process(0)

func _capture(name: String) -> void:
	player.get_node("Camera2D").force_update_scroll()
	await _settle()
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var directory := OS.get_environment("RECEIVING_QA_DIR")
	if directory.is_empty():
		directory = "res://tmp/decor_rc_qa/receiving/"
	DirAccess.make_dir_recursive_absolute(directory)
	_check(viewport.get_texture().get_image().save_png(directory.path_join(name + ".png")) == OK, "Save receiving preview")

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
