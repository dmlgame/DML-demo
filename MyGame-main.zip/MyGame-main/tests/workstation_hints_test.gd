extends SceneTree

const OUTPUT := "res://tmp/workstation_hints_qa/"
const ROLES := {
	"ChairWithNpcBack": "Старший смены приемки и размещения",
	"ChairWithNpcLeftFemaleBlonde": "Товаровед",
	"ChairWithNpcRight": "Старший участка приемки",
	"ChairEmptyLeft": "Участок подбора (нет на месте)",
	"ChairEmptyRight": "Старший участка размещения (нет на месте)",
	"ChairWithNpcBackBlond": "Старший смены производства",
	"ChairWithNpcLeftFemaleDark": "Администратор",
	"ChairWithNpcLeftMaleBlond": "Старший участка упаковки",
	"ChairEmptyRight3": "Старший участка сортировки (нет на месте)",
	"ChairEmptyRight4": "",
	"ChairWithNpcBackDark": "Старший смены отгрузки",
	"ChairWithNpcLeftMaleDark": "Администратор",
	"ChairWithNpcLeftMaleGrayGlasses": "Старший участка отгрузки",
	"ChairWithNpcRightMaleBrown": "Старший участка отгрузки",
	"ChairEmptyRight2": "",
}

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var furniture := world.get_node("YSortActors/FurnitureSprites") as Node2D
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var hint: RichTextLabel = player.get("_interaction_hint")
	var camera := player.get_node("Camera2D") as Camera2D
	var original_maps := {}
	for path in ["YSortActors/ObjectsLayer", "YSortActors/MezzanineLayer", "YSortActors/PalletLayer"]:
		original_maps[path] = world.get_node(path).tile_map_data.duplicate()
	await _settle()
	_check(player._workstation_hints.size() == 15, "15 separate workstation zones, including two unnamed places")
	var named_count := 0
	for chair_name in ROLES:
		var zone := furniture.get_node(chair_name + "/InteractionArea") as Area2D
		var expected: String = ROLES[chair_name]
		_check(zone.title == expected, "Correct role at " + chair_name)
		_check(zone.collision_layer == 0 and zone.collision_mask == 0 and not zone.monitoring and not zone.monitorable, "Informational zones do not affect physics")
		player.global_position = _approach_point(zone) - Vector2(0, 25)
		player.call("_update_interaction_hint")
		_check(player._nearest_workstation_hint() == zone, "Nearest place selected at " + chair_name)
		_check(hint.get_parsed_text() == expected and hint.visible == not expected.is_empty(), "Only the selected role is shown at " + chair_name)
		var body_shape := player.get_node("CollisionOnFoot") as CollisionShape2D
		_check(not player._shape_overlaps(body_shape.shape, body_shape.global_transform), "Role is reachable outside existing furniture collisions at " + chair_name)
		if not expected.is_empty():
			named_count += 1
			_check(hint.text == "[color=#ff6868]" + expected + "[/color]", "The entire role is red, including absence text")
			camera.force_update_scroll()
			await _capture(viewport, chair_name)
		var before := player.global_position
		for key in [KEY_E, KEY_ENTER]:
			var event := InputEventKey.new()
			event.physical_keycode = key
			event.pressed = true
			player._unhandled_input(event)
		_check(player.global_position == before and hint.get_parsed_text() == expected, "Workstations have no action yet")
	_check(named_count == 13, "13 named places and two silent placeholders")
	for path in original_maps:
		_check(world.get_node(path).tile_map_data == original_maps[path], "Information leaves tile data unchanged")

	var occupied := furniture.get_node("ChairWithNpcLeftFemaleBlonde/InteractionArea") as Area2D
	player.global_position = _approach_point(occupied) - Vector2(0, 25)
	player.set_interaction_locked(true)
	_check(not hint.visible, "Interaction locks hide role hints")
	player.set_interaction_locked(false)
	_check(hint.visible and hint.get_parsed_text() == ROLES.ChairWithNpcLeftFemaleBlonde, "Unlock restores the role")
	var vehicle := world.get_node("YSortActors/PalletJackAssets").get_child(0) as PickupVehicle
	player.register_pickup_vehicle(vehicle)
	player.call("_update_interaction_hint")
	_check(hint.get_parsed_text() == vehicle.get_interaction_text(), "Actionable vehicle hints retain priority")
	player.unregister_pickup_vehicle(vehicle)
	player.call("_update_interaction_hint")
	_check(hint.get_parsed_text() == occupied.title, "Role returns after vehicle hint ends")
	for mode in [player.MoveMode.ON_FOOT, player.MoveMode.PALLET_JACK, player.MoveMode.TRANSPORTER]:
		player.set_move_mode(mode)
		player.call("_update_interaction_hint")
		_check(hint.get_parsed_text() == occupied.title, "Foot-based zones work in every movement mode")
	player.set_move_mode(player.MoveMode.ON_FOOT)

	var upper := furniture.get_node("ChairEmptyRight3/InteractionArea") as Area2D
	var unnamed := furniture.get_node("ChairEmptyRight4/InteractionArea") as Area2D
	player.global_position = unnamed.global_position - Vector2(0, 37)
	_check(upper.contains_actor(player) and unnamed.contains_actor(player), "Test point lies in both right-hand zones")
	player.call("_update_interaction_hint")
	_check(player._nearest_workstation_hint() == unnamed and not hint.visible, "Unnamed place does not borrow its neighbor's title")
	player.global_position = upper.global_position - Vector2(0, 13)
	player.call("_update_interaction_hint")
	_check(player._nearest_workstation_hint() == upper and hint.get_parsed_text() == upper.title, "Overlap selects the closer named place")

	var chair := occupied.get_parent() as Node2D
	var old_position := chair.position
	var old_zone_position := occupied.global_position
	chair.position += Vector2(16, 8)
	_check(occupied.global_position.is_equal_approx(old_zone_position + Vector2(16, 8)), "Moving a chair also moves its interaction zone")
	player.global_position = _approach_point(occupied) - Vector2(0, 25)
	player.call("_update_interaction_hint")
	_check(hint.get_parsed_text() == occupied.title, "Moved zone remains functional")
	chair.position = old_position
	player.global_position = _approach_point(occupied) - Vector2(0, 25)
	occupied.hide()
	player.call("_update_interaction_hint")
	_check(not hint.visible, "Hidden workstations do not display hints")
	occupied.show()
	var shape := occupied.get_node("CollisionShape2D") as CollisionShape2D
	shape.disabled = true
	player.call("_update_interaction_hint")
	_check(not hint.visible, "Disabling a zone disables its role hint")
	shape.disabled = false
	player.global_position = Vector2(0, -3500)
	player.call("_update_interaction_hint")
	_check(not hint.visible, "Walking away hides the role")

	viewport.size = Vector2i(320, 240)
	var long_role := furniture.get_node("ChairEmptyRight/InteractionArea") as Area2D
	player.global_position = _approach_point(long_role) - Vector2(0, 25)
	camera.force_update_scroll()
	player.call("_update_interaction_hint")
	await _capture(viewport, "compact_hint")
	_check(Rect2(Vector2.ZERO, Vector2(viewport.size)).encloses(Rect2(hint.get_global_transform_with_canvas().origin, hint.size)), "Long role and absence text fit the compact HUD")
	occupied.free()
	_check(player._workstation_hints.size() == 14, "Removed zones unregister cleanly")
	world.free()
	viewport.free()
	if not failed:
		print("Workstation hints passed: 15 zones / 13 roles, correct positions, red titles, vacancies, unnamed places, reachable approaches, nearest overlap, action priority, locks, all movement modes, relocation, removal, unchanged map and compact HUD")
	quit(1 if failed else 0)

func _approach_point(zone: Area2D) -> Vector2:
	var shape := zone.get_node("CollisionShape2D") as CollisionShape2D
	var rect := shape.shape.get_rect()
	var chair_name := String(zone.get_parent().name)
	var point := Vector2.ZERO
	if chair_name.contains("Back"):
		point.y = rect.end.y - 6
	elif chair_name.contains("Left"):
		point.x = rect.position.x + 6
	else:
		point.x = rect.end.x - 6
	return shape.to_global(point)

func _settle() -> void:
	await physics_frame
	await process_frame
	await process_frame

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		await _settle()
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	_check(viewport.get_texture().get_image().save_png(OUTPUT + name + ".png") == OK, "Save workstation preview")

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
