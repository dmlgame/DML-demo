extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"
const RECEIVING := "Стол приемки"
const PACKING := "Стол упаковки"
const SORTING := "Стол сортировки"

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var layer := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	var tables := world.get_node("TableHints")
	var hint: RichTextLabel = player.get("_interaction_hint")
	var source := layer.tile_set.get_source(0) as TileSetAtlasSource
	var receiving := source.get_tile_data(Vector2i(0, 6), 0)
	var packing := source.get_tile_data(Vector2i(0, 6), 1)
	_check(receiving.get_custom_data("interaction_name") == RECEIVING and packing.get_custom_data("interaction_name") == PACKING, "Identical table graphics have distinct roles")
	_check(receiving.texture_origin == packing.texture_origin and receiving.y_sort_origin == packing.y_sort_origin and receiving.get_collision_polygon_points(0, 0) == packing.get_collision_polygon_points(0, 0), "Packing alternative preserves the original image alignment, depth and collision")
	var original_bytes: PackedByteArray = layer.get("tile_map_data")
	var expected := _expected_cells()
	_check(tables._tables.size() == 34, "Exactly 34 table zones")
	var counts := {RECEIVING: 0, PACKING: 0, SORTING: 0}
	var captured := {}
	for table in tables._tables:
		_check(expected.get(table.cell, "") == table.title, "Correct table role at " + str(table.cell))
		counts[table.title] += 1
		var footprint: Rect2 = table.footprint
		var points := [
			Vector2(footprint.get_center().x, footprint.end.y + 24),
			Vector2(footprint.position.x - 24, footprint.get_center().y),
			Vector2(footprint.end.x + 24, footprint.get_center().y),
			Vector2(footprint.get_center().x, footprint.position.y - 24),
		]
		for feet in points:
			player.global_position = layer.to_global(feet) - Vector2(0, 25)
			player.call("_update_interaction_hint")
			_check(tables.get_interaction_text(player) == table.title, "Each table has a single approach zone from every side")
			_check(hint.visible and hint.get_parsed_text() == table.title and hint.text == "[color=#ff6868]" + table.title + "[/color]", "Only the red table title is displayed")
		player.global_position = layer.to_global(points[0]) - Vector2(0, 25)
		player.get_node("Camera2D").force_update_scroll()
		if not captured.has(table.title):
			player.call("_update_interaction_hint")
			await _capture(viewport, "table_" + str(captured.size()))
			captured[table.title] = true
	_check(counts == {RECEIVING: 14, PACKING: 10, SORTING: 10}, "14 receiving, 10 packing and 10 sorting tables")
	player.call("_update_interaction_hint")
	var before_position := player.global_position
	for key in [KEY_E, KEY_ENTER]:
		var event := InputEventKey.new()
		event.physical_keycode = key
		event.pressed = true
		player._unhandled_input(event)
	_check(layer.get("tile_map_data") == original_bytes and player.global_position == before_position, "Informational table hints add no action or map changes")
	player.set_interaction_locked(true)
	_check(not hint.visible, "Hide table hints during modal/transition interaction locks")
	player.set_interaction_locked(false)
	_check(hint.visible, "Unlock restores the nearby table title")
	var vehicle := world.get_node("YSortActors/PalletJackAssets").get_child(0) as PickupVehicle
	player.register_pickup_vehicle(vehicle)
	player.call("_update_interaction_hint")
	_check(hint.get_parsed_text() == vehicle.get_interaction_text(), "Actionable vehicle hints take priority over informational table names")
	player.unregister_pickup_vehicle(vehicle)
	player.call("_update_interaction_hint")
	_check(hint.get_parsed_text() == tables.get_interaction_text(player), "Table name returns after the actionable hint leaves")
	var old_cell := Vector2i(47, -73)
	var new_cell := Vector2i(-104, -80)
	_check(layer.get_cell_source_id(new_cell) == -1, "Relocation test destination is empty")
	layer.erase_cell(old_cell)
	layer.set_cell(new_cell, 0, Vector2i(0, 6), 1)
	await _settle()
	_check(tables._tables.size() == 34, "Tile changes rebuild zones without duplicate tables")
	for table in tables._tables:
		if table.cell == new_cell:
			player.global_position = layer.to_global(table.footprint.get_center() + Vector2(0, 24)) - Vector2(0, 25)
	_check(tables.get_interaction_text(player) == PACKING, "A packing table keeps its name after moving into block two")
	layer.erase_cell(new_cell)
	layer.set_cell(old_cell, 0, Vector2i(0, 6), 1)
	await _settle()
	player.global_position = Vector2(0, -3500)
	player.call("_update_interaction_hint")
	_check(not hint.visible and tables.get_interaction_text(player).is_empty(), "Table hint disappears when walking away")
	viewport.size = Vector2i(320, 240)
	var table: Dictionary = tables._tables[0]
	player.global_position = layer.to_global(table.footprint.get_center() + Vector2(0, 24)) - Vector2(0, 25)
	player.get_node("Camera2D").force_update_scroll()
	player.call("_update_interaction_hint")
	await _capture(viewport, "table_small")
	_check(Rect2(Vector2.ZERO, Vector2(viewport.size)).encloses(Rect2(hint.get_global_transform_with_canvas().origin, hint.size)), "Single-line table hint fits small viewports")
	world.free()
	viewport.free()
	if not failed:
		print("Table hints passed: 14 receiving / 10 packing / 10 sorting, four approaches, red title only, unchanged collisions, metadata follows moved tiles, live rebuild, action priority, locks, walking away, compact HUD")
	quit(1 if failed else 0)

func _expected_cells() -> Dictionary:
	var result := {}
	for x in [-111, -96, -80, -64, -48, -32, -9]:
		for y in [-76, -63]:
			result[Vector2i(x, y)] = RECEIVING
	for x in [47, 63, 79, 94, 109]:
		for y in [-73, -57]:
			result[Vector2i(x, y)] = PACKING
		for y in [-41, -26]:
			result[Vector2i(x, y)] = SORTING
	return result

func _settle() -> void:
	await process_frame
	await process_frame

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		await _settle()
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	_check(viewport.get_texture().get_image().save_png(OUTPUT + name + ".png") == OK, "Save table hint preview")

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
