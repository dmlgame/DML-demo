extends SceneTree

const STEP := 1.0 / 60.0
const DIRECTIONS := [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN,
	Vector2(-1, -1), Vector2(1, -1), Vector2(-1, 1), Vector2(1, 1)]
const OUTPUT := "res://tmp/decor_rc_qa/camera_scenery/"

var _failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("Camera scenery validation needs a renderer")
		quit(1)
		return
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	viewport.canvas_item_default_texture_filter = Viewport.DEFAULT_CANVAS_ITEM_TEXTURE_FILTER_NEAREST
	root.add_child(viewport)
	var player := load("res://character_body_2d.tscn").instantiate() as CharacterBody2D
	viewport.add_child(player)
	player.set_physics_process(false)
	player.set_process(false)
	player.get_node("Visuals").hide()
	var camera := player.get_node("Camera2D") as Camera2D
	var scenery: Array[Sprite2D] = []
	var npc := Sprite2D.new()
	npc.name = "Supervisor"
	npc.texture = (player.get_node("Visuals/OnFoot") as AnimatedSprite2D).sprite_frames.get_frame_texture("idle_down", 0)
	npc.position = Vector2(155.3, 210.2)
	npc.scale = Vector2.ONE * 1.1
	scenery.append(npc)
	var jack := Sprite2D.new()
	jack.name = "ParkedJack"
	jack.texture = load("res://assets/objects/pallet_jack/pallet_jack_right.png")
	jack.position = Vector2(485.25, 200.7)
	jack.scale = Vector2.ONE * 0.7
	scenery.append(jack)
	var stair := Sprite2D.new()
	stair.name = "Staircase"
	var steps := AtlasTexture.new()
	steps.atlas = load("res://assets/objects/second_floor_staircase/second_floor_staircase.png")
	steps.region = Rect2(300, 700, 256, 256)
	stair.texture = steps
	stair.position = Vector2(475.4, 305.6)
	stair.scale = Vector2.ONE * 0.35
	scenery.append(stair)
	for sprite in scenery:
		viewport.add_child(sprite)
	for size in [Vector2i(1100, 619), Vector2i(1100, 620), Vector2i(768, 432)]:
		viewport.size = size
		camera.zoom = Vector2.ONE * (1.25 if size.x < 1000 else 2.0)
		for direction in DIRECTIONS:
			player.position = Vector2(320.17, 240.37)
			player.call("set_move_mode", 0)
			var facing: Vector2 = player.call("_cardinal_direction", direction)
			var reference_origin := Vector2i.ZERO
			var references: Array[Dictionary] = []
			var changed := 0
			for frame in range(18):
				await physics_frame
				player.call("_move_with_direction", direction, false, STEP, facing)
				(player.get_node("Visuals/OnFoot") as AnimatedSprite2D).stop()
				(player.get_node("Visuals/OnFoot") as AnimatedSprite2D).frame = 0
				await RenderingServer.frame_post_draw
				await RenderingServer.frame_post_draw
				var captured := viewport.get_texture().get_image()
				var transform := viewport.canvas_transform
				var origin := Vector2i(transform.origin.round())
				if frame == 0:
					reference_origin = origin
					for sprite in scenery:
						var bounds := (transform * sprite.global_transform) * sprite.get_rect()
						var rect := Rect2i(Vector2i(bounds.position.floor()) - Vector2i(3, 3), Vector2i(bounds.size.ceil()) + Vector2i(6, 6))
						if not Rect2i(Vector2i.ZERO, size).encloses(rect):
							push_error("Scenery test must render the entire reference: " + str(sprite.name))
							quit(1)
							return
						references.append({"rect": rect, "pixels": captured.get_region(rect).get_data(), "name": sprite.name})
				else:
					for reference in references:
						var rect: Rect2i = reference.rect
						rect.position += origin - reference_origin
						if not Rect2i(Vector2i.ZERO, size).encloses(rect):
							push_error("Scenery test moved outside the viewport: " + str(reference.name))
							quit(1)
							return
						if captured.get_region(rect).get_data() != reference.pixels:
							changed += 1
			print("viewport=%s direction=%s scenery_changes=%d/51" % [size, direction, changed])
			_failed = _failed or changed > 0
	viewport.queue_free()
	await process_frame
	await _check_warehouse()
	if _failed and not OS.get_cmdline_user_args().has("--probe"):
		push_error("Stationary scenery changes pixels instead of translating as one image")
		quit(1)
		return
	print("Scenery pixel stability: %s" % ("FAIL" if _failed else "PASS"))
	quit()

func _check_warehouse() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	await physics_frame
	await physics_frame
	for worker in world.find_children("*", "CharacterBody2D", true, false):
		worker.set_physics_process(false)
	for hud in world.find_children("*", "CanvasLayer", true, false):
		hud.hide()
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.collision_mask = 0
	player.get_node("Visuals").hide()
	var camera := player.get_node("Camera2D") as Camera2D
	for path in ["FurnitureSprites/ChairWithNpcRight", "PalletJackAssets/PalletJackRight5", "SecondFloorStaircaseSort/SecondFloorStaircase"]:
		var sprite := world.get_node("YSortActors/" + path) as Sprite2D
		var center := sprite.to_global(sprite.get_rect().get_center())
		camera.zoom = Vector2.ONE * 2.0
		for direction in DIRECTIONS.slice(4):
			player.global_position = center + Vector2(120.17, -60.37)
			var reference_origin := Vector2i.ZERO
			var reference_rect := Rect2i()
			var reference_pixels := PackedByteArray()
			var changed := 0
			for frame in range(18):
				await physics_frame
				player.call("_move_with_direction", direction, false, STEP, Vector2.RIGHT)
				await RenderingServer.frame_post_draw
				await RenderingServer.frame_post_draw
				var captured := viewport.get_texture().get_image()
				var origin := Vector2i(viewport.canvas_transform.origin.round())
				if frame == 0:
					reference_origin = origin
					var screen_center := Vector2i((viewport.canvas_transform * center).round())
					reference_rect = Rect2i(screen_center - Vector2i(64, 64), Vector2i(128, 128))
					reference_pixels = captured.get_region(reference_rect).get_data()
				else:
					var rect := reference_rect
					rect.position += origin - reference_origin
					if captured.get_region(rect).get_data() != reference_pixels:
						changed += 1
				if direction == Vector2(1, 1) and frame in [0, 8, 17]:
					DirAccess.make_dir_recursive_absolute(OUTPUT)
					captured.save_png(OUTPUT + "%s_%d.png" % [sprite.name, frame])
			print("warehouse=%s direction=%s scenery_changes=%d/17" % [sprite.name, direction, changed])
			_failed = _failed or changed > 0
