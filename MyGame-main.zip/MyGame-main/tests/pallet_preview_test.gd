extends SceneTree

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var session: Node = load("res://demo_pallet_preview.tscn").instantiate()
	root.add_child(session)
	for frame in 12:
		await physics_frame
		await process_frame
	var valid: bool = session.world != null and session.save_store.directory == "user://pallet_preview/saves"
	if valid:
		var demo: Node = session.world.get_node("DemoTasks")
		valid = demo.stage == "find_stock_jack" and demo.placed_count == 12 and demo.gate17_checked and not session.menu.visible and session.save_store._valid(session.save_store.capture(session.world))
	session.free()
	if valid:
		print("Pallet preview passed: starts at the pallet assignment, preserves earlier completed work and isolates saves")
	else:
		push_error("Pallet preview checkpoint failed")
	quit(0 if valid else 1)
