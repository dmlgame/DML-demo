extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	var actors: Node2D = world.get_node("YSortActors")
	var back_sort: Node2D = actors.get_node("BackWallSort")
	var back: TileMapLayer = back_sort.get_node("BackWallLayer")
	var sides: TileMapLayer = world.get_node("WallLayer")
	var front_sort: Node2D = actors.get_node("FrontWallSort")
	var front: TileMapLayer = front_sort.get_node("FrontWallLayer")
	var door: TileMapLayer = front_sort.get_node("FrontDoorLayer")
	var player: CharacterBody2D = actors.get_node("Player")

	if world.y_sort_enabled or not actors.y_sort_enabled or back_sort.y_sort_enabled or front_sort.y_sort_enabled:
		return _fail("Wall groups are not configured for unit Y-sorting")
	if back_sort.z_index != player.z_index or front_sort.z_index != player.z_index:
		return _fail("Walls and player must share a Z index")
	if sides.z_index != actors.z_index or sides.get_index() >= actors.get_index():
		return _fail("Side walls must render behind the front and back wall groups")
	if front.z_index != 0 or door.z_index != 0 or back.z_index != 0:
		return _fail("Wall tiles bypass their Y-sort groups")
	if back.get_used_cells().size() != 1528 or sides.get_used_cells().size() != 516:
		return _fail("Back or side wall tiles were lost")
	for cell in back.get_used_cells():
		if cell.y < -108 or cell.y > -105:
			return _fail("A side wall tile moved into the back wall layer")
	for cell in sides.get_used_cells():
		if cell.y >= -108 and cell.y <= -105:
			return _fail("A back wall tile remained in the side wall layer")
	if front.get_used_cells().size() != 1441 or door.get_used_cells().size() != 1:
		return _fail("Front wall or door tiles were lost")
	if back.tile_set != sides.tile_set:
		return _fail("Back wall lost its shared tile set and collision data")
	for layer in [back, sides, front, door]:
		if layer.global_position != Vector2.ZERO:
			return _fail("Wall tiles or collisions shifted in world space")
	if back_sort.position.y != -3353.0 or front_sort.position.y != 95.0:
		return _fail("Wall sort origins no longer match the player's foot offset")

	print("Wall Y-sort scene tests passed")
	quit()


func _fail(message: String) -> void:
	push_error(message)
	quit(1)
