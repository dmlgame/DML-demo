extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"
const GATE_CELL := Vector2i(-37, -106)
const BUTTON_CELL := Vector2i(-35, -106)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var camera := player.get_node("Camera2D") as Camera2D
	var gate := world.get_node("DockGate17Interaction")
	var dock := world.get_node("YSortActors/UnloadingDockLayer") as TileMapLayer
	var objects := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	var original_gates := _snapshot(dock)
	var original_objects := _snapshot(objects)
	var button_position := objects.to_global(objects.map_to_local(BUTTON_CELL))
	var hint := player.get("_interaction_hint") as RichTextLabel
	if dock.get_cell_atlas_coords(GATE_CELL) != Vector2i(4, 9) or objects.get_cell_atlas_coords(BUTTON_CELL) != Vector2i(1, 0):
		return _fail("Gate 17 must start closed with its red button")
	var numbers := world.get_node("FloorLayer2/NumbersLayer") as TileMapLayer
	if numbers.get_cell_atlas_coords(Vector2i(-37, -108)) != Vector2i(8, 2):
		return _fail("Interaction does not belong to the gate marked 17")
	player.global_position = button_position + Vector2(0, 150)
	player.call("_update_interaction_hint")
	_press(player, KEY_E)
	if gate.get("_busy") or hint.visible:
		return _fail("Gate must not react or show its hint from far away")
	player.global_position = button_position + Vector2(0, 60) - Vector2(0, 25)
	camera.force_update_scroll()
	await physics_frame
	await physics_frame
	if player.call("_collision_profile_overlaps", player.get("collision_on_foot")):
		return _fail("The gate interaction position must be reachable outside the wall collision")
	player.call("_update_interaction_hint")
	if not hint.visible or hint.get_parsed_text() != "Нажмите E или Enter, чтобы открыть ворота":
		return _fail("The red button must show the opening instruction")
	if not _check_hud(hint, viewport):
		return
	await _capture(viewport, "gate_17_closed")
	_press(player, KEY_E, true)
	_press(player, KEY_E, false, false)
	if gate.get("_busy"):
		return _fail("Autorepeat and key release must not activate the gate")
	_press(player, KEY_E)
	var transition := gate.get("_transition") as Tween
	if transition == null or not gate.get("_busy") or not player.get("_interaction_locked") or hint.visible:
		return _fail("Gate transition must lock movement and hide the approach hint")
	transition.pause()
	if dock.get_cell_atlas_coords(GATE_CELL) != Vector2i(4, 9):
		return _fail("Gate changed before the screen became black")
	_press(player, KEY_ENTER)
	transition.custom_step(0.13)
	var shade := gate.get("_shade") as ColorRect
	if not gate.get("is_open") or shade.color.a != 1.0:
		return _fail("Gate must swap at full blackout")
	if dock.get_cell_atlas_coords(GATE_CELL) != Vector2i(0, 9) or objects.get_cell_atlas_coords(BUTTON_CELL) != Vector2i(0, 0):
		return _fail("Opening must replace both the dock and the button atlases")
	await _capture(viewport, "gate_17_blackout", true)
	transition.custom_step(1.0)
	if gate.get("_busy") or player.get("_interaction_locked") or (gate.get("_transition_layer") as CanvasLayer).visible:
		return _fail("Transition must restore movement and clear the blackout")
	if not hint.visible or hint.get_parsed_text() != "Нажмите E или Enter, чтобы закрыть ворота":
		return _fail("The green button must show the closing instruction")
	if not _unchanged_except(dock, original_gates, GATE_CELL) or not _unchanged_except(objects, original_objects, BUTTON_CELL):
		return _fail("Opening gate 17 modified another gate or object")
	await _capture(viewport, "gate_17_open")
	viewport.size = Vector2i(640, 360)
	camera.force_update_scroll()
	await _capture(viewport, "gate_17_small")
	if not _check_hud(hint, viewport):
		return
	_press(player, KEY_ENTER)
	transition = gate.get("_transition") as Tween
	transition.pause()
	transition.custom_step(0.13)
	if gate.get("is_open") or dock.get_cell_atlas_coords(GATE_CELL) != Vector2i(4, 9) or objects.get_cell_atlas_coords(BUTTON_CELL) != Vector2i(1, 0):
		return _fail("Closing must restore the original closed gate and red button")
	await _capture(viewport, "gate_17_small_blackout", true)
	transition.custom_step(1.0)
	if _snapshot(dock) != original_gates or _snapshot(objects) != original_objects:
		return _fail("Closing did not restore the exact original tile state")
	viewport.size = Vector2i(1100, 619)
	var jack := load("res://assets/objects/pallet_jack/pallet_jack_right.tscn").instantiate() as PickupVehicle
	jack.position = player.position + Vector2(50, 0)
	world.get_node("YSortActors").add_child(jack)
	player.register_pickup_vehicle(jack)
	player.call("_update_interaction_hint")
	if not hint.get_parsed_text().ends_with("открыть ворота"):
		return _fail("Gate hint must take priority over a nearby vehicle")
	_press(player, KEY_KP_ENTER)
	transition = gate.get("_transition") as Tween
	transition.pause()
	transition.custom_step(1.0)
	if jack.is_carried or not gate.get("is_open"):
		return _fail("One gate interaction must not also pick up a nearby vehicle")
	player.global_position = button_position + Vector2(0, 180)
	jack.position = player.position + Vector2(35, 0)
	player.register_pickup_vehicle(jack)
	player.call("_update_interaction_hint")
	if hint.get_parsed_text() != "Рохля\nНажмите E или Enter, чтобы взять рохлю":
		return _fail("Vehicle instruction must return when leaving the gate")
	camera.force_update_scroll()
	await _capture(viewport, "pallet_jack_hint")
	_press(player, KEY_ENTER)
	if not jack.is_carried:
		return _fail("Enter failed to pick up the jack away from the gate")
	player.global_position = button_position + Vector2(0, 60) - Vector2(0, 25)
	_press(player, KEY_ENTER)
	transition = gate.get("_transition") as Tween
	transition.pause()
	transition.custom_step(1.0)
	if not jack.is_carried or gate.get("is_open"):
		return _fail("Operating the gate must not drop a carried vehicle")
	player.global_position = button_position + Vector2(0, 180)
	_press(player, KEY_E)
	jack.position = player.position + Vector2(60, 0)
	var transporter := load("res://assets/objects/transporter/transporter_left_empty.tscn").instantiate() as PickupVehicle
	transporter.position = player.position + Vector2(30, 0)
	world.get_node("YSortActors").add_child(transporter)
	player.register_pickup_vehicle(jack)
	player.register_pickup_vehicle(transporter)
	player.call("_update_interaction_hint")
	if hint.get_parsed_text() != "Паллетовоз\nНажмите E или Enter, чтобы сесть в транспорт":
		return _fail("Nearest vehicle must show the correctly spelled transporter name")
	camera.force_update_scroll()
	await _capture(viewport, "transporter_hint")
	_press(player, KEY_E)
	if not transporter.is_carried or jack.is_carried or player.get("move_mode") != 2:
		return _fail("Pickup must select the same nearest vehicle as the hint")
	player.global_position = button_position + Vector2(0, 60) - Vector2(0, 25)
	_press(player, KEY_ENTER)
	transition = gate.get("_transition") as Tween
	await transition.finished
	if not gate.get("is_open") or gate.get("_busy") or player.get("_interaction_locked"):
		return _fail("The real-time transition did not finish and restore input")
	print("Gate 17 hints, E/Enter, reversible tiles, blackout, input priority and unchanged map passed")
	quit()

func _snapshot(layer: TileMapLayer) -> Dictionary:
	var result := {}
	for cell in layer.get_used_cells():
		result[cell] = [layer.get_cell_source_id(cell), layer.get_cell_atlas_coords(cell), layer.get_cell_alternative_tile(cell)]
	return result

func _check_hud(hint: RichTextLabel, viewport: SubViewport) -> bool:
	var transform := hint.get_global_transform_with_canvas()
	if transform.origin != Vector2(16, 16) or transform.get_scale() != Vector2.ONE:
		_fail("Hint must stay in the upper-left corner without camera scaling")
		return false
	if hint.size.x > 300 or hint.size.y > 96 or not Rect2(Vector2.ZERO, viewport.size).encloses(Rect2(transform.origin, hint.size)):
		_fail("Hint must remain compact and inside the screen")
		return false
	if hint.horizontal_alignment != HORIZONTAL_ALIGNMENT_LEFT or hint.get_theme_font_size("normal_font_size") != 16:
		_fail("Hint must use left-aligned native-size text")
		return false
	return true

func _unchanged_except(layer: TileMapLayer, original: Dictionary, changed: Vector2i) -> bool:
	var current := _snapshot(layer)
	current.erase(changed)
	var expected := original.duplicate()
	expected.erase(changed)
	return current == expected

func _press(player: CharacterBody2D, keycode: Key, echo := false, pressed := true) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	event.pressed = pressed
	event.echo = echo
	player._unhandled_input(event)

func _capture(viewport: SubViewport, name: String, blackout := false) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var image := viewport.get_texture().get_image()
	if blackout:
		for point in [Vector2i(0, 0), viewport.size / 2, viewport.size - Vector2i.ONE]:
			var pixel := image.get_pixelv(point)
			if maxf(pixel.r, maxf(pixel.g, pixel.b)) > 0.01:
				return _fail("Blackout does not cover the entire viewport at " + str(point))
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	if image.save_png(OUTPUT + name + ".png") != OK:
		_fail("Could not save interaction preview")

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
