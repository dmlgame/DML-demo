extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	var saved_maps := {}
	for layer_name in ["ConveyorLayer", "PalletLayer", "MezzanineLayer"]:
		saved_maps[layer_name] = world.get_node("YSortActors/" + layer_name).tile_map_data.duplicate()
	root.add_child(world)
	var actors: Node2D = world.get_node("YSortActors")
	var player: Node2D = actors.get_node("Player")
	for entry in [
		["ConveyorLayer", -9],
		["PalletLayer", 23],
		["MezzanineLayer", 23],
	]:
		var layer: TileMapLayer = actors.get_node(entry[0])
		if not layer.y_sort_enabled or layer.z_index != player.z_index:
			return _fail("Layer does not sort with the player: " + entry[0])
		if layer.get_used_cells().is_empty() or layer.tile_map_data != saved_maps[entry[0]] or layer.y_sort_origin != entry[1]:
			return _fail("Layer tiles or sort origin changed: " + entry[0])
	var pallets: TileMapLayer = actors.get_node("PalletLayer")
	var pallet_source := pallets.tile_set.get_source(0) as TileSetAtlasSource
	for atlas_coords in [Vector2i(2, 6), Vector2i(0, 10), Vector2i(3, 10), Vector2i(6, 10)]:
		if pallet_source.get_tile_data(atlas_coords, 0).y_sort_origin != 16:
			return _fail("Tall pallet does not sort at its collision base: " + str(atlas_coords))
	if pallet_source.get_tile_data(Vector2i(6, 3), 0).y_sort_origin != 0:
		return _fail("Short pallets lost their base sort origin")
	for path in [
		"ConveyorLayer/ConveyorSprites",
		"PalletJackAssets",
		"MezzanineLayer/MezzanineAccessSprites",
		"FurnitureSprites",
		"TransporterSprites",
	]:
		var group: Node2D = actors.get_node(path)
		if not group.y_sort_enabled or group.z_index != player.z_index:
			return _fail("Sprite group does not sort with the player: " + path)
		for child in group.get_children():
			if child is not Sprite2D:
				return _fail("Unexpected child in sprite group: " + path)
			var sprite := child as Sprite2D
			var anchor := sprite.get_node_or_null("SortVisual") as Node2D
			if anchor == null or anchor.get_child_count(true) != 1:
				return _fail("Sprite has no contact-point visual: " + str(sprite.name))
			if anchor.z_index != player.z_index:
				return _fail("Sprite visual bypasses Y-sorting: " + str(sprite.name))
			if not sprite.y_sort_enabled or sprite.z_index != player.z_index or sprite.self_modulate.a != 0.0:
				return _fail("Original sprite bypasses contact-point sorting: " + str(sprite.name))
	var numbers: TileMapLayer = world.get_node("FloorLayer2/NumbersLayer")
	if numbers.global_position != Vector2(-16, 0) or numbers.z_index != 1:
		return _fail("Number labels moved or do not render above the objects")
	var monitor: Sprite2D = actors.get_node("FurnitureSprites/Monitor")
	var furniture: Node2D = actors.get_node("FurnitureSprites")
	await process_frame
	player.global_position = monitor.global_position
	furniture._process(0.0)
	if player.z_index != 0:
		return _fail("Furniture overlap raises the player above unrelated objects")
	var objects: TileMapLayer = actors.get_node("ObjectsLayer")
	for station in [
		["Monitor", Vector2(-624, -2512), "ChairWithNpcBack"],
		["Monitor2", Vector2(2000, -1456), "ChairWithNpcBackBlond"],
		["Monitor3", Vector2(2704, -2480), "ChairWithNpcBackDark"],
	]:
		var central_monitor: Sprite2D = furniture.get_node(station[0])
		var workstation_back_y := INF
		for child in objects.get_children(true):
			if child.is_in_group("object_footprint_visual") and absf(child.global_position.x - station[1].x) < 4.0:
				workstation_back_y = minf(workstation_back_y, child.global_position.y)
		var monitor_base_y := central_monitor.to_global(Vector2(0, central_monitor.texture.get_height() / 2.0)).y
		if monitor_base_y < station[1].y - 64.0 or monitor_base_y > station[1].y - 30.0:
			return _fail("Central monitor is not standing on the tabletop: " + station[0])
		var monitor_anchor: Node2D = central_monitor.get_node("SortVisual")
		var npc_anchor: Node2D = furniture.get_node(station[2] + "/SortVisual")
		if not (workstation_back_y < monitor_anchor.global_position.y and monitor_anchor.global_position.y < npc_anchor.global_position.y):
			return _fail("Central monitor does not sort between tabletop and NPC: " + station[0])
	for pair in [
		["MonitorLeft", "ChairWithNpcRight"],
		["MonitorLeft2", "ChairEmptyRight"],
		["MonitorRight", "ChairEmptyLeft"],
		["MonitorRight2", "ChairWithNpcLeftFemaleBlonde"],
		["MonitorLeft3", "ChairEmptyRight3"],
		["MonitorLeft4", "ChairEmptyRight4"],
		["MonitorRight3", "ChairWithNpcLeftMaleBlond"],
		["MonitorRight4", "ChairWithNpcLeftFemaleDark"],
		["MonitorLeft5", "ChairWithNpcRightMaleBrown"],
		["MonitorLeft6", "ChairEmptyRight2"],
		["MonitorRight5", "ChairWithNpcLeftMaleDark"],
		["MonitorRight6", "ChairWithNpcLeftMaleGrayGlasses"],
	]:
		var monitor_anchor: Node2D = furniture.get_node(pair[0] + "/SortVisual")
		var chair_anchor: Node2D = furniture.get_node(pair[1] + "/SortVisual")
		if monitor_anchor.global_position.y >= chair_anchor.global_position.y:
			return _fail("Side monitor renders in front of its character or chair: " + pair[0])
	for chair_name in ["ChairEmptyRight", "ChairWithNpcBack"]:
		var chair: Sprite2D = actors.get_node("FurnitureSprites/" + chair_name)
		var chair_anchor: Node2D = chair.get_node("SortVisual")
		for offset_y in [-10.0, 10.0]:
			player.global_position = Vector2(chair.global_position.x, chair_anchor.global_position.y + offset_y)
			furniture._process(0.0)
			if player.z_index != 0 or chair_anchor.z_index != 0:
				return _fail("Player and chair do not share a Y-sort layer: " + chair_name)
	player.global_position = Vector2(10000, 10000)
	furniture._process(0.0)
	if player.z_index != 0:
		return _fail("Player keeps workstation depth away from furniture")
	var column_source := objects.tile_set.get_source(0) as TileSetAtlasSource
	for atlas in [Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1), Vector2i(3, 1)]:
		var tile := column_source.get_tile_data(atlas, 0)
		var collision_base := -INF
		for point in tile.get_collision_polygon_points(0, 0):
			collision_base = maxf(collision_base, point.y)
		if not is_equal_approx(tile.y_sort_origin, collision_base - 25.0):
			return _fail("Tall column does not sort at its collision base: " + str(atlas))
	world.queue_free()
	await process_frame
	for entry in [
		["res://assets/objects/conveyor/conveyor_turn_left_down.tscn", 1.0],
		["res://assets/objects/pallet_jack/pallet_jack_right.tscn", 0.7],
		["res://assets/objects/mezzanine_lift/freight_lift_ground_floor.tscn", 0.3],
		["res://assets/objects/admin_workstation/placeable/chair_with_npc_back.tscn", 1.4],
		["res://assets/objects/transporter/transporter_left_empty.tscn", 1.0],
	]:
		if not await _check_sprite_render(entry[0], entry[1]):
			return
	if not await _check_workstation_chair_render():
		return
	if not await _check_workstation_monitor_render():
		return
	if not await _check_column_render():
		return
	if not await _check_lift_footprint():
		return
	if not await _check_transporter_footprint():
		return
	print("Remaining map object Y-sort tests passed")
	quit()


func _check_lift_footprint() -> bool:
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	root.add_child(actors)
	var group := Node2D.new()
	group.y_sort_enabled = true
	group.set_script(load("res://world_sprite_sort.gd"))
	var lift := load("res://assets/objects/mezzanine_lift/freight_lift_ground_floor.tscn").instantiate() as Sprite2D
	lift.scale = Vector2(0.3, 0.27)
	group.add_child(lift)
	actors.add_child(group)
	var player := Node2D.new()
	player.name = "Player"
	actors.add_child(player)
	player.position = lift.to_global(Vector2(180, 650))
	await process_frame
	var anchor: Node2D = lift.get_node("SortVisual")
	var stair_y := anchor.global_position.y
	player.position = lift.to_global(Vector2(700, 650))
	await process_frame
	var door_y := anchor.global_position.y
	if stair_y - door_y < 18.0:
		return _fail("Lift stairs and door still share one incorrect sort depth")
	if lift.get_node("StaticBody2D/CollisionPolygon2D").polygon.size() != 7:
		return _fail("Lift collision was changed by sorting")
	actors.queue_free()
	await process_frame
	return true


func _check_transporter_footprint() -> bool:
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	root.add_child(actors)
	var group := Node2D.new()
	group.y_sort_enabled = true
	group.set_script(load("res://world_sprite_sort.gd"))
	var transporter := load("res://assets/objects/transporter/transporter_left_empty.tscn").instantiate() as Sprite2D
	group.add_child(transporter)
	actors.add_child(group)
	var player := Node2D.new()
	player.name = "Player"
	actors.add_child(player)
	player.position = Vector2(0, 50)
	await process_frame
	var anchor: Node2D = transporter.get_node("SortVisual")
	var left_y := anchor.position.y
	player.position.x = 70
	await process_frame
	if left_y - anchor.position.y < 7.0:
		return _fail("Transporter still sorts both sides at the same depth")
	actors.queue_free()
	await process_frame
	return true


func _check_sprite_render(scene_path: String, scale_value: float) -> bool:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(512, 512)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var group := Node2D.new()
	group.y_sort_enabled = true
	group.set_script(load("res://world_sprite_sort.gd"))
	var sprite := load(scene_path).instantiate() as Sprite2D
	sprite.position = Vector2(200, 180)
	sprite.scale = Vector2.ONE * scale_value
	group.add_child(sprite)
	actors.add_child(group)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var anchor: Node2D = sprite.get_node("SortVisual")
	var baseline := viewport.get_texture().get_image()
	var sample := Vector2i(-1, -1)
	for y in 512:
		for x in 512:
			if baseline.get_pixel(x, y).a > 0.999:
				sample = Vector2i(x, y)
				break
		if sample.x >= 0:
			break
	if sample.x < 0:
		return _fail("Sorted sprite became invisible: " + scene_path)
	var marker := Node2D.new()
	marker.position = Vector2(200, anchor.global_position.y - 10.0)
	var patch := ColorRect.new()
	patch.color = Color.MAGENTA
	patch.position = Vector2(-1000, -1000)
	patch.size = Vector2(2000, 2000)
	marker.add_child(patch)
	actors.add_child(marker)
	await RenderingServer.frame_post_draw
	if viewport.get_texture().get_image().get_pixelv(sample) != baseline.get_pixelv(sample):
		return _fail("Player behind sprite is drawn in front: " + scene_path)
	marker.position.y = anchor.global_position.y + 10.0
	await RenderingServer.frame_post_draw
	if not viewport.get_texture().get_image().get_pixelv(sample).is_equal_approx(Color.MAGENTA):
		return _fail("Player in front of sprite is hidden: " + scene_path)
	viewport.queue_free()
	await process_frame
	return true


func _check_workstation_chair_render() -> bool:
	for scene_path in [
		"res://assets/objects/admin_workstation/placeable/chair_empty_right.tscn",
		"res://assets/objects/admin_workstation/placeable/chair_with_npc_back.tscn",
	]:
		var viewport := SubViewport.new()
		viewport.size = Vector2i(256, 256)
		viewport.transparent_bg = true
		viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
		root.add_child(viewport)
		var actors := Node2D.new()
		actors.y_sort_enabled = true
		viewport.add_child(actors)
		var furniture := Node2D.new()
		furniture.name = "FurnitureSprites"
		furniture.y_sort_enabled = true
		furniture.set_script(load("res://world_sprite_sort.gd"))
		var chair := load(scene_path).instantiate() as Sprite2D
		chair.position = Vector2(100, 100)
		furniture.add_child(chair)
		actors.add_child(furniture)
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var anchor: Node2D = chair.get_node("SortVisual")
		var baseline := viewport.get_texture().get_image()
		var sample := Vector2i(-1, -1)
		for y in 256:
			for x in 256:
				if baseline.get_pixel(x, y).a > 0.999:
					sample = Vector2i(x, y)
					break
			if sample.x >= 0:
				break
		if sample.x < 0:
			return _fail("Chair is invisible: " + scene_path)
		var marker := Node2D.new()
		marker.z_index = 0
		var patch := ColorRect.new()
		patch.color = Color.MAGENTA
		patch.position = Vector2(-256, -256)
		patch.size = Vector2(512, 512)
		marker.add_child(patch)
		actors.add_child(marker)
		marker.position.y = anchor.global_position.y - 10.0
		await RenderingServer.frame_post_draw
		if viewport.get_texture().get_image().get_pixelv(sample) != baseline.get_pixelv(sample):
			return _fail("Chair does not cover the player above its collision base: " + scene_path)
		marker.position.y = anchor.global_position.y + 10.0
		await RenderingServer.frame_post_draw
		if not viewport.get_texture().get_image().get_pixelv(sample).is_equal_approx(Color.MAGENTA):
			return _fail("Player does not cover the chair below its collision base: " + scene_path)
		viewport.queue_free()
		await process_frame
	return true


func _check_workstation_monitor_render() -> bool:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(960, 640)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	viewport.add_child(world)
	var furniture: Node2D = world.get_node("YSortActors/FurnitureSprites")
	for child in furniture.get_children():
		if child is Sprite2D and child.name.begins_with("Chair"):
			child.visible = false
	var camera := Camera2D.new()
	camera.zoom = Vector2(3, 3)
	viewport.add_child(camera)
	camera.make_current()
	for station in [
		[Vector2(-624, -2512), ["Monitor", "MonitorLeft", "MonitorLeft2", "MonitorRight", "MonitorRight2"]],
		[Vector2(2000, -1456), ["Monitor2", "MonitorLeft3", "MonitorLeft4", "MonitorRight3", "MonitorRight4"]],
		[Vector2(2704, -2480), ["Monitor3", "MonitorLeft5", "MonitorLeft6", "MonitorRight5", "MonitorRight6"]],
	]:
		camera.position = station[0]
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var frame := viewport.get_texture().get_image()
		for monitor_name in station[1]:
			var monitor: Sprite2D = furniture.get_node(monitor_name)
			var screen_center: Vector2 = (monitor.global_position - camera.global_position) * camera.zoom + Vector2(viewport.size) / 2.0
			var half_size: Vector2 = Vector2(monitor.texture.get_size()) * monitor.global_scale * camera.zoom / 2.0
			var blue_pixels := 0
			for y in range(maxi(0, floori(screen_center.y - half_size.y)), mini(viewport.size.y, ceili(screen_center.y + half_size.y))):
				for x in range(maxi(0, floori(screen_center.x - half_size.x)), mini(viewport.size.x, ceili(screen_center.x + half_size.x))):
					var pixel := frame.get_pixel(x, y)
					if pixel.b > 0.35 and pixel.b > pixel.r * 1.5 and pixel.b > pixel.g * 1.1:
						blue_pixels += 1
			if blue_pixels < 12:
				return _fail("Monitor is hidden by the workstation: " + monitor_name)
	viewport.queue_free()
	await process_frame
	return true


func _check_column_render() -> bool:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(256, 256)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	viewport.add_child(world)
	var camera := Camera2D.new()
	camera.position = Vector2(1930, -1250)
	camera.zoom = Vector2(2, 2)
	viewport.add_child(camera)
	camera.make_current()
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var sample := Vector2i(128, 168)
	var baseline := viewport.get_texture().get_image().get_pixelv(sample)
	if baseline.r < 0.5 or baseline.b < 0.5:
		return _fail("Tall column sample is not visible in the warehouse scene")
	var marker := Node2D.new()
	marker.position = Vector2(1930, -1252)
	var patch := ColorRect.new()
	patch.color = Color.MAGENTA
	patch.position = Vector2(-300, -300)
	patch.size = Vector2(600, 600)
	marker.add_child(patch)
	world.get_node("YSortActors").add_child(marker)
	await RenderingServer.frame_post_draw
	if viewport.get_texture().get_image().get_pixelv(sample) != baseline:
		return _fail("Player behind a tall column is rendered in front of it")
	marker.position.y = -1232
	await RenderingServer.frame_post_draw
	if not viewport.get_texture().get_image().get_pixelv(sample).is_equal_approx(Color.MAGENTA):
		return _fail("Player below the column base is still hidden by it")
	viewport.queue_free()
	await process_frame
	return true


func _fail(message: String) -> bool:
	push_error(message)
	quit(1)
	return false
