extends SceneTree

const DemoTasks = preload("res://demo_tasks.gd")
const FOOT_OFFSET := Vector2(0, 25)
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var demo := DemoTasks.new()
	demo.name = "DemoTasks"
	world.add_child(demo)
	var camera := player.get_node("Camera2D") as Camera2D
	camera.position_smoothing_enabled = false
	await _settle()
	_check(not demo.completed and not demo.hint_enabled and demo._route.points.is_empty(), "New game asks for independent search without a route")
	_check(demo._objective.text.contains("Найдите старшего смены приемки"), "Objective names the correct supervisor")
	_check(demo._hint_button.text == "Показать путь", "The route action uses the new label")
	await _capture(viewport, "initial_search")

	demo._hint_button.pressed.emit()
	_check(demo._modal.visible and player._interaction_locked, "Hint confirmation blocks world movement")
	_check(demo._dialog_title.text == "Показать путь", "The route confirmation uses the new title")
	_check(demo._dialog_text.text == "Вы точно не сможете найти самостоятельно?", "Exact hint confirmation")
	_check(demo._buttons.get_child(0).text == "Смогу" and demo._buttons.get_child(1).text == "Да", "Confirmation has both choices")
	_check(viewport.gui_get_focus_owner() == demo._buttons.get_child(0), "Confirmation defaults to independent search")
	await _capture(viewport, "hint_confirmation")
	demo._buttons.get_child(0).pressed.emit()
	_check(not demo.hint_enabled and not demo._modal.visible and not player._interaction_locked and demo._route.points.is_empty(), "No declines without revealing a route")
	demo.request_hint()
	_press_escape(demo)
	_check(not demo.hint_enabled and not player._interaction_locked, "Escape safely declines the hint")
	demo.request_hint()
	demo._buttons.get_child(1).pressed.emit()
	_check(demo.hint_enabled and demo._route.enabled and not player._interaction_locked, "Only Yes enables the route")
	_check(demo._hint_button.text == "Скрыть путь", "An enabled route offers the matching hide action")
	_check_straight_guide(demo, player, "Hint immediately points directly to the supervisor even with the entry door closed")
	await _capture(viewport, "guide_from_entry")
	world.get_node("FrontDoorInteraction").restore_save_state(true)
	await _settle()
	_check_straight_guide(demo, player, "Opening the door does not add detours or intermediate targets")
	await _capture(viewport, "route_inside")
	var start_position := player.global_position
	var monitor := world.get_node(DemoTasks.SUPERVISOR_MONITOR_PATH) as Node2D
	_check(is_equal_approx(demo.supervisor_point().x, monitor.global_position.x) and demo.supervisor_point().y < monitor.global_position.y, "Guide destination is outside the desk, north of the receiving monitor")
	player.global_position = demo.supervisor_point() + Vector2(80, -35) - FOOT_OFFSET
	camera.force_update_scroll()
	await _settle()
	_check_straight_guide(demo, player, "Nearby guide ends at the north approach")
	await _capture(viewport, "route_north_approach")
	player.global_position += Vector2(1, 0)
	await _settle()
	_check_straight_guide(demo, player, "The line follows small player movements without a grid threshold")
	for feet in [Vector2(-4400, -2640), Vector2(-4400, -528), Vector2(750, -2576), Vector2(750, -368)]:
		player.global_position = feet - FOOT_OFFSET
		await _settle()
		_check_straight_guide(demo, player, "The guide remains a single straight line from neighboring blocks")
	player.global_position = start_position
	camera.force_update_scroll()
	demo._route._update_path()
	var store := WarehouseSaveStore.new()
	var searching := store.capture(world)
	_check(searching.demo == {"completed": false, "hint_enabled": true, "stage": "find_supervisor", "free_time_remaining": 60.0, "gate19_open": false, "assigned_vehicle": "", "placed_count": 0, "tote_source": [], "totes_delivered": false} and store._valid(searching), "Hint choice and search progress are saved")
	demo._hint_button.pressed.emit()
	_check(not demo.hint_enabled and demo._route.points.is_empty(), "Hint can be hidden")
	_check(demo._hint_button.text == "Показать путь", "Hiding the route restores the show label")

	for vehicle in store._vehicles(world):
		player.global_position = vehicle.global_position + Vector2(0, 65)
		player._nearby_vehicles.clear()
		player.register_pickup_vehicle(vehicle)
		player._update_interaction_hint()
		_check(player._interaction_hint.get_parsed_text().contains("только по поручению"), "Parked vehicles explain assignment restriction")
		_check(player._interact_with_vehicle() and player._carried_vehicle == null and player.move_mode == player.MoveMode.ON_FOOT and not vehicle.is_carried, "Unassigned vehicle cannot be taken")
	player._nearby_vehicles.clear()
	var other := world.get_node("YSortActors/FurnitureSprites/ChairWithNpcBackBlond/InteractionArea") as Area2D
	player.global_position = other.global_position - FOOT_OFFSET
	_check(not demo.try_interact(player), "Other supervisors cannot complete the receiving introduction")
	player.global_position = demo._supervisor.global_position - FOOT_OFFSET
	_check(not demo.get_interaction_text(player).is_empty(), "Original desk interaction remains available")
	player.global_position = demo.supervisor_point() - FOOT_OFFSET
	_check(not demo._supervisor.contains_actor(player) and not demo.get_interaction_text(player).is_empty(), "Conversation works at the new guide endpoint outside the original desk zone")
	var supervisor_shape := demo._supervisor.get_node("CollisionShape2D") as CollisionShape2D
	supervisor_shape.disabled = true
	_check(demo.get_interaction_text(player).is_empty(), "Disabled supervisor does not expose the additional approach")
	supervisor_shape.disabled = false
	camera.force_update_scroll()
	player._update_interaction_hint()
	_check(player._interaction_hint.text.begins_with("[color=#ff6868]") and player._interaction_hint.get_parsed_text().contains("чтобы поговорить"), "Receiving supervisor keeps red role and adds the conversation action")
	await _capture(viewport, "supervisor_approach")
	_press_interact(player, KEY_E, true)
	_check(not demo._modal.visible, "Key autorepeat does not open dialogue")
	_press_interact(player, KEY_E)
	_check(demo._modal_kind == "conversation" and player._interaction_locked and not demo.completed, "E opens dialogue at the correct desk")
	_check(demo._dialog_title.text == DemoTasks.SPEAKER, "Dialogue has the receiving supervisor's role")
	await _capture(viewport, "conversation_desktop")
	_press_escape(demo)
	_check(not demo.completed and not player._interaction_locked, "Closing dialogue early does not complete the objective")
	_press_interact(player, KEY_ENTER)
	_check(demo._modal_kind == "conversation", "Enter also opens dialogue")
	for index in DemoTasks.DIALOGUE.size():
		_check(demo._dialogue_index == index and demo._dialog_text.text == DemoTasks.DIALOGUE[index], "Every dialogue page is displayed in order")
		demo._buttons.get_children().back().pressed.emit()
	_check(demo.completed and not demo._modal.visible and not player._interaction_locked and not demo._route.enabled and demo._hint_button.visible == not DemoTasks.FREE_TIME_ENABLED, "Completion is recorded only after the full conversation and exposes the next objective when free time is disabled")
	await _capture(viewport, "introduction_complete")
	var completed := store.capture(world)
	_check(completed.demo.completed and store._valid(completed), "Completed introduction is saveable")
	_check(store.apply_state(world, searching) and not demo.completed and demo.hint_enabled and demo._route.enabled, "Loading search state restores its hint choice")
	_check(store.apply_state(world, completed) and demo.completed and not demo.hint_enabled, "Loading completed state does not restart the search")
	var invalid := completed.duplicate(true)
	invalid.demo.completed = "yes"
	var before := player.global_position
	_check(not store.apply_state(world, invalid) and player.global_position == before, "Invalid quest data is rejected before changing the world")
	invalid = completed.duplicate(true)
	invalid.player.vehicle = str(world.get_path_to(store._vehicles(world)[0]))
	_check(not store._valid(invalid), "Demo saves cannot bypass the unassigned transport restriction")
	var legacy := completed.duplicate(true)
	legacy.erase("demo")
	_check(store._valid(legacy), "Existing sandbox save format remains valid")

	for viewport_size in [Vector2i(640, 360), Vector2i(320, 240)]:
		viewport.size = viewport_size
		demo.restore_save_state({"completed": false, "hint_enabled": false})
		player.global_position = demo.supervisor_point() - FOOT_OFFSET
		camera.force_update_scroll()
		await _settle()
		_check_inside(viewport, demo._task_panel, "Compact objective fits")
		world.get_node("BlockNotifications")._show_notification(2)
		await _settle()
		_check(not demo._task_panel.visible, "Compact block notification temporarily takes priority over the objective")
		world.get_node("BlockNotifications")._process(10.0)
		await _settle()
		_check(demo._task_panel.visible, "Objective returns after the block notification")
		demo.request_hint()
		await _settle()
		_check_inside(viewport, demo._dialog, "Compact confirmation fits")
		await _capture(viewport, "confirmation_%dx%d" % [viewport_size.x, viewport_size.y])
		demo.close_modal()
		_press_interact(player, KEY_ENTER)
		await _settle()
		_check_inside(viewport, demo._dialog, "Compact conversation fits")
		await _capture(viewport, "conversation_%dx%d" % [viewport_size.x, viewport_size.y])
		demo.close_modal()
	world.free()
	viewport.free()
	if not failed:
		print("Demo introduction passed: independent search, confirmed optional straight-line guide, live movement updates, fixed north endpoint, correct supervisor, red role, E/Enter, dialogue cancellation/completion, restricted vehicles, save/restore, legacy compatibility and desktop/compact layouts")
	quit(1 if failed else 0)

func _check_straight_guide(demo: Node, player: Node2D, message: String) -> void:
	var points: PackedVector2Array = demo._route.points
	_check(points.size() == 2, message)
	if points.size() == 2:
		_check(points[0].distance_to(player.global_position + FOOT_OFFSET) < 0.1 and points[1].distance_to(demo.supervisor_point()) < 0.1, "Line connects the player's feet directly to the supervisor")

func _press_interact(player: Node, code: Key, echo := false) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	event.echo = echo
	player._unhandled_input(event)

func _press_escape(demo: Node) -> void:
	var event := InputEventKey.new()
	event.keycode = KEY_ESCAPE
	event.pressed = true
	demo._input(event)

func _check_inside(viewport: SubViewport, control: Control, message: String) -> void:
	var rect := Rect2(control.global_position, control.size)
	_check(Rect2(Vector2.ZERO, Vector2(viewport.size)).encloses(rect), message + ": " + str(rect))

func _settle() -> void:
	await physics_frame
	await process_frame
	await process_frame

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var output := OS.get_environment("DEMO_QA_DIR")
	if output.is_empty():
		output = "user://tmp/demo_introduction_qa"
	DirAccess.make_dir_recursive_absolute(output)
	_check(viewport.get_texture().get_image().save_png(output.path_join(name + ".png")) == OK, "Save demo preview")

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
