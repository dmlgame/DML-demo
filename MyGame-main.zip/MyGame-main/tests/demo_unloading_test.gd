extends SceneTree

const DemoTasks = preload("res://demo_tasks.gd")
const Unloading = preload("res://demo_unloading.gd")
const FOOT_OFFSET := Vector2(0, 25)
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var camera := player.get_node("Camera2D") as Camera2D
	camera.position_smoothing_enabled = false
	var demo := DemoTasks.new()
	demo.name = "DemoTasks"
	world.add_child(demo)
	demo.set_process(false)
	demo.restore_save_state({"completed": true, "hint_enabled": false, "stage": "find_free_transporter", "free_time_remaining": 0, "gate19_open": true})
	var floor_layer := world.get_node("FloorLayer2") as TileMapLayer
	_check(Unloading.SLOT_CELLS[10] == Vector2i(-68, -94) and Unloading.SLOT_CELLS[11] == Vector2i(-65, -94), "Destinations eleven and twelve occupy the two right-hand markings in the fourth row")
	var seen := {}
	for cell in Unloading.SLOT_CELLS:
		_check(floor_layer.get_cell_atlas_coords(cell) == Vector2i(5, 1) and not seen.has(cell), "Each destination is a different existing yellow marking")
		seen[cell] = true
		for y in 2:
			for x in 3:
				_check(floor_layer.get_cell_atlas_coords(cell + Vector2i(x, y)) == Vector2i(5 + x, 1 + y), "The entire 3x2 destination rectangle exists")
	var jack := world.get_node("YSortActors/TransporterSprites").get_child(0) as PickupVehicle
	jack.global_position = demo.gate19_approach_point() + Vector2(0, 240)
	player.global_position = jack.interaction_area.global_position + Vector2(0, 35) - FOOT_OFFSET
	await _settle(demo)
	player.register_pickup_vehicle(jack)
	_press(player, KEY_E)
	_check(player._carried_vehicle == jack, "The existing E action takes the assigned empty jack")
	player.global_position = demo.gate19_approach_point() - FOOT_OFFSET
	await _settle(demo)
	_check(demo.stage == "at_gate19_with_transporter" and demo._task_title.text == "Начинаем выгрузку", "Arrival starts the unloading assignment")
	_check(demo.remaining_pallets() == 12 and demo._gate19.dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL) == Vector2i(0, 0), "The opened truck initially contains twelve pallets")
	var store := WarehouseSaveStore.new()
	store.directory = "user://tmp/demo_unloading_test"
	var initial := store.capture(world)
	var pallet_layer := world.get_node("YSortActors/PalletLayer") as TileMapLayer
	var pallet_atlas := pallet_layer.tile_set.get_source(0) as TileSetAtlasSource
	var native_points := pallet_atlas.get_tile_data(Unloading.SMALL_BOXES_ATLAS, 0).get_collision_polygon_points(0, 0)
	_check(Unloading.PALLET_SCALE == 1.0, "Unloaded pallets use the tileset's original scale")
	var nearest_original := Vector2.ZERO
	var nearest_distance := INF
	for cell in pallet_layer.get_used_cells():
		if pallet_layer.get_cell_atlas_coords(cell) == Unloading.SMALL_BOXES_ATLAS:
			var center := pallet_layer.to_global(pallet_layer.map_to_local(cell))
			var distance: float = center.distance_squared_to(demo._unloading.slot_rect(0).get_center())
			if distance < nearest_distance:
				nearest_original = center
				nearest_distance = distance
	print("Full-size pallet comparison: original center ", nearest_original, " placed center ", demo._unloading.slot_rect(0).get_center() + Vector2(0, 20) - Unloading.PALLET_ORIGIN)
	for vertex in native_points.size():
		_check((demo._unloading._footprint.points[vertex] + Unloading.PALLET_ORIGIN).is_equal_approx(native_points[vertex]), "Unloaded footprint matches the original tileset polygon without shrinking")
	var other_gate: Vector2i = demo._gate19.dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL + Vector2i(16, 0))
	var partial_loaded := {}
	var partial_parked := {}
	for index in Unloading.PALLET_COUNT:
		player.global_position = demo.gate19_approach_point() - FOOT_OFFSET
		player.last_direction = Vector2.UP
		player._apply_collision_profile(Vector2.UP)
		player._update_active_visual(false, false, 0)
		await _settle(demo)
		_check(demo.get_interaction_text(player).contains("забрать паллет"), "The gate offers a cargo pickup, not a jack drop")
		_press(player, KEY_ENTER, true)
		_check(not player.transporter_loaded and demo.remaining_pallets() == 12 - index, "Key repeat cannot remove an extra pallet")
		_press(player, KEY_ENTER if index % 2 == 0 else KEY_E)
		await _settle(demo)
		_check(player.transporter_loaded and player.move_mode == player.MoveMode.TRANSPORTER and player._carried_vehicle == jack, "Pickup keeps the same jack and enables small-box cargo")
		_check(demo.stage == "unload_place" and demo.placed_count == index and demo.remaining_pallets() == 11 - index, "One cargo pickup removes exactly one pallet from the truck")
		_check(demo._gate19.dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL) == Unloading.gate_atlas(11 - index), "The correct reduced-cargo atlas frame is used")
		_check(demo._unloading.target_visible and demo._unloading.placed_count == index and player.transporter_sprite.texture == player.TRANSPORTER_LOADED_TEXTURE and player.transporter_visual.visible and not player.pallet_jack_visual.visible and not player._cargo_collision.disabled, "The hand-drawn loaded transporter sheet replaces the empty vehicle and has a solid footprint")
		_press(player, KEY_E)
		await _settle(demo)
		_check(player.transporter_loaded and demo.remaining_pallets() == 11 - index and demo.placed_count == index, "Another pickup press cannot duplicate cargo or drop a loaded jack")
		if index == 0:
			demo.request_hint()
			demo._buttons.get_child(1).pressed.emit()
			_check(demo._route.points[-1].is_equal_approx(demo._unloading.target_point()), "The optional straight hint points to the selected marking")
			for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
				player.global_position = demo.gate19_approach_point() + Vector2(0, 200) - FOOT_OFFSET
				player._try_face_direction(direction)
				player._update_active_visual(false, false, 0)
				camera.force_update_scroll()
				await _capture(viewport, demo, "loaded_" + player._collision_direction_name(direction))
				_check(player.transporter_sprite.texture == player.TRANSPORTER_LOADED_TEXTURE and player.transporter_sprite.frame_coords.y == [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN].find(direction) and player._cargo_collision.position.is_equal_approx(player.TRANSPORTER_CARGO_BASES[player._collision_direction_name(direction)] - player.TRANSPORTER_CARGO_FOOT_OFFSET), "The hand-drawn sheet and cargo footprint follow the same four-direction facing")
			player.global_position = demo._unloading.slot_rect(9).get_center() - player.TRANSPORTER_CARGO_BASES["left"]
			player.last_direction = Vector2.LEFT
			player._apply_collision_profile(Vector2.LEFT)
			player._update_active_visual(false, false, 0)
			await _settle(demo)
			_press(player, KEY_E)
			_check(player.transporter_loaded and demo.placed_count == 0, "Cargo cannot be placed into a different empty marking")
			for directions in [[Vector2.LEFT, Vector2.UP], [Vector2.RIGHT, Vector2.DOWN]]:
				player.global_position = demo.gate19_approach_point() + Vector2(0, 200) - FOOT_OFFSET
				player._held_movement_directions.clear()
				var input: Array[Vector2] = [directions[0], directions[1]]
				var movement: Vector2 = player._update_movement_input(input)
				player._try_face_direction(input[0])
				await _settle(demo)
				var start := player.global_position
				for frame in 15:
					await physics_frame
					player._move_with_direction(movement, false, 1.0 / 60.0, player._input_facing_direction)
				_check(player.global_position.distance_to(start) > 10 and player.last_direction == input[0], "Loaded diagonal movement preserves horizontal priority and real movement")
		if index == 4:
			_check(store.save_world(world, "slot_1"), "Loaded mid-task state saves to disk")
			partial_loaded = store.read_slot("slot_1")
		_check(_find_placement_approach(player, demo, index == 0), "There is a clear approach to every slot even after earlier pallets have been placed")
		camera.force_update_scroll()
		await _settle(demo)
		_check(not player._collision_profile_overlaps(player._active_collision), "The loaded jack can reach the placement approach without passing through columns or earlier pallets")
		_check(demo._unloading.can_place(player) and demo.get_interaction_text(player).contains("поставить паллет"), "The assigned destination is reachable from its side without overlap")
		if failed:
			world.free()
			viewport.free()
			quit(1)
			return
		if index == 0:
			_check(not demo._unloading.slot_rect(0).grow(16).has_point(player.transporter_cargo_ground_point()), "Placement is available near the operator even when the carried pallet is outside the marking")
			player.global_position = demo._unloading.target_point() + Vector2(-63, 0) - player.TRANSPORTER_CARGO_BASES["left"]
			player.last_direction = Vector2.LEFT
			player._apply_collision_profile(Vector2.LEFT)
			player._update_active_visual(false, false, 0)
			_check(demo._unloading.slot_rect(0).grow(16).has_point(player.transporter_cargo_ground_point()) and not demo._unloading.slot_rect(0).grow(Unloading.PLACEMENT_REACH).has_point(player.global_position + FOOT_OFFSET), "Cargo-only proximity leaves the operator outside the interaction zone")
			_check(not demo._unloading.can_place(player) and not demo.get_interaction_text(player).contains("поставить паллет"), "The carried pallet entering the marking alone must not offer placement")
			var count_before: int = demo.placed_count
			_press(player, KEY_E)
			_check(demo.placed_count == count_before and player.transporter_loaded, "The placement key cannot bypass the operator proximity requirement")
			_check(_find_placement_approach(player, demo), "Restore a safe operator approach after the cargo-only test")
			await _drive_final_approach(player, demo)
			await _capture(viewport, demo, "first_placement_action")
		_press(player, KEY_E if index % 2 == 0 else KEY_ENTER)
		await _settle(demo)
		_check(not player.transporter_loaded and player.transporter_sprite.texture == player.TRANSPORTER_EMPTY_TEXTURE and player._cargo_collision.disabled and player._carried_vehicle == jack, "Placement returns to the empty transporter sheet and keeps the same vehicle")
		_check(demo.placed_count == index + 1 and demo._unloading._pallets.get_child_count() == index + 1, "Placement creates one solid pallet in the next exact marking")
		var placed := demo._unloading._pallets.get_child(index) as StaticBody2D
		var sprite := placed.get_child(0) as Sprite2D
		_check(sprite.global_scale.is_equal_approx(pallet_layer.global_scale) and sprite.texture.region == Rect2(pallet_atlas.get_tile_texture_region(Unloading.SMALL_BOXES_ATLAS)), "Every placed pallet has the same texture dimensions and scale as PalletLayer")
		var footprint := placed.get_node("Footprint") as CollisionShape2D
		for point in footprint.shape.points:
			_check(demo._unloading.slot_rect(index).has_point(footprint.to_global(point)), "The full-size pallet footprint remains inside its marking")
		_check(demo.remaining_pallets() == 11 - index and not demo._unloading.target_visible, "Placement does not remove another truck pallet and clears the highlight")
		_check(not player._collision_profile_overlaps(player._active_collision), "The placed pallet does not overlap the operator or jack")
		if index == 4:
			_check(store.save_world(world, "slot_2"), "Partially filled floor state saves to disk")
			partial_parked = store.read_slot("slot_2")
			_press(player, KEY_E)
			await _settle(demo)
			_check(player._carried_vehicle == null and demo.stage == "unload_pickup" and demo.placed_count == 5 and demo._objective.text.contains("Сядьте в выбранный паллетовоз"), "An empty jack may be dropped without resetting the unloading task")
			var dropped := store.capture(world)
			_check(store._valid(dropped) and store.apply_state(world, dropped) and demo.placed_count == 5 and player._carried_vehicle == null, "A mid-unloading dropped-jack save retains floor progress")
			_check(store.apply_state(world, partial_parked) and player._carried_vehicle == jack, "Restoring the mounted state retains the same jack and placed cargo")
		_check(demo._gate19.dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL + Vector2i(16, 0)) == other_gate, "Other gates remain unchanged")
		if index == 9:
			_check(demo.stage == "unload_pickup" and demo.remaining_pallets() == 2, "Ten parked pallets no longer finish an unfinished truck")
		if index == 11:
			_check(demo.remaining_pallets() == 0, "The last delivery finishes placement after the truck becomes empty")
	_check(demo.stage == "unload_complete" and demo.remaining_pallets() == 0 and demo._hint_button.visible and demo._objective.text.contains("старшему смены"), "All twelve filled markings finish the empty truck and offer a return to the supervisor")
	_check(demo._gate19.dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL) == Vector2i(0, 9), "The final truck uses the empty dock frame")
	player.global_position = demo.gate19_approach_point() - FOOT_OFFSET
	player.last_direction = Vector2.UP
	player._apply_collision_profile(Vector2.UP)
	player._update_active_visual(false, false, 0)
	camera.zoom = Vector2.ONE
	camera.offset = Vector2(0, 64)
	camera.force_update_scroll()
	await _capture(viewport, demo, "all_twelve_markings")
	camera.zoom = Vector2(2, 2)
	camera.offset = Vector2.ZERO
	var finished := store.capture(world)
	_check(store.apply_state(world, partial_loaded) and demo.placed_count == 4 and demo.remaining_pallets() == 7 and player.transporter_loaded and demo._unloading._pallets.get_child_count() == 4, "Disk load restores carried cargo, four placed pallets and the exact truck count")
	await _settle(demo)
	_check(player._active_collision == player._collision_for_mode(player.last_direction) and not player._collision_profile_overlaps(player._active_collision), "Loaded disk restore keeps the saved facing and a clear cargo footprint")
	_check(store.apply_state(world, partial_loaded) and demo._unloading._pallets.get_child_count() == 4, "Repeated restore does not duplicate floor pallets")
	_check(store.apply_state(world, partial_parked) and demo.placed_count == 5 and demo.remaining_pallets() == 7 and not player.transporter_loaded, "Empty-jack save restores five floor pallets and no duplicate cargo")
	_check(store.apply_state(world, initial) and demo.placed_count == 0 and demo._unloading._pallets.get_child_count() == 0 and demo.remaining_pallets() == 12, "Restoring an earlier stage removes later cargo without changing the warehouse's own pallet layer")
	_check(store.apply_state(world, finished) and demo.placed_count == 12 and not player.transporter_loaded, "Completed unloading restores all twelve floor pallets")
	for override in [{"placed_count": -1}, {"placed_count": 13}, {"placed_count": 4.5}, {"placed_count": "5"}, {"stage": "unload_pickup", "placed_count": 0}, {"stage": "unload_complete", "placed_count": 9}, {"gate19_open": false}]:
		var invalid := partial_loaded.duplicate(true)
		invalid.demo.merge(override, true)
		_check(not store.apply_state(world, invalid) and demo.placed_count == 12, "Invalid unloading progress is rejected before world mutation")
	var invalid := partial_loaded.duplicate(true)
	invalid.player.vehicle = ""
	_check(not store.apply_state(world, invalid), "Cargo cannot be loaded without its assigned jack")
	var inside_save := {}
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		_check(store.apply_state(world, partial_loaded), "Restore a loaded pallet for each interior-facing test")
		await _settle(demo)
		_check(_find_inside_placement(player, demo, direction), "A loaded transporter can place from inside the marking in every facing")
		await _settle(demo)
		_check(demo._unloading.slot_rect(4).has_point(player.global_position + FOOT_OFFSET) and demo.get_interaction_text(player).contains("поставить паллет"), "The placement action is available with the operator inside the actual rectangle")
		await _capture(viewport, demo, "inside_before_" + player._collision_direction_name(direction))
		_press(player, KEY_ENTER)
		await _settle(demo)
		var pallet := demo._unloading._pallets.get_child(4) as StaticBody2D
		_check(demo.placed_count == 5 and not player.transporter_loaded and demo._unloading._overlaps_player(pallet), "Interior placement creates one pallet without moving the operator")
		_check(player.get_collision_exceptions().has(pallet) and demo._unloading._exit_pallets.has(pallet) and not player._collision_profile_overlaps(player._active_collision), "Only the placing transporter can leave its overlapping pallet")
		var query := PhysicsShapeQueryParameters2D.new()
		query.shape = demo._unloading._footprint
		query.transform = pallet.get_node("Footprint").global_transform
		query.collision_mask = 1
		query.exclude = [player.get_rid()]
		var solid := false
		for hit in player.get_world_2d().direct_space_state.intersect_shape(query):
			solid = solid or hit.collider == pallet
		_check(solid and pallet.collision_layer == 1, "The parked pallet stays solid for other bodies during the driver's exit")
		_check(store.save_world(world, "slot_2"), "Saving while the transporter is inside a freshly placed pallet succeeds")
		inside_save = store.read_slot("slot_2")
		_check(store.apply_state(world, inside_save), "Restoring the same count inside a pallet recreates the exit exception")
		await _settle(demo)
		await _drive_out_of_pallet(player, demo)
	_check(store.apply_state(world, finished) and store.apply_state(world, inside_save), "A later twelve-pallet state can rewind to a saved interior placement")
	await _settle(demo)
	_check(player.global_position.is_equal_approx(Vector2(inside_save.player.position[0], inside_save.player.position[1])) and player._active_collision == player._collision_for_mode(player.last_direction) and player.get_collision_exceptions().size() == 1, "Rewinding preserves the exact saved position, facing and only one live exit exception")
	await _drive_out_of_pallet(player, demo)
	var old_finished := finished.duplicate(true)
	old_finished.demo.placed_count = 10
	_check(store.write_state(old_finished, "slot_3") and store.apply_state(world, store.read_slot("slot_3")), "A completed ten-pallet save remains readable from disk")
	_check(demo.stage == "unload_pickup" and demo.placed_count == 10 and demo.remaining_pallets() == 2 and player._carried_vehicle == jack, "Old completion resumes the remaining two pallets with the same transporter")
	_check(demo._unloading._pallets.get_child_count() == 10 and demo._unloading.slot_rect(10).has_point(demo._unloading.target_point()), "Old saves preserve their first ten pallet positions and select a new marking")
	var old_jack_path := str(world.get_path_to(world.get_node("YSortActors/PalletJackAssets").get_child(0)))
	for previous in [partial_loaded, partial_parked, old_finished, finished]:
		var legacy: Dictionary = previous.duplicate(true)
		legacy.demo.erase("assigned_vehicle")
		legacy.demo.assigned_jack = old_jack_path
		legacy.player.vehicle = old_jack_path
		_check(store.write_state(legacy, "slot_3"), "An old assigned-jack progress save remains readable")
		legacy = store.read_slot("slot_3")
		_check(store.apply_state(world, legacy), "An old jack task migrates through the real disk loader")
		var expected_stage := "unload_complete" if int(previous.demo.placed_count) == 12 else "find_free_transporter"
		_check(demo.stage == expected_stage and demo.placed_count == int(previous.demo.placed_count) and demo._unloading._pallets.get_child_count() == demo.placed_count and demo.remaining_pallets() == 12 - demo.placed_count, "Migration preserves parked cargo and returns any undelivered pallet to the truck")
		_check(demo.assigned_vehicle.is_empty() and player._carried_vehicle == null and player.move_mode == player.MoveMode.ON_FOOT and not player.transporter_loaded and world.get_node(old_jack_path).visible, "Migration releases the old jack instead of using the wrong animation")
		_check(store._valid(store.capture(world)) and legacy.demo.has("assigned_jack") and legacy.player.vehicle == old_jack_path, "Migrated progress is saveable without mutating the original save data")
		if demo.placed_count == 4:
			player.global_position = jack.interaction_area.global_position + Vector2(0, 35) - FOOT_OFFSET
			await _settle(demo)
			player.register_pickup_vehicle(jack)
			_press(player, KEY_ENTER)
			_check(player._carried_vehicle == jack and demo.placed_count == 4 and demo.stage == "bring_transporter_to_gate19", "Choosing a transporter after migration keeps the four parked pallets")
			_check(store.save_world(world, "slot_3"), "The replacement transporter and existing four-pallet progress can be saved before returning to the gate")
			_check(store.apply_state(world, store.read_slot("slot_3")) and player._carried_vehicle == jack and demo.placed_count == 4 and demo.stage == "bring_transporter_to_gate19", "Continuation restores the replacement transporter without resetting parked cargo")
			player.global_position = demo.gate19_approach_point() - FOOT_OFFSET
			await _settle(demo)
			_check(demo.stage == "unload_pickup" and demo.remaining_pallets() == 8, "Returning to the gate continues the existing unloading progress")
	var old_arrival := partial_loaded.duplicate(true)
	old_arrival.demo.erase("assigned_vehicle")
	old_arrival.demo.assigned_jack = old_jack_path
	old_arrival.demo.stage = "at_gate19_with_jack"
	old_arrival.demo.placed_count = 0
	old_arrival.player.vehicle = old_jack_path
	_check(store.apply_state(world, old_arrival) and demo.stage == "find_free_transporter" and demo.remaining_pallets() == 12, "An earlier arrival with a jack now asks for a transporter without losing truck cargo")
	for size in [Vector2i(640, 360), Vector2i(320, 240)]:
		viewport.size = size
		store.apply_state(world, partial_loaded)
		camera.force_update_scroll()
		await _capture(viewport, demo, "unloading_%dx%d" % [size.x, size.y])
		_check(Rect2(Vector2.ZERO, Vector2(size)).encloses(Rect2(demo._task_panel.global_position, demo._task_panel.size)), "Unloading UI fits compact screens")
	world.free()
	world = load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	player = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	demo = DemoTasks.new()
	demo.name = "DemoTasks"
	world.add_child(demo)
	demo.set_process(false)
	_check(store.apply_state(world, partial_loaded), "A loaded-cargo disk save opens in a freshly instantiated warehouse")
	await _settle(demo)
	_check(demo.placed_count == 4 and demo.remaining_pallets() == 7 and player.transporter_loaded and demo._unloading._pallets.get_child_count() == 4 and str(world.get_path_to(player._carried_vehicle)) == demo.assigned_vehicle, "Fresh-world continuation restores the vehicle, its animation, truck frame and all four placed pallets")
	_check(player._active_collision == player._collision_for_mode(player.last_direction) and not player._collision_profile_overlaps(player._active_collision), "Fresh-world continuation restores the correct safe loaded collision profile")
	_check(store.apply_state(world, inside_save), "An interior-placement disk save opens in a freshly instantiated warehouse")
	await _settle(demo)
	_check(demo.placed_count == 5 and demo._unloading._exit_pallets.size() == 1 and player._active_collision == player._collision_for_mode(player.last_direction), "Fresh-world restore reconstructs the correct facing and temporary exit exception")
	await _drive_out_of_pallet(player, demo)
	_check(store.apply_state(world, finished) and demo._unloading._pallets.get_child_count() == 12 and demo.stage == "unload_complete", "Completed unloading also opens in a fresh world")
	world.free()
	viewport.free()
	if not failed:
		print("Demo unloading passed: all 12 markings, 12-to-empty truck states, reserved transporter, hand-drawn loaded sheet, interior placement in four facings, safe exit and solid reentry, disk restores, old ten-pallet completion migration and compact UI")
	quit(1 if failed else 0)

func _press(player: Node, code: Key, echo := false) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	event.echo = echo
	player._unhandled_input(event)

func _find_placement_approach(player: Node, demo: Node, cargo_outside := false) -> bool:
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.DOWN, Vector2.UP]:
		for offset in [Vector2(76, 0), Vector2(-76, 0), Vector2(64, 0), Vector2(-64, 0), Vector2(76, 24), Vector2(-76, 24), Vector2(64, 24), Vector2(-64, 24), Vector2(0, 56), Vector2(0, -56), Vector2(32, 56), Vector2(-32, 56)]:
			player.global_position = demo._unloading.target_point() + offset - FOOT_OFFSET
			var target: Node2D = player._collision_for_mode(direction)
			if player._collision_profile_overlaps(target):
				continue
			player.last_direction = direction
			player._apply_collision_profile(direction)
			player._update_active_visual(false, false, 0)
			if cargo_outside and demo._unloading.slot_rect(demo.placed_count).grow(16).has_point(player.transporter_cargo_ground_point()):
				continue
			if demo._unloading.can_place(player):
				return true
	return false

func _find_inside_placement(player: Node, demo: Node, direction: Vector2) -> bool:
	for offset in [Vector2.ZERO, Vector2(16, 0), Vector2(-16, 0), Vector2(32, 0), Vector2(-32, 0), Vector2(0, 16), Vector2(0, -16), Vector2(32, 16), Vector2(-32, 16), Vector2(32, -16), Vector2(-32, -16)]:
		player.global_position = demo._unloading.target_point() + offset - FOOT_OFFSET
		player.last_direction = direction
		player._apply_collision_profile(direction)
		player._update_active_visual(false, false, 0)
		if player._collision_profile_overlaps(player._active_collision) or not demo._unloading.can_place(player):
			continue
		var transform := Transform2D(0, demo._unloading.target_point() + Vector2(0, 20))
		for shape in player._collision_profile_shapes(player._active_collision):
			if demo._unloading._footprint.collide(transform, shape, player._active_collision.global_transform):
				return true
	return false

func _drive_out_of_pallet(player: Node, demo: Node) -> void:
	var pallet := demo._unloading._pallets.get_child(4) as StaticBody2D
	var start: Vector2 = player.global_position
	var facing: Vector2 = player.last_direction
	var exit_direction := Vector2.ZERO
	for direction in [Vector2.DOWN, Vector2.UP, Vector2.RIGHT, Vector2.LEFT]:
		var clear := true
		for step in range(1, 17):
			player.global_position = start + direction * step * 10
			if player._collision_profile_overlaps(player._active_collision):
				clear = false
				break
		if clear:
			exit_direction = direction
			break
	player.global_position = start
	_check(exit_direction != Vector2.ZERO, "There is an unobstructed exit from the interior placement")
	if exit_direction == Vector2.ZERO:
		return
	for frame in 180:
		await physics_frame
		player._move_with_direction(exit_direction, false, 1.0 / 60.0, facing)
		if player.global_position.distance_to(start) >= 150:
			break
	await _settle(demo)
	_check(player.global_position.distance_to(start) >= 150 and not demo._unloading._overlaps_player(pallet), "Real move_and_slide can leave the newly placed pallet without getting trapped")
	_check(not player.get_collision_exceptions().has(pallet) and not demo._unloading._exit_pallets.has(pallet), "The exception ends once the whole transporter has exited")
	var hit := KinematicCollision2D.new()
	_check(player.test_move(player.global_transform, start - player.global_position, hit) and hit.get_collider() == pallet, "The driver cannot drive back through the pallet after leaving it")

func _drive_final_approach(player: Node, demo: Node) -> void:
	var goal: Vector2 = player.global_position
	var facing: Vector2 = player.last_direction
	for offset in [Vector2(30, 0), Vector2(-30, 0), Vector2(0, 30), Vector2(0, -30)]:
		var clear := true
		for step in 7:
			player.global_position = goal + offset * (float(step) / 6.0)
			if player._collision_profile_overlaps(player._active_collision):
				clear = false
				break
		if not clear:
			continue
		player.global_position = goal + offset
		await _settle(demo)
		for frame in 40:
			await physics_frame
			player._move_with_direction(-offset.normalized(), false, 1.0 / 60.0, facing)
			if player.global_position.distance_to(goal) < 1.5:
				break
		_check(player.global_position.distance_to(goal) < 2 and demo._unloading.can_place(player), "Real move_and_slide reaches the unloading action with cargo and no collision bypass")
		return
	player.global_position = goal
	_check(false, "The placement approach must be reachable by driving, not just an isolated clear position")

func _settle(demo: Node) -> void:
	if demo._gate19._busy:
		await demo._gate19._transition.finished
	await physics_frame
	await physics_frame
	await process_frame
	await process_frame
	demo._process(0.0)

func _capture(viewport: SubViewport, demo: Node, name: String) -> void:
	await _settle(demo)
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	var output := OS.get_environment("DEMO_QA_DIR")
	if output.is_empty():
		output = "user://tmp/demo_unloading_qa"
	DirAccess.make_dir_recursive_absolute(output)
	_check(viewport.get_texture().get_image().save_png(output.path_join(name + ".png")) == OK, "Save unloading preview")

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
