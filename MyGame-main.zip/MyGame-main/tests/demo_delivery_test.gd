extends SceneTree

const DemoTasks = preload("res://demo_tasks.gd")
const FOOT_OFFSET := Vector2(0, 25)
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var camera := player.get_node("Camera2D") as Camera2D
	camera.position_smoothing_enabled = false
	var dock := world.get_node("YSortActors/UnloadingDockLayer") as TileMapLayer
	var objects := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	var original_dock := _snapshot(dock)
	var original_objects := _snapshot(objects)
	var demo := DemoTasks.new()
	demo.name = "DemoTasks"
	world.add_child(demo)
	# Advance simulated game time explicitly, without spending a real minute in each test.
	demo.set_process(false)
	var gate: Node = demo._gate19
	var button_position := objects.to_global(objects.map_to_local(DemoTasks.GATE_19_BUTTON_CELL))
	var store := WarehouseSaveStore.new()
	store.directory = "user://tmp/demo_delivery_test"
	await _settle(demo)
	_check(player._gate_interaction == world.get_node("DockGate17Interaction"), "Task gate does not replace gate 17's existing registration")
	_check(world.get_node("FloorLayer2/NumbersLayer").get_cell_atlas_coords(Vector2i(-69, -108)) == Vector2i(0, 3), "Task uses the dock marked 19")
	demo._process(120.0)
	_check(demo.stage == "find_supervisor" and demo.free_time_remaining == 60.0, "The free-time minute does not start before the introduction")
	player.global_position = button_position + Vector2(0, 60) - FOOT_OFFSET
	_press(player, KEY_E)
	_check(not gate._busy and not gate.is_open, "Gate 19 cannot open before its assignment")
	player.global_position = demo.supervisor_point() - FOOT_OFFSET
	_press(player, KEY_ENTER)
	for index in DemoTasks.DIALOGUE.size():
		demo._buttons.get_child(0).pressed.emit()
	var waiting: Dictionary
	if DemoTasks.FREE_TIME_ENABLED:
		_check(demo.completed and demo.stage == "free_time" and demo.free_time_remaining == 60.0, "The full introduction starts exactly one minute of free time")
		_check(demo._task_title.text == "Знакомство завершено" and not demo._hint_button.visible, "The existing completion message stays during free time")
		camera.force_update_scroll()
		await _capture(viewport, demo, "free_time")
		paused = true
		demo._process(120.0)
		_check(demo.free_time_remaining == 60.0, "Pause does not consume free time")
		paused = false
		player.set_interaction_locked(true)
		demo._process(120.0)
		_check(demo.free_time_remaining == 60.0, "Other locked interactions do not consume free time")
		player.set_interaction_locked(false)
		demo._process(20.0)
		_check(demo.stage == "free_time" and demo.free_time_remaining == 40.0, "Free time counts down while the player can freely explore")
		_press(player, KEY_E)
		demo._process(120.0)
		_check(demo.free_time_remaining == 40.0, "Re-reading the introduction pauses the existing clock")
		for index in DemoTasks.DIALOGUE.size():
			demo._buttons.get_child(0).pressed.emit()
		_check(demo.stage == "free_time" and demo.free_time_remaining == 40.0, "Finishing a repeated conversation does not restart the minute")
		demo._process(39.0)
		_check(demo.stage == "free_time" and demo.free_time_remaining == 1.0, "No assignment appears before all 60 seconds elapse")
		_check(store.save_world(world, "slot_1"), "Free-time countdown can be saved")
		waiting = store.read_slot("slot_1")
		_check(waiting.demo.free_time_remaining == 1.0 and waiting.demo.stage == "free_time", "Remaining seconds survive JSON serialization")
		demo.restore_save_state({"completed": true, "hint_enabled": false})
		_check(demo.stage == "free_time" and demo.free_time_remaining == 60.0 and not gate.is_open, "Earlier completed-introduction saves start the new free-time minute")
		_check(store.apply_state(world, waiting) and demo.free_time_remaining == 1.0, "Loading resumes the remaining second instead of restarting the minute")
	else:
		_check(demo.completed and demo.stage == "return_to_supervisor" and demo.free_time_remaining == 0.0, "The full introduction immediately exposes the assignment without free time")
		_check(demo._task_title.text == "Есть поручение" and demo._hint_button.visible and demo._modal_kind.is_empty(), "The next objective is visible without forcing a second dialogue")
		camera.force_update_scroll()
		await _capture(viewport, demo, "immediate_assignment")
		demo._process(120.0)
		_check(demo.stage == "return_to_supervisor" and demo.free_time_remaining == 0.0 and demo._modal_kind.is_empty(), "Standing at the desk does not reopen dialogue automatically")
		_press(player, KEY_E)
		_check(demo._modal_kind == "assignment", "E opens the next assignment immediately after the introduction")
		_modal_key(demo, KEY_ESCAPE)
		demo._process(0.0)
		_check(demo._modal_kind.is_empty() and demo.stage == "return_to_supervisor", "Cancelling the immediate assignment does not restart a delay or reopen it")
		_check(store.save_world(world, "slot_1"), "The immediate assignment is saveable")
		waiting = store.read_slot("slot_1")
		waiting.demo.stage = "free_time"
		waiting.demo.free_time_remaining = 23.0
		_check(store.write_state(waiting, "slot_1"), "An older in-progress free-time save remains valid")
		waiting = store.read_slot("slot_1")
		_check(store.apply_state(world, waiting) and demo.stage == "return_to_supervisor" and demo.free_time_remaining == 0.0 and demo._modal_kind.is_empty(), "Loading a saved countdown skips it without forcing a dialogue")
		_check(store._valid(store.capture(world)), "A migrated countdown saves as a valid immediate assignment")
		demo.restore_save_state({"completed": true, "hint_enabled": false})
		_check(demo.stage == "return_to_supervisor" and demo.free_time_remaining == 0.0 and not gate.is_open, "Earlier introduction-only saves also skip the minute")
	player.global_position = Vector2(0, -3000)
	demo._process(1.0)
	_check(demo.stage == "return_to_supervisor" and demo._objective.text == "Подойдите к старшему смены приемки и размещения, есть поручение", "The shift supervisor assignment is active")
	player.global_position = world.get_node("YSortActors/FurnitureSprites/ChairWithNpcLeftFemaleBlonde/InteractionArea").global_position - FOOT_OFFSET
	demo._process(0.0)
	_check(demo._modal_kind.is_empty(), "Approaching a different staff member does not reveal the assignment")
	var old_lead := world.get_node("YSortActors/FurnitureSprites/ChairWithNpcRight/InteractionArea") as Area2D
	var old_shape := old_lead.get_node("CollisionShape2D") as CollisionShape2D
	player.global_position = old_shape.to_global(Vector2(old_shape.shape.get_rect().end.x - 6.0, 0)) - FOOT_OFFSET
	demo._process(0.0)
	_check(demo._modal_kind.is_empty() and not demo.try_interact(player), "The area lead no longer gives the assignment")
	demo.request_hint()
	demo._buttons.get_child(1).pressed.emit()
	_check(demo._route.points.size() == 2 and demo._route.points[-1].is_equal_approx(demo.supervisor_point()), "Optional direct guide now points to the shift supervisor's monitor")
	await _capture(viewport, demo, "return_to_supervisor")
	player.global_position = demo.supervisor_point() - FOOT_OFFSET
	camera.force_update_scroll()
	await physics_frame
	_check(not player._collision_profile_overlaps(player.collision_on_foot), "The shift supervisor's approach is outside furniture collisions")
	demo._process(0.0)
	_check(demo._modal_kind == "assignment" and player._interaction_locked, "Approaching the shift supervisor automatically opens the message")
	_check(demo._dialog_title.text == DemoTasks.SPEAKER and demo._dialog_text.text == DemoTasks.ASSIGNMENT, "The shift supervisor gives the exact gate 19 instruction")
	_check(demo._dialog_title.get_theme_color("font_color") == Color("ff6868"), "The shift supervisor's role remains red")
	await _capture(viewport, demo, "receiving_assignment")
	_modal_key(demo, KEY_ESCAPE)
	demo._process(0.0)
	_check(demo.stage == "return_to_supervisor" and demo._modal_kind.is_empty(), "Escape cancels without instantly reopening or unlocking the gate")
	_press(player, KEY_E)
	_check(demo._modal_kind == "assignment", "The assignment can be reopened with E after cancellation")
	_modal_key(demo, KEY_ENTER)
	_check(demo.stage == "open_gate_19" and not player._interaction_locked and not demo.hint_enabled, "Acknowledging the assignment activates the gate objective")
	_press(player, KEY_E)
	_check(demo._modal_kind == "conversation", "The introduction can still be re-read after accepting an assignment")
	for index in DemoTasks.DIALOGUE.size():
		demo._buttons.get_child(0).pressed.emit()
	_check(demo.stage == "open_gate_19" and demo.free_time_remaining == 0.0 and demo._modal_kind.is_empty(), "Re-reading the introduction never restarts free time or replaces the current assignment")
	_check(store.save_world(world, "slot_2"), "The accepted assignment is saveable")
	var assigned := store.read_slot("slot_2")
	demo.request_hint()
	demo._buttons.get_child(1).pressed.emit()
	_check(demo._route.points.size() == 2 and demo._route.points[-1].is_equal_approx(button_position), "Gate hint points directly at the control button")
	player.global_position = button_position + Vector2(0, 150) - FOOT_OFFSET
	_press(player, KEY_ENTER)
	_check(not gate._busy and not gate.is_open, "Gate 19 cannot be opened remotely")
	player.global_position = button_position + Vector2(0, 60) - FOOT_OFFSET
	camera.force_update_scroll()
	await _settle(demo)
	_check(not player._collision_profile_overlaps(player.collision_on_foot), "The gate control is reachable outside the wall collision")
	player._update_interaction_hint()
	_check(player._interaction_hint.get_parsed_text() == "Нажмите E или Enter, чтобы открыть ворота" and not player._interaction_hint.text.contains("[color="), "Gate instruction uses normal action text, not a red role title")
	await _capture(viewport, demo, "gate_19_closed")
	_press(player, KEY_E, true)
	_check(not gate._busy, "Autorepeat cannot trigger the opening")
	_press(player, KEY_E)
	var transition := gate._transition as Tween
	_check(transition != null and gate._busy and player._interaction_locked and not player._interaction_hint.visible, "Opening locks input and hides the action hint")
	_check(not store.save_world(world, "slot_3"), "A transient blackout cannot be saved")
	transition.pause()
	_check(dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL) == Vector2i(4, 9), "Gate stays closed before the blackout")
	_press(player, KEY_ENTER)
	transition.custom_step(0.13)
	_check(gate._shade.color.a == 1.0 and dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL) == Vector2i(0, 0), "At full blackout, the gate changes to the full-cargo dock")
	_check(objects.get_cell_atlas_coords(DemoTasks.GATE_19_BUTTON_CELL) == Vector2i(0, 0), "The opened gate has a green control button")
	_check(demo.stage == "open_gate_19", "Progress waits until the transition finishes")
	await _capture(viewport, demo, "gate_19_blackout", true)
	transition.custom_step(1.0)
	_check(demo.stage == "find_free_transporter" and not gate._busy and not player._interaction_locked and not gate._transition_layer.visible, "The completed transition restores movement and starts the pallet jack search")
	_check(not demo._route.enabled and demo._hint_button.visible, "The next assignment starts without a route but offers an optional hint")
	_check(demo._objective.text == "Найдите свободный паллетовоз", "The next assignment is to find a free pallet jack")
	demo.request_hint()
	_check(demo._modal_kind == "hint", "The pallet jack search has a hint confirmation")
	demo._buttons.get_child(0).pressed.emit()
	_check(not demo.hint_enabled and demo._route.points.is_empty(), "Declining preserves independent pallet jack search")
	await _check_nearest_jack_hint(demo, world, player, viewport)
	_check(_unchanged_except(dock, original_dock, DemoTasks.GATE_19_CELL) and _unchanged_except(objects, original_objects, DemoTasks.GATE_19_BUTTON_CELL), "Opening changes only gate 19 and its button")
	_press(player, KEY_E)
	_check(gate.is_open and not gate._busy, "The cargo gate stays open for the next task")
	await _capture(viewport, demo, "gate_19_loaded")
	_check(store.save_world(world, "slot_3"), "The open loaded gate and quest stage can be saved")
	var loaded := store.read_slot("slot_3")
	_check(loaded.demo.gate19_open and loaded.demo.stage == "find_free_transporter", "Gate 19 and the pallet jack search survive disk serialization")
	_check(store.apply_state(world, assigned) and not gate.is_open and demo.stage == "open_gate_19", "Loading the assignment restores the closed gate and active objective")
	_check(_snapshot(dock) == original_dock and _snapshot(objects) == original_objects, "Restoring a closed gate preserves the original map exactly")
	_check(store.apply_state(world, loaded) and gate.is_open and demo.stage == "find_free_transporter" and demo.hint_enabled and demo._route.enabled, "Loading restores the pallet jack search and its optional hint")
	var legacy_assignment := assigned.duplicate(true)
	legacy_assignment.demo.stage = "find_receiving_lead"
	_check(store.apply_state(world, legacy_assignment) and demo.stage == "return_to_supervisor", "An earlier area-lead save now sends the player to the shift supervisor")
	var legacy_arrival := loaded.duplicate(true)
	legacy_arrival.demo.stage = "cargo_ready"
	_check(store.apply_state(world, legacy_arrival) and demo.stage == "find_free_transporter" and demo._hint_button.visible, "An earlier completed-gate save starts the pallet jack search with its optional hint")
	_check(dock.get_cell_atlas_coords(DemoTasks.GATE_19_CELL) == DemoTasks.LOADED_GATE_ATLAS, "Restored gate contains full cargo, not an empty dock")
	for bad_time in [-1.0, 61.0, "bad", INF, NAN]:
		var invalid := waiting.duplicate(true)
		invalid.demo.free_time_remaining = bad_time
		_check(not store.apply_state(world, invalid) and gate.is_open and demo.stage == "find_free_transporter", "Malformed countdown is rejected before changing the world")
	for overrides in [{"stage": "unknown"}, {"completed": false}, {"gate19_open": false}, {"free_time_remaining": 1.0}]:
		var invalid := loaded.duplicate(true)
		invalid.demo.merge(overrides, true)
		_check(not store.apply_state(world, invalid) and gate.is_open, "Inconsistent quest/gate state is rejected before changing tiles")
	for size in [Vector2i(640, 360), Vector2i(320, 240)]:
		viewport.size = size
		var looking: Dictionary = assigned.demo.duplicate(true)
		looking.stage = "return_to_supervisor"
		demo.restore_save_state(looking)
		world.get_node("BlockNotifications")._process(10.0)
		await _capture(viewport, demo, "receiving_objective_%dx%d" % [size.x, size.y])
		_check_inside(viewport, demo._task_panel, "Receiving objective fits the compact viewport")
		player.global_position = demo.supervisor_point() - FOOT_OFFSET
		camera.force_update_scroll()
		demo._process(0.0)
		await _capture(viewport, demo, "receiving_assignment_%dx%d" % [size.x, size.y])
		_check_inside(viewport, demo._dialog, "Receiving dialogue fits the compact viewport")
		_modal_key(demo, KEY_ENTER)
		player.global_position = button_position + Vector2(0, 60) - FOOT_OFFSET
		camera.force_update_scroll()
		_press(player, KEY_ENTER)
		transition = gate._transition as Tween
		_check(transition != null and gate._busy, "Enter opens the assigned gate on compact viewports")
		transition.pause()
		transition.custom_step(0.13)
		await _capture(viewport, demo, "gate_19_blackout_%dx%d" % [size.x, size.y], true)
		transition.custom_step(1.0)
		await _capture(viewport, demo, "gate_19_loaded_%dx%d" % [size.x, size.y])
		_check(demo._hint_button.visible and not demo.hint_enabled and demo._objective.text == "Найдите свободный паллетовоз", "Compact pallet jack search offers an optional hint without enabling it automatically")
		_check_inside(viewport, demo._task_panel, "Pallet jack search fits the compact viewport")
	world.free()
	viewport.free()
	paused = false
	if not failed:
		print("Demo delivery passed: configurable free time, immediate shift supervisor assignment, repeated dialogue, countdown-save migration, loaded gate, optional nearest free jack guide, live retargeting, unavailable vehicles, disk restore, invalid saves and compact layouts")
	quit(1 if failed else 0)

func _check_nearest_jack_hint(demo: Node, world: Node2D, player: Node2D, viewport: SubViewport) -> void:
	var jacks := world.get_node("YSortActors/TransporterSprites").get_children()
	var originals := {}
	for jack in jacks:
		originals[jack] = {"position": jack.global_position, "visible": jack.visible, "carried": jack.is_carried}
		jack.hide()
	var first := jacks[0] as PickupVehicle
	var second := jacks[1] as PickupVehicle
	var old_player := player.global_position
	var feet := old_player + FOOT_OFFSET
	first.global_position = feet + Vector2(100, 50)
	second.global_position = feet + Vector2(300, 50)
	first.set_carried(false)
	second.set_carried(false)
	demo.request_hint()
	demo._buttons.get_child(1).pressed.emit()
	_check(demo.nearest_free_transporter() == first and demo._route.points.size() == 2 and demo._route.points[-1].is_equal_approx(first.interaction_area.global_position), "The guide selects the closest free pallet jack")
	first.set_carried(true)
	await _settle(demo)
	_check(demo.nearest_free_transporter() == second and demo._route.points[-1].is_equal_approx(second.interaction_area.global_position), "A carried jack is excluded and the guide switches to the next free one")
	first.set_carried(false)
	player.global_position = second.interaction_area.global_position + Vector2(0, 20) - FOOT_OFFSET
	await _settle(demo)
	_check(demo.nearest_free_transporter() == second and demo._route.points[-1].is_equal_approx(second.interaction_area.global_position), "Moving updates which jack is closest")
	var transporter := world.get_node("YSortActors/PalletJackAssets").get_child(0) as PickupVehicle
	var old_transporter := transporter.global_position
	transporter.global_position = player.global_position + FOOT_OFFSET
	_check(demo.nearest_free_transporter() == second, "A nearer transporter is not mistaken for a pallet jack")
	transporter.global_position = old_transporter
	first.hide()
	second.hide()
	await _settle(demo)
	_check(demo.nearest_free_transporter() == null and demo._route.points.is_empty(), "No available jacks clears the guide instead of pointing to a stale target")
	first.show()
	await _settle(demo)
	_check(demo.nearest_free_transporter() == first and demo._route.points.size() == 2, "The guide resumes when a free jack becomes available")
	for jack in originals:
		jack.global_position = originals[jack].position
		jack.set_carried(originals[jack].carried)
		jack.visible = originals[jack].visible
	player.global_position = old_player
	await _settle(demo)
	var nearest: PickupVehicle = demo.nearest_free_transporter()
	_check(nearest != null and demo._route.points.size() == 2 and demo._route.points[-1].is_equal_approx(nearest.interaction_area.global_position), "The real warehouse uses its nearest available jack")
	player.global_position = nearest.interaction_area.global_position + Vector2(80, 0) - FOOT_OFFSET
	player.get_node("Camera2D").force_update_scroll()
	await _capture(viewport, demo, "nearest_free_transporter_guide")
	player.global_position = old_player
	player.get_node("Camera2D").force_update_scroll()
	await _settle(demo)

func _press(player: Node, code: Key, echo := false) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	event.echo = echo
	player._unhandled_input(event)

func _modal_key(demo: Node, code: Key) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = code
	event.pressed = true
	demo._input(event)

func _snapshot(layer: TileMapLayer) -> Dictionary:
	var result := {}
	for cell in layer.get_used_cells():
		result[cell] = [layer.get_cell_source_id(cell), layer.get_cell_atlas_coords(cell), layer.get_cell_alternative_tile(cell)]
	return result

func _unchanged_except(layer: TileMapLayer, original: Dictionary, changed: Vector2i) -> bool:
	var current := _snapshot(layer)
	current.erase(changed)
	var expected := original.duplicate()
	expected.erase(changed)
	return current == expected

func _settle(demo: Node) -> void:
	await physics_frame
	await process_frame
	await process_frame
	demo._process(0.0)

func _capture(viewport: SubViewport, demo: Node, name: String, blackout := false) -> void:
	await _settle(demo)
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var picture := viewport.get_texture().get_image()
	if blackout:
		for point in [Vector2i.ZERO, viewport.size / 2, viewport.size - Vector2i.ONE]:
			var pixel := picture.get_pixelv(point)
			_check(maxf(pixel.r, maxf(pixel.g, pixel.b)) <= 0.01, "Blackout covers the complete viewport")
	var output := OS.get_environment("DEMO_QA_DIR")
	if output.is_empty():
		output = "user://tmp/demo_delivery_qa"
	DirAccess.make_dir_recursive_absolute(output)
	_check(picture.save_png(output.path_join(name + ".png")) == OK, "Save delivery preview")

func _check_inside(viewport: SubViewport, control: Control, message: String) -> void:
	_check(Rect2(Vector2.ZERO, Vector2(viewport.size)).encloses(Rect2(control.global_position, control.size)), message)

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
