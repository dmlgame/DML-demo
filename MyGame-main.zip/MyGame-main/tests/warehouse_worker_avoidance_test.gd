extends SceneTree

const WorkerScene := preload("res://assets/npcs/warehouse_worker.tscn")
const Worker := preload("res://warehouse_worker.gd")
var failed := false
var _reported := {}

class RoamingArea extends Node:
	var bounds := Rect2(-300, -300, 600, 600)

	func can_roam(feet: Vector2) -> bool:
		return bounds.has_point(feet - Vector2(12, 0)) and bounds.has_point(feet + Vector2(12, 0))

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	await _encounter("horizontal", [Vector2(-100, 0), Vector2(100, 0)], [Vector2(100, 0), Vector2(-100, 0)])
	await _encounter("vertical", [Vector2(0, -100), Vector2(0, 100)], [Vector2(0, 100), Vector2(0, -100)])
	await _encounter("diagonal", [Vector2(-80, -80), Vector2(80, 80)], [Vector2(80, 80), Vector2(-80, -80)])
	await _encounter("crossing", [Vector2(-100, 0), Vector2(0, -100)], [Vector2(100, 0), Vector2(0, 100)])
	await _encounter("already touching", [Vector2(-10.5, 0), Vector2(10.5, 0)], [Vector2(100, 0), Vector2(-100, 0)])
	await _encounter("standing colleague", [Vector2(-100, 0), Vector2.ZERO], [Vector2(100, 0), Vector2.ZERO], 1)
	await _encounter("wall on passing side", [Vector2(-100, 0), Vector2(100, 0)], [Vector2(100, 0), Vector2(-100, 0)], -1, [Rect2(-160, 16, 320, 16)])
	await _encounter("narrow passage", [Vector2(-100, 0), Vector2(100, 0)], [Vector2(100, 0), Vector2(-100, 0)], -1, [Rect2(-40, -28, 80, 23), Rect2(-40, 5, 80, 23)])
	await _encounter("four-way crossing", [Vector2(-100, 0), Vector2(100, 0), Vector2(0, -100), Vector2(0, 100)], [Vector2(100, 0), Vector2(-100, 0), Vector2(0, 100), Vector2(0, -100)])
	await _encounter("boundary beside encounter", [Vector2(-100, 275), Vector2(100, 275)], [Vector2(100, 275), Vector2(-100, 275)])
	await _encounter("unequal speeds", [Vector2(-100, 0), Vector2(100, 0)], [Vector2(100, 0), Vector2(-100, 0)], -1, [], [62, 180])
	await _encounter("following colleague", [Vector2(-150, 0), Vector2(-80, 0)], [Vector2(100, 0), Vector2(160, 0)], -1, [], [180, 62])
	await _encounter("reverse processing order", [Vector2(-100, 0), Vector2(100, 0)], [Vector2(100, 0), Vector2(-100, 0)], -1, [], [], true)
	if not failed:
		print("Worker avoidance passed: thirteen encounters, head-on, diagonal, crossing, touching, stationary, wall, narrow passage, crowd, boundary, varied speeds and order; no overlaps or endless pushing")
	quit(1 if failed else 0)

func _encounter(label: String, starts: Array, targets: Array, stationary := -1, walls: Array = [], speeds: Array = [], reverse_order := false) -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(640, 640)
	viewport.world_2d = World2D.new()
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := Node2D.new()
	viewport.add_child(world)
	var output := OS.get_environment("NPC_QA_DIR")
	var capture := label == "horizontal" and DisplayServer.get_name() != "headless" and not output.is_empty()
	if capture:
		DirAccess.make_dir_recursive_absolute(output)
		var camera := Camera2D.new()
		camera.zoom = Vector2(2, 2)
		world.add_child(camera)
		camera.make_current()
	var area := RoamingArea.new()
	area.name = "WarehouseActivity"
	world.add_child(area)
	var floor_layer := TileMapLayer.new()
	floor_layer.name = "FloorLayer"
	floor_layer.tile_set = TileSet.new()
	floor_layer.tile_set.tile_size = Vector2i(32, 32)
	var atlas := TileSetAtlasSource.new()
	var tile := Image.create(32, 32, false, Image.FORMAT_RGBA8)
	tile.fill(Color("#666b6e"))
	atlas.texture = ImageTexture.create_from_image(tile)
	atlas.texture_region_size = Vector2i(32, 32)
	atlas.create_tile(Vector2i.ZERO)
	floor_layer.tile_set.add_source(atlas, 0)
	for y in range(-10, 10):
		for x in range(-10, 10):
			floor_layer.set_cell(Vector2i(x, y), 0, Vector2i.ZERO)
	world.add_child(floor_layer)
	var actors := Node2D.new()
	actors.name = "YSortActors"
	actors.y_sort_enabled = true
	world.add_child(actors)
	var player := CharacterBody2D.new()
	player.name = "Player"
	player.position = Vector2(-240, -240)
	actors.add_child(player)
	for bounds: Rect2 in walls:
		var wall := StaticBody2D.new()
		var shape := CollisionShape2D.new()
		shape.shape = RectangleShape2D.new()
		shape.shape.size = bounds.size
		wall.position = bounds.get_center()
		wall.add_child(shape)
		world.add_child(wall)
	var workers: Array[CharacterBody2D] = []
	for index in starts.size():
		var worker = WorkerScene.instantiate()
		if index == 1:
			worker.skin = preload("res://assets/npcs/lpc_workers/worker_male_blond.png")
		worker.position = starts[index] - Worker.FOOT_OFFSET
		worker.walk_speed = 70
		if not speeds.is_empty():
			worker.walk_speed = speeds[index]
		worker.pause_seconds = Vector2(1000, 1000)
		actors.add_child(worker)
		var points: Array[Dictionary] = [{"point": targets[index], "look_at": starts[index]}]
		worker.configure(world, points, 0)
		worker._target_index = 0
		worker._path = PackedVector2Array([targets[index]])
		worker.resting = index == stationary
		worker._rest_left = 1000
		workers.append(worker)
		_check(worker.motion_mode == CharacterBody2D.MOTION_MODE_FLOATING, "Workers use top-down collisions without moving-platform physics")
	if reverse_order:
		for index in workers.size():
			workers[index].process_physics_priority = workers.size() - index
	var stalled_frames := 0
	var longest_stall := 0
	var finished := false
	for frame in 720:
		var previous: Array[Vector2] = []
		for worker in workers:
			previous.append(worker.global_position)
		await physics_frame
		await process_frame
		finished = true
		var moving := false
		for index in workers.size():
			var worker = workers[index]
			_check(not _overlaps(worker), label + ": feet never overlap workers or walls")
			_check(area.can_roam(worker.global_position + Worker.FOOT_OFFSET), label + ": detours stay in the permitted area")
			if index == stationary:
				_check(worker.global_position.distance_to(starts[index] - Worker.FOOT_OFFSET) < 0.01, label + ": resting colleague stays at the object")
				continue
			finished = finished and worker.completed_stops > 0
			moving = moving or worker.global_position.distance_to(previous[index]) > 0.1
			_check(worker._animating or worker.sprite.frame_coords.x == 0, label + ": waiting workers use the standing pose")
		if finished:
			break
		stalled_frames = 0 if moving else stalled_frames + 1
		longest_stall = maxi(longest_stall, stalled_frames)
		if capture and frame in [30, 65, 90, 125, 175]:
			await RenderingServer.frame_post_draw
			_check(viewport.get_texture().get_image().save_png(output.path_join("passing_%03d.png" % frame)) == OK, "Save the real walking and sidestepping poses")
	_check(finished, label + ": all walking workers reach their original destination")
	_check(longest_stall < 90, label + ": workers do not repeatedly push each other in place")
	print(label, ": completed=", finished, " longest collective stall=", longest_stall, " frames")
	world.free()
	viewport.free()
	await physics_frame

func _overlaps(worker: CharacterBody2D) -> bool:
	var shape := RectangleShape2D.new()
	shape.size = Vector2(18, 6)
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0, worker.global_position + Worker.FOOT_OFFSET)
	query.collision_mask = 1
	query.exclude = [worker.get_rid()]
	return not worker.get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		if not _reported.has(message):
			_reported[message] = true
			push_error(message)
