extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	for mode in [1, 2]:
		for direction in [Vector2.LEFT, Vector2.RIGHT]:
			if not await _check_blocked_turn(mode, direction):
				return
			if not await _check_open_turn(mode, direction):
				return
	if not await _check_real_map_turn():
		return
	if not await _check_real_map_long_turn():
		return
	if not await _check_real_pickup_turn():
		return
	print("Collision profile switch tests passed")
	quit()


func _check_blocked_turn(mode: int, direction: Vector2) -> bool:
	var world := Node2D.new()
	root.add_child(world)
	var player: CharacterBody2D = load("res://character_body_2d.tscn").instantiate()
	world.add_child(player)
	player.last_direction = direction
	player.set_move_mode(mode)
	await physics_frame
	await physics_frame

	var initial_collision: Node2D = player._collision_for_mode(direction)
	if player._active_collision != initial_collision or initial_collision.disabled:
		return _fail("Initial vehicle collision did not activate", world)

	var obstacle := StaticBody2D.new()
	obstacle.position = Vector2(0, -55 if mode == 1 else -40)
	var obstacle_shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size = Vector2(20, 20)
	obstacle_shape.shape = rectangle
	obstacle.add_child(obstacle_shape)
	world.add_child(obstacle)
	await physics_frame
	await physics_frame

	var rear_obstacle := StaticBody2D.new()
	rear_obstacle.position = Vector2(0, 50)
	var rear_shape := CollisionShape2D.new()
	var rear_rectangle := RectangleShape2D.new()
	rear_rectangle.size = Vector2(20, 10)
	rear_shape.shape = rear_rectangle
	rear_obstacle.add_child(rear_shape)
	world.add_child(rear_obstacle)
	await physics_frame
	await physics_frame

	var start_position := player.global_position
	player.turn_knockback_limit = 0
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	if player._active_collision != initial_collision:
		return _fail("Turn activated with knockback disabled", world)
	if player.last_direction != direction:
		return _fail("Player visually turned with knockback disabled", world)
	if player.global_position != start_position or player.velocity != Vector2.ZERO:
		return _fail("Player moved with knockback disabled", world)
	if mode == 1 and not player.pallet_jack_horizontal.visible:
		return _fail("Pallet jack sprite turned while collision was blocked", world)
	if mode == 2 and player.transporter_sprite.frame_coords.y != (0 if direction == Vector2.LEFT else 1):
		return _fail("Transporter sprite turned while collision was blocked", world)

	player.turn_knockback_limit = 64
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	var knockback := player.global_position - start_position
	if knockback.x == 0.0 or knockback.y != 0.0 or absf(knockback.x) > player.turn_knockback_limit:
		return _fail("Turn did not use a safe lateral path", world)
	if player.velocity != Vector2.ZERO:
		return _fail("Player moved before the new collision became active", world)
	await physics_frame
	var down_collision: Node2D = player._collision_for_mode(Vector2.DOWN)
	if player._active_collision != down_collision or down_collision.disabled:
		return _fail("Down collision did not activate after clearing the wall", world)
	if player.last_direction != Vector2.DOWN:
		return _fail("Visual direction did not switch after clearing the wall", world)
	if mode == 1 and not player.pallet_jack_vertical.visible:
		return _fail("Pallet jack sprite did not turn after clearing the wall", world)
	if mode == 2 and player.transporter_sprite.frame_coords.y != 3:
		return _fail("Transporter sprite did not turn after clearing the wall", world)
	if player._collision_profile_overlaps(down_collision):
		return _fail("Lateral turn left the new collision overlapping", world)

	world.queue_free()
	await process_frame
	return true


func _check_open_turn(mode: int, direction: Vector2) -> bool:
	var world := Node2D.new()
	root.add_child(world)
	var player: CharacterBody2D = load("res://character_body_2d.tscn").instantiate()
	world.add_child(player)
	player.last_direction = direction
	player.set_move_mode(mode)
	var obstacle := StaticBody2D.new()
	obstacle.position = Vector2(0, -55 if mode == 1 else -40)
	var obstacle_shape := CollisionShape2D.new()
	var rectangle := RectangleShape2D.new()
	rectangle.size = Vector2(20, 20)
	obstacle_shape.shape = rectangle
	obstacle.add_child(obstacle_shape)
	world.add_child(obstacle)
	await physics_frame
	await physics_frame

	var start_position := player.global_position
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	var knockback := player.global_position - start_position
	if knockback == Vector2.ZERO or knockback.length() > player.turn_knockback_limit:
		return _fail("Turn did not find a safe nearby position", world)
	await physics_frame
	if player._active_collision != player._collision_for_mode(Vector2.DOWN):
		return _fail("Down collision did not activate after knockback", world)
	if player._collision_profile_overlaps(player._active_collision):
		return _fail("Turn placed player inside an obstacle", world)
	start_position = player.global_position
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	if player.global_position.y <= start_position.y:
		return _fail("Player did not move after the down turn completed", world)

	world.queue_free()
	await process_frame
	return true


func _check_real_map_turn() -> bool:
	return await _check_parked_transporter_turn(false)


func _check_real_map_long_turn() -> bool:
	return await _check_parked_transporter_turn(true)


func _check_parked_transporter_turn(long_turn: bool) -> bool:
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	var player: CharacterBody2D = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	player.last_direction = Vector2.UP
	player.set_move_mode(1)
	player._apply_collision_profile(Vector2.UP)
	await physics_frame
	await physics_frame
	var approach := _parked_transporter_approach(world, player, long_turn)
	if approach.is_empty():
		return _fail("Expected a clear up-facing approach requiring a %s turn beside an existing parked transporter" % ("long" if long_turn else "short"), world)
	player.global_position = approach.position
	var start_position := player.global_position
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	var knockback := player.global_position - start_position
	if not is_equal_approx(knockback.length(), approach.distance) or player.velocity != Vector2.ZERO:
		return _fail("Turn must use the nearest physically reachable clear position: expected=%s actual=%s" % [approach.distance, knockback], world)
	await physics_frame
	if player._active_collision != player.collision_pallet_jack_down or player.last_direction != Vector2.DOWN:
		return _fail("The pallet jack must activate the downward profile after clearing the real parked transporter", world)
	if player._collision_profile_overlaps(player.collision_pallet_jack_down):
		return _fail("The turned pallet jack overlaps an obstacle on the current warehouse map", world)
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	if player.global_position.y <= start_position.y + knockback.y:
		return _fail("The pallet jack must move after the downward profile becomes active", world)
	world.queue_free()
	await process_frame
	return true


func _parked_transporter_approach(world: Node2D, player: CharacterBody2D, long_turn: bool) -> Dictionary:
	var target: Node2D = player.collision_pallet_jack_down
	for vehicle in world.get_node("YSortActors/TransporterSprites").get_children():
		if not vehicle is PickupVehicle or vehicle.vehicle_mode != PickupVehicle.VehicleMode.TRANSPORTER:
			continue
		for y in range(24, 65, 4):
			for x in range(-20, 121, 4):
				player.global_position = vehicle.global_position + Vector2(x, y)
				if player._collision_profile_overlaps(player.collision_pallet_jack_up) or not _profile_hits_body(player, target, vehicle.get_node("StaticBody2D")):
					continue
				var distance := _nearest_turn_clearance(player, target)
				if distance > 0 and (distance > 64) == long_turn:
					return {"position": player.global_position, "distance": distance}
	return {}


func _profile_hits_body(player: CharacterBody2D, target: Node2D, body: PhysicsBody2D) -> bool:
	for shape in player._collision_profile_shapes(target):
		for hit in player.get_world_2d().direct_space_state.intersect_shape(player._shape_query(shape, target.global_transform)):
			if hit.collider == body:
				return true
	return false


func _nearest_turn_clearance(player: CharacterBody2D, target: Node2D) -> int:
	for distance in range(1, player.turn_knockback_limit + 1):
		for direction in [Vector2.DOWN, Vector2.LEFT, Vector2.RIGHT, Vector2.UP]:
			var offset: Vector2 = direction * distance
			if not player.test_move(player.global_transform, offset, null, 0.0) and not player._collision_profile_overlaps(target, offset):
				return distance
	return 0


func _check_real_pickup_turn() -> bool:
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	var player: CharacterBody2D = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	await physics_frame
	await physics_frame
	var jack := _clear_pickup_approach(world, player)
	if jack == null:
		return _fail("Expected a real manual jack with a physically clear pickup approach on the current map", world)
	player._nearby_vehicles.clear()
	player.register_pickup_vehicle(jack)
	if not player._interact_with_vehicle() or not jack.is_carried or player._carried_vehicle != jack:
		return _fail("The selected existing manual jack could not be picked up", world)
	await physics_frame
	await physics_frame
	var start_position := player.global_position
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	await physics_frame
	player._move_with_direction(Vector2.DOWN, false, 1.0 / 60.0)
	if player.global_position.y <= start_position.y or player._active_collision != player.collision_pallet_jack_down:
		return _fail("The pallet jack must move downward with its matching profile after a real pickup", world)
	if player._collision_profile_overlaps(player.collision_pallet_jack_down):
		return _fail("The pallet jack overlaps an obstacle after pickup", world)
	await physics_frame
	if player.collision_pallet_jack_down.disabled or player.collision_on_foot.disabled:
		return _fail("Both jack and operator footprints must remain enabled after pickup", world)
	world.queue_free()
	await process_frame
	return true


func _clear_pickup_approach(world: Node2D, player: CharacterBody2D) -> PickupVehicle:
	for vehicle in world.get_node("YSortActors/PalletJackAssets").get_children():
		var jack := vehicle as PickupVehicle
		if jack == null or jack.vehicle_mode != PickupVehicle.VehicleMode.PALLET_JACK or jack.is_carried:
			continue
		for offset in [Vector2(0, 40), Vector2(0, 50), Vector2(40, 0), Vector2(-40, 0)]:
			player.global_position = jack.interaction_area.global_position + offset - Vector2(0, 25)
			if player._collision_profile_overlaps(player.collision_on_foot):
				continue
			var clear := true
			for shape in player._collision_profile_shapes(player.collision_pallet_jack_down):
				var query: PhysicsShapeQueryParameters2D = player._shape_query(shape, player.collision_pallet_jack_down.global_transform)
				var excluded: Array[RID] = query.exclude
				excluded.append(jack.get_node("StaticBody2D").get_rid())
				query.exclude = excluded
				if not player.get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty():
					clear = false
					break
			if clear:
				return jack
	return null


func _fail(message: String, world: Node2D) -> bool:
	push_error(message)
	world.queue_free()
	quit(1)
	return false
