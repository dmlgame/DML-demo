extends SceneTree

const SortGeometry = preload("res://footprint_sort_geometry.gd")
const OUTPUT := "res://tmp/decor_rc_qa/"
const CELL := Vector2i(10, 6)


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("Object layer footprint test requires a renderer")
		quit(1)
		return
	var viewport := SubViewport.new()
	viewport.size = Vector2i(680, 420)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var tiles: TileSet = load("res://assets/tiles/warehouse_objects_tileset.tres")
	var checked := 0
	for source_index in tiles.get_source_count():
		var source_id := tiles.get_source_id(source_index)
		var source := tiles.get_source(source_id) as TileSetAtlasSource
		if source == null:
			continue
		for tile_index in source.get_tiles_count():
			var atlas := source.get_tile_id(tile_index)
			if source_id == 0 and atlas == Vector2i(0, 13):
				continue # The U-shaped workstation has its own split-visual test.
			for alternative_index in source.get_alternative_tiles_count(atlas):
				var alternative := source.get_alternative_tile_id(atlas, alternative_index)
				var data := source.get_tile_data(atlas, alternative)
				if data.get_collision_polygons_count(0) == 0:
					continue
				if not await _check_tile(viewport, tiles, source_id, atlas, alternative):
					return
				checked += 1
	for transform_flags in [4096, 8192, 16384, 4096 | 16384, 8192 | 16384, 4096 | 8192 | 16384]:
		if not await _check_tile(viewport, tiles, 6, Vector2i(4, 0), transform_flags):
			return
	if not await _check_live_collision_edit(viewport, tiles):
		return
	if not await _check_world_visuals(viewport):
		return
	print("Object layer footprint passed: %d solid tile variants, sloping bases, unchanged pixels/collisions, transforms and live collision edits" % checked)
	quit()


func _check_tile(viewport: SubViewport, tiles: TileSet, source_id: int, atlas: Vector2i, alternative: int) -> bool:
	var label := "%d:%s:%d" % [source_id, atlas, alternative]
	var plain := TileMapLayer.new()
	plain.tile_set = tiles
	plain.set_cell(CELL, source_id, atlas, alternative)
	viewport.add_child(plain)
	var baseline := await _frame(viewport)
	viewport.remove_child(plain)
	plain.free()
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var layer := TileMapLayer.new()
	layer.set_script(load("res://object_footprint_sort.gd"))
	layer.tile_set = tiles
	layer.y_sort_enabled = true
	layer.set_cell(CELL, source_id, atlas, alternative)
	actors.add_child(layer)
	var player := Node2D.new()
	player.name = "Player"
	player.position = Vector2(1000, 1000)
	actors.add_child(player)
	var patch := ColorRect.new()
	patch.color = Color.MAGENTA
	patch.size = Vector2(4, 4)
	patch.visible = false
	player.add_child(patch)
	var rendered := await _frame(viewport)
	if baseline.get_data() != rendered.get_data():
		baseline.save_png(OUTPUT + "object_before.png")
		rendered.save_png(OUTPUT + "object_after.png")
		return _fail("Tile moved, changed color or lost pixels: " + label)
	var entries: Array = layer.get("_visuals")
	if entries.size() != 1:
		return _fail("Solid tile does not follow its collision footprint: " + label)
	var entry: Dictionary = entries[0]
	var center := layer.map_to_local(CELL)
	var left := INF
	var right := -INF
	for polygon in entry.polygons:
		for point in polygon:
			left = minf(left, point.x)
			right = maxf(right, point.x)
	patch.visible = true
	for fraction in [0.05, 0.5, 0.95]:
		var local_x := lerpf(left, right, fraction)
		var front := SortGeometry.front_y(entry.polygons, local_x, entry.fallback)
		var sample := _opaque_pixel(baseline, int(center.x + local_x), int(center.y + front))
		if sample.x < 0:
			baseline.save_png(OUTPUT + "object_sample_missing.png")
			return _fail("No opaque test pixel found: " + label)
		for in_front in [false, true]:
			player.position = center + Vector2(local_x, front - 25.0 + (2 if in_front else -2))
			patch.position = Vector2(sample) - player.position - Vector2(1, 1)
			layer.call("_process", 0.0)
			var image := await _frame(viewport)
			if not is_equal_approx(entry.visual.position.y, center.y + front - 25.0):
				return _fail("Sort depth ignores the edited footprint at x=%s: %s" % [local_x, label])
			if image.get_pixelv(sample).is_equal_approx(Color.MAGENTA) != in_front:
				return _fail("Incorrect front/back rendering at x=%s: %s" % [local_x, label])
		patch.visible = false
		if (await _frame(viewport)).get_data() != baseline.get_data():
			return _fail("Moving the sort origin moved or clipped the sprite: " + label)
		patch.visible = true
	viewport.remove_child(actors)
	actors.free()
	return true


func _check_live_collision_edit(viewport: SubViewport, tiles: TileSet) -> bool:
	var edited := tiles.duplicate(true) as TileSet
	var source := edited.get_source(6) as TileSetAtlasSource
	var data := source.get_tile_data(Vector2i(4, 0), 0)
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var player := Node2D.new()
	player.name = "Player"
	player.position = Vector2(326, 200)
	actors.add_child(player)
	var layer := TileMapLayer.new()
	layer.set_script(load("res://object_footprint_sort.gd"))
	layer.tile_set = edited
	layer.y_sort_enabled = true
	layer.set_cell(CELL, 6, Vector2i(4, 0))
	actors.add_child(layer)
	await _frame(viewport)
	var old_points := data.get_collision_polygon_points(0, 0)
	var shifted := old_points.duplicate()
	for index in shifted.size():
		shifted[index].y -= 8
	data.set_collision_polygon_points(0, 0, shifted)
	await _frame(viewport)
	await _frame(viewport)
	var entries: Array = layer.get("_visuals")
	if entries.size() != 1 or entries[0].polygons[0] != shifted:
		return _fail("Editing TileSet collision leaves a stale Y-sort footprint")
	layer.call("_process", 0.0)
	var expected := layer.map_to_local(CELL).y + SortGeometry.front_y([shifted], -10.0, 0.0) - 25.0
	if not is_equal_approx(entries[0].visual.position.y, expected):
		return _fail("Changed collision did not update the visual sort origin")
	if data.get_collision_polygon_points(0, 0) != shifted or data.modulate.a != 1.0:
		return _fail("Sorting modified the shared collision or tint")
	layer.erase_cell(CELL)
	await _frame(viewport)
	if not layer.get_children(true).is_empty():
		return _fail("Erased tile left a duplicate visual")
	viewport.remove_child(actors)
	actors.free()
	return true


func _check_world_visuals(viewport: SubViewport) -> bool:
	viewport.transparent_bg = false
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var layer := world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	player.set_process(false)
	player.call("set_move_mode", 0)
	player.get_node("Visuals/OnFoot").pause()
	player.get_node("Camera2D").enabled = false
	var camera := Camera2D.new()
	camera.zoom = Vector2(3, 3)
	viewport.add_child(camera)
	camera.make_current()
	await _frame(viewport)
	for target in [[6, Vector2i(2, 4)], [1, Vector2i(4, 0)], [0, Vector2i(7, 0)]]:
		var best := {}
		var distance := INF
		for entry in layer.get("_visuals"):
			if layer.get_cell_source_id(entry.cell) != target[0] or layer.get_cell_atlas_coords(entry.cell) != target[1]:
				continue
			var candidate: float = entry.center.distance_squared_to(Vector2(560, -144))
			if candidate < distance:
				best = entry
				distance = candidate
		if best.is_empty():
			return _fail("Expected placed prop missing from the current warehouse")
		camera.position = layer.to_global(best.center) + Vector2(0, 8)
		var front := SortGeometry.front_y(best.polygons, 0.0, best.fallback)
		for in_front in [false, true]:
			player.position = best.center + Vector2(0, front - 25.0 + (10 if in_front else -14))
			layer.call("_process", 0.0)
			var image := await _frame(viewport)
			image.save_png(OUTPUT + "object_world_%d_%s.png" % [target[0], "front" if in_front else "behind"])
			if (best.visual.global_position.y < player.global_position.y) != in_front:
				return _fail("Actual warehouse prop has incorrect front/back depth")
	world.free()
	camera.free()
	return true


func _opaque_pixel(image: Image, preferred_x: int, front_y: int) -> Vector2i:
	for x_offset in [0, -1, 1, -2, 2, -4, 4, -8, 8]:
		var x: int = preferred_x + x_offset
		if x < 0 or x >= image.get_width():
			continue
		for y in range(clampi(front_y, 0, image.get_height() - 1), -1, -1):
			if image.get_pixel(x, y).a > 0.9:
				return Vector2i(x, y)
		for y in range(clampi(front_y + 1, 0, image.get_height()), image.get_height()):
			if image.get_pixel(x, y).a > 0.9:
				return Vector2i(x, y)
	return Vector2i(-1, -1)


func _frame(viewport: SubViewport) -> Image:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	return viewport.get_texture().get_image()


func _fail(message: String) -> bool:
	push_error(message)
	quit(1)
	return false
