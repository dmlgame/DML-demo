extends SceneTree

var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var session: Node = load("res://game_session.tscn").instantiate()
	_check(not session.animation_test_mode and session.orientation_only, "The main scene starts the informational tour, not animation testing")
	session.save_store.directory = "user://tmp/animation_test_mode_%d" % Time.get_ticks_usec()
	session.animation_test_mode = false
	root.add_child(session)
	await session._start_world("")
	_check(session.world.has_node("DemoTasks"), "Disabling the switch restores ordinary demo quests")
	_check(not session.world.get_node("YSortActors/Player").pallet_jack_animation_test, "Ordinary games retain the empty jack animation")
	var state: Dictionary = session.save_store.capture(session.world)
	for slot in WarehouseSaveStore.SLOTS:
		_check(session.save_store.write_state(state, slot), "Create existing progress fixture: " + slot)
	session._return_to_menu()
	var original_files := {}
	for slot in WarehouseSaveStore.SLOTS:
		for suffix in ["", ".bak"]:
			var path: String = session.save_store._path(slot) + suffix
			original_files[path] = FileAccess.get_file_as_bytes(path) if FileAccess.file_exists(path) else PackedByteArray()
	session.animation_test_mode = true
	await session._start_world("")
	var world: Node = session.world
	var player: CharacterBody2D = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	_check(not world.has_node("DemoTasks") and player._demo_tasks == null, "Test games have no quests or vehicle restrictions")
	_check(player.pallet_jack_animation_test and player.pallet_jack_totes_animation_test, "The blue-totes animation is selected in the actual main scene")
	var jack_count := 0
	var transporter_count := 0
	for vehicle in session.save_store._vehicles(world):
		player._nearby_vehicles.clear()
		player.register_pickup_vehicle(vehicle)
		_check(player._interact_with_vehicle(), "Any warehouse vehicle can be picked up")
		_check(player._carried_vehicle == vehicle and vehicle.is_carried, "The chosen vehicle is actually carried")
		if vehicle.vehicle_mode == PickupVehicle.VehicleMode.PALLET_JACK:
			jack_count += 1
			_check(player.pallet_jack_loaded and player._tote_sprite.visible and not player._pallet_test_sprite.visible and not player.pallet_jack_horizontal.visible and not player.pallet_jack_vertical.visible, "Picking up any jack automatically shows the pallet and blue totes")
			for row in range(4):
				var direction: Vector2 = [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN][row]
				player.last_direction = direction
				player._reset_vehicle_animation()
				for frame in range(8):
					player._update_vehicle_frame(direction, frame)
					_check(player._tote_sprite.frame_coords == Vector2i(frame, row), "The test sheet uses all 32 frames")
				player._reset_vehicle_animation()
				player._update_active_visual(true, false, 1.0 / player.vehicle_animation_fps)
				_check(player._tote_sprite.frame_coords == Vector2i(1, row), "Movement advances the loaded jack animation")
			_check(player._tote_sprite.texture.resource_path == "res://assets/objects/pallet_jack_operator/pallet_jack_operator_blue_tote_stack_walk_300.png", "The test uses the edited blue-totes sheet")
		else:
			transporter_count += 1
			_check(player.transporter_visual.visible and not player.pallet_jack_visual.visible, "The transporter keeps its own animation")
		_check(player._interact_with_vehicle(), "Equipment can also be put down")
		_check(player.move_mode == 0 and not vehicle.is_carried, "Putting equipment down restores walking")
		_check(not player.pallet_jack_loaded, "Putting equipment down clears test cargo")
	_check(jack_count > 0 and transporter_count > 0, "Both types of equipment were exercised")
	player.set_move_mode(1)
	_check(player.pallet_jack_loaded, "Switching back to a jack reapplies the selected test animation")
	player.set_pallet_jack_animation_test(true)
	_check(not player.pallet_jack_loaded and player._pallet_test_sprite.visible, "Bare pallet testing is still selectable")
	player.set_pallet_jack_animation_test(true, true)
	_check(player.pallet_jack_loaded and player._tote_sprite.visible, "Blue-totes testing can also be enabled while holding a jack")
	_check(player.set_pallet_jack_totes(true, true), "Blue cargo still uses its ordinary animation")
	_check(player._tote_sprite.visible and not player._pallet_test_sprite.visible, "Blue cargo does not overlap the test pallet sheet")
	player.set_pallet_jack_totes(false)
	_check(player._pallet_test_sprite.visible, "Unloading blue cargo returns to the test animation")
	player.set_move_mode(0)
	for slot in WarehouseSaveStore.SLOTS:
		_check(not session.save_store.save_world(world, slot), "Test progress cannot overwrite " + slot)
	session._save_manual("slot_1")
	_check(session.menu.status.text.contains("отключены"), "Manual saving explains that test saves are disabled")
	var quicksave := InputEventKey.new()
	quicksave.keycode = KEY_F5
	quicksave.pressed = true
	session._input(quicksave)
	_check(session._toast.text.contains("отключены"), "F5 cannot overwrite normal progress")
	session._autosave_elapsed = 61.0
	session._process(0.01)
	_check(session._autosave_elapsed == 61.0, "Timed autosaving is skipped in test mode")
	await session._start_world("slot_1")
	_check(session.world == world, "Test mode leaves existing saves unloaded")
	session._return_to_menu()
	_check(session.world == null and session.menu.visible and not paused, "Test mode can return to the menu without saving")
	for path in original_files:
		var actual := FileAccess.get_file_as_bytes(path) if FileAccess.file_exists(path) else PackedByteArray()
		_check(actual == original_files[path], "Existing saves and backups stay byte-identical: " + path)
	session.free()
	paused = false
	if not failed:
		print("Animation test mode passed: %d free jacks, %d free transporters, all pallet directions/frames, quest restoration and unchanged saves" % [jack_count, transporter_count])
	quit(1 if failed else 0)

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
