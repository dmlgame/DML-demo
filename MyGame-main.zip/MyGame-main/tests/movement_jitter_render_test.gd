extends SceneTree

const STEP := 1.0 / 60.0
const MARKER_COLOR := Color(1, 0, 1, 1)
const OUTPUT := "res://tmp/decor_rc_qa/movement_jitter/"

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if DisplayServer.get_name() == "headless":
		push_error("Movement jitter validation needs a renderer")
		quit(1)
		return
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var player := load("res://character_body_2d.tscn").instantiate() as CharacterBody2D
	viewport.add_child(player)
	player.set_physics_process(false)
	player.set_process(false)
	var marker := ColorRect.new()
	marker.color = MARKER_COLOR
	marker.position = Vector2(-3, -3)
	marker.size = Vector2(6, 6)
	marker.z_index = 100
	player.get_node("Visuals").add_child(marker)
	var snap_transforms: bool = ProjectSettings.get_setting("rendering/2d/snap/snap_2d_transforms_to_pixel", false)
	var snap_vertices: bool = ProjectSettings.get_setting("rendering/2d/snap/snap_2d_vertices_to_pixel", false)
	var profiles := [[snap_transforms, snap_vertices]]
	if OS.get_cmdline_user_args().has("--probe"):
		profiles = [[true, true], [true, false], [false, true], [false, false]]
	var failed := false
	for profile in profiles:
		RenderingServer.viewport_set_snap_2d_transforms_to_pixel(viewport.get_viewport_rid(), profile[0])
		RenderingServer.viewport_set_snap_2d_vertices_to_pixel(viewport.get_viewport_rid(), profile[1])
		for state in [[0, false, false], [0, false, true], [1, false, false], [1, true, false], [2, false, false], [2, true, false]]:
			var mode: int = state[0]
			player.call("set_pallet_jack_totes", false, true)
			player.call("set_transporter_cargo", false, true)
			player.call("set_move_mode", mode)
			if state[1]:
				player.call("set_pallet_jack_totes" if mode == 1 else "set_transporter_cargo", true, true)
			for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN, Vector2(-1, -1).normalized(), Vector2(1, -1).normalized(), Vector2(-1, 1).normalized(), Vector2(1, 1).normalized()]:
				player.position = Vector2(320, 240)
				var facing: Vector2 = player.call("_cardinal_direction", direction)
				player.call("_try_face_direction", facing)
				await physics_frame
				await physics_frame
				var reference := Rect2i()
				var reference_pixels := PackedByteArray()
				var jitter_frames := 0
				var sprite_jitter_frames := 0
				for frame in range(18):
					await physics_frame
					player.call("_move_with_direction", direction, state[2], STEP, facing)
					(player.get_node("Visuals/OnFoot") as AnimatedSprite2D).stop()
					(player.get_node("Visuals/OnFoot") as AnimatedSprite2D).frame = 0
					player.call("_update_vehicle_frame", facing, 0)
					await RenderingServer.frame_post_draw
					await RenderingServer.frame_post_draw
					var captured := viewport.get_texture().get_image()
					var bounds := _marker_bounds(captured)
					if bounds.size == Vector2i.ZERO:
						push_error("The camera-following marker must render")
						quit(1)
						return
					if frame == 0:
						reference = bounds
						reference_pixels = captured.get_data()
					elif bounds != reference:
						jitter_frames += 1
					if frame > 0 and captured.get_data() != reference_pixels:
						sprite_jitter_frames += 1
					if not OS.get_cmdline_user_args().has("--probe") and frame in [0, 8, 17]:
						DirAccess.make_dir_recursive_absolute(OUTPUT)
						captured.save_png(OUTPUT + "mode_%d_loaded_%s_run_%s_direction_%s_frame_%d.png" % [mode, state[1], state[2], str(direction), frame])
				print("snap=%s state=%s direction=%s marker_jitter=%d/17 sprite_jitter=%d/17" % [str(profile), state, direction, jitter_frames, sprite_jitter_frames])
				failed = failed or jitter_frames > 0 or sprite_jitter_frames > 0
	if failed and not OS.get_cmdline_user_args().has("--probe"):
		push_error("Fractional movement makes the actor jitter relative to its following camera")
		quit(1)
		return
	print("Walking, running, empty/loaded jack and transporter in eight directions: stable camera-relative marker and frozen sprites passed")
	quit()

func _marker_bounds(captured: Image) -> Rect2i:
	var bounds := Rect2i()
	var found := false
	var center := captured.get_size() / 2
	for y in range(center.y - 12, center.y + 12):
		for x in range(center.x - 12, center.x + 12):
			if captured.get_pixel(x, y) != MARKER_COLOR:
				continue
			if not found:
				bounds = Rect2i(x, y, 1, 1)
				found = true
			else:
				bounds = bounds.merge(Rect2i(x, y, 1, 1))
	return bounds
