extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"
const TITLE := "Грузовой лифт, лестница на мезонин"
const OPEN_ACTION := "Нажмите E, чтобы открыть лифт"
const CLOSE_ACTION := "Нажмите E, чтобы закрыть лифт"
const FLOOR_ACTION := "Нажмите Enter, чтобы подняться на нужный вам этаж мезонина"
const LOCKED_NOTICE := "Данный этаж временно недоступен, ведутся строительные работы!"
const OPEN_TEXTURE := preload("res://assets/objects/mezzanine_lift/freight_lift_ground_floor_open.png")
const FootprintSortGeometry = preload("res://footprint_sort_geometry.gd")
const FEET_OFFSET := Vector2(0, 25)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1152, 648)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.position = Vector2(-64, -1620)
	viewport.add_child(world)
	player.set_physics_process(false)
	var camera := player.get_node("Camera2D") as Camera2D
	var controller := world.get_node("FreightLiftInteraction")
	var lifts: Array = controller.get("_lifts")
	var hint := player.get("_interaction_hint") as RichTextLabel
	var menu := controller.get("_menu") as PanelContainer
	var locked_hint := controller.get("_locked_hint") as PanelContainer
	var floor_buttons: Array = controller.get("_floor_buttons")
	if lifts.size() != 6 or floor_buttons.size() != 5:
		return _fail("Only the six selected block 2 lifts must offer five floors")
	var original_tiles := {}
	for layer in world.find_children("*", "TileMapLayer", true, false):
		original_tiles[world.get_path_to(layer)] = _snapshot(layer)
	var original_lifts := {}
	var sprites := world.get_node("YSortActors/MezzanineLayer/MezzanineAccessSprites")
	for sprite in sprites.get_children():
		original_lifts[sprite.name] = {
			"texture": sprite.texture, "transform": sprite.global_transform, "scale": sprite.scale,
			"shape": sprite.get_node("StaticBody2D/CollisionPolygon2D"),
			"polygon": sprite.get_node("StaticBody2D/CollisionPolygon2D").polygon.duplicate(),
		}
	for index in range(6, 12):
		var other := sprites.get_child(index) as Sprite2D
		player.global_position = _approach(other, 750)
		player.call("_update_interaction_hint")
		_press(player, KEY_E)
		_press(player, KEY_ENTER)
		if hint.get_parsed_text().contains(TITLE) or controller.get("_busy") or not controller.get("_selected").is_empty():
			return _fail("Lifts outside block 2 must remain non-interactive")
	var first: Sprite2D = lifts[0].sprite
	player.global_position = _approach(first, 750) + Vector2(0, 150)
	player.call("_update_interaction_hint")
	_press(player, KEY_E)
	if hint.visible or controller.get("_busy"):
		return _fail("The lift must not react from far away")
	player.global_position = first.to_global(Vector2(750, 450)) - FEET_OFFSET
	player.call("_update_interaction_hint")
	_press(player, KEY_E)
	if hint.visible or controller.get("_busy"):
		return _fail("The lift hint must not appear behind the front collision")
	player.global_position = _approach(first, 150)
	player.call("_update_interaction_hint")
	if hint.get_parsed_text() != TITLE + "\n" + OPEN_ACTION + "\n" + FLOOR_ACTION:
		return _fail("The attached staircase must offer the same E/Enter instructions")
	_press(player, KEY_ENTER)
	if controller.get("_selected").is_empty() or controller.get("_busy"):
		return _fail("Enter at the staircase must show the picker rather than opening the lift")
	await _capture(viewport, "lift_floor_picker_before_opening")
	await _click(viewport, floor_buttons[0].get_global_rect().get_center())
	if not lifts[0].dismissed or first.texture != original_lifts[first.name].texture:
		return _fail("Selecting floor 1 must not open, resize or move the lift")
	_leave_and_return(player, controller, first)
	for index in lifts.size():
		var lift: Dictionary = lifts[index]
		var sprite: Sprite2D = lift.sprite
		player.global_position = _approach(sprite, 750)
		camera.force_update_scroll()
		await physics_frame
		await physics_frame
		player.call("_update_interaction_hint")
		if hint.get_parsed_text() != TITLE + "\n" + OPEN_ACTION + "\n" + FLOOR_ACTION or not hint.visible:
			return _fail("Each closed block 2 lift must show both distinct keyboard actions")
		if not hint.text.begins_with("[color=#ff6868]" + TITLE + "[/color]"):
			return _fail("The lift title must retain the existing red title style")
		if player.call("_collision_profile_overlaps", player.get("collision_on_foot")):
			return _fail("The lift interaction position must be reachable in front of its collision")
		if index == 0:
			await _capture(viewport, "lift_block2_closed")
			if not _check_hud(hint, viewport):
				return
		_press(player, KEY_E, true)
		_press(player, KEY_E, false, false)
		if controller.get("_busy"):
			return _fail("Echoes and key releases must not open a lift")
		var player_origin := player.global_position
		_dispatch_key(viewport, KEY_E)
		var transition := controller.get("_transition") as Tween
		if transition == null or not player.get("_interaction_locked") or hint.visible:
			return _fail("E must start a quick blackout and temporarily lock movement")
		transition.pause()
		_dispatch_key(viewport, KEY_E, false)
		_press(player, KEY_ENTER)
		transition.custom_step(0.06)
		if sprite.texture != original_lifts[sprite.name].texture or not controller.get("_selected").is_empty():
			return _fail("The texture must not change before full blackout, and input must not open the picker")
		transition.custom_step(0.07)
		var shade := controller.get("_shade") as ColorRect
		var visual := sprite.get_node("SortVisual").get_child(0) as Sprite2D
		if not lift.is_open or sprite.texture != OPEN_TEXTURE or visual.texture != OPEN_TEXTURE or shade.color.a != 1.0:
			return _fail("Full blackout must swap both the lift texture and its visible sorted image")
		if sprite.texture.get_size() != original_lifts[sprite.name].texture.get_size():
			return _fail("The open lift artwork must have the exact same dimensions")
		for other_index in range(index + 1, lifts.size()):
			var other_sprite: Sprite2D = lifts[other_index].sprite
			if lifts[other_index].is_open or other_sprite.texture != original_lifts[other_sprite.name].texture:
				return _fail("Opening one lift must not open the other five")
		if index == 0:
			await _capture(viewport, "lift_block2_blackout", true)
		transition.custom_step(1.0)
		if controller.get("_busy") or player.get("_interaction_locked") or player.global_position != player_origin:
			return _fail("Opening must restore input without moving the character")
		if hint.get_parsed_text() != TITLE + "\n" + CLOSE_ACTION + "\n" + FLOOR_ACTION:
			return _fail("An opened lift must offer closing on E and floor selection on Enter")
		await _capture(viewport, "lift_block2_open_" + str(index + 1))
		_press(player, KEY_E, true)
		_press(player, KEY_E, false, false)
		if controller.get("_busy"):
			return _fail("Echoes and key releases must not close an open lift")
		var other_textures := {}
		for other in lifts:
			other_textures[other.sprite.name] = other.sprite.texture
		_dispatch_key(viewport, KEY_E)
		transition = controller.get("_transition") as Tween
		if transition == null or not player.get("_interaction_locked") or hint.visible:
			return _fail("Closing must use the same blackout and movement lock as opening")
		transition.pause()
		_dispatch_key(viewport, KEY_E, false)
		_press(player, KEY_E)
		_press(player, KEY_ENTER)
		transition.custom_step(0.06)
		if not lift.is_open or sprite.texture != OPEN_TEXTURE or not controller.get("_selected").is_empty():
			return _fail("Closing must not swap the image early or accept another action during the blackout")
		transition.custom_step(0.07)
		if lift.is_open or sprite.texture != original_lifts[sprite.name].texture or visual.texture != original_lifts[sprite.name].texture or shade.color.a != 1.0:
			return _fail("Closing must restore the exact original texture at full blackout")
		for other in lifts:
			if other != lift and other.sprite.texture != other_textures[other.sprite.name]:
				return _fail("Closing one lift must not change another lift")
		if index == 0:
			await _capture(viewport, "lift_block2_closing_blackout", true)
		transition.custom_step(1.0)
		if controller.get("_busy") or player.get("_interaction_locked") or player.global_position != player_origin or hint.get_parsed_text() != TITLE + "\n" + OPEN_ACTION + "\n" + FLOOR_ACTION:
			return _fail("Closing must restore input and the opening instruction without moving the player")
		_press(player, KEY_E)
		transition = controller.get("_transition") as Tween
		transition.pause()
		transition.custom_step(1.0)
		if not lift.is_open or sprite.texture != OPEN_TEXTURE or hint.get_parsed_text() != TITLE + "\n" + CLOSE_ACTION + "\n" + FLOOR_ACTION:
			return _fail("A closed lift must be reopenable with the closing hint restored afterwards")
		_press(player, KEY_ENTER if index % 2 == 0 else KEY_KP_ENTER)
		if controller.get("_selected").is_empty() or not player.get("_interaction_locked") or hint.visible:
			return _fail("Enter must open the compact floor picker and suspend world input")
		await _capture(viewport, "lift_floor_picker_" + str(index + 1))
		if not _check_picker(controller, viewport):
			return
		for floor_index in range(1, 5):
			var button: Button = floor_buttons[floor_index]
			if not button.disabled or button.icon == null:
				return _fail("Floors 2 through 5 must be disabled with a visible lock")
			await _hover(viewport, button.get_global_rect().get_center())
			if not locked_hint.visible or (locked_hint.get_child(0) as Label).text != LOCKED_NOTICE:
				return _fail("Hovering any locked floor must show the exact construction message")
			if index == 0:
				await _capture(viewport, "lift_locked_floor_" + str(floor_index + 1))
			await _click(viewport, button.get_global_rect().get_center())
			if controller.get("_selected").is_empty() or lift.dismissed:
				return _fail("Clicking a locked floor must not close the picker or select the floor")
			if not _check_picker(controller, viewport):
				return
		await _hover(viewport, floor_buttons[0].get_global_rect().get_center())
		if locked_hint.visible or floor_buttons[0].disabled or floor_buttons[0].icon != null:
			return _fail("Floor 1 must be available without a lock or unavailable-floor tooltip")
		await _click(viewport, floor_buttons[0].get_global_rect().get_center())
		player.call("_update_interaction_hint")
		if not controller.get("_selected").is_empty() or player.get("_interaction_locked") or hint.visible or not lift.dismissed:
			return _fail("Choosing floor 1 must close the picker and suppress the lift hint until leaving")
		if player.global_position != player_origin or sprite.texture != OPEN_TEXTURE:
			return _fail("Floor 1 must leave the player and the open lift unchanged")
		_press(player, KEY_ENTER)
		_press(player, KEY_E)
		if not controller.get("_selected").is_empty() or controller.get("_busy") or sprite.texture != OPEN_TEXTURE:
			return _fail("Lift actions must stay dismissed until the character leaves and returns")
		_leave_and_return(player, controller, sprite)
		if lift.dismissed or hint.get_parsed_text() != TITLE + "\n" + CLOSE_ACTION + "\n" + FLOOR_ACTION:
			return _fail("Returning to each lift must restore its floor-selection hint")
	for size in [Vector2i(640, 360), Vector2i(360, 240)]:
		viewport.size = size
		camera.zoom = Vector2(3, 3)
		camera.force_update_scroll()
		player.call("_update_interaction_hint")
		await _capture(viewport, "lift_hint_" + str(size.x))
		if not _check_hud(hint, viewport):
			return
		_press(player, KEY_E)
		var small_transition := controller.get("_transition") as Tween
		small_transition.pause()
		small_transition.custom_step(0.13)
		await _capture(viewport, "lift_closing_blackout_" + str(size.x), true)
		small_transition.custom_step(1.0)
		await _capture(viewport, "lift_closed_hint_" + str(size.x))
		if not _check_hud(hint, viewport):
			return
		_press(player, KEY_E)
		small_transition = controller.get("_transition") as Tween
		small_transition.pause()
		small_transition.custom_step(1.0)
		_press(player, KEY_ENTER)
		await _hover(viewport, floor_buttons[2].get_global_rect().get_center())
		await _capture(viewport, "lift_picker_" + str(size.x))
		if not _check_picker(controller, viewport):
			return
		var escape := InputEventKey.new()
		escape.keycode = KEY_ESCAPE
		escape.pressed = true
		viewport.push_input(escape, true)
		if not controller.get("_selected").is_empty() or player.get("_interaction_locked"):
			return _fail("Escape must dismiss the modal without losing the approach instruction")
	viewport.size = Vector2i(1152, 648)
	camera.zoom = Vector2(2, 2)
	_dispatch_key(viewport, KEY_ENTER)
	_dispatch_key(viewport, KEY_ENTER, false)
	await process_frame
	if controller.get("_selected").is_empty():
		return _fail("An actual Enter press must open the menu without immediately selecting floor 1")
	_dispatch_key(viewport, KEY_ENTER)
	_dispatch_key(viewport, KEY_ENTER, false)
	await process_frame
	if not controller.get("_selected").is_empty() or player.get("_interaction_locked") or hint.visible:
		return _fail("A second Enter must select the focused first floor and restore world input")
	_leave_and_return(player, controller, lifts.back().sprite)
	_dispatch_key(viewport, KEY_ENTER)
	_dispatch_key(viewport, KEY_ENTER, false)
	await process_frame
	if controller.get("_selected").is_empty():
		return _fail("A hidden picker must not retain keyboard focus and swallow Enter on the next approach")
	controller.call("_close_picker")
	_press(player, KEY_ENTER)
	await _capture(viewport, "lift_picker_close_button")
	await _click(viewport, (controller.get("_close_button") as Button).get_global_rect().get_center())
	if not controller.get("_selected").is_empty() or player.get("_interaction_locked"):
		return _fail("The close icon must close the picker and unlock movement")
	_press(player, KEY_ENTER)
	await _click(viewport, Vector2(5, 5))
	if not controller.get("_selected").is_empty():
		return _fail("Clicking outside the picker must dismiss it")
	first.texture = original_lifts[first.name].texture
	lifts[0].is_open = false
	player.global_position = _approach(first, 750)
	_dispatch_key(viewport, KEY_E)
	_dispatch_key(viewport, KEY_E, false)
	var real_transition := controller.get("_transition") as Tween
	if real_transition == null:
		return _fail("Real viewport E input must open the selected lift")
	await real_transition.finished
	if controller.get("_busy") or player.get("_interaction_locked") or first.texture != OPEN_TEXTURE:
		return _fail("The real-time lift blackout must finish and restore input")
	for expected_open in [false, true]:
		_dispatch_key(viewport, KEY_E)
		_dispatch_key(viewport, KEY_E, false)
		real_transition = controller.get("_transition") as Tween
		if real_transition == null:
			return _fail("Real viewport E input must both close and reopen the lift")
		await real_transition.finished
		var expected_texture: Texture2D = OPEN_TEXTURE if expected_open else original_lifts[first.name].texture
		if lifts[0].is_open != expected_open or first.texture != expected_texture or player.get("_interaction_locked"):
			return _fail("Real-time opening and closing must restore the expected state and input")
	var jack := load("res://assets/objects/pallet_jack/pallet_jack_right.tscn").instantiate() as PickupVehicle
	jack.position = player.position + Vector2(45, 0)
	world.get_node("YSortActors").add_child(jack)
	player.register_pickup_vehicle(jack)
	_press(player, KEY_ENTER)
	if jack.is_carried or controller.get("_selected").is_empty():
		return _fail("A lift action must not also pick up a nearby jack")
	controller.call("_close_picker")
	player.call("_interact_with_vehicle")
	_press(player, KEY_E)
	var vehicle_transition := controller.get("_transition") as Tween
	vehicle_transition.pause()
	vehicle_transition.custom_step(1.0)
	if not jack.is_carried or lifts[0].is_open:
		return _fail("Closing a lift must not drop a carried vehicle")
	_press(player, KEY_E)
	vehicle_transition = controller.get("_transition") as Tween
	vehicle_transition.pause()
	vehicle_transition.custom_step(1.0)
	_press(player, KEY_ENTER)
	if not jack.is_carried or controller.get("_selected").is_empty():
		return _fail("A lift action must not drop a carried vehicle")
	world.remove_child(controller)
	if player.get("_lift_interaction") != null or player.get("_interaction_locked"):
		return _fail("Removing a modal controller must unregister it and unlock input")
	controller.free()
	var cleanup := load("res://freight_lift_interaction.gd").new() as Node
	world.add_child(cleanup)
	first.texture = original_lifts[first.name].texture
	(cleanup.get("_lifts") as Array)[0].is_open = false
	_press(player, KEY_E)
	var cancelled := cleanup.get("_transition") as Tween
	cancelled.pause()
	cancelled.custom_step(0.06)
	world.remove_child(cleanup)
	if player.get("_lift_interaction") != null or player.get("_interaction_locked") or first.texture != original_lifts[first.name].texture:
		return _fail("Removing the controller mid-blackout must restore input without an early texture swap")
	cleanup.free()
	for path in original_tiles:
		if _snapshot(world.get_node(path)) != original_tiles[path]:
			return _fail("Freight lift interaction modified a warehouse tile layer: " + str(path))
	for sprite in sprites.get_children():
		var original: Dictionary = original_lifts[sprite.name]
		var shape := sprite.get_node("StaticBody2D/CollisionPolygon2D") as CollisionPolygon2D
		if sprite.scale != original.scale or sprite.global_transform != original.transform or shape != original.shape or shape.polygon != original.polygon:
			return _fail("Lift scale, position, collision node or polygon changed: " + str(sprite.name))
		if sprite.scale != Vector2(0.3, 0.27):
			return _fail("Every lift must retain the user's 0.3 by 0.27 scale")
		if str(sprite.name).trim_prefix("FreightLiftGroundFloor").to_int() > 6 and sprite.texture != original.texture:
			return _fail("An unrelated lift's artwork was changed")
	print("All six block 2 lifts: reversible E opening/closing, blackout, Enter picker, locked-floor hovers, floor 1 dismissal, exact scale/collisions and unchanged map passed")
	quit()

func _approach(sprite: Sprite2D, x: float) -> Vector2:
	var shape := sprite.get_node("StaticBody2D/CollisionPolygon2D") as CollisionPolygon2D
	var polygons: Array[PackedVector2Array] = [shape.polygon]
	var front := FootprintSortGeometry.front_y(polygons, x, 704)
	return shape.to_global(Vector2(x, front)) + Vector2(0, 28) - FEET_OFFSET

func _leave_and_return(player: CharacterBody2D, controller: Node, sprite: Sprite2D) -> void:
	player.global_position = _approach(sprite, 750) + Vector2(0, 150)
	controller.call("_process", 0.0)
	player.call("_update_interaction_hint")
	player.global_position = _approach(sprite, 750)
	player.call("_update_interaction_hint")

func _snapshot(layer: TileMapLayer) -> Dictionary:
	var result := {}
	for cell in layer.get_used_cells():
		result[cell] = [layer.get_cell_source_id(cell), layer.get_cell_atlas_coords(cell), layer.get_cell_alternative_tile(cell)]
	return result

func _check_hud(hint: RichTextLabel, viewport: SubViewport) -> bool:
	var transform := hint.get_global_transform_with_canvas()
	if transform.origin != Vector2(16, 16) or transform.get_scale() != Vector2.ONE or hint.size.x > 300 or hint.size.y > 180:
		_fail("The lift hint must remain compact and fixed in the upper-left corner")
		return false
	if not Rect2(Vector2.ZERO, viewport.size).encloses(Rect2(transform.origin, hint.size)):
		_fail("The lift instructions must fit the viewport")
		return false
	return true

func _check_picker(controller: Node, viewport: SubViewport) -> bool:
	var menu := controller.get("_menu") as PanelContainer
	var locked_hint := controller.get("_locked_hint") as PanelContainer
	var viewport_rect := Rect2(Vector2.ZERO, viewport.size)
	if menu.size.x > 300 or menu.size.y > 120 or not viewport_rect.encloses(menu.get_global_rect()):
		_fail("The floor selector must stay small and fit inside the screen")
		return false
	for button in controller.get("_floor_buttons"):
		if not menu.get_global_rect().encloses(button.get_global_rect()):
			_fail("Floor buttons must remain inside their popup")
			return false
	if locked_hint.visible and (not viewport_rect.encloses(locked_hint.get_global_rect()) or menu.get_global_rect().intersects(locked_hint.get_global_rect())):
		_fail("The locked-floor explanation must not overlap the menu or leave the screen: " + str(locked_hint.get_global_rect()))
		return false
	return true

func _press(player: CharacterBody2D, keycode: Key, echo := false, pressed := true) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	event.pressed = pressed
	event.echo = echo
	player._unhandled_input(event)

func _dispatch_key(viewport: SubViewport, keycode: Key, pressed := true) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	event.keycode = keycode
	event.pressed = pressed
	viewport.push_input(event, true)

func _hover(viewport: SubViewport, position: Vector2) -> void:
	var event := InputEventMouseMotion.new()
	event.position = position
	event.global_position = position
	viewport.push_input(event, true)
	await process_frame
	await process_frame

func _click(viewport: SubViewport, position: Vector2) -> void:
	await _hover(viewport, position)
	for pressed in [true, false]:
		var event := InputEventMouseButton.new()
		event.button_index = MOUSE_BUTTON_LEFT
		event.position = position
		event.global_position = position
		event.pressed = pressed
		viewport.push_input(event, true)
		await process_frame

func _capture(viewport: SubViewport, name: String, blackout := false) -> void:
	if DisplayServer.get_name() == "headless":
		# Container layout still needs to settle before the next simulated click.
		await process_frame
		await process_frame
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var image := viewport.get_texture().get_image()
	if blackout:
		for point in [Vector2i.ZERO, viewport.size / 2, viewport.size - Vector2i.ONE]:
			var pixel := image.get_pixelv(point)
			if maxf(pixel.r, maxf(pixel.g, pixel.b)) > 0.01:
				return _fail("Lift blackout did not cover the whole viewport")
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	if image.save_png(OUTPUT + name + ".png") != OK:
		_fail("Could not save freight lift preview")

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
