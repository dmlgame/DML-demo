extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"
const TITLE := "Лестница"
const ACTION := "Нажмите E или Enter, чтобы подняться на второй этаж третьего блока"
const NOTICE := "Данное действие временно недоступно, ведутся строительные работы!"
const FEET_OFFSET := Vector2(0, 25)

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1152, 648)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.position = Vector2(720, -480)
	viewport.add_child(world)
	player.set_physics_process(false)
	var controller := world.get_node("StaircaseInteraction")
	var camera := player.get_node("Camera2D") as Camera2D
	var hint := player.get("_interaction_hint") as RichTextLabel
	var lower_edge := controller.get("lower_edge") as CollisionPolygon2D
	var start := lower_edge.to_global(lower_edge.polygon[0])
	var end := lower_edge.to_global(lower_edge.polygon[1])
	var middle := (start + end) / 2
	var approach := middle + Vector2(0, 26)
	var original_tiles := {}
	for layer in world.find_children("*", "TileMapLayer", true, false):
		original_tiles[world.get_path_to(layer)] = _snapshot(layer)
	var original_polygons := {}
	for polygon in lower_edge.get_parent().get_children():
		original_polygons[polygon.name] = polygon.polygon.duplicate()
	camera.offset = Vector2(3, -2)
	var camera_origin := camera.offset
	for feet in [middle + Vector2(0, 150), middle + Vector2(0, -44), end + Vector2(80, 14)]:
		player.global_position = feet - FEET_OFFSET
		player.call("_update_interaction_hint")
		_press(player, KEY_E)
		if hint.visible or controller.get("_busy"):
			return _fail("The staircase must not react from far away or from underneath")
	for feet in [start + Vector2(-24, 10), approach, end + Vector2(40, 12)]:
		player.global_position = feet - FEET_OFFSET
		player.call("_update_interaction_hint")
		if not hint.visible or hint.get_parsed_text() != TITLE + "\n" + ACTION:
			return _fail("The lower stair entrance and right approach must show the exact instruction")
		if not hint.text.begins_with("[color=#ff6868]" + TITLE + "[/color]"):
			return _fail("The staircase title must match the red vehicle titles")
	player.global_position = approach - FEET_OFFSET
	camera.force_update_scroll()
	await physics_frame
	await physics_frame
	if player.call("_collision_profile_overlaps", player.get("collision_on_foot")):
		return _fail("The staircase hint must be reachable in front of the lower step")
	await _capture(viewport, "staircase_approach_hint")
	if not _check_hud(hint, viewport):
		return
	_press(player, KEY_E, true)
	_press(player, KEY_E, false, false)
	if controller.get("_busy"):
		return _fail("Autorepeat and key release must not shake the screen")
	var player_origin := player.global_position
	_press(player, KEY_E)
	var shake := controller.get("_shake") as Tween
	if shake == null or not controller.get("_busy") or not player.get("_interaction_locked") or hint.visible:
		return _fail("E must start a short shake and hide the approach hint until it finishes")
	shake.pause()
	_press(player, KEY_ENTER)
	if controller.get("_shake") != shake or controller.get("_notice_active"):
		return _fail("Repeated input must not start another effect or show the notice early")
	shake.custom_step(0.035)
	camera.force_update_scroll()
	if camera.offset == camera_origin or camera.offset.distance_to(camera_origin) > 2.0:
		return _fail("The camera must move only slightly during the shake")
	player.velocity = Vector2(100, 0)
	player.call("_physics_process", 0.1)
	if player.global_position != player_origin or player.velocity != Vector2.ZERO:
		return _fail("The screen shake must not move the character")
	await _capture(viewport, "staircase_shake")
	shake.custom_step(0.5)
	if controller.get("_busy") or player.get("_interaction_locked") or camera.offset != camera_origin:
		return _fail("Finishing the effect must restore input and the exact original camera offset")
	if not hint.visible or hint.get_parsed_text() != TITLE + "\n" + NOTICE:
		return _fail("The construction notice must appear after the shake")
	await _capture(viewport, "staircase_unavailable_hint")
	if not _check_hud(hint, viewport):
		return
	player.global_position += Vector2(5, 0)
	camera.zoom = Vector2(3, 3)
	camera.force_update_scroll()
	await _capture(viewport, "staircase_unavailable_zoomed")
	if hint.get_parsed_text() != TITLE + "\n" + NOTICE or not _check_hud(hint, viewport):
		return _fail("The notice must persist nearby and remain a fixed-size screen overlay")
	camera.zoom = Vector2(2, 2)
	for keycode in [KEY_ENTER, KEY_KP_ENTER]:
		player.global_position = middle + Vector2(0, 150) - FEET_OFFSET
		controller.call("_process", 0.0)
		player.call("_update_interaction_hint")
		if hint.visible or controller.get("_notice_active"):
			return _fail("Walking away must clear the construction notice")
		player.global_position = approach - FEET_OFFSET
		player.call("_update_interaction_hint")
		if hint.get_parsed_text() != TITLE + "\n" + ACTION:
			return _fail("Returning to the staircase must restore the action instruction")
		_press(player, keycode)
		shake = controller.get("_shake") as Tween
		if shake == null:
			return _fail("Enter and keypad Enter must activate the staircase")
		await shake.finished
		if not controller.get("_notice_active") or hint.get_parsed_text() != TITLE + "\n" + NOTICE or camera.offset != camera_origin:
			return _fail("The real-time effect must complete with the construction notice")
	viewport.size = Vector2i(360, 240)
	camera.force_update_scroll()
	player.call("_update_interaction_hint")
	await _capture(viewport, "staircase_unavailable_small")
	if not _check_hud(hint, viewport):
		return
	controller.set("_notice_active", false)
	player.call("_update_interaction_hint")
	await _capture(viewport, "staircase_approach_small")
	if not _check_hud(hint, viewport):
		return
	var jack := load("res://assets/objects/pallet_jack/pallet_jack_right.tscn").instantiate() as PickupVehicle
	jack.position = player.position + Vector2(50, 0)
	world.get_node("YSortActors").add_child(jack)
	player.register_pickup_vehicle(jack)
	_press(player, KEY_E)
	shake = controller.get("_shake") as Tween
	if shake == null or jack.is_carried:
		return _fail("A staircase action must not also pick up a nearby vehicle")
	shake.pause()
	shake.custom_step(1.0)
	player.call("_interact_with_vehicle")
	if not jack.is_carried:
		return _fail("The test vehicle must be carried before checking input priority")
	_press(player, KEY_ENTER)
	shake = controller.get("_shake") as Tween
	if shake == null or not jack.is_carried:
		return _fail("A staircase action must not drop a carried vehicle")
	shake.pause()
	shake.custom_step(0.035)
	player.global_position = middle + Vector2(0, 150) - FEET_OFFSET
	controller.call("_process", 0.0)
	if controller.get("_busy") or player.get("_interaction_locked") or camera.offset != camera_origin:
		return _fail("Leaving the entrance during feedback must safely cancel the effect")
	player.global_position = approach - FEET_OFFSET
	_press(player, KEY_E)
	shake = controller.get("_shake") as Tween
	shake.pause()
	shake.custom_step(0.035)
	world.remove_child(controller)
	if player.get("_stair_interaction") != null or player.get("_interaction_locked") or camera.offset != camera_origin:
		return _fail("Removing the interaction must unregister it, unlock input and restore the camera")
	controller.free()
	for path in original_tiles:
		if _snapshot(world.get_node(path)) != original_tiles[path]:
			return _fail("Staircase feedback modified warehouse tiles: " + str(path))
	for polygon in lower_edge.get_parent().get_children():
		if polygon.polygon != original_polygons[polygon.name]:
			return _fail("Staircase feedback modified its collision polygons")
	print("Staircase approach, E/Enter, short shake, construction notice, compact HUD, input priority and unchanged map passed")
	quit()

func _snapshot(layer: TileMapLayer) -> Dictionary:
	var result := {}
	for cell in layer.get_used_cells():
		result[cell] = [layer.get_cell_source_id(cell), layer.get_cell_atlas_coords(cell), layer.get_cell_alternative_tile(cell)]
	return result

func _check_hud(hint: RichTextLabel, viewport: SubViewport) -> bool:
	var transform := hint.get_global_transform_with_canvas()
	if transform.origin != Vector2(16, 16) or transform.get_scale() != Vector2.ONE:
		_fail("The staircase hint must remain in the upper-left corner without camera scaling")
		return false
	if hint.size.x > 300 or hint.size.y > 120 or not Rect2(Vector2.ZERO, viewport.size).encloses(Rect2(transform.origin, hint.size)):
		_fail("The staircase hint must remain compact and fit inside the screen")
		return false
	if hint.horizontal_alignment != HORIZONTAL_ALIGNMENT_LEFT or hint.get_theme_font_size("normal_font_size") != 16:
		_fail("The staircase hint must retain the existing clear native-size text")
		return false
	return true

func _press(player: CharacterBody2D, keycode: Key, echo := false, pressed := true) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	event.pressed = pressed
	event.echo = echo
	player._unhandled_input(event)

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	if viewport.get_texture().get_image().save_png(OUTPUT + name + ".png") != OK:
		_fail("Could not save staircase interaction preview")

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
