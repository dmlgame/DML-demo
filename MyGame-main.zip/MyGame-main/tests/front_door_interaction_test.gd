extends SceneTree

const OUTPUT := "res://tmp/decor_rc_qa/"
const CELL := Vector2i(6, 3)
const TITLE := "Вход в операционную зону"
const COLORED_TITLE := "[color=#ff6868]" + TITLE + "[/color]\n"

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(1100, 619)
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var player := world.get_node("YSortActors/Player") as CharacterBody2D
	player.set_physics_process(false)
	var camera := player.get_node("Camera2D") as Camera2D
	var controller := world.get_node("FrontDoorInteraction")
	var door := world.get_node("YSortActors/FrontWallSort/FrontDoorLayer") as TileMapLayer
	var original_cells := door.get_used_cells()
	var source := door.get_cell_source_id(CELL)
	var alternative := door.get_cell_alternative_tile(CELL)
	var threshold := door.to_global(door.map_to_local(CELL) + Vector2(0, 12))
	var hint := player.get("_interaction_hint") as RichTextLabel
	if original_cells != [CELL] or door.get_cell_atlas_coords(CELL) != Vector2i(0, 0):
		return _fail("The entrance must use the user's closed door tile")
	player.position = threshold + Vector2(0, 180) - Vector2(0, 25)
	player.call("_update_interaction_hint")
	_press(player, KEY_E)
	if hint.visible or controller.get("is_open"):
		return _fail("The door must not react from far away")
	player.position = threshold + Vector2(0, 40) - Vector2(0, 25)
	camera.force_update_scroll()
	await physics_frame
	await physics_frame
	player.call("_update_interaction_hint")
	if not hint.visible or hint.get_parsed_text() != TITLE + "\nНажмите E или Enter, чтобы открыть дверь":
		return _fail("Approaching the closed entrance must show the opening instruction")
	if not hint.text.begins_with(COLORED_TITLE) or hint.text.count("[color=") != 1:
		return _fail("Only the entrance title must be red; the action stays below in its normal color")
	if not player.test_move(player.global_transform, Vector2(0, -60)):
		return _fail("The closed entrance must block walking through it")
	await _capture(viewport, "front_door_closed")
	_press(player, KEY_E, true)
	_press(player, KEY_E, false, false)
	if controller.get("is_open"):
		return _fail("Autorepeat or key release must not open the door")
	_press(player, KEY_E)
	await physics_frame
	await physics_frame
	if not controller.get("is_open") or door.get_cell_atlas_coords(CELL) != Vector2i(2, 0):
		return _fail("E must swap the entrance to the open door sprite")
	if player.test_move(player.global_transform, Vector2(0, -60)):
		return _fail("Opening the door must also clear its collision")
	if hint.get_parsed_text() != TITLE + "\nНажмите E или Enter, чтобы закрыть дверь" or not hint.text.begins_with(COLORED_TITLE):
		return _fail("Opening must replace the hint with the closing instruction")
	await _capture(viewport, "front_door_open")
	var original_hint_size := hint.size
	camera.zoom = Vector2(3, 3)
	player.position.x += 12
	camera.force_update_scroll()
	await _capture(viewport, "front_door_zoomed")
	if hint.get_global_transform_with_canvas().origin != Vector2(16, 16) or hint.get_global_transform_with_canvas().get_scale() != Vector2.ONE or hint.size != original_hint_size:
		return _fail("Camera movement and zoom must not move or enlarge the HUD text")
	camera.zoom = Vector2(2, 2)
	player.position = threshold + Vector2(0, -40) - Vector2(0, 25)
	camera.force_update_scroll()
	await physics_frame
	await physics_frame
	player.call("_update_interaction_hint")
	if hint.get_parsed_text() != TITLE + "\nНажмите E или Enter, чтобы закрыть дверь" or not hint.text.begins_with(COLORED_TITLE):
		return _fail("Door interaction must be available from the warehouse side")
	_press(player, KEY_ENTER)
	await physics_frame
	await physics_frame
	if controller.get("is_open") or door.get_cell_atlas_coords(CELL) != Vector2i(0, 0) or not player.test_move(player.global_transform, Vector2(0, 60)):
		return _fail("Enter must close the door and restore its collision from inside")
	_press(player, KEY_KP_ENTER)
	await physics_frame
	await physics_frame
	if not controller.get("is_open"):
		return _fail("Keypad Enter must open the door from inside")
	player.position = threshold - Vector2(0, 25)
	await physics_frame
	await physics_frame
	player.call("_update_interaction_hint")
	if not hint.get_parsed_text().ends_with("Отойдите от дверного проёма") or not hint.text.begins_with(COLORED_TITLE):
		return _fail("The player must be warned before closing the door on their feet")
	_press(player, KEY_ENTER)
	if not controller.get("is_open"):
		return _fail("Closing the door must not trap the player inside its collision")
	player.position = threshold + Vector2(0, 40) - Vector2(0, 25)
	await physics_frame
	await physics_frame
	_press(player, KEY_ENTER)
	if controller.get("is_open") or door.get_cell_source_id(CELL) != source or door.get_cell_alternative_tile(CELL) != alternative or door.get_used_cells() != original_cells:
		return _fail("Door toggle must preserve its source, alternative and map placement")
	viewport.size = Vector2i(360, 240)
	camera.force_update_scroll()
	player.call("_update_interaction_hint")
	await _capture(viewport, "front_door_small")
	var rect := Rect2(hint.get_global_transform_with_canvas().origin, hint.size)
	if not Rect2(Vector2.ZERO, viewport.size).encloses(rect) or hint.size.x > 300 or hint.size.y > 96:
		return _fail("The compact hint must fit a small viewport")
	player.position = threshold + Vector2(0, 180) - Vector2(0, 25)
	player.call("_update_interaction_hint")
	if hint.visible:
		return _fail("The door instruction must disappear after walking away")
	print("Front door red entrance title, E/Enter, both approaches, reversible sprites/collisions, safe closing and fixed compact HUD passed")
	quit()

func _press(player: CharacterBody2D, keycode: Key, echo := false, pressed := true) -> void:
	var event := InputEventKey.new()
	event.physical_keycode = keycode
	event.pressed = pressed
	event.echo = echo
	player._unhandled_input(event)

func _capture(viewport: SubViewport, name: String) -> void:
	if DisplayServer.get_name() == "headless":
		return
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	if viewport.get_texture().get_image().save_png(OUTPUT + name + ".png") != OK:
		_fail("Could not save entrance preview")

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
