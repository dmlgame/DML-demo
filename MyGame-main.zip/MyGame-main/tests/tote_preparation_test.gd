extends SceneTree

const Tasks = preload("res://demo_tasks.gd")
const Supplies = preload("res://demo_receiving_supplies.gd")
const FOOT := Vector2(0, 25)
var failed := false
var session: Node
var demo: Node
var player: CharacterBody2D

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	session = load("res://game_session.tscn").instantiate()
	session.save_store.directory = "user://tmp/tote_preparation_%d" % Time.get_ticks_usec()
	root.add_child(session)
	await session._start_world("")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	demo._director.set_physics_process(false)
	var jack: PickupVehicle = demo.nearest_free_pallet_jack()
	var completed_pallet: Dictionary = session.save_store.capture(session.world)
	var path: String = str(session.world.get_path_to(jack))
	completed_pallet.demo.merge({"stage": "empty_pallet_complete", "completed": true, "zph_assignment": true,
		"gate17_checked": true, "placed_count": 12, "gate19_open": true, "assigned_vehicle": path,
		"pallet_source": [12, -65], "pallet_delivered": true}, true)
	_check(session.save_store.apply_state(session.world, completed_pallet), "A previous release's delivered pallet loads")
	_check(demo._hint_button.visible and demo._current_target_point() == demo._receiving_lead.global_position, "Delivered pallet offers the next briefing")
	player.global_position = demo._receiving_lead.global_position - FOOT
	_check(demo.try_interact(player) and demo._conversation_kind == "receiving_preparation", "The section lead starts the preparation briefing")
	_check(demo._dialog_text.text.contains("столах приемки") and demo._dialog_text.text.contains("пустыми сетками") and demo._dialog_text.text.contains("синими тарниками"), "Lead explains receiving tables and supplies")
	demo.close_modal()
	_check(demo.stage == "empty_pallet_complete", "Canceling the briefing does not take the delivered pallet")
	demo.try_interact(player)
	for index in 3:
		demo._advance_dialogue()
	_check(demo.stage == "retrieve_empty_pallet" and demo._pallet_stock.delivered, "Finishing the briefing requires retrieving the same pallet")
	for page in Tasks.PREPARATION_DIALOGUE:
		_check(not page.contains("одна стопка") and not page.contains("две стопки") and not page.contains("последн"), "Single-stock rule is not exposed in dialogue")
	_check(not demo.can_use_vehicle(demo.nearest_free_transporter()) and demo.can_use_vehicle(jack), "Only the already assigned jack remains available")
	player.global_position = jack.interaction_area.global_position + Vector2(0, 35) - FOOT
	player.register_pickup_vehicle(jack)
	_check(player._interact_with_vehicle() and player._carried_vehicle == jack, "Retake the assigned empty jack")
	player.global_position = demo._supplies.source_point(Vector2i(-134, -99)) - FOOT
	_check(not demo.try_interact(player) and demo.stage == "retrieve_empty_pallet" and not player.pallet_jack_loaded, "Totes cannot be loaded before retrieving the delivered pallet")
	player.global_position = demo._pallet_stock.delivery_point() + Vector2(0, 40) - FOOT
	player.last_direction = Vector2.UP
	player._apply_collision_profile(Vector2.UP)
	await _settle()
	_check(demo.try_interact(player), "Retrieve the delivered pallet")
	var fade: Tween = demo._gate19._transition
	fade.pause()
	_check(demo._pallet_stock._delivery != null and not player.pallet_jack_pallet_loaded and not session.save_store.save_world(session.world, "slot_1"), "Floor pallet stays visible before blackout and cannot be saved mid-transfer")
	fade.custom_step(0.13)
	_check(player.pallet_jack_pallet_loaded and demo.stage == "find_blue_tote_stock" and not demo._pallet_stock.delivered and demo._pallet_stock._delivery == null, "Pallet moves from the floor onto the jack while fully black")
	fade.custom_step(1.0)
	await _settle()
	_check(demo._pallet_stock._stock.get_cell_atlas_coords(Vector2i(12, -65)) == Vector2i(4, 3), "Retrieving the delivered pallet does not remove another stock pallet")
	var retrieved: Dictionary = session.save_store.capture(session.world)
	_check(session.save_store._valid(retrieved), "Retrieved pallet saves with its original source")
	player.global_position = demo._supplies.source_point(Vector2i(1, -69)) - FOOT
	var single_atlas: Vector2i = demo._supplies._stock.get_cell_atlas_coords(Vector2i(1, -69))
	_check(demo._supplies.nearby_source(player) == null and demo.get_interaction_text(player) == "Запас тарников", "Last remaining stack has no pickup prompt or count explanation")
	_check(demo.try_interact(player) and not player.pallet_jack_loaded and player.pallet_jack_pallet_loaded and demo._supplies._stock.get_cell_atlas_coords(Vector2i(1, -69)) == single_atlas, "Last stack cannot be taken or remove the player's empty pallet")
	for cell in [Vector2i(-134, -99), Vector2i(3, -76)]:
		_check(session.save_store.apply_state(session.world, retrieved), "Reset a valid retrieved-pallet fixture")
		_check(_stock_approach(cell), "Clear pickup approach exists in either marked tote zone " + str(cell))
		print("Tote pickup fixture: ", cell, " position ", player.global_position, " direction ", player.last_direction, " jack ", path)
		var original: Vector2i = demo._supplies._stock.get_cell_atlas_coords(cell)
		_check(demo.try_interact(player), "Take a tote stack onto the retrieved pallet")
		fade = demo._gate19._transition
		fade.pause()
		_check(player.pallet_jack_pallet_loaded and not player.pallet_jack_loaded and demo._supplies._stock.get_cell_atlas_coords(cell) == original and not demo.try_interact(player), "Before blackout cargo stays empty and repeated pickup is blocked")
		fade.custom_step(0.13)
		_check(player.pallet_jack_loaded and not player.pallet_jack_pallet_loaded and demo.stage == "deliver_blue_totes" and demo._supplies.picked_source == cell, "Loading switches to the blue-tote animation while black")
		var index := Supplies.STOCK_ATLASES.find(original)
		_check(demo._supplies._stock.get_cell_atlas_coords(cell) == Supplies.STOCK_ATLASES[index - 1], "Exactly one tote stack is removed")
		fade.custom_step(1.0)
		await _settle()
		_check(not demo.can_use_vehicle(jack), "Loaded totes cannot be abandoned")
		_check(session.save_store.save_world(session.world, "slot_1"), "Loaded totes and the original pallet save together")
		var loaded: Dictionary = session.save_store.read_slot("slot_1")
		_check(session.save_store.apply_state(session.world, loaded) and player.pallet_jack_loaded and demo._pallet_stock._delivery == null, "Loaded cargo restores without recreating the old floor pallet")
		for override in [{"pallet_delivered": true}, {"pallet_source": []}, {"tote_source": []}, {"totes_delivered": true}, {"gate17_checked": false}]:
			var invalid: Dictionary = loaded.duplicate(true)
			invalid.demo.merge(override, true)
			_check(not session.save_store._valid(invalid), "Invalid cross-assignment progress is rejected")
		var unmounted: Dictionary = loaded.duplicate(true)
		unmounted.player.vehicle = ""
		_check(not session.save_store._valid(unmounted), "Totes stay tied to the assigned mounted jack")
		await _check_layout()
		_check(_delivery_approach(), "A clear table-five delivery approach exists")
		print("Tote delivery fixture: ", player.global_position, " direction ", player.last_direction)
		await _settle()
		_check(demo.try_interact(player) and demo.stage == "return_empty_pallet" and demo._supplies.delivered and not player.pallet_jack_loaded and player.pallet_jack_pallet_loaded, "Only totes are placed at table five; the empty pallet stays on the jack")
		var sprite: Sprite2D = demo._supplies._delivery.get_child(0)
		var atlas := demo._supplies._stock.tile_set.get_source(0) as TileSetAtlasSource
		_check(sprite.texture.region == Rect2(atlas.get_tile_texture_region(Vector2i(1, 6))) and sprite.scale == Vector2.ONE, "Delivered stack uses the loose tote stack from PalletLayer, without a pallet")
		_check(demo._pallet_stock._delivery == null and demo._hint_button.visible and not demo.can_use_vehicle(jack), "Pallet return has guidance and cannot abandon its load")
		_check(session.save_store.save_world(session.world, "slot_2"), "Pending pallet return saves")
		var pending: Dictionary = session.save_store.read_slot("slot_2")
		_check(session.save_store.apply_state(session.world, pending) and player.pallet_jack_pallet_loaded, "Pending return restores an empty pallet, not blue cargo")
		player.global_position = demo._receiving_lead.global_position - FOOT
		_check(demo.try_interact(player) and demo._dialog_text.text.contains("верни пустой паллет"), "Reporting before the pallet return only reminds the player")
		demo._advance_dialogue()
		_check(demo.stage == "return_empty_pallet", "Early conversation cannot complete the assignment")
		var returned_cell := Vector2i(12, -65) if cell.x < 0 else Vector2i(125, -38)
		_check(_return_approach(returned_cell), "Return approach exists in either pallet stock zone " + str(returned_cell))
		print("Pallet return fixture: ", returned_cell, " position ", player.global_position, " direction ", player.last_direction)
		await _settle()
		var count_before: int = demo._pallet_stock._remaining_count(returned_cell)
		_check(demo.try_interact(player), "Return the same empty pallet to stock")
		fade = demo._gate19._transition
		fade.pause()
		_check(player.pallet_jack_pallet_loaded and not demo.try_interact(player), "Return before blackout preserves cargo and blocks duplicate input")
		fade.custom_step(0.13)
		_check(demo.stage == "report_preparation" and not player.pallet_jack_pallet_loaded and demo._pallet_stock.returned_source == returned_cell, "Return changes to an empty jack while fully black")
		var stock_atlas: Vector2i = demo._pallet_stock._stock.get_cell_atlas_coords(returned_cell)
		_check(demo._pallet_stock.PALLET_ATLASES.find(stock_atlas) == count_before, "Exactly one pallet is added to the chosen stock")
		fade.custom_step(1.0)
		await _settle()
		_check(session.save_store.save_world(session.world, "slot_2"), "Returned pallet and pending report save")
		var report: Dictionary = session.save_store.read_slot("slot_2")
		_check(session.save_store.apply_state(session.world, report) and not player.pallet_jack_loaded and not player.pallet_jack_pallet_loaded and demo._pallet_stock._stock.get_cell_atlas_coords(returned_cell) == stock_atlas, "Restoring a return does not add another pallet")
		for override in [{"pallet_return": []}, {"pallet_return": [0, 0]}, {"totes_delivered": false}]:
			var invalid: Dictionary = report.duplicate(true)
			invalid.demo.merge(override, true)
			_check(not session.save_store._valid(invalid), "Invalid return progress is rejected")
		var full_stock: Dictionary = report.duplicate(true)
		full_stock.demo.pallet_return = [131, -46]
		_check(not session.save_store.apply_state(session.world, full_stock), "Returning to another full six-pallet stack is rejected")
		player.global_position = demo._receiving_lead.global_position - FOOT
		_check(demo._current_target_point() == demo._receiving_lead.global_position and demo.try_interact(player), "Guidance leads back to the section lead and conversation works on the empty jack")
		_check(demo._dialog_text.text.contains("Спасибо") and not demo._dialog_text.text.contains("Следующим") and not demo._dialog_text.text.contains("Далее"), "Final thanks do not start or promise another assignment")
		demo.close_modal()
		_check(demo.stage == "report_preparation", "Closing without finishing preserves pending report")
		demo.try_interact(player)
		demo._advance_dialogue()
		_check(demo._dialog_counter.text == "2 / 2" and demo._dialog_text.text == "На этом пока что все, в ожидании новых поручений, можешь походить по операционной зоне и посмотреть, как здесь все устроено", "Second report page invites exploration using the requested wording")
		_check(demo.stage == "report_preparation" and player._interaction_locked, "First page cannot finish the report before the second message")
		demo.close_modal()
		_check(demo.stage == "report_preparation", "Canceling on the second page keeps the report pending")
		demo.try_interact(player)
		demo._advance_dialogue()
		demo._advance_dialogue()
		_check(demo.stage == "preparation_complete" and not demo._hint_button.visible and not player._interaction_locked and demo._modal_kind.is_empty(), "Finishing both report pages ends the chain and restores free movement")
		_check(session.save_store.save_world(session.world, "slot_3"), "Final preparation saves")
		var legacy: Dictionary = pending.duplicate(true)
		legacy.demo.stage = "blue_totes_complete"
		legacy.demo.erase("pallet_return")
		legacy.player.vehicle = ""
		_check(session.save_store.apply_state(session.world, legacy) and demo.stage == "return_empty_pallet" and player.pallet_jack_pallet_loaded and demo._supplies.delivered, "Previous completed-tote saves continue with pallet return without restarting the demo")
		if failed:
			break
	var pending_return: Dictionary = session.save_store.capture(session.world)
	for single in [Vector2i(17, -69), Vector2i(125, -38)]:
		var returning_single: Dictionary = pending_return.duplicate(true)
		returning_single.demo.pallet_source = [single.x, single.y]
		returning_single.demo.pallet_return = []
		_check(session.save_store.apply_state(session.world, returning_single), "A return fixture accepts an originally single pallet")
		_check(demo._pallet_stock._stock.get_cell_source_id(single) == -1 and _return_approach(single), "An erased single-pallet stock cell remains a valid return destination")
		await _settle()
		_check(demo.try_interact(player), "Return to the original single-pallet stock position")
		var transition: Tween = demo._gate19._transition
		transition.pause()
		transition.custom_step(1.0)
		await _settle()
		_check(demo._pallet_stock._stock.get_cell_atlas_coords(single) == Vector2i(2, 0) and not player.pallet_jack_pallet_loaded, "Returning a single pallet recreates exactly one pallet at its original position")
	await session._start_world("slot_3")
	demo = session.world.get_node("DemoTasks")
	player = session.world.get_node("YSortActors/Player")
	_check(demo.stage == "preparation_complete" and demo._supplies._delivery != null and demo._pallet_stock._delivery == null and demo._pallet_stock.picked_source == Vector2i(12, -65) and demo._pallet_stock.returned_source == Vector2i(125, -38), "Fresh-world continuation preserves loose totes, returned pallet and final thanks")
	session.free()
	if not failed:
		print("Tote preparation passed: briefing, exact pallet retrieval, both stock zones, last-stack exclusion, fades, animations, delivery and chained saves")
	quit(1 if failed else 0)

func _stock_approach(cell: Vector2i) -> bool:
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		for offset in [Vector2.ZERO, Vector2(0, 16), Vector2(24, 16), Vector2(-24, 16), Vector2(40, 0), Vector2(-40, 0), Vector2(0, 32)]:
			player.global_position = demo._supplies.source_point(cell) + offset - FOOT
			player.last_direction = direction
			var profile: Node2D = player._collision_for_mode(direction)
			if player._collision_profile_overlaps(profile) or not player.can_load_pallet_jack_totes() or demo._supplies.nearby_source(player) != cell:
				continue
			player._apply_collision_profile(direction)
			return true
	return false

func _delivery_approach() -> bool:
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		for offset in [Vector2.ZERO, Vector2(0, 20), Vector2(0, -20), Vector2(-30, 0), Vector2(30, 0), Vector2(-40, 24), Vector2(40, 24)]:
			player.global_position = demo._supplies.delivery_point() + offset - FOOT
			player.last_direction = direction
			player._apply_collision_profile(direction)
			if demo._supplies.can_place(player):
				return true
	return false

func _return_approach(cell: Vector2i) -> bool:
	var center: Vector2 = demo._pallet_stock._stock.to_global(demo._pallet_stock._stock.map_to_local(cell))
	for direction in [Vector2.UP, Vector2.LEFT, Vector2.RIGHT, Vector2.DOWN]:
		for offset in [Vector2(0, 104), Vector2(-80, 40), Vector2(80, 40), Vector2(0, -40)]:
			player.global_position = center + offset - FOOT
			player.last_direction = direction
			player._apply_collision_profile(direction)
			if not player._collision_profile_overlaps(player._active_collision) and demo._pallet_stock.nearby_return(player) == cell:
				return true
	return false

func _check_layout() -> void:
	session.touch_controls.available = true
	for size in [Vector2i(390, 844), Vector2i(320, 640), Vector2i(844, 390)]:
		root.size = size
		await _settle()
		_check(root.get_visible_rect().encloses(demo._task_panel.get_global_rect()) and demo._objective.visible, "Preparation task fits mobile HUD " + str(size))
		for button in [session.touch_controls._action_button, session.touch_controls._secondary_action_button]:
			_check(not demo._task_panel.get_global_rect().intersects(Rect2(button.position - button.shape.size / 2, button.shape.size)), "Preparation leaves action buttons clear")

func _settle() -> void:
	for frame in 4:
		await physics_frame
		await process_frame

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
