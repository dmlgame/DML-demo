extends SceneTree

const Store = preload("res://warehouse_save_store.gd")
const DIR := "res://tmp/decor_rc_qa/save_test"
var store := Store.new()
var failed := false

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	store.directory = DIR
	DirAccess.make_dir_recursive_absolute(ProjectSettings.globalize_path(DIR))
	for slot in Store.SLOTS:
		for suffix in [".json", ".json.bak", ".json.tmp"]:
			DirAccess.remove_absolute(ProjectSettings.globalize_path(DIR.path_join(slot + suffix)))
	var world: Node2D = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	world.get_node("YSortActors/Player").set_physics_process(false)
	await physics_frame
	await physics_frame
	var player := world.get_node("YSortActors/Player")
	var vehicles: Array[PickupVehicle] = store._vehicles(world)
	_check(vehicles.size() > 0, "No vehicles")
	world.get_node("FrontDoorInteraction").restore_save_state(true)
	world.get_node("DockGate17Interaction").restore_save_state(true)
	var lifts := world.get_node("FreightLiftInteraction")
	var lifted: Dictionary = lifts.get_save_state()
	for name in lifted:
		lifted[name] = true
	lifts.restore_save_state(lifted)
	for vehicle in vehicles:
		vehicle.global_position += Vector2(13, 9)
	player.global_position = Vector2(120, 200)
	player.last_direction = Vector2.LEFT
	_check(store.save_world(world, "slot_1"), "Initial save: " + store.last_error)
	var original: Dictionary = store.read_slot("slot_1")
	var snapshot := original.duplicate(true)
	world.free()
	await process_frame
	world = load("res://warehouse_main.tscn").instantiate()
	root.add_child(world)
	player = world.get_node("YSortActors/Player")
	player.set_physics_process(false)
	var restarted_store := Store.new()
	restarted_store.directory = DIR
	_check(restarted_store.apply_state(world, restarted_store.read_slot("slot_1")), "Reload in new session")
	await physics_frame
	await physics_frame
	_check(player.global_position == Vector2(120, 200) and player.last_direction == Vector2.LEFT, "Player position and direction")
	_check(world.get_node("FrontDoorInteraction").is_open and world.get_node("DockGate17Interaction").is_open, "Door and gate states")
	_check(world.get_node("FreightLiftInteraction").get_save_state() == lifted, "All six lift states")
	_check(world.get_node("YSortActors/FrontWallSort/FrontDoorLayer").get_cell_atlas_coords(Vector2i(6, 3)) == Vector2i(2, 0), "Door tile restored")
	_check(world.get_node("YSortActors/UnloadingDockLayer").get_cell_atlas_coords(Vector2i(-37, -106)) == Vector2i(0, 9), "Gate tile restored")
	_check(world.get_node("YSortActors/ObjectsLayer").get_cell_atlas_coords(Vector2i(-35, -106)) == Vector2i(0, 0), "Green gate button restored")
	for vehicle in store._vehicles(world):
		var path := str(world.get_path_to(vehicle))
		_check(vehicle.global_position == Vector2(original.vehicles[path][0], original.vehicles[path][1]), "Parked vehicle position")
	for mode in [1, 2]:
		var selected: PickupVehicle
		for vehicle in store._vehicles(world):
			if vehicle.vehicle_mode == mode:
				selected = vehicle
				break
		player._carried_vehicle = selected
		player._pickup_offset = Vector2(44, -12)
		selected.set_carried(true)
		player.set_move_mode(mode)
		_check(store.save_world(world, "slot_2"), "Save mounted mode " + str(mode))
		var state := store.read_slot("slot_2")
		_check(store.apply_state(world, original), "Reset mounted state")
		_check(store.apply_state(world, state), "Restore mounted state")
		await physics_frame
		_check(player.move_mode == mode and player._carried_vehicle == selected, "Carried vehicle identity")
		_check(not selected.visible and selected.solid_shape.disabled, "No duplicate parked vehicle")
		_check(player._pickup_offset == Vector2(44, -12), "Pickup offset retained")
		player._interact_with_vehicle()
		await physics_frame
		_check(not selected.is_carried and selected.visible and not selected.solid_shape.disabled, "Vehicle can be dropped after loading")
		_check(selected.global_position == player.global_position + Vector2(44, -12), "Drop location after loading")
	_check(store.write_state(snapshot, "slot_1"), "Second write creates backup")
	var corrupt := FileAccess.open(ProjectSettings.globalize_path(DIR.path_join("slot_1.json")), FileAccess.WRITE)
	corrupt.store_string("{broken")
	corrupt.close()
	_check(not store.read_slot("slot_1").is_empty() and store.recovered_backup, "Corruption backup recovery")
	var invalid := snapshot.duplicate(true)
	invalid.player.position = ["bad", 10]
	_check(not store.write_state(invalid, "slot_3"), "Reject malformed coordinates")
	invalid = snapshot.duplicate(true)
	invalid.player.vehicle = "../bad"
	_check(not store.apply_state(world, invalid), "Reject unsafe vehicle paths")
	invalid = snapshot.duplicate(true)
	var missing := "YSortActors/PalletJackAssets/RemovedVehicle"
	invalid.player.vehicle = missing
	invalid.vehicles[missing] = [10, 20]
	var unchanged: Dictionary = store.capture(world)
	_check(not store.apply_state(world, invalid), "Reject missing carried vehicle before changing world")
	var after_failure: Dictionary = store.capture(world)
	_check(unchanged.player == after_failure.player and unchanged.vehicles == after_failure.vehicles, "Failed load leaves running game intact")
	invalid = snapshot.duplicate(true)
	invalid.version = 900
	_check(not store.write_state(invalid, "slot_3"), "Reject unsupported version")
	_check(not store.write_state(snapshot, "../../bad"), "Reject unsafe slot paths")
	player.set_interaction_locked(true)
	_check(not store.save_world(world, "slot_3"), "Block transient action save")
	player.set_interaction_locked(false)
	_check(store.write_state(snapshot, "autosave") and not store.latest_slot().is_empty(), "Autosave and continue selection")
	_check(not store.read_slot("slot_1").is_empty(), "Failed writes preserve valid backup")
	var temporary := FileAccess.open(store._path("slot_1") + ".tmp", FileAccess.WRITE)
	temporary.store_string("temporary")
	temporary.close()
	_check(not store.delete_slot("../../bad") and not store.delete_slot("slot_1.json"), "Deletion rejects unsafe and unknown slot names")
	_check(store.has_slot_files("slot_1"), "Invalid deletion keeps valid files")
	var kept: Dictionary = store.read_slot("slot_2")
	_check(store.delete_slot("slot_1"), "Delete corrupt primary with valid backup and temporary file")
	_check(not store.has_slot_files("slot_1") and store.read_slot("slot_1").is_empty(), "Deleted backup must not restore slot")
	_check(store.read_slot("slot_2") == kept, "Deleting a record preserves other slots")
	_check(store.delete_slot("slot_1"), "Deleting an empty slot is idempotent")
	var newest := snapshot.duplicate(true)
	newest.timestamp = 9999999999
	_check(store.write_state(newest, "autosave") and store.latest_slot() == "autosave", "Latest autosave fixture")
	_check(store.delete_slot("autosave") and store.latest_slot() == "slot_2", "Deleting latest record updates Continue selection")
	var broken_record := FileAccess.open(store._path("slot_3"), FileAccess.WRITE)
	broken_record.store_string("invalid")
	broken_record.close()
	_check(store.has_slot_files("slot_3") and store.read_slot("slot_3").is_empty(), "Corrupt record remains visible for deletion")
	_check(store.delete_slot("slot_3") and not store.has_slot_files("slot_3"), "Corrupt record deletion")
	world.free()
	if not failed:
		print("Warehouse save tests passed: disk reload, 24 vehicles, mounted modes, door/gate/lifts, corruption recovery, validated deletion, primary/backup/temp cleanup, other slots preserved, latest slot refresh")
	quit(1 if failed else 0)

func _check(condition: bool, message: String) -> void:
	if not condition:
		failed = true
		push_error(message)
