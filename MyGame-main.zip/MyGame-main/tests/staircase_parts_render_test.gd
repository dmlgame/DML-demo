extends SceneTree

const STAIR_SCENE := "res://assets/objects/second_floor_staircase/second_floor_staircase.tscn"
const OUTPUT := "res://tmp/decor_rc_qa/"
# Feet locations aligned to the staircase texture in the user's screenshots.
const CASES := [
	[Vector2(84, 1184), [false, true, true], [0]],
	[Vector2(1172, 984), [true, true, false], [2]],
	[Vector2(344, 792), [true, false, true], [0]],
	[Vector2(480, 656), [true, false, true], [0, 1]],
	[Vector2(204, 668), [true, false, true], [1]],
	[Vector2(602, 1018), [true, true, false], [0]],
]
const MAIN_BEAM_SAMPLES := [Vector2(584, 922), Vector2(588, 922), Vector2(592, 920), Vector2(596, 916)]
const BRACE_SAMPLES := [Vector2(626, 947), Vector2(646, 958)]

func _initialize() -> void:
	call_deferred("_run")

func _run() -> void:
	if DisplayServer.get_name() == "headless":
		return _fail("This test requires a renderer to check staircase overlap pixels")
	var viewport := SubViewport.new()
	viewport.size = Vector2i(620, 620)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var player := Node2D.new()
	player.name = "Player"
	player.position = Vector2(600, 600)
	var patch := ColorRect.new()
	patch.color = Color.MAGENTA
	patch.position = Vector2(-16, -24)
	patch.size = Vector2(32, 50)
	patch.visible = false
	player.add_child(patch)
	actors.add_child(player)
	var sort_parent := Node2D.new()
	sort_parent.y_sort_enabled = true
	actors.add_child(sort_parent)
	var staircase: Sprite2D = load(STAIR_SCENE).instantiate()
	staircase.position = Vector2(50, 50)
	staircase.scale = Vector2(0.25, 0.25)
	sort_parent.add_child(staircase)
	for point in MAIN_BEAM_SAMPLES:
		if _part_at(staircase, point) != 0:
			return _fail("The diagonal stair beam must not be assigned to the support layer: " + str(point))
	for point in BRACE_SAMPLES:
		if _part_at(staircase, point) != 2:
			return _fail("The brace must remain in the independently sorted support layer: " + str(point))
	var original_polygons: Array[PackedVector2Array] = []
	for collider in staircase.get_node("StaticBody2D").get_children():
		original_polygons.append(collider.polygon.duplicate())
	var baseline := Sprite2D.new()
	baseline.texture = staircase.texture
	baseline.texture_filter = staircase.texture_filter
	baseline.centered = staircase.centered
	baseline.position = staircase.position
	baseline.scale = staircase.scale
	actors.add_child(baseline)
	staircase.visible = false
	await _draw_frame()
	var original := viewport.get_texture().get_image()
	baseline.visible = false
	staircase.visible = true
	await _draw_frame()
	var split := viewport.get_texture().get_image()
	for y in viewport.size.y:
		for x in viewport.size.x:
			if original.get_pixel(x, y) != split.get_pixel(x, y):
				return _fail("Splitting the staircase changes its artwork at %s" % Vector2i(x, y))
	patch.visible = true
	for index in CASES.size():
		var entry: Array = CASES[index]
		player.position = staircase.to_global(entry[0]) - Vector2(0, 25)
		staircase._update_occlusion()
		await _draw_frame()
		var layers := [staircase.foreground.visible, staircase._support_visuals[0].foreground.visible, staircase._support_visuals[1].foreground.visible]
		if layers != entry[1]:
			return _fail("Screenshot %d has the wrong stair/support order: %s" % [index + 1, layers])
		var image := viewport.get_texture().get_image()
		var counts := [0, 0, 0]
		var bounds := Rect2(player.position + patch.position, patch.size).grow(-2)
		for y in range(int(bounds.position.y), int(bounds.end.y)):
			for x in range(int(bounds.position.x), int(bounds.end.x)):
				if original.get_pixel(x, y).a < 0.995:
					continue
				var local := staircase.to_local(Vector2(x + 0.5, y + 0.5)).floor()
				var part := _part_at(staircase, local)
				# Skip classification boundaries where CPU/GPU rounding can select adjacent texels.
				var boundary_pixel := false
				for delta in [Vector2(-2, -2), Vector2(2, 2), Vector2(-2, 2), Vector2(2, -2)]:
					boundary_pixel = boundary_pixel or _part_at(staircase, local + delta) != part
				if boundary_pixel:
					continue
				var expected := original.get_pixel(x, y) if layers[part] else Color.MAGENTA
				if not image.get_pixel(x, y).is_equal_approx(expected):
					return _fail("Screenshot %d: incorrect overlap in part %d at %s" % [index + 1, part, Vector2i(x, y)])
				counts[part] += 1
		for required_part in entry[2]:
			if counts[required_part] < 4:
				return _fail("Screenshot %d does not exercise enough pixels in part %d: %s" % [index + 1, required_part, counts])
	for y in range(1000, 1041, 8):
		for x in range(580, 629, 8):
			player.position = staircase.to_global(Vector2(x, y)) - Vector2(0, 25)
			staircase._update_occlusion()
			await _draw_frame()
			var image := viewport.get_texture().get_image()
			for point in MAIN_BEAM_SAMPLES:
				var sample := Vector2i(staircase.to_global(point))
				if original.get_pixelv(sample).a < 0.995 or image.get_pixelv(sample) != original.get_pixelv(sample):
					return _fail("Approaching the brace cuts out part of the stair beam: feet=%s sample=%s" % [Vector2(x, y), point])
	for index in original_polygons.size():
		if staircase.get_node("StaticBody2D").get_child(index).polygon != original_polygons[index]:
			return _fail("Staircase collision polygons were changed")
	actors.queue_free()
	await process_frame
	viewport.size = Vector2i(1152, 648)
	viewport.transparent_bg = false
	var world := load("res://warehouse_main.tscn").instantiate() as Node2D
	viewport.add_child(world)
	var actual_player := world.get_node("YSortActors/Player") as CharacterBody2D
	actual_player.set_physics_process(false)
	var actual_staircase := world.get_node("YSortActors/SecondFloorStaircaseSort/SecondFloorStaircase") as Sprite2D
	var camera := actual_player.get_node("Camera2D") as Camera2D
	camera.zoom = Vector2(2, 2)
	DirAccess.make_dir_recursive_absolute(OUTPUT)
	for index in CASES.size():
		actual_player.global_position = actual_staircase.to_global(CASES[index][0]) - Vector2(0, 25)
		actual_player.call("_play_idle", Vector2.RIGHT if index == 0 else (Vector2.UP if index == 1 else Vector2.DOWN))
		camera.force_update_scroll()
		actual_staircase._update_occlusion()
		await _draw_frame()
		if viewport.get_texture().get_image().save_png(OUTPUT + "staircase_case_%d.png" % (index + 1)) != OK:
			return _fail("Could not save staircase preview")
	print("All six screenshot positions, intact stair beam during approach, independent supports, unchanged artwork and collisions passed")
	quit()

func _part_at(staircase: Sprite2D, point: Vector2) -> int:
	if Geometry2D.is_point_in_polygon(point, PackedVector2Array(staircase.REAR_REGION)):
		return 1
	if Geometry2D.is_point_in_polygon(point, PackedVector2Array(staircase.PLATFORM_REGION)):
		return 2
	return 0

func _draw_frame() -> void:
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw

func _fail(message: String) -> void:
	push_error(message)
	quit(1)
