extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	if DisplayServer.get_name() == "headless":
		print("Object footprint render test skipped without a renderer")
		quit()
		return
	var viewport := SubViewport.new()
	viewport.size = Vector2i(350, 230)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var tile_set: TileSet = load("res://assets/tiles/warehouse_objects_tileset.tres")
	var tiles := [Vector2i(0, 0), Vector2i(5, 0), Vector2i(10, 0), Vector2i(0, 0), Vector2i(6, 0)]
	for index in tiles.size():
		var tile: Vector2i = tiles[index]
		var source_id := 3 if index < 3 else 5
		var plain := TileMapLayer.new()
		plain.tile_set = tile_set
		plain.set_cell(Vector2i(5, 3), source_id, tile)
		viewport.add_child(plain)
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var before := viewport.get_texture().get_image()
		viewport.remove_child(plain)
		plain.free()
		var split := TileMapLayer.new()
		split.set_script(load("res://object_footprint_sort.gd"))
		split.tile_set = tile_set
		split.y_sort_enabled = true
		split.set_cell(Vector2i(5, 3), source_id, tile)
		var actors := Node2D.new()
		actors.y_sort_enabled = true
		viewport.add_child(actors)
		actors.add_child(split)
		await RenderingServer.frame_post_draw
		await RenderingServer.frame_post_draw
		var after := viewport.get_texture().get_image()
		if split.get_children(true).size() != 1:
			return _fail("Source %d must render as one whole object" % source_id)
		var differences := 0
		for y in viewport.size.y:
			for x in viewport.size.x:
				if before.get_pixel(x, y) != after.get_pixel(x, y):
					differences += 1
		if differences > 0:
			return _fail("Source %d tile %s changed %d pixels" % [source_id, tile, differences])
		if (tile_set.get_source(source_id) as TileSetAtlasSource).get_tile_data(tile, 0).modulate.a != 1.0:
			return _fail("Runtime visual override changed the shared tile source")
		var marker := Node2D.new()
		marker.name = "Player"
		var patch := ColorRect.new()
		patch.color = Color.MAGENTA
		patch.size = Vector2(4, 4)
		marker.add_child(patch)
		actors.add_child(marker)
		var columns := [1, 3] if source_id == 3 else [0, 5]
		for column in columns:
			var sample_x: int = 176 + column * 32 - (80 if source_id == 3 else 96) + 16
			var sample_y := -1
			for y in range(132, 178):
				if before.get_pixel(sample_x, y).a > 0.9:
					sample_y = y
					break
			if sample_y < 0:
				return _fail("No tile pixel found in region %d of source %d" % [column, source_id])
			var visual: Node2D = split.get_children(true)[0]
			marker.position.x = sample_x
			await RenderingServer.frame_post_draw
			for in_front in [false, true]:
				marker.position = Vector2(sample_x, visual.position.y + (2 if in_front else -2))
				patch.position = Vector2(-2, sample_y - marker.position.y - 1)
				await RenderingServer.frame_post_draw
				await RenderingServer.frame_post_draw
				var pixel := viewport.get_texture().get_image().get_pixel(sample_x, sample_y)
				if pixel.is_equal_approx(Color.MAGENTA) != in_front:
					return _fail("Source %d does not sort at region %d (front=%s, pixel=%s, anchor=%s, player=%s)" % [source_id, column, in_front, pixel, visual.position, marker.position])
		viewport.remove_child(actors)
		actors.free()
	if not await _check_workstation_footprint(viewport, tile_set):
		return
	var editable := TileMapLayer.new()
	editable.set_script(load("res://object_footprint_sort.gd"))
	editable.tile_set = tile_set
	editable.set_cell(Vector2i(4, 3), 3, Vector2i(0, 0))
	editable.set_cell(Vector2i(8, 3), 5, Vector2i(0, 0))
	viewport.add_child(editable)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	if editable.get_children(true).size() != 2:
		return _fail("Placed objects did not generate whole visuals")
	if editable.get_cell_tile_data(Vector2i(4, 3)).get_collision_polygons_count(0) != 1:
		return _fail("Mesh cart collision was removed")
	if editable.get_cell_tile_data(Vector2i(8, 3)).get_collision_polygons_count(0) != 2:
		return _fail("Charging station collisions were removed")
	editable.erase_cell(Vector2i(4, 3))
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	if editable.get_children(true).size() != 1:
		return _fail("Erased object left a stale visual")
	print("Mesh cart, charger and workstation footprint render tests passed")
	quit()


func _check_workstation_footprint(viewport: SubViewport, tile_set: TileSet) -> bool:
	var plain := TileMapLayer.new()
	plain.tile_set = tile_set
	plain.set_cell(Vector2i(5, 3), 0, Vector2i(0, 13))
	viewport.add_child(plain)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var baseline := viewport.get_texture().get_image()
	viewport.remove_child(plain)
	plain.free()
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var desk := TileMapLayer.new()
	desk.set_script(load("res://object_footprint_sort.gd"))
	desk.tile_set = tile_set
	desk.y_sort_enabled = true
	desk.set_cell(Vector2i(5, 3), 0, Vector2i(0, 13))
	actors.add_child(desk)
	var player := Node2D.new()
	player.name = "Player"
	actors.add_child(player)
	await process_frame
	await RenderingServer.frame_post_draw
	if desk.get_children(true).size() != 1 + (128 - 32) / 8:
		_fail("Workstation back rail and tabletop rows must sort separately")
		return false
	var rendered := viewport.get_texture().get_image()
	for y in viewport.size.y:
		for x in viewport.size.x:
			if baseline.get_pixel(x, y) != rendered.get_pixel(x, y):
				_fail("Workstation pixels changed when split from its collision")
				return false
	var center_pixel := Vector2i(176, -1)
	for y in range(50, 80):
		if baseline.get_pixel(center_pixel.x, y).a > 0.9:
			center_pixel.y = y
			break
	var leg_pixel := Vector2i(85, -1)
	for y in range(120, 170):
		if baseline.get_pixel(leg_pixel.x, y).a > 0.9:
			leg_pixel.y = y
			break
	if center_pixel.y < 0 or leg_pixel.y < 0:
		_fail("Workstation test pixels were not found")
		return false
	var patch := ColorRect.new()
	patch.color = Color.MAGENTA
	patch.size = Vector2(4, 4)
	player.add_child(patch)
	player.position = Vector2(176, 100)
	patch.position = Vector2(-2, center_pixel.y - 102)
	await process_frame
	await RenderingServer.frame_post_draw
	if not viewport.get_texture().get_image().get_pixelv(center_pixel).is_equal_approx(Color.MAGENTA):
		_fail("Player in the workstation opening is incorrectly hidden by the back rail")
		return false
	player.position = Vector2(85, 100)
	patch.position = Vector2(-2, leg_pixel.y - 102)
	await process_frame
	await RenderingServer.frame_post_draw
	if viewport.get_texture().get_image().get_pixelv(leg_pixel).is_equal_approx(Color.MAGENTA):
		_fail("Player behind the workstation leg is incorrectly in front")
		return false
	player.position.y = 170
	patch.position.y = leg_pixel.y - 172
	await process_frame
	await RenderingServer.frame_post_draw
	if not viewport.get_texture().get_image().get_pixelv(leg_pixel).is_equal_approx(Color.MAGENTA):
		_fail("Player in front of the workstation leg is incorrectly hidden")
		return false
	patch.visible = false
	var observer := Node2D.new()
	observer.position = Vector2(176, 100)
	var observer_patch := ColorRect.new()
	observer_patch.color = Color.CYAN
	observer_patch.size = Vector2(4, 4)
	observer_patch.position = Vector2(-2, center_pixel.y - 102)
	observer.add_child(observer_patch)
	actors.add_child(observer)
	for player_x in [176.0, 50.0, 300.0]:
		player.position = Vector2(player_x, 100)
		await process_frame
		await RenderingServer.frame_post_draw
		if not viewport.get_texture().get_image().get_pixelv(center_pixel).is_equal_approx(Color.CYAN):
			_fail("Workstation back rail changes depth over a seated NPC when the player moves")
			return false
	viewport.remove_child(actors)
	actors.free()
	return true


func _fail(message: String) -> void:
	push_error(message)
	quit(1)
