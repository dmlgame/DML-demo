extends SceneTree


func _initialize() -> void:
	call_deferred("_run")


func _run() -> void:
	var viewport := SubViewport.new()
	viewport.size = Vector2i(620, 620)
	viewport.transparent_bg = true
	viewport.render_target_update_mode = SubViewport.UPDATE_ALWAYS
	root.add_child(viewport)
	var actors := Node2D.new()
	actors.y_sort_enabled = true
	viewport.add_child(actors)
	var baseline := Sprite2D.new()
	baseline.texture = load("res://assets/objects/second_floor_staircase/second_floor_staircase.png")
	baseline.texture_filter = 4
	baseline.centered = false
	baseline.scale = Vector2(0.4083, 0.4083)
	baseline.position = Vector2(50, 50)
	actors.add_child(baseline)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var original := viewport.get_texture().get_image()
	actors.remove_child(baseline)
	baseline.free()

	var player := Node2D.new()
	player.name = "Player"
	player.position = Vector2(600, 600)
	var patch := ColorRect.new()
	patch.color = Color.MAGENTA
	patch.position = Vector2(-20, -10)
	patch.size = Vector2(40, 40)
	patch.visible = false
	player.add_child(patch)
	actors.add_child(player)
	var sort_parent := Node2D.new()
	sort_parent.y_sort_enabled = true
	actors.add_child(sort_parent)
	var staircase: Sprite2D = load("res://assets/objects/second_floor_staircase/second_floor_staircase.tscn").instantiate()
	staircase.position = Vector2(50, 50)
	sort_parent.add_child(staircase)
	if staircase.get_node("StaticBody2D").get_child_count() != 4:
		return _fail("Staircase collision polygons were changed")
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	var unchanged := viewport.get_texture().get_image()
	for y in 620:
		for x in 620:
			if original.get_pixel(x, y) != unchanged.get_pixel(x, y):
				return _fail("Staircase image changed without the player nearby")

	var foreground: Sprite2D = staircase.get_node("Foreground")
	var under: Vector2 = staircase.to_global(Vector2(900, 760))
	if staircase._in_front_of_marked_edge(under):
		return _fail("Under-platform position is incorrectly in front")
	player.position = under - Vector2(0, 25)
	patch.visible = true
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	if not foreground.visible or staircase.self_modulate.a != 0.0:
		return _fail("Overhead staircase is not in front of the player")
	var under_sample := _find_sample(original, player.position)
	if under_sample.x < 0:
		return _fail("No platform pixel overlaps the player under the staircase")
	var under_pixel := viewport.get_texture().get_image().get_pixelv(under_sample)
	if under_pixel != original.get_pixelv(under_sample):
		return _fail("The player shows through the overhead platform")

	var contact: Vector2 = staircase.to_global(Vector2(256, 1235))
	if not staircase._in_front_of_marked_edge(contact):
		return _fail("The marked lower stair edge is not recognized")
	player.position = contact - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	await RenderingServer.frame_post_draw
	if foreground.visible or staircase.self_modulate.a != 1.0:
		return _fail("The player is not drawn above the staircase at its collision")
	var contact_sample := _find_sample(original, player.position)
	if contact_sample.x < 0:
		return _fail("No staircase pixel overlaps the player at the collision")
	var contact_pixel := viewport.get_texture().get_image().get_pixelv(contact_sample)
	if not contact_pixel.is_equal_approx(Color.MAGENTA):
		return _fail("Staircase collision artwork is drawn above the player")
	for edge in staircase._front_edges:
		var midpoint: Vector2 = (edge[0] + edge[1]) / 2.0
		var forward: Vector2 = Vector2(-(edge[1] - edge[0]).y, (edge[1] - edge[0]).x).normalized()
		if staircase._in_front_of_marked_edge(midpoint - forward * 4.0):
			return _fail("Player behind a marked edge is incorrectly drawn in front")
		player.position = midpoint + forward * 4.0 - Vector2(0, 25)
		await RenderingServer.frame_post_draw
		if foreground.visible or staircase.self_modulate.a != 1.0:
			return _fail("Player is hidden in front of a marked edge")
	var lower_edge: PackedVector2Array = staircase._front_edges[1]
	var lower_midpoint: Vector2 = (lower_edge[0] + lower_edge[1]) / 2.0
	var below_lower_edge := lower_midpoint + Vector2(0, 10)
	if not staircase._in_front_of_marked_edge(below_lower_edge):
		return _fail("Lower stair edge hides the player's head after their feet pass it")
	player.position = below_lower_edge - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	if foreground.visible or staircase.self_modulate.a != 1.0:
		return _fail("Staircase is drawn in front of the player below the lower edge")
	if staircase._in_front_of_marked_edge(lower_midpoint + Vector2(0, 65)):
		return _fail("The lower stair edge affects the player far from its collision")
	for local_point in [Vector2(350, 900), Vector2(660, 586)]:
		if staircase._in_front_of_marked_edge(staircase.to_global(local_point)):
			return _fail("Marked edges incorrectly expose the player on the upper stairs")
	var upper_stairs := staircase.to_global(Vector2(660, 586))
	player.position = upper_stairs - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	if not foreground.visible or staircase.self_modulate.a != 0.0:
		return _fail("Player is drawn over the upper stairs away from marked edges")
	var hidden: CollisionPolygon2D = staircase.get_node("StaticBody2D/CollisionPolygon2D3")
	var hidden_center := Vector2.ZERO
	for point in hidden.polygon:
		hidden_center += point
	hidden_center /= hidden.polygon.size()
	player.position = hidden.to_global(hidden_center) - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	if not foreground.visible or staircase.self_modulate.a != 0.0:
		return _fail("Hidden middle collision incorrectly draws the player in front")
	staircase.scale = Vector2(0.25, 0.25)
	staircase._build_front_edges()
	for local_point in [Vector2(283, 969), Vector2(335, 1007), Vector2(531, 667), Vector2(498, 732), Vector2(386, 778), Vector2(488, 738)]:
		if staircase._in_front_of_marked_edge(staircase.to_global(local_point)):
			return _fail("A player underneath the stairs is drawn on top of the railing")
	for local_point in [Vector2(140, 1175), Vector2(320, 1244), Vector2(113, 1348)]:
		if not staircase._in_front_of_marked_edge(staircase.to_global(local_point)):
			return _fail("A marked collision edge hides the player")
	for local_point in [Vector2(320, 620), Vector2(476, 693), Vector2(272, 826)]:
		if not staircase._in_front_of_edges(staircase.to_global(local_point), staircase._rear_edges, staircase._rear_heights):
			return _fail("A rear support edge hides the player")
	for local_point in [Vector2(650, 1008), Vector2(612, 1115), Vector2(760, 1234)]:
		if not staircase._in_front_of_edges(staircase.to_global(local_point), staircase._platform_edges, staircase._platform_heights):
			return _fail("A platform support edge hides the player")
	var under_join := Vector2(498, 732)
	player.position = staircase.to_global(under_join) - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	if not foreground.visible or staircase.self_modulate.a != 0.0:
		return _fail("The player is incorrectly in front of the landing stairs")
	player.position = staircase.to_global(Vector2(386, 778)) - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	if not foreground.visible or staircase.self_modulate.a != 0.0:
		return _fail("The player is incorrectly in front of the lower stair railing")
	player.position = staircase.to_global(Vector2(113, 1348)) - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	if foreground.visible or staircase.self_modulate.a != 1.0:
		return _fail("The lower stair edge hides the player")
	player.position = staircase.to_global(Vector2(760, 1234)) - Vector2(0, 25)
	await RenderingServer.frame_post_draw
	if staircase._support_visuals[1].foreground.visible or not staircase._support_visuals[1].background.visible:
		return _fail("The platform support is drawn over the player")
	print("Staircase overhead and collision occlusion tests passed")
	quit()


func _find_sample(image: Image, player_position: Vector2) -> Vector2i:
	for y in range(int(player_position.y) - 8, int(player_position.y) + 28):
		for x in range(int(player_position.x) - 18, int(player_position.x) + 18):
			if image.get_pixel(x, y).a > 0.99:
				return Vector2i(x, y)
	return Vector2i(-1, -1)


func _fail(message: String) -> void:
	push_error(message)
	quit(1)
