extends "res://game_session.gd"

func _ready() -> void:
	save_store.directory = "user://pallet_preview/saves"
	super._ready()
	call_deferred("_start_world", "")

func _start_world(slot: String) -> void:
	await super._start_world(slot)
	if not slot.is_empty() or world == null:
		return
	var demo: Node = world.get_node("DemoTasks")
	var state := save_store.capture(world)
	state.demo.merge({"completed": true, "zph_assignment": true, "gate17_checked": true,
		"stage": "find_stock_jack", "free_time_remaining": 0, "gate19_open": true,
		"placed_count": 12, "hint_enabled": false, "assigned_vehicle": ""}, true)
	state.gate_open = true
	var point: Vector2 = demo._receiving_lead.global_position - Vector2(0, 25)
	state.player.position = [point.x, point.y]
	state.player.direction = [0, -1]
	if not save_store.apply_state(world, state):
		menu.set_status(save_store.last_error, true)
		return
	_refresh_pickups()
	_update_controls_hint_visibility()
