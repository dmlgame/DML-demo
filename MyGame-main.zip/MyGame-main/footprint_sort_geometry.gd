extends RefCounted


static func front_y(polygons: Array[PackedVector2Array], x: float, fallback: float) -> float:
	var left := INF
	var right := -INF
	for polygon in polygons:
		for point in polygon:
			left = minf(left, point.x)
			right = maxf(right, point.x)
	if left == INF:
		return fallback
	x = clampf(x, left + 0.001, right - 0.001)
	var front := -INF
	for polygon in polygons:
		for index in polygon.size():
			var a := polygon[index]
			var b := polygon[(index + 1) % polygon.size()]
			if x < minf(a.x, b.x) or x > maxf(a.x, b.x):
				continue
			if is_equal_approx(a.x, b.x):
				front = maxf(front, maxf(a.y, b.y))
			else:
				front = maxf(front, lerpf(a.y, b.y, (x - a.x) / (b.x - a.x)))
	return front if front != -INF else fallback
