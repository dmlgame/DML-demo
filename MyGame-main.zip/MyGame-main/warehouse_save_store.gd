class_name WarehouseSaveStore
extends RefCounted

const VERSION := 1
const SLOTS := ["slot_1", "slot_2", "slot_3", "autosave"]
const VEHICLE_PARENTS := ["YSortActors/PalletJackAssets", "YSortActors/TransporterSprites"]
const DemoTasks = preload("res://demo_tasks.gd")
var directory := "user://saves"
var last_error := ""
var recovered_backup := false

func capture(world: Node) -> Dictionary:
	var vehicles := {}
	for vehicle in _vehicles(world):
		vehicles[str(world.get_path_to(vehicle))] = [vehicle.global_position.x, vehicle.global_position.y]
	var state := {
		"version": VERSION, "scene": "res://warehouse_main.tscn",
		"saved_at": Time.get_datetime_string_from_system(),
		"timestamp": Time.get_unix_time_from_system(),
		"player": world.get_node("YSortActors/Player").get_save_state(world),
		"vehicles": vehicles,
		"door_open": world.get_node("FrontDoorInteraction").is_open,
		"gate_open": world.get_node("DockGate17Interaction").is_open,
		"lifts": world.get_node("FreightLiftInteraction").get_save_state(),
	}
	if world.has_node("DemoTasks"):
		state["demo"] = world.get_node("DemoTasks").get_save_state()
	return state

func save_world(world: Node, slot: String) -> bool:
	if world.get_meta("animation_test_mode", false):
		last_error = "В режиме проверки анимаций сохранения отключены. Обычный прогресс не изменяется."
		return false
	if world.get_node("YSortActors/Player").get("_interaction_locked"):
		last_error = "Дождитесь завершения действия или закройте открытое окно."
		return false
	return write_state(capture(world), slot)

func write_state(state: Dictionary, slot: String) -> bool:
	last_error = ""
	if slot not in SLOTS or not _valid(state):
		last_error = "Некорректные данные сохранения."
		return false
	var folder := ProjectSettings.globalize_path(directory)
	if DirAccess.make_dir_recursive_absolute(folder) != OK:
		last_error = "Не удалось создать папку сохранений."
		return false
	var path := _path(slot)
	var temporary := path + ".tmp"
	var file := FileAccess.open(temporary, FileAccess.WRITE)
	if file == null:
		last_error = "Не удалось записать сохранение."
		return false
	file.store_string(JSON.stringify(state))
	file.flush()
	var write_error := file.get_error()
	file.close()
	if write_error != OK or _read_file(temporary).is_empty():
		last_error = "Ошибка записи сохранения. Предыдущий файл не изменён."
		return false
	# Keep a validated previous version; a corrupt primary must not replace its backup.
	if not _read_file(path).is_empty():
		if DirAccess.copy_absolute(path, path + ".bak") != OK:
			last_error = "Не удалось создать резервную копию."
			return false
	if DirAccess.rename_absolute(temporary, path) != OK:
		last_error = "Не удалось заменить файл сохранения."
		return false
	return true

func read_slot(slot: String) -> Dictionary:
	last_error = ""
	recovered_backup = false
	if slot not in SLOTS:
		last_error = "Неизвестный слот."
		return {}
	var state := _read_file(_path(slot))
	if state.is_empty():
		state = _read_file(_path(slot) + ".bak")
		recovered_backup = not state.is_empty()
	if state.is_empty():
		last_error = "Сохранение отсутствует или повреждено."
	return state

func list_slots() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for slot in SLOTS:
		var state := read_slot(slot)
		result.append({"id": slot, "data": state, "recovered": recovered_backup, "exists": has_slot_files(slot)})
	return result

func has_slot_files(slot: String) -> bool:
	if slot not in SLOTS:
		return false
	for suffix in ["", ".bak", ".tmp"]:
		if FileAccess.file_exists(_path(slot) + suffix):
			return true
	return false

func delete_slot(slot: String) -> bool:
	last_error = ""
	recovered_backup = false
	if slot not in SLOTS:
		last_error = "Неизвестный слот."
		return false
	# Remove fallback files first so a deleted save cannot be restored from its backup.
	for suffix in [".tmp", ".bak", ""]:
		var path: String = _path(slot) + suffix
		if FileAccess.file_exists(path) and DirAccess.remove_absolute(path) != OK:
			last_error = "Не удалось удалить запись. Проверьте доступ к папке сохранений."
			return false
	return true

func latest_slot() -> String:
	var latest := ""
	var timestamp := -1.0
	for slot in list_slots():
		if not slot.data.is_empty() and float(slot.data.timestamp) > timestamp:
			timestamp = float(slot.data.timestamp)
			latest = slot.id
	return latest

func apply_state(world: Node, state: Dictionary) -> bool:
	if not _valid(state):
		last_error = "Сохранение имеет неподдерживаемый формат."
		return false
	if state.has("demo") and not world.has_node("DemoTasks"):
		last_error = "На этой карте отсутствует сценарий демоверсии."
		return false
	if state.has("demo"):
		var assigned: String = state.demo.get("assigned_vehicle", state.demo.get("assigned_jack", ""))
		var legacy_jack: bool = not assigned.is_empty() and state.demo.has("assigned_jack")
		var receiving: bool = state.demo.get("stage", "") in DemoTasks.RECEIVING_STAGES + DemoTasks.PALLET_PROGRESS_STAGES
		if not assigned.is_empty():
			var vehicle := world.get_node_or_null(NodePath(assigned)) as PickupVehicle
			var mode := PickupVehicle.VehicleMode.PALLET_JACK if legacy_jack or receiving else PickupVehicle.VehicleMode.TRANSPORTER
			var parent := VEHICLE_PARENTS[0] if legacy_jack or receiving else VEHICLE_PARENTS[1]
			if vehicle == null or vehicle.vehicle_mode != mode or vehicle.get_parent() != world.get_node(parent):
				last_error = "Техника из поручения отсутствует на этой карте."
				return false
		var source: Array = state.demo.get("tote_source", [])
		if source.size() == 2 and not world.get_node("DemoTasks")._supplies.is_source_cell(Vector2i(int(source[0]), int(source[1]))):
			last_error = "Паллет запаса из поручения отсутствует на этой карте."
			return false
		var pallet_source: Array = state.demo.get("pallet_source", [])
		if pallet_source.size() == 2 and not world.get_node("DemoTasks")._pallet_stock.is_source_cell(Vector2i(int(pallet_source[0]), int(pallet_source[1]))):
			last_error = "Зона складирования паллет из поручения отсутствует на этой карте."
			return false
		var pallet_return: Array = state.demo.get("pallet_return", [])
		if pallet_return.size() == 2:
			var stock: Node2D = world.get_node("DemoTasks")._pallet_stock
			var cell := Vector2i(int(pallet_return[0]), int(pallet_return[1]))
			if not stock.is_source_cell(cell) or (stock.PALLET_ATLASES.find(stock._originals[cell].atlas) == 5 and pallet_return != pallet_source):
				last_error = "В зоне складирования нет места для возвращенного паллета."
				return false
		# Old releases left the pallet at table five; continue with its return, not a new tour.
		if state.demo.get("stage", "") == "blue_totes_complete":
			state = state.duplicate(true)
			state.demo.stage = "return_empty_pallet"
			state.demo.pallet_return = []
			state.player.vehicle = assigned
			state.player.pickup_offset = [0, -28]
		# Return any undelivered old jack load to the truck; keep all parked pallets.
		if legacy_jack:
			state = state.duplicate(true)
			state.demo.erase("assigned_jack")
			state.demo.assigned_vehicle = ""
			state.demo.stage = "unload_complete" if state.demo.get("placed_count", 0) == DemoTasks.Unloading.PALLET_COUNT else "find_free_transporter"
			state.player.vehicle = ""
			state.player.pickup_offset = [0, 0]
			if not _valid(state):
				last_error = "Не удалось обновить старое поручение."
				return false
	var carried: String = state.player.vehicle
	if not carried.is_empty():
		var vehicle := world.get_node_or_null(NodePath(carried)) as PickupVehicle
		if vehicle == null or not state.vehicles.has(carried):
			last_error = "Транспорт из сохранения отсутствует на этой карте."
			return false
	for vehicle in _vehicles(world):
		var key := str(world.get_path_to(vehicle))
		vehicle.set_carried(false)
		if state.vehicles.has(key):
			vehicle.global_position = Vector2(state.vehicles[key][0], state.vehicles[key][1])
	world.get_node("FrontDoorInteraction").restore_save_state(state.door_open)
	world.get_node("DockGate17Interaction").restore_save_state(state.gate_open)
	world.get_node("FreightLiftInteraction").restore_save_state(state.lifts)
	world.get_node("YSortActors/Player").restore_save_state(state.player, world)
	if state.has("demo"):
		world.get_node("DemoTasks").restore_save_state(state.demo)
	return true

func _vehicles(world: Node) -> Array[PickupVehicle]:
	var result: Array[PickupVehicle] = []
	for path in VEHICLE_PARENTS:
		for child in world.get_node(path).get_children():
			if child is PickupVehicle:
				result.append(child)
	return result

func _path(slot: String) -> String:
	return ProjectSettings.globalize_path(directory.path_join(slot + ".json"))

func _read_file(path: String) -> Dictionary:
	if not FileAccess.file_exists(path):
		return {}
	var file := FileAccess.open(path, FileAccess.READ)
	if file == null or file.get_length() > 1024 * 1024:
		return {}
	var json := JSON.new()
	if json.parse(file.get_as_text()) != OK or not json.data is Dictionary:
		return {}
	return json.data if _valid(json.data) else {}

func _valid(data: Dictionary) -> bool:
	if data.get("version") != VERSION or data.get("scene") != "res://warehouse_main.tscn":
		return false
	if not data.get("saved_at") is String or not _number(data.get("timestamp")):
		return false
	if not data.get("player") is Dictionary or not data.get("vehicles") is Dictionary or not data.get("lifts") is Dictionary:
		return false
	if not data.get("door_open") is bool or not data.get("gate_open") is bool:
		return false
	var player: Dictionary = data.player
	if not _vector(player.get("position")) or not _vector(player.get("direction")) or not _vector(player.get("pickup_offset")):
		return false
	if Vector2(player.direction[0], player.direction[1]) not in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		return false
	if not player.get("vehicle") is String:
		return false
	if data.has("demo"):
		if not DemoTasks.valid_save_state(data.demo):
			return false
		var assigned: String = data.demo.get("assigned_vehicle", data.demo.get("assigned_jack", ""))
		if not assigned.is_empty() and not data.vehicles.has(assigned):
			return false
		if not player.vehicle.is_empty() and player.vehicle != assigned:
			return false
		var saved_stage: String = DemoTasks.LEGACY_STAGES.get(data.demo.get("stage", ""), data.demo.get("stage", ""))
		if saved_stage in ["at_gate19_with_transporter", "unload_place", "deliver_totes", "deliver_empty_pallet", "find_blue_tote_stock", "deliver_blue_totes", "return_empty_pallet"] and player.vehicle != assigned:
			return false
	if not player.vehicle.is_empty() and not _vehicle_path(player.vehicle):
		return false
	for path in data.vehicles:
		if not _vehicle_path(path) or not _vector(data.vehicles[path]):
			return false
	for key in data.lifts:
		if not key is String or not data.lifts[key] is bool:
			return false
	return true

func _vehicle_path(path: Variant) -> bool:
	if not path is String or path.contains("..") or path.contains(":"):
		return false
	return (path.begins_with(VEHICLE_PARENTS[0] + "/") or path.begins_with(VEHICLE_PARENTS[1] + "/")) and path.count("/") == 2

func _number(value: Variant) -> bool:
	return (value is float or value is int) and is_finite(float(value))

func _vector(value: Variant) -> bool:
	return value is Array and value.size() == 2 and _number(value[0]) and _number(value[1]) and absf(value[0]) < 1000000 and absf(value[1]) < 1000000
