extends "res://warehouse_worker.gd"

const TALK_RADIUS := 64.0
var initialized := false
var conversation_locked := false
var _catalogue: Array[Dictionary] = []
var _warmup_frames := 0
var _initialization_queued := false

func configure_director(world: Node2D) -> void:
	var points: Array[Dictionary] = []
	configure(world, points, 0, self)
	add_to_group("warehouse_director")
	hide()

func _physics_process(delta: float) -> void:
	if not initialized:
		if _world != null and not _initialization_queued:
			_warmup_frames += 1
			if _warmup_frames >= 2:
				_initialization_queued = true
				call_deferred("_initialize_roaming")
		return
	if conversation_locked:
		_stand()
		return
	super._physics_process(delta)

func _initialize_roaming() -> void:
	var floor_layer := _world.get_node("FloorLayer") as TileMapLayer
	for cell in floor_layer.get_used_cells():
		if posmod(cell.x, 8) != 0 or posmod(cell.y, 8) != 0:
			continue
		var point := floor_layer.to_global(floor_layer.map_to_local(cell))
		if _point_is_clear(point):
			_catalogue.append({"point": point, "look_at": point + Vector2.DOWN, "kind": "floor"})
	var player_feet := _player.global_position + FOOT_OFFSET
	var spawn := Vector2.INF
	var candidates: Array[Vector2] = []
	var blocks := _world.get_node("BlockNotifications")
	for point in _catalogue:
		var distance := player_feet.distance_to(point.point)
		if distance >= 600 and distance <= 1600 and blocks.get_block_at(point.point) == blocks.get_block_at(player_feet):
			candidates.append(point.point)
	while not candidates.is_empty():
		var index := _rng.randi_range(0, candidates.size() - 1)
		var candidate := candidates[index]
		candidates.remove_at(index)
		if _try_spawn_at(candidate):
			spawn = candidate
			break
	for offset in [Vector2(160, -64), Vector2(-160, -64), Vector2(160, 128), Vector2(-160, 128), Vector2(0, 192)]:
		if spawn.is_finite():
			break
		if _try_spawn_at(player_feet + offset):
			spawn = player_feet + offset
			break
	if not spawn.is_finite() and not _catalogue.is_empty():
		_catalogue.sort_custom(func(a: Dictionary, b: Dictionary) -> bool: return a.point.distance_squared_to(player_feet) < b.point.distance_squared_to(player_feet))
		for point in _catalogue:
			if _try_spawn_at(point.point):
				spawn = point.point
				break
	if not spawn.is_finite():
		push_error("No clear warehouse floor for the director")
		return
	global_position = spawn - FOOT_OFFSET
	destinations = _catalogue.duplicate()
	_path.clear()
	_path_index = 0
	_target_index = -1
	resting = true
	_rest_left = _rng.randf_range(pause_seconds.x, pause_seconds.y)
	initialized = true
	show()

func _try_spawn_at(feet: Vector2) -> bool:
	if not _point_is_clear(feet):
		return false
	global_position = feet - FOOT_OFFSET
	# A free foot rectangle can still sit inside a sealed pocket between cages.
	_choose_destination()
	return not _path.is_empty() and _can_step_to(_path[0])

func can_roam(feet: Vector2) -> bool:
	var floor_layer := _world.get_node("FloorLayer") as TileMapLayer
	for offset in [Vector2(-12, 0), Vector2(12, 0)]:
		if floor_layer.get_cell_source_id(floor_layer.local_to_map(floor_layer.to_local(feet + offset))) == -1:
			return false
	return true

func _point_is_clear(feet: Vector2) -> bool:
	if not can_roam(feet):
		return false
	var shape := RectangleShape2D.new()
	shape.size = Vector2(24, 14)
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0, feet)
	query.collision_mask = 1
	query.exclude = [get_rid()]
	return get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func _choose_destination() -> void:
	# Nearby random stops let him cross blocks through real passages without huge grids.
	var feet := global_position + FOOT_OFFSET
	destinations.clear()
	for point in _catalogue:
		if feet.distance_to(point.point) <= 1400:
			destinations.append(point)
	_target_index = -1
	super._choose_destination()

func contains_actor(actor: Node2D) -> bool:
	if not initialized or not is_visible_in_tree() or actor.get_world_2d() != get_world_2d():
		return false
	var feet := actor.global_position + FOOT_OFFSET
	var own_feet := global_position + FOOT_OFFSET
	if feet.distance_to(own_feet) > TALK_RADIUS:
		return false
	var exclude: Array[RID] = [get_rid()]
	if actor is CollisionObject2D:
		exclude.append(actor.get_rid())
	var ray := PhysicsRayQueryParameters2D.create(feet, own_feet, 1, exclude)
	return get_world_2d().direct_space_state.intersect_ray(ray).is_empty()

func set_conversation_locked(value: bool, actor: Node2D = null) -> void:
	conversation_locked = value
	resting = true
	_passing_worker = null
	_path.clear()
	_path_index = 0
	_rest_left = _rng.randf_range(0.6, 1.2)
	if value and actor != null:
		facing = _direction_to_facing(actor.global_position - global_position)
	_stand()
