extends Node

const OCCLUSION_SHADER: Shader = preload("res://front_wall_occlusion.gdshader")
const FADE_SPEED := 5.0
const FAR_SIDE_MARGIN := 96.0

@onready var front_sort: Node2D = $"../YSortActors/FrontWallSort"
@onready var wall: TileMapLayer = $"../YSortActors/FrontWallSort/FrontWallLayer"
@onready var door: TileMapLayer = $"../YSortActors/FrontWallSort/FrontDoorLayer"
@onready var player: CharacterBody2D = $"../YSortActors/Player"

var _wall_material: ShaderMaterial
var _door_material: ShaderMaterial
var _base_y := 0.0
var _top_y := 0.0
var _fade_amount := 0.0


func _ready() -> void:
	_base_y = wall.to_global(wall.map_to_local(Vector2i(0, 3))).y + 8.0
	_top_y = wall.to_global(wall.map_to_local(Vector2i(0, 0))).y - 16.0
	_wall_material = _create_material(_base_y, _base_y - 6.0, true)
	_door_material = _create_material(_base_y, _base_y, false)
	wall.material = _wall_material
	door.material = _door_material


func _process(delta: float) -> void:
	var player_y := player.global_position.y
	var behind_wall := player_y < front_sort.global_position.y and player_y > _top_y - FAR_SIDE_MARGIN
	_fade_amount = move_toward(_fade_amount, float(behind_wall), FADE_SPEED * delta)
	_wall_material.set_shader_parameter("fade_amount", _fade_amount)
	_door_material.set_shader_parameter("fade_amount", _fade_amount)


func _create_material(base_y: float, shutter_base_y: float, has_shutters: bool) -> ShaderMaterial:
	var result := ShaderMaterial.new()
	result.shader = OCCLUSION_SHADER
	result.set_shader_parameter("base_y", base_y)
	result.set_shader_parameter("shutter_base_y", shutter_base_y)
	result.set_shader_parameter("has_shutters", has_shutters)
	if not has_shutters:
		result.set_shader_parameter("faded_alpha", 0.25)
	return result
