extends Node

const CLOSED_DOOR := Vector2i(0, 0)
const OPEN_DOOR := Vector2i(2, 0)
const TITLE := "Вход в операционную зону"

@export var door_cell := Vector2i(6, 3)
@export_range(16, 128, 1) var proximity := 64.0

@onready var door: TileMapLayer = $"../YSortActors/FrontWallSort/FrontDoorLayer"
@onready var player: CharacterBody2D = $"../YSortActors/Player"

var is_open := false
var _source := 0
var _alternative := 0

func _ready() -> void:
	_source = door.get_cell_source_id(door_cell)
	if _source < 0:
		push_error("The entrance door is missing from FrontDoorLayer")
		return
	_alternative = door.get_cell_alternative_tile(door_cell)
	is_open = door.get_cell_atlas_coords(door_cell) == OPEN_DOOR
	player.register_door_interaction(self)

func _exit_tree() -> void:
	if is_instance_valid(player):
		player.unregister_door_interaction(self)

func can_interact(actor: Node2D) -> bool:
	if _source < 0:
		return false
	var feet := actor.global_position + Vector2(0, 25)
	var threshold := door.to_global(door.map_to_local(door_cell) + Vector2(0, 12))
	return feet.distance_to(threshold) <= proximity

func get_interaction_text(actor: Node2D) -> String:
	if not can_interact(actor):
		return ""
	if is_open:
		var text := TITLE + "\nНажмите E или Enter, чтобы закрыть дверь"
		if _would_hit_actor(actor):
			text += "\nОтойдите от дверного проёма"
		return text
	return TITLE + "\nНажмите E или Enter, чтобы открыть дверь"

func try_interact(actor: Node2D) -> bool:
	if not can_interact(actor):
		return false
	if is_open and _would_hit_actor(actor):
		return true
	is_open = not is_open
	door.set_cell(door_cell, _source, OPEN_DOOR if is_open else CLOSED_DOOR, _alternative)
	door.update_internals()
	return true

func _would_hit_actor(actor: Node2D) -> bool:
	var atlas := door.tile_set.get_source(_source) as TileSetAtlasSource
	var closed_data := atlas.get_tile_data(CLOSED_DOOR, _alternative)
	for index in closed_data.get_collision_polygons_count(0):
		var shape := ConvexPolygonShape2D.new()
		shape.points = closed_data.get_collision_polygon_points(0, index)
		var query := PhysicsShapeQueryParameters2D.new()
		query.shape = shape
		query.transform = door.global_transform * Transform2D(0.0, door.map_to_local(door_cell))
		query.collision_mask = player.collision_layer
		for hit in door.get_world_2d().direct_space_state.intersect_shape(query, 64):
			if hit.collider == actor:
				return true
	return false

func restore_save_state(opened: bool) -> void:
	is_open = opened
	door.set_cell(door_cell, _source, OPEN_DOOR if is_open else CLOSED_DOOR, _alternative)
	door.update_internals()
