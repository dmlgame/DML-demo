extends Node

const WORLD := preload("res://warehouse_main.tscn")
const Menu = preload("res://game_menu.gd")
const DemoTasks = preload("res://demo_tasks.gd")
const ControlsHint = preload("res://controls_hint.gd")
const TouchControls = preload("res://touch_controls.gd")
const Minimap = preload("res://warehouse_minimap.gd")
@export var animation_test_mode := false
@export var orientation_only := true
var save_store := WarehouseSaveStore.new()
var world: Node2D
var menu: Control
var controls_hint: Control
var touch_controls: Control
var desktop_minimap: Control
var _autosave_elapsed := 0.0
var _loading := false
var _toast: Label
var _toast_remaining := 0.0
var _pending_exit := false

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	get_tree().auto_accept_quit = false
	var layer := CanvasLayer.new()
	layer.layer = 200
	add_child(layer)
	menu = Menu.new()
	menu.store = save_store
	layer.add_child(menu)
	menu.new_game_requested.connect(_start_world.bind(""))
	menu.load_requested.connect(_start_world)
	menu.save_requested.connect(_save_manual)
	menu.resume_requested.connect(_resume)
	menu.main_menu_requested.connect(_return_to_menu)
	menu.quit_requested.connect(_quit_game)
	var controls_layer := CanvasLayer.new()
	controls_layer.layer = 35
	add_child(controls_layer)
	controls_hint = ControlsHint.new()
	controls_hint.name = "ControlsHint"
	controls_hint.theme = menu.theme
	controls_layer.add_child(controls_hint)
	controls_hint.hide()
	touch_controls = TouchControls.new()
	touch_controls.name = "TouchControls"
	touch_controls.theme = menu.theme
	controls_layer.add_child(touch_controls)
	touch_controls.pause_requested.connect(_pause)
	desktop_minimap = Minimap.new()
	desktop_minimap.name = "DesktopMinimap"
	desktop_minimap.theme = menu.theme
	desktop_minimap.position = Vector2(16, 16)
	desktop_minimap.size = Vector2(176, 80)
	desktop_minimap.add_to_group("desktop_minimap")
	controls_layer.add_child(desktop_minimap)
	desktop_minimap.hide()
	menu.visibility_changed.connect(_update_controls_hint_visibility)
	_toast = Label.new()
	_toast.theme = menu.theme
	_toast.position = Vector2(16, 16)
	_toast.add_theme_font_size_override("font_size", 16)
	_toast.add_theme_stylebox_override("normal", menu._style(Color("202725")))
	_toast.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_toast.hide()
	layer.add_child(_toast)

func _input(event: InputEvent) -> void:
	if _loading or not event is InputEventKey or not event.pressed or event.echo:
		return
	if event.keycode == KEY_ESCAPE:
		if menu.visible:
			menu.handle_escape()
		elif world != null:
			if world.get_node("YSortActors/Player").get("_interaction_locked"):
				return
			_pause()
		get_viewport().set_input_as_handled()
	elif not menu.visible and world != null and event.keycode == KEY_F5:
		if save_store.save_world(world, "autosave"):
			_notify("Игра сохранена")
		else:
			_notify(save_store.last_error)
		get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	_update_controls_hint_visibility()
	if _pending_exit and world != null and not world.get_node("YSortActors/Player").get("_interaction_locked"):
		_pending_exit = false
		_quit_game()
		return
	if _toast_remaining > 0:
		_toast_remaining -= delta
		_toast.visible = _toast_remaining > 0 and not menu.visible and world != null and not world.get_node("YSortActors/Player").get("_interaction_locked")
		_toast.reset_size()
		var viewport_size := get_viewport().get_visible_rect().size
		if touch_controls.available:
			_toast.position = Vector2((viewport_size.x - _toast.size.x) / 2.0, maxf(76, viewport_size.y - 208))
		else:
			_toast.position = Vector2(16, maxf(108, viewport_size.y - _toast.size.y - 16))
	if world == null or get_tree().paused or _loading or _is_animation_test():
		return
	_autosave_elapsed += delta
	if _autosave_elapsed >= 60.0 and not world.get_node("YSortActors/Player").get("_interaction_locked"):
		_autosave_elapsed = 0.0
		if not save_store.save_world(world, "autosave"):
			_notify(save_store.last_error)

func _start_world(slot: String) -> void:
	if _loading:
		return
	if animation_test_mode and not slot.is_empty():
		menu.set_status("Для проверки анимаций начните новую игру. Сохранения оставлены без изменений.", true)
		return
	var state := {} if slot.is_empty() else save_store.read_slot(slot)
	var recovered := save_store.recovered_backup
	if not slot.is_empty() and state.is_empty():
		menu.set_status(save_store.last_error, true)
		return
	_loading = true
	# Build and validate the replacement before discarding a running session.
	var replacement := WORLD.instantiate() as Node2D
	replacement.process_mode = Node.PROCESS_MODE_DISABLED
	add_child(replacement)
	# Test sessions never attach quests or write ordinary demo progress.
	if animation_test_mode:
		replacement.set_meta("animation_test_mode", true)
		replacement.get_node("YSortActors/Player").set_pallet_jack_animation_test(true, true)
	elif slot.is_empty() or state.has("demo"):
		var demo := DemoTasks.new()
		demo.name = "DemoTasks"
		demo.orientation_only = orientation_only
		replacement.add_child(demo)
	if not state.is_empty() and not save_store.apply_state(replacement, state):
		replacement.free()
		_loading = false
		menu.set_status(save_store.last_error, true)
		return
	if is_instance_valid(world):
		touch_controls.set_active(null, false)
		desktop_minimap.bind_player(null)
		world.free()
	world = replacement
	world.process_mode = Node.PROCESS_MODE_PAUSABLE
	menu.hide()
	get_tree().paused = false
	_autosave_elapsed = 0.0
	await get_tree().physics_frame
	await get_tree().physics_frame
	_refresh_pickups()
	world.get_node("YSortActors/Player/Camera2D").make_current()
	_loading = false
	if slot.is_empty():
		controls_hint.set_expanded(true)
	_update_controls_hint_visibility()
	if recovered:
		_notify("Сохранение восстановлено из резервной копии")

func _refresh_pickups() -> void:
	var player := world.get_node("YSortActors/Player")
	for vehicle in save_store._vehicles(world):
		if not vehicle.is_carried and vehicle.interaction_area.get_overlapping_bodies().has(player):
			player.register_pickup_vehicle(vehicle)

func _save_manual(slot: String) -> void:
	if world != null and save_store.save_world(world, slot):
		menu._show_slots(true)
		menu.set_status("Игра сохранена")
	else:
		menu.set_status(save_store.last_error, true)

func _resume() -> void:
	menu.hide()
	get_tree().paused = false
	_update_controls_hint_visibility()

func _pause() -> void:
	if _loading or world == null or menu.visible or world.get_node("YSortActors/Player").get("_interaction_locked"):
		return
	touch_controls.reset_input()
	get_tree().paused = true
	menu.show_main(true)

func _return_to_menu() -> void:
	var testing := _is_animation_test()
	if not testing and not save_store.save_world(world, "autosave"):
		menu.set_status(save_store.last_error, true)
		return
	touch_controls.set_active(null, false)
	desktop_minimap.bind_player(null)
	desktop_minimap.hide()
	world.free()
	world = null
	get_tree().paused = false
	menu.show_main()
	menu.set_status("Проверка завершена. Обычные сохранения не изменены." if testing else "Игра сохранена")

func _quit_game() -> void:
	if world != null and world.has_node("DemoTasks"):
		world.get_node("DemoTasks").close_modal()
	if world != null and world.get_node("YSortActors/Player").get("_interaction_locked"):
		var lift := world.get_node("FreightLiftInteraction")
		if not lift.get("_selected").is_empty():
			lift.call("_close_picker")
		else:
			_pending_exit = true
			return
	if world != null and not _is_animation_test() and not save_store.save_world(world, "autosave"):
		get_tree().paused = true
		menu.show_main(true)
		menu.set_status(save_store.last_error, true)
		return
	get_tree().paused = false
	get_tree().quit()

func _notification(what: int) -> void:
	if what == NOTIFICATION_WM_CLOSE_REQUEST:
		_quit_game()

func _is_animation_test() -> bool:
	return is_instance_valid(world) and world.get_meta("animation_test_mode", false)

func _notify(text: String) -> void:
	_toast.text = text
	_toast_remaining = 3.0
	_toast.show()

func _update_controls_hint_visibility() -> void:
	var active := world != null and not menu.visible and not _loading
	controls_hint.visible = active and not touch_controls.available
	var actor: CharacterBody2D = world.get_node("YSortActors/Player") if world != null else null
	touch_controls.set_active(actor, active)
	var map_actor: CharacterBody2D = actor if not touch_controls.available else null
	if desktop_minimap.player != map_actor:
		desktop_minimap.bind_player(map_actor)
	desktop_minimap.visible = active and is_instance_valid(map_actor) and not map_actor._interaction_locked and not get_tree().paused
