extends Node2D

const PART_SHADER = preload("res://pallet_jack_depth.gdshader")
const FOOT_OFFSET := 25.0
const OPERATOR_GROUND := 36.0
const JACK_GROUND := {"left": 42.0, "right": 42.0, "up": 93.0, "down": -40.0}

var operator_anchor: Node2D
var equipment_anchor: Node2D
var _operator: Sprite2D
var _equipment: Sprite2D
var _sources: Array[Sprite2D] = []

func _ready() -> void:
	y_sort_enabled = true
	var ancestor := get_parent() as Node2D
	for index in range(3):
		ancestor.y_sort_enabled = true
		ancestor = ancestor.get_parent() as Node2D
	operator_anchor = Node2D.new()
	operator_anchor.name = "OperatorDepth"
	add_child(operator_anchor)
	equipment_anchor = Node2D.new()
	equipment_anchor.name = "EquipmentDepth"
	add_child(equipment_anchor)
	_operator = _make_part(operator_anchor, true)
	_equipment = _make_part(equipment_anchor, false)

func _make_part(anchor: Node2D, operator_part: bool) -> Sprite2D:
	var sprite := Sprite2D.new()
	var part := ShaderMaterial.new()
	part.shader = PART_SHADER
	part.set_shader_parameter("operator_part", operator_part)
	sprite.material = part
	anchor.add_child(sprite)
	return sprite

func update_frame(source: Sprite2D, direction: String, loaded: bool, empty_pallet := false) -> void:
	if not _sources.has(source):
		_sources.append(source)
		source.self_modulate.a = 0.0
	var frame_size := source.texture.get_size() / Vector2(source.hframes, source.vframes)
	var operator_rect := Vector4(0, 0, frame_size.x, frame_size.y)
	var cargo_rect := Vector4.ZERO
	match direction:
		"left":
			operator_rect.z = 135 if empty_pallet or loaded else 110
		"right":
			operator_rect.x = 165 if empty_pallet or loaded else 140
		"up":
			operator_rect.w = 140
			if loaded:
				cargo_rect = Vector4(161, 99, 300, 300)
		"down":
			operator_rect.y = 180
	operator_anchor.position.y = OPERATOR_GROUND - FOOT_OFFSET
	equipment_anchor.position.y = JACK_GROUND[direction] - FOOT_OFFSET
	for pair in [[operator_anchor, _operator], [equipment_anchor, _equipment]]:
		var anchor: Node2D = pair[0]
		var sprite: Sprite2D = pair[1]
		sprite.texture = source.texture
		sprite.texture_filter = source.texture_filter
		sprite.centered = source.centered
		sprite.offset = source.offset
		sprite.hframes = source.hframes
		sprite.vframes = source.vframes
		sprite.frame = source.frame
		sprite.transform = source.transform
		sprite.position -= anchor.position
		sprite.material.set_shader_parameter("frame_size", frame_size)
		sprite.material.set_shader_parameter("operator_rect", operator_rect)
		sprite.material.set_shader_parameter("cargo_rect", cargo_rect)
