extends Node

const HintRoute = preload("res://demo_hint_route.gd")
const DockGate = preload("res://dock_gate_interaction.gd")
const Unloading = preload("res://demo_unloading.gd")
const ReceivingSupplies = preload("res://demo_receiving_supplies.gd")
const PalletStock = preload("res://demo_pallet_stock.gd")
const Orientation = preload("res://warehouse_orientation_dialogue.gd")
const DirectorScene = preload("res://assets/npcs/warehouse_director.tscn")
const ORIENTATION_STAGES := ["find_director", "meet_shift_lead", "meet_receiving_lead", "orientation_complete"]
const ZPH_STAGES := ["open_gate_19", "find_free_transporter", "bring_transporter_to_gate19", "at_gate19_with_transporter", "unload_pickup", "unload_place", "check_gate_17", "report_receiving_lead", "zph_complete"]
const ZPH_REPORT := ["Спасибо за выполненную работу! На воротах 17 фура уже выгружена, а на воротах 19 ты выгрузил все двенадцать паллет. Оба поручения выполнены. Отличная работа!"]
const PALLET_STAGES := ["find_stock_jack", "find_pallet_stock", "deliver_empty_pallet", "empty_pallet_complete"]
const PREPARATION_STAGES := ["retrieve_empty_pallet", "find_blue_tote_stock", "deliver_blue_totes", "return_empty_pallet", "report_preparation", "preparation_complete", "blue_totes_complete"]
const PALLET_PROGRESS_STAGES := PALLET_STAGES + PREPARATION_STAGES
const PREPARATION_DIALOGUE := [
	"Спасибо, паллет доставлен! Приемка товара происходит на столах приемки: здесь товар проверяют, пересчитывают и принимают. Перед началом работы нужно запастись пустыми сетками и синими тарниками.",
	"Твое рабочее место - стол приемки №5. Начнем с тарников. На той же рохле забери паллет, который ты привез к моему рабочему месту. С ним отправляйся в зону складирования тарников, возьми одну стопку с паллета запаса и привези к столу №5, в выделенное место.",
	"Стопки и отдельные тарники вне зоны складирования лучше не брать: они могут быть в работе у других сотрудников. У стола оставь только стопку тарников, а пустой паллет верни в зону складирования паллет в блоке 3. Затем подъезжай ко мне и сообщи о выполнении.",
]
const PALLET_ASSIGNMENT := [
	"Теперь найди свободную рохлю и привези один пустой паллет в выделенную зону возле моего рабочего места. Паллет возьми из зоны складирования паллет: в третьем блоке их две, у левого и правого края.",
	"Паллеты, оставленные в других местах, могут быть в работе у сотрудников или просто оставлены без пояснения. Чтобы избежать недопониманий, пользуйся запасом в зонах складирования. Из стопки возьми только один паллет; можно взять и одиночный паллет в этой зоне.",
]
@export var orientation_only := false
const RECEIVING_LEAD_PATH := "YSortActors/FurnitureSprites/ChairWithNpcRight/InteractionArea"
const RECEIVING_SPEAKER := "Старший участка приемки"
const RECEIVING_STAGES := ["find_receiving_supervisor", "find_receiving_jack", "find_tote_stock", "deliver_totes", "totes_complete"]
const REPORT_DIALOGUE := [
	"Отличная работа! Фура полностью выгружена, все двенадцать паллет стоят на своих местах. Спасибо за аккуратность.",
	"Теперь подойди к старшему участка приемки за следующим поручением. Ее рабочее место справа от моего, у верхнего монитора.",
]
const RECEIVING_DIALOGUE := [
	"Привет! Я старший участка приемки. Слежу за тем, чтобы поступивший товар проверили, пересчитали и правильно приняли. Если обнаружишь повреждение или расхождение, сообщи мне.",
	"Твое рабочее место — стол приемки №5. Прежде чем приступать к товару, подготовь его: понадобятся синие тарники и две пустые сетки. Начнем с тарников.",
	"Найди свободную рохлю. Возьми одну стопку с паллета запаса: такие паллеты стоят у левого и правого края зоны приемки.",
	"Одиночные тарники и стопки без паллеты не бери: они могут быть заняты или находиться в работе. Привези свою стопку к столу №5 и поставь рядом с ним, в выделенное место. Пустые сетки подготовим следующим этапом.",
]
const SUPERVISOR_PATH := "YSortActors/FurnitureSprites/ChairWithNpcBack/InteractionArea"
const SUPERVISOR_MONITOR_PATH := "YSortActors/FurnitureSprites/Monitor"
const SUPERVISOR_APPROACH_OFFSET := Vector2(0, -20)
const SUPERVISOR_APPROACH_RADIUS := 24.0
const ASSIGNMENT := "Прибыл груз на 19 ворота, нужно выгрузить товар"
const FREE_TIME_ENABLED := true
const FREE_TIME_SECONDS := 60.0
const GATE_19_CELL := Vector2i(-69, -106)
const GATE_19_BUTTON_CELL := Vector2i(-67, -106)
const LOADED_GATE_ATLAS := Vector2i(0, 0)
const GATE_19_APPROACH_OFFSET := Vector2(0, 96)
const GATE_19_APPROACH_RADIUS := 56.0
const TRANSPORTER_TRAVEL_STAGES := ["bring_transporter_to_gate19", "at_gate19_with_transporter", "unload_pickup", "unload_place", "unload_complete"]
const UNLOADING_PICKUP_STAGES := ["at_gate19_with_transporter", "unload_pickup"]
const STAGES := ["find_supervisor", "free_time", "return_to_supervisor", "open_gate_19", "find_free_transporter", "bring_transporter_to_gate19", "at_gate19_with_transporter", "unload_pickup", "unload_place", "unload_complete", "find_receiving_supervisor", "find_receiving_jack", "find_tote_stock", "deliver_totes", "totes_complete"]
const LEGACY_STAGES := {
	"find_receiving_lead": "return_to_supervisor", "cargo_ready": "find_free_transporter",
	"find_free_jack": "find_free_transporter", "bring_jack_to_gate19": "bring_transporter_to_gate19",
	"at_gate19_with_jack": "at_gate19_with_transporter",
}
const SPEAKER := "Старший смены приемки и размещения"
const DIALOGUE := [
	"Добро пожаловать. Я старший смены приемки и размещения. Прежде чем начинать работу, познакомимся со складом.",
	"Мы во втором блоке. Здесь принимают поступивший товар и размещают его на хранение. В третьем блоке находятся упаковка, сортировка и отгрузка. В первом пока идут строительные работы.",
	"Рохли, паллетовозы и груз берут только для конкретного поручения. Для каждого задания я укажу, какую технику взять и куда доставить товар. Остальную технику пока не трогай.",
	"Хорошо, мы познакомились. Пока осмотрись и запомни, где находится мой стол." if FREE_TIME_ENABLED else "Хорошо, мы познакомились. У меня есть для тебя первое поручение.",
]

var completed := false
var hint_enabled := false
var stage := "find_supervisor"
var free_time_remaining := FREE_TIME_SECONDS
var assigned_vehicle := ""
var placed_count := 0
var gate17_checked := false
var _zph_assignment := false
var _supervisor_was_near := false
var _dialogue_index := 0
var _conversation_kind := "introduction"
var _modal_kind := ""
var _world: Node2D
var _player: CharacterBody2D
var _supervisor: Area2D
var _receiving_lead: Area2D
var _director: CharacterBody2D
var _gate19: Node
var _gate17: Node
var _route: Node2D
var _unloading: Node2D
var _supplies: Node2D
var _pallet_stock: Node2D
var _hud: Control
var _task_panel: PanelContainer
var _task_title: Label
var _objective: Label
var _hint_button: Button
var _task_box: VBoxContainer
var _task_hide: Button
var _task_restore: Button
var _mobile_task_collapsed := false
var _modal: ColorRect
var _dialog: PanelContainer
var _dialog_title: Label
var _dialog_text: Label
var _dialog_counter: Label
var _buttons: HBoxContainer
var _scroll: ScrollContainer

func _ready() -> void:
	_world = get_parent() as Node2D
	_player = _world.get_node("YSortActors/Player")
	_supervisor = _world.get_node(SUPERVISOR_PATH)
	_receiving_lead = _world.get_node(RECEIVING_LEAD_PATH)
	_gate17 = _world.get_node("DockGate17Interaction")
	_gate17.transition_finished.connect(_inspection_gate_finished)
	if orientation_only:
		stage = "find_director"
		free_time_remaining = 0
		_director = DirectorScene.instantiate()
		_director.name = "WarehouseDirector"
		_world.get_node("YSortActors").add_child(_director)
		_director.configure_director(_world)
	_player.register_demo_tasks(self)
	_create_hud()
	_create_delivery_gate()
	_unloading = Unloading.new()
	_unloading.name = "DemoUnloading"
	_world.get_node("FloorLayer2").add_child(_unloading)
	_supplies = ReceivingSupplies.new()
	_supplies.name = "DemoReceivingSupplies"
	_world.get_node("FloorLayer2").add_child(_supplies)
	_pallet_stock = PalletStock.new()
	_pallet_stock.name = "DemoPalletStock"
	_world.get_node("FloorLayer2").add_child(_pallet_stock)
	_route = HintRoute.new()
	_route.name = "DemoHintRoute"
	_route.process_physics_priority = 1
	_route.player = _player
	_route.destination = _current_target_point
	_world.get_node("FloorLayer2").add_child(_route)
	_route.set_enabled(false)
	_refresh_task()

func _exit_tree() -> void:
	if is_instance_valid(_director):
		_director.queue_free()
	if is_instance_valid(_player):
		_player.unregister_demo_tasks(self)
		if not _modal_kind.is_empty():
			_player.set_interaction_locked(false)
	if is_instance_valid(_route):
		_route.queue_free()
	if is_instance_valid(_gate19):
		_gate19.queue_free()
	if is_instance_valid(_unloading):
		_unloading.queue_free()
	if is_instance_valid(_supplies):
		_supplies.queue_free()
	if is_instance_valid(_pallet_stock):
		_pallet_stock.queue_free()

func _process(delta: float) -> void:
	if (not orientation_only or _zph_assignment) and not get_tree().paused and _modal_kind.is_empty() and not _player.get("_interaction_locked"):
		if _zph_assignment and not gate17_checked and _gate17.is_open and not _gate17._busy and _is_at_gate17(_player):
			_inspection_gate_finished(true)
		if stage == "free_time":
			free_time_remaining = maxf(0.0, free_time_remaining - delta) if FREE_TIME_ENABLED else 0.0
			if free_time_remaining <= 0.0:
				stage = "return_to_supervisor"
				_refresh_task()
		if stage == "return_to_supervisor":
			var near := _is_at_supervisor(_player)
			if near and not _supervisor_was_near:
				_show_assignment()
			_supervisor_was_near = near
		if stage == "bring_transporter_to_gate19":
			var jack := _assigned_vehicle()
			var feet := _player.global_position + HintRoute.FOOT_OFFSET
			if jack != null and _player.get("_carried_vehicle") == jack and feet.distance_to(gate19_approach_point()) <= GATE_19_APPROACH_RADIUS:
				stage = "unload_pickup" if placed_count > 0 else "at_gate19_with_transporter"
				_clear_hint()
				_refresh_task()
	_layout()
	_route.visible = hint_enabled and _has_active_target() and _modal_kind.is_empty()
	_update_task_visibility()

func _input(event: InputEvent) -> void:
	if _modal_kind.is_empty() or not event is InputEventKey or not event.pressed:
		return
	var key: Key = event.physical_keycode if event.physical_keycode != 0 else event.keycode
	if event.echo:
		if key in [KEY_E, KEY_ENTER, KEY_KP_ENTER, KEY_ESCAPE]:
			get_viewport().set_input_as_handled()
		return
	if key == KEY_ESCAPE:
		close_modal()
		get_viewport().set_input_as_handled()
	elif key in [KEY_E, KEY_ENTER, KEY_KP_ENTER] and _modal_kind in ["conversation", "assignment"]:
		if _modal_kind == "assignment":
			_accept_assignment()
		else:
			_advance_dialogue()
		get_viewport().set_input_as_handled()

func get_interaction_text(actor: Node2D) -> String:
	if not _modal_kind.is_empty():
		return ""
	if stage in PREPARATION_STAGES:
		if stage == "retrieve_empty_pallet" and _has_assigned_vehicle(actor) and _pallet_stock.can_take(actor):
			return "Привезенный паллет\nНажмите E или Enter, чтобы забрать паллет"
		if stage == "find_blue_tote_stock" and _has_assigned_vehicle(actor):
			if _supplies.nearby_source(actor) != null:
				return "Запас тарников\nНажмите E или Enter, чтобы взять стопку на свой паллет" if _player.can_load_pallet_jack_totes() else "Запас тарников\nДля стопки не хватает места. Отъедьте от препятствия или разверните рохлю."
			if not _supplies.single_stack_hint(actor).is_empty():
				return "Запас тарников"
			var loose_hint: String = _supplies.loose_tote_hint(actor)
			if not loose_hint.is_empty():
				return loose_hint
		if stage == "deliver_blue_totes":
			return "Стол приемки №5\nНажмите E или Enter, чтобы поставить стопку тарников" if _has_assigned_vehicle(actor) and _supplies.can_place(actor) else ""
		if stage == "return_empty_pallet" and _has_assigned_vehicle(actor) and _pallet_stock.nearby_return(actor) != null:
			return "Зона складирования паллет\nНажмите E или Enter, чтобы вернуть пустой паллет"
		return RECEIVING_SPEAKER + "\nНажмите E или Enter, чтобы поговорить" if _is_at_receiving_lead(actor) else ""
	if stage in PALLET_STAGES:
		if stage == "find_pallet_stock" and _has_assigned_vehicle(actor):
			if _pallet_stock.nearby_source(actor) != null:
				return "Зона складирования паллет\nНажмите E или Enter, чтобы взять один паллет" if _player.can_load_pallet_jack_totes() else "Зона складирования паллет\nДля паллета не хватает места. Отъедьте от препятствия или разверните рохлю."
			var loose_hint: String = _pallet_stock.loose_pallet_hint(actor)
			if not loose_hint.is_empty():
				return loose_hint
		if stage == "deliver_empty_pallet":
			return "Зона возле старшего участка\nНажмите E или Enter, чтобы поставить паллет" if _has_assigned_vehicle(actor) and _pallet_stock.can_place(actor) else ""
		if _is_at_receiving_lead(actor):
			return RECEIVING_SPEAKER + "\nНажмите E или Enter, чтобы поговорить"
		return ""
	if _zph_assignment:
		if _is_at_receiving_lead(actor):
			if stage == "report_receiving_lead" and actor.get("_carried_vehicle") != null:
				return RECEIVING_SPEAKER + "\nНажмите E или Enter, чтобы оставить паллетовоз перед разговором"
			return RECEIVING_SPEAKER + "\nНажмите E или Enter, чтобы поговорить"
		if _is_at_supervisor(actor):
			return SPEAKER + "\nНажмите E или Enter, чтобы поговорить"
		var inspection_hint: String = _gate17.get_interaction_text(actor)
		if not inspection_hint.is_empty():
			return "Ворота №17\n" + ("Фура разгружена.\n" if gate17_checked else "") + inspection_hint
	if orientation_only and not _zph_assignment:
		if is_instance_valid(_director) and _director.contains_actor(actor):
			return Orientation.DIRECTOR_SPEAKER + "\nНажмите E или Enter, чтобы с ним поговорить"
		if stage in ["meet_receiving_lead", "orientation_complete"] and _is_at_receiving_lead(actor):
			return RECEIVING_SPEAKER + "\nНажмите E или Enter, чтобы поговорить"
		if stage != "find_director" and _is_at_supervisor(actor):
			return SPEAKER + "\nНажмите E или Enter, чтобы поговорить"
		return ""
	if stage == "find_tote_stock" and _has_assigned_vehicle(actor):
		if _supplies.nearby_source(actor) != null:
			return "Запас тарников\nНажмите E или Enter, чтобы взять одну стопку" if _player.can_load_pallet_jack_totes() else "Запас тарников\nДля стопки не хватает места. Отъедьте от препятствия или разверните рохлю."
		var stock_hint: String = _supplies.single_stack_hint(actor)
		if stock_hint.is_empty():
			stock_hint = _supplies.loose_tote_hint(actor)
		if not stock_hint.is_empty():
			return stock_hint
	if stage == "deliver_totes":
		return "Стол приемки №5\nНажмите E или Enter, чтобы поставить стопку тарников" if _has_assigned_vehicle(actor) and _supplies.can_place(actor) else ""
	if stage in RECEIVING_STAGES and _is_at_receiving_lead(actor):
		return RECEIVING_SPEAKER + "\nНажмите E или Enter, чтобы поговорить"
	if stage in UNLOADING_PICKUP_STAGES and _has_assigned_vehicle(actor) and _is_at_gate19(actor):
		if not _player.can_load_transporter_cargo():
			return "Ворота №19\nДля паллета не хватает места. Отъедьте от препятствия или разверните паллетовоз."
		return "Ворота №19\nНажмите E или Enter, чтобы забрать паллет"
	if stage == "unload_place" and _has_assigned_vehicle(actor) and _unloading.can_place(actor):
		return "Разметка №%d\nНажмите E или Enter, чтобы поставить паллет" % (placed_count + 1)
	if stage == "open_gate_19":
		var gate_hint: String = _gate19.get_interaction_text(actor)
		if not gate_hint.is_empty():
			return gate_hint
	if _zph_assignment or not _is_at_supervisor(actor):
		return ""
	if stage == "unload_complete" and actor.get("_carried_vehicle") != null:
		return SPEAKER + "\nНажмите E или Enter, чтобы оставить паллетовоз перед разговором"
	return SPEAKER + "\nНажмите E или Enter, чтобы поговорить"

func _is_at_receiving_lead(actor: Node2D) -> bool:
	return _receiving_lead.contains_actor(actor)

func _is_at_supervisor(actor: Node2D) -> bool:
	var shape := _supervisor.get_node("CollisionShape2D") as CollisionShape2D
	if not _supervisor.is_visible_in_tree() or shape.disabled:
		return false
	var at_approach := (actor.global_position + HintRoute.FOOT_OFFSET).distance_to(supervisor_point()) <= SUPERVISOR_APPROACH_RADIUS
	return at_approach or _supervisor.contains_actor(actor)

func try_interact(actor: Node2D) -> bool:
	if not _modal_kind.is_empty() or actor.get("_interaction_locked"):
		return false
	if stage in PREPARATION_STAGES:
		if stage == "retrieve_empty_pallet" and _has_assigned_vehicle(actor) and _pallet_stock.can_take(actor):
			_gate19.play_transition(_retrieve_empty_pallet)
			return true
		if stage == "find_blue_tote_stock" and _has_assigned_vehicle(actor):
			var cell: Variant = _supplies.nearby_source(actor)
			if cell != null:
				if _player.pallet_jack_pallet_loaded and _player.can_load_pallet_jack_totes():
					_gate19.play_transition(_take_blue_totes.bind(cell))
				return true
			if not _supplies.single_stack_hint(actor).is_empty() or not _supplies.loose_tote_hint(actor).is_empty():
				return true
		if stage == "deliver_blue_totes":
			if _has_assigned_vehicle(actor) and _supplies.can_place(actor) and _player.set_pallet_jack_pallet(true):
				_supplies.set_progress(_supplies.picked_source, true)
				stage = "return_empty_pallet"
				_clear_hint()
				_refresh_task()
			return true
		if stage == "return_empty_pallet":
			var cell: Variant = _pallet_stock.nearby_return(actor) if _has_assigned_vehicle(actor) else null
			if cell != null:
				_gate19.play_transition(_return_empty_pallet.bind(cell))
				return true
		if _is_at_receiving_lead(actor):
			_start_conversation("receiving_preparation_progress")
			return true
		return false
	if stage in PALLET_STAGES:
		if stage == "find_pallet_stock" and _has_assigned_vehicle(actor):
			var cell: Variant = _pallet_stock.nearby_source(actor)
			if cell != null:
				if _player.can_load_pallet_jack_totes():
					_gate19.play_transition(_take_empty_pallet.bind(cell))
				return true
			if not _pallet_stock.loose_pallet_hint(actor).is_empty():
				return true
		if stage == "deliver_empty_pallet":
			if _has_assigned_vehicle(actor) and _pallet_stock.can_place(actor):
				_player.set_pallet_jack_pallet(false)
				_pallet_stock.set_progress(_pallet_stock.picked_source, true)
				stage = "empty_pallet_complete"
				_clear_hint()
				_refresh_task()
			return true
		if _is_at_receiving_lead(actor):
			_start_conversation("receiving_preparation" if stage == "empty_pallet_complete" else "pallet_progress")
			return true
		return false
	if _zph_assignment:
		if _is_at_receiving_lead(actor):
			if stage == "report_receiving_lead" and actor.get("_carried_vehicle") != null:
				return false
			_start_conversation("pallet_assignment" if stage == "zph_complete" else "zph_report" if stage == "report_receiving_lead" else "zph_progress")
			return true
		if _is_at_supervisor(actor):
			_start_conversation("shift_orientation")
			return true
		if _gate17.try_interact(actor):
			return true
	if orientation_only and not _zph_assignment:
		if is_instance_valid(_director) and _director.contains_actor(actor):
			_start_conversation("director_orientation")
			return true
		if stage in ["meet_receiving_lead", "orientation_complete"] and _is_at_receiving_lead(actor):
			_start_conversation("receiving_orientation")
			return true
		if stage != "find_director" and _is_at_supervisor(actor):
			_start_conversation("shift_orientation")
			return true
		return false
	if stage == "find_tote_stock" and _has_assigned_vehicle(actor):
		var cell: Variant = _supplies.nearby_source(actor)
		if cell != null:
			if _player.set_pallet_jack_totes(true):
				_supplies.set_progress(cell, false)
				stage = "deliver_totes"
				_clear_hint()
				_refresh_task()
			return true
		if not _supplies.single_stack_hint(actor).is_empty() or not _supplies.loose_tote_hint(actor).is_empty():
			return true
	if stage == "deliver_totes":
		if _has_assigned_vehicle(actor) and _supplies.can_place(actor):
			_player.set_pallet_jack_totes(false)
			_supplies.set_progress(_supplies.picked_source, true)
			stage = "totes_complete"
			_clear_hint()
			_refresh_task()
		return true
	if stage in RECEIVING_STAGES and _is_at_receiving_lead(actor):
		_start_conversation("receiving_intro" if stage == "find_receiving_supervisor" else "receiving_progress")
		return true
	if stage in UNLOADING_PICKUP_STAGES and _has_assigned_vehicle(actor) and _is_at_gate19(actor):
		if _player.can_load_transporter_cargo():
			_gate19.play_transition(_take_truck_pallet)
		return true
	if stage == "unload_place":
		if _has_assigned_vehicle(actor) and _unloading.can_place(actor):
			_player.set_transporter_cargo(false)
			placed_count += 1
			stage = "unload_complete" if placed_count == Unloading.PALLET_COUNT else "unload_pickup"
			if _zph_assignment and placed_count == Unloading.PALLET_COUNT:
				stage = "report_receiving_lead" if gate17_checked else "check_gate_17"
			_sync_unloading()
			_clear_hint()
			_refresh_task()
		return true
	if stage == "open_gate_19" and _gate19.try_interact(actor):
		return true
	if stage == "return_to_supervisor" and _is_at_supervisor(actor):
		_supervisor_was_near = true
		_show_assignment()
		return true
	if _zph_assignment or not _is_at_supervisor(actor):
		return false
	if stage == "unload_complete" and actor.get("_carried_vehicle") != null:
		return false
	_start_conversation("unload_report" if stage == "unload_complete" or stage in RECEIVING_STAGES else "introduction")
	return true

func _start_conversation(kind: String) -> void:
	if kind == "director_orientation":
		_director.set_conversation_locked(true, _player)
	_conversation_kind = kind
	_dialogue_index = 0
	_open_modal("conversation")
	_show_dialogue_page()

func can_use_vehicle(vehicle: PickupVehicle) -> bool:
	if orientation_only and not _zph_assignment:
		return false
	if stage in PREPARATION_STAGES:
		return stage in ["retrieve_empty_pallet", "report_preparation", "preparation_complete", "blue_totes_complete"] and vehicle == _assigned_vehicle()
	if stage in PALLET_STAGES:
		if vehicle.vehicle_mode != PickupVehicle.VehicleMode.PALLET_JACK or vehicle.get_parent() != _world.get_node("YSortActors/PalletJackAssets"):
			return false
		if stage == "find_stock_jack":
			return not vehicle.is_carried and vehicle.is_visible_in_tree()
		return stage in ["find_pallet_stock", "empty_pallet_complete"] and vehicle == _assigned_vehicle()
	if _zph_assignment and stage in ["check_gate_17", "report_receiving_lead"]:
		return vehicle == _assigned_vehicle()
	if stage in RECEIVING_STAGES:
		if vehicle.vehicle_mode != PickupVehicle.VehicleMode.PALLET_JACK or vehicle.get_parent() != _world.get_node("YSortActors/PalletJackAssets"):
			return false
		if stage == "find_receiving_jack":
			return not vehicle.is_carried and vehicle.is_visible_in_tree()
		return stage in ["find_tote_stock", "totes_complete"] and vehicle == _assigned_vehicle()
	if vehicle.vehicle_mode != PickupVehicle.VehicleMode.TRANSPORTER or vehicle.get_parent() != _world.get_node("YSortActors/TransporterSprites"):
		return false
	if stage == "find_free_transporter":
		return not vehicle.is_carried and vehicle.is_visible_in_tree()
	return stage in TRANSPORTER_TRAVEL_STAGES and stage != "unload_place" and vehicle == _assigned_vehicle()

func on_vehicle_picked_up(vehicle: PickupVehicle) -> void:
	if stage in PALLET_PROGRESS_STAGES:
		if stage == "find_stock_jack":
			assigned_vehicle = str(_world.get_path_to(vehicle))
			stage = "find_pallet_stock"
			_clear_hint()
		_refresh_task()
		return
	if stage == "find_receiving_jack":
		assigned_vehicle = str(_world.get_path_to(vehicle))
		stage = "find_tote_stock"
		_clear_hint()
		_refresh_task()
		return
	var first_pickup := stage == "find_free_transporter"
	assigned_vehicle = str(_world.get_path_to(vehicle))
	if first_pickup or stage == "bring_transporter_to_gate19":
		stage = "bring_transporter_to_gate19"
	if first_pickup:
		_clear_hint()
	_refresh_task()

func on_vehicle_dropped(vehicle: PickupVehicle) -> void:
	if stage in RECEIVING_STAGES + PALLET_PROGRESS_STAGES:
		_refresh_task()
		return
	if stage in TRANSPORTER_TRAVEL_STAGES and vehicle == _assigned_vehicle():
		if stage in ["bring_transporter_to_gate19", "at_gate19_with_transporter"]:
			stage = "bring_transporter_to_gate19"
		_refresh_task()

func _has_assigned_vehicle(actor: Node2D) -> bool:
	var jack := _assigned_vehicle()
	return jack != null and actor.get("_carried_vehicle") == jack

func _is_at_gate19(actor: Node2D) -> bool:
	return (actor.global_position + HintRoute.FOOT_OFFSET).distance_to(gate19_approach_point()) <= GATE_19_APPROACH_RADIUS

func _is_at_gate17(actor: Node2D) -> bool:
	var button: Vector2 = _gate17.objects.to_global(_gate17.objects.map_to_local(_gate17.button_cell))
	return (actor.global_position + HintRoute.FOOT_OFFSET).distance_to(button) <= _gate17.proximity

func _take_truck_pallet() -> void:
	if stage in UNLOADING_PICKUP_STAGES and _has_assigned_vehicle(_player) and _player.set_transporter_cargo(true):
		stage = "unload_place"
		_sync_unloading()
		_clear_hint()
		_refresh_task()

func _start_zph_assignment() -> void:
	_zph_assignment = true
	completed = true
	gate17_checked = false
	stage = "open_gate_19"
	free_time_remaining = 0
	_clear_hint()

func _start_pallet_assignment() -> void:
	stage = "find_stock_jack"
	assigned_vehicle = ""
	_clear_hint()

func _take_empty_pallet(cell: Vector2i) -> void:
	if stage == "find_pallet_stock" and _has_assigned_vehicle(_player) and _pallet_stock.nearby_source(_player) == cell and _player.set_pallet_jack_pallet(true):
		_pallet_stock.set_progress(cell, false)
		stage = "deliver_empty_pallet"
		_clear_hint()
		_refresh_task()

func _retrieve_empty_pallet() -> void:
	if stage == "retrieve_empty_pallet" and _has_assigned_vehicle(_player) and _pallet_stock.can_take(_player) and _player.set_pallet_jack_pallet(true, false, _pallet_stock.pickup_exclusions()):
		_pallet_stock.set_progress(_pallet_stock.picked_source, false)
		stage = "find_blue_tote_stock"
		_clear_hint()
		_refresh_task()

func _take_blue_totes(cell: Vector2i) -> void:
	if stage == "find_blue_tote_stock" and _has_assigned_vehicle(_player) and _player.pallet_jack_pallet_loaded and _supplies.nearby_source(_player) == cell and _player.set_pallet_jack_totes(true):
		_supplies.set_progress(cell, false)
		stage = "deliver_blue_totes"
		_clear_hint()
		_refresh_task()

func _return_empty_pallet(cell: Vector2i) -> void:
	if stage == "return_empty_pallet" and _has_assigned_vehicle(_player) and _pallet_stock.can_return(_player, cell):
		_player.set_pallet_jack_pallet(false)
		_pallet_stock.set_progress(_pallet_stock.picked_source, false, cell)
		stage = "report_preparation"
		_clear_hint()
		_refresh_task()

func _inspection_gate_finished(opened: bool) -> void:
	if not opened or not _zph_assignment or gate17_checked or not _is_at_gate17(_player):
		return
	if _gate17.dock.get_cell_atlas_coords(_gate17.gate_cell) != DockGate.OPEN_GATE:
		return
	gate17_checked = true
	if stage == "check_gate_17":
		stage = "report_receiving_lead"
		_clear_hint()
	_refresh_task()

func remaining_pallets() -> int:
	return Unloading.PALLET_COUNT - placed_count - (1 if stage == "unload_place" else 0)

func _sync_unloading() -> void:
	_unloading.set_placed_count(placed_count)
	if _gate19.is_open:
		_gate19.dock.set_cell(GATE_19_CELL, _gate19._gate_source, Unloading.gate_atlas(remaining_pallets()), _gate19._gate_alternative)
		_gate19.dock.update_internals()

func _assigned_vehicle() -> PickupVehicle:
	return _world.get_node_or_null(NodePath(assigned_vehicle)) as PickupVehicle if not assigned_vehicle.is_empty() else null

func get_vehicle_hint(vehicle: PickupVehicle) -> String:
	if vehicle.vehicle_mode == PickupVehicle.VehicleMode.PALLET_JACK:
		return "Рохля\nНа данный момент рохля доступна только по поручению старшего"
	return "Паллетовоз\nНа данный момент техника доступна только по поручению старшего."

func supervisor_point() -> Vector2:
	var monitor := _world.get_node(SUPERVISOR_MONITOR_PATH) as Node2D
	return monitor.global_position + SUPERVISOR_APPROACH_OFFSET

func gate19_approach_point() -> Vector2:
	return _gate19.dock.to_global(_gate19.dock.map_to_local(GATE_19_CELL)) + GATE_19_APPROACH_OFFSET

func nearest_free_transporter() -> PickupVehicle:
	return _nearest_free_vehicle("YSortActors/TransporterSprites", PickupVehicle.VehicleMode.TRANSPORTER)

func nearest_free_pallet_jack() -> PickupVehicle:
	return _nearest_free_vehicle("YSortActors/PalletJackAssets", PickupVehicle.VehicleMode.PALLET_JACK)

func _nearest_free_vehicle(parent: String, mode: int) -> PickupVehicle:
	var nearest: PickupVehicle
	var distance := INF
	var feet := _player.global_position + HintRoute.FOOT_OFFSET
	for child in _world.get_node(parent).get_children():
		var jack := child as PickupVehicle
		if jack == null or jack.vehicle_mode != mode or jack.is_carried or not jack.is_visible_in_tree():
			continue
		var candidate_distance := feet.distance_squared_to(jack.interaction_area.global_position)
		if candidate_distance < distance:
			nearest = jack
			distance = candidate_distance
	return nearest

func _current_target_point() -> Variant:
	if stage in PREPARATION_STAGES:
		if stage in ["preparation_complete", "blue_totes_complete"]:
			return null
		if stage == "report_preparation":
			return _receiving_lead.global_position
		if not _has_assigned_vehicle(_player):
			var jack := _assigned_vehicle()
			return jack.interaction_area.global_position if jack != null else null
		if stage == "retrieve_empty_pallet":
			return _pallet_stock.delivery_point()
		if stage == "deliver_blue_totes":
			return _supplies.delivery_point()
		if stage == "return_empty_pallet":
			var cell: Variant = _pallet_stock.nearest_return(_player)
			return _pallet_stock.source_point(cell) if cell != null else null
		var cell: Variant = _supplies.nearest_source(_player)
		return _supplies.source_point(cell) if cell != null else null
	if stage in PALLET_STAGES:
		if stage == "empty_pallet_complete":
			return _receiving_lead.global_position
		if stage == "find_stock_jack":
			var jack := nearest_free_pallet_jack()
			return jack.interaction_area.global_position if jack != null else null
		if not _has_assigned_vehicle(_player):
			var jack := _assigned_vehicle()
			return jack.interaction_area.global_position if jack != null else null
		if stage == "deliver_empty_pallet":
			return _pallet_stock.delivery_point()
		var cell: Variant = _pallet_stock.nearest_source(_player)
		return _pallet_stock.source_point(cell) if cell != null else null
	if _zph_assignment:
		if stage == "check_gate_17":
			return _gate17.objects.to_global(_gate17.objects.map_to_local(_gate17.button_cell))
		if stage == "report_receiving_lead":
			return _receiving_lead.global_position
		if stage == "zph_complete":
			return null
	if orientation_only and not _zph_assignment:
		match stage:
			"find_director":
				return _director.global_position + HintRoute.FOOT_OFFSET if is_instance_valid(_director) and _director.initialized else null
			"meet_shift_lead":
				return supervisor_point()
			"meet_receiving_lead":
				return _receiving_lead.global_position
		return null
	if stage == "find_receiving_supervisor":
		return _receiving_lead.global_position
	if stage == "find_receiving_jack":
		var jack := nearest_free_pallet_jack()
		return jack.interaction_area.global_position if jack != null else null
	if stage == "find_tote_stock":
		if not _has_assigned_vehicle(_player):
			var jack := _assigned_vehicle()
			return jack.interaction_area.global_position if jack != null else null
		var cell: Variant = _supplies.nearest_source(_player)
		return _supplies.source_point(cell) if cell != null else null
	if stage == "deliver_totes":
		return _supplies.delivery_point()
	if stage == "unload_place":
		return _unloading.target_point()
	if stage in UNLOADING_PICKUP_STAGES:
		var jack := _assigned_vehicle()
		return gate19_approach_point() if _has_assigned_vehicle(_player) else (jack.interaction_area.global_position if jack != null else null)
	if stage == "bring_transporter_to_gate19":
		var jack := _assigned_vehicle()
		if jack == null:
			return null
		return gate19_approach_point() if _player.get("_carried_vehicle") == jack else jack.interaction_area.global_position
	if stage == "find_free_transporter":
		var jack := nearest_free_transporter()
		return jack.interaction_area.global_position if jack != null else null
	if stage == "open_gate_19":
		return _gate19.objects.to_global(_gate19.objects.map_to_local(GATE_19_BUTTON_CELL))
	return supervisor_point()

func _has_active_target() -> bool:
	if stage in PREPARATION_STAGES:
		return stage not in ["preparation_complete", "blue_totes_complete"]
	if stage in PALLET_STAGES:
		return true
	if _zph_assignment:
		return stage != "zph_complete"
	if orientation_only:
		return stage != "orientation_complete"
	return stage not in ["free_time", "totes_complete"]

func _create_delivery_gate() -> void:
	_gate19 = DockGate.new()
	_gate19.name = "DockGate19Interaction"
	_gate19.gate_cell = GATE_19_CELL
	_gate19.button_cell = GATE_19_BUTTON_CELL
	_gate19.open_gate_atlas = LOADED_GATE_ATLAS
	_gate19.allow_closing = false
	_gate19.register_with_player = false
	_world.add_child(_gate19)
	_gate19.transition_finished.connect(_delivery_gate_finished)

func _show_assignment() -> void:
	_open_modal("assignment")
	_dialog_title.text = SPEAKER
	_dialog_title.add_theme_color_override("font_color", Color("ff6868"))
	_dialog_text.text = ASSIGNMENT
	_dialog_counter.hide()
	_clear_buttons()
	_button("Понятно", _accept_assignment, true).grab_focus()
	_scroll.scroll_vertical = 0

func _accept_assignment() -> void:
	stage = "open_gate_19"
	_clear_hint()
	close_modal()
	_refresh_task()

func _delivery_gate_finished(opened: bool) -> void:
	if opened and stage == "open_gate_19":
		stage = "find_free_transporter"
		_clear_hint()
		_refresh_task()

func _clear_hint() -> void:
	hint_enabled = false
	_route.set_enabled(false)

func request_hint() -> void:
	if not _has_active_target() or not _modal_kind.is_empty() or _player.get("_interaction_locked"):
		return
	_open_modal("hint")
	_dialog_title.text = "Показать путь"
	_dialog_title.add_theme_color_override("font_color", Color("f2cc45"))
	_dialog_text.text = "Вы точно не сможете найти самостоятельно?"
	_dialog_counter.hide()
	_clear_buttons()
	var no := _button("Смогу", _decline_hint, false)
	_button("Да", _accept_hint, true)
	no.grab_focus()

func _decline_hint() -> void:
	close_modal()

func _accept_hint() -> void:
	hint_enabled = true
	close_modal()
	_route.set_enabled(true)
	_refresh_task()

func _advance_dialogue() -> void:
	if _dialogue_index + 1 < _dialogue_pages().size():
		_dialogue_index += 1
		_show_dialogue_page()
	else:
		if _conversation_kind == "receiving_preparation" and stage == "empty_pallet_complete":
			stage = "retrieve_empty_pallet"
			_clear_hint()
		elif _conversation_kind == "receiving_preparation_progress" and stage == "report_preparation":
			stage = "preparation_complete"
			_clear_hint()
		elif (_conversation_kind == "zph_report" and stage == "report_receiving_lead") or (_conversation_kind == "pallet_assignment" and stage == "zph_complete"):
			_start_pallet_assignment()
		elif orientation_only:
			var next := {"director_orientation": ["find_director", "meet_shift_lead"], "shift_orientation": ["meet_shift_lead", "meet_receiving_lead"], "receiving_orientation": ["meet_receiving_lead", "orientation_complete"]}
			var transition: Array = next.get(_conversation_kind, [])
			if transition.size() == 2 and stage == transition[0]:
				stage = transition[1]
				completed = stage == "orientation_complete"
				_clear_hint()
				if stage == "orientation_complete":
					_start_zph_assignment()
		elif _conversation_kind == "unload_report" and stage == "unload_complete":
			stage = "find_receiving_supervisor"
			assigned_vehicle = ""
			_clear_hint()
		elif _conversation_kind == "receiving_intro" and stage == "find_receiving_supervisor":
			stage = "find_receiving_jack"
			_clear_hint()
		elif _conversation_kind == "introduction" and not completed:
			completed = true
			stage = "free_time" if FREE_TIME_ENABLED else "return_to_supervisor"
			free_time_remaining = FREE_TIME_SECONDS if FREE_TIME_ENABLED else 0.0
			_supervisor_was_near = not FREE_TIME_ENABLED and _is_at_supervisor(_player)
			_clear_hint()
		close_modal()
		_refresh_task()

func _show_dialogue_page() -> void:
	var pages := _dialogue_pages()
	_dialog_title.text = Orientation.DIRECTOR_SPEAKER if _conversation_kind == "director_orientation" else (RECEIVING_SPEAKER if _conversation_kind.begins_with("receiving") or _conversation_kind.begins_with("zph") or _conversation_kind.begins_with("pallet") else SPEAKER)
	_dialog_title.add_theme_color_override("font_color", Color("ff6868"))
	_dialog_text.text = pages[_dialogue_index]
	_dialog_counter.text = "%d / %d" % [_dialogue_index + 1, pages.size()]
	_dialog_counter.show()
	_clear_buttons()
	var next := _button("Закончить разговор" if _dialogue_index == pages.size() - 1 else "Далее", _advance_dialogue, true)
	next.grab_focus()
	_scroll.scroll_vertical = 0

func _dialogue_pages() -> Array:
	match _conversation_kind:
		"director_orientation":
			return Orientation.DIRECTOR
		"shift_orientation":
			return Orientation.SHIFT_LEAD
		"receiving_orientation":
			return Orientation.RECEIVING_LEAD
		"zph_report":
			return ZPH_REPORT + PALLET_ASSIGNMENT
		"pallet_assignment":
			return PALLET_ASSIGNMENT
		"pallet_progress":
			return ["Спасибо! Пустой паллет доставлен в нужную зону возле моего рабочего места."] if stage == "empty_pallet_complete" else PALLET_ASSIGNMENT
		"receiving_preparation":
			return PREPARATION_DIALOGUE
		"receiving_preparation_progress":
			if stage in ["report_preparation", "preparation_complete"]:
				return [
					"Спасибо за выполненную работу! Стопка синих тарников у стола приемки №5, пустой паллет возвращен в зону складирования. Все сделано правильно.",
					"На этом пока что все, в ожидании новых поручений, можешь походить по операционной зоне и посмотреть, как здесь все устроено",
				]
			return ["Тарники у стола №5. Теперь верни пустой паллет в зону складирования в блоке 3 и подъезжай ко мне."] if stage == "return_empty_pallet" else PREPARATION_DIALOGUE
		"zph_progress":
			return ["Выгрузи все двенадцать паллет на воротах 19 и проверь, выгружена ли фура на воротах 17. После выполнения обоих поручений подойди ко мне и сообщи результат."]
		"unload_report":
			return REPORT_DIALOGUE
		"receiving_intro":
			return RECEIVING_DIALOGUE
		"receiving_progress":
			return ["Тарники у стола №5, первая часть подготовки готова. Следующим этапом займемся пустыми сетками."] if stage == "totes_complete" else ["Привези одну стопку синих тарников с паллета запаса к столу приемки №5. Нужна свободная рохля; отдельные тарники и стопки без паллеты оставь на месте."]
	return DIALOGUE

func _open_modal(kind: String) -> void:
	_modal_kind = kind
	_player.set_interaction_locked(true)
	_task_panel.hide()
	_task_restore.hide()
	_modal.show()
	_route.hide()

func close_modal() -> void:
	if _modal_kind.is_empty():
		return
	if _modal_kind == "conversation" and _conversation_kind == "director_orientation" and is_instance_valid(_director):
		_director.set_conversation_locked(false)
	_modal_kind = ""
	_modal.hide()
	_update_task_visibility()
	_player.set_interaction_locked(false)
	if _hud.get_viewport().gui_get_focus_owner() != null:
		_hud.get_viewport().gui_get_focus_owner().release_focus()

func get_save_state() -> Dictionary:
	var state := {"completed": completed, "hint_enabled": hint_enabled, "stage": stage,
		"free_time_remaining": free_time_remaining, "gate19_open": _gate19.is_open, "assigned_vehicle": assigned_vehicle, "placed_count": placed_count,
		"tote_source": [] if _supplies.picked_source == ReceivingSupplies.NO_SOURCE else [_supplies.picked_source.x, _supplies.picked_source.y], "totes_delivered": _supplies.delivered}
	if _zph_assignment:
		state.zph_assignment = true
		state.gate17_checked = gate17_checked
	if stage in PALLET_PROGRESS_STAGES:
		state.pallet_source = [] if _pallet_stock.picked_source == PalletStock.NO_SOURCE else [_pallet_stock.picked_source.x, _pallet_stock.picked_source.y]
		state.pallet_delivered = _pallet_stock.delivered
		state.pallet_return = [] if _pallet_stock.returned_source == PalletStock.NO_SOURCE else [_pallet_stock.returned_source.x, _pallet_stock.returned_source.y]
	return state

func restore_save_state(state: Dictionary) -> void:
	close_modal()
	_zph_assignment = state.get("zph_assignment", false)
	gate17_checked = state.get("gate17_checked", false) if _zph_assignment else false
	if orientation_only and not _zph_assignment:
		# Earlier work assignments are retained on disk but no longer launch in this tour.
		_pallet_stock.set_progress(PalletStock.NO_SOURCE, false)
		stage = state.get("stage", "find_director")
		if stage not in ORIENTATION_STAGES:
			stage = "find_director"
		if stage == "orientation_complete":
			stage = "meet_receiving_lead"
		completed = stage == "orientation_complete"
		assigned_vehicle = ""
		placed_count = 0
		free_time_remaining = 0
		var vehicle = _player.get("_carried_vehicle")
		if is_instance_valid(vehicle):
			vehicle.set_carried(false)
			_player._carried_vehicle = null
		_player.set_move_mode(_player.MoveMode.ON_FOOT)
		hint_enabled = state.hint_enabled and _has_active_target()
		_route.set_enabled(hint_enabled)
		_refresh_task()
		return
	completed = state.completed
	# Earlier demo saves contained only the introduction and its optional hint.
	stage = state.get("stage", "free_time" if completed else "find_supervisor")
	stage = LEGACY_STAGES.get(stage, stage)
	assigned_vehicle = state.get("assigned_vehicle", "")
	placed_count = int(state.get("placed_count", 0))
	if stage == "unload_complete" and placed_count < Unloading.PALLET_COUNT:
		stage = "unload_pickup" if not assigned_vehicle.is_empty() else "find_free_transporter"
	free_time_remaining = float(state.get("free_time_remaining", FREE_TIME_SECONDS))
	if stage == "free_time" and not FREE_TIME_ENABLED:
		stage = "return_to_supervisor"
		free_time_remaining = 0.0
	_supervisor_was_near = stage == "return_to_supervisor" and _is_at_supervisor(_player)
	_gate19.restore_save_state(state.get("gate19_open", false))
	_player.set_transporter_cargo(stage == "unload_place", true)
	_player.set_pallet_jack_totes(stage in ["deliver_totes", "deliver_blue_totes"], true)
	_player.set_pallet_jack_pallet(stage in ["deliver_empty_pallet", "find_blue_tote_stock", "return_empty_pallet"], true)
	_sync_unloading()
	var source: Array = state.get("tote_source", [])
	_supplies.set_progress(Vector2i(int(source[0]), int(source[1])) if source.size() == 2 else ReceivingSupplies.NO_SOURCE, state.get("totes_delivered", false))
	var pallet_source: Array = state.get("pallet_source", [])
	var pallet_return: Array = state.get("pallet_return", [])
	_pallet_stock.set_progress(Vector2i(int(pallet_source[0]), int(pallet_source[1])) if pallet_source.size() == 2 else PalletStock.NO_SOURCE, state.get("pallet_delivered", false), Vector2i(int(pallet_return[0]), int(pallet_return[1])) if pallet_return.size() == 2 else PalletStock.NO_SOURCE)
	_player._apply_collision_profile(_player.last_direction)
	hint_enabled = state.hint_enabled and _has_active_target()
	_route.set_enabled(hint_enabled)
	_refresh_task()

static func valid_save_state(state: Variant) -> bool:
	if not state is Dictionary or not state.get("completed") is bool or not state.get("hint_enabled") is bool:
		return false
	if not state.get("zph_assignment", false) is bool or not state.get("gate17_checked", false) is bool:
		return false
	if state.get("gate17_checked", false) and not state.get("zph_assignment", false):
		return false
	var placed: Variant = state.get("placed_count", 0)
	if not (placed is int or placed is float) or not is_finite(float(placed)) or placed != int(placed) or placed < 0 or placed > Unloading.PALLET_COUNT:
		return false
	if state.has("assigned_vehicle") and state.has("assigned_jack"):
		return false
	var jack_path: Variant = state.get("assigned_vehicle", state.get("assigned_jack", ""))
	if not jack_path is String:
		return false
	var receiving: bool = state.get("stage", "") in RECEIVING_STAGES + PREPARATION_STAGES
	var pallet_task: bool = state.get("stage", "") in PALLET_PROGRESS_STAGES
	var vehicle_parent := "YSortActors/PalletJackAssets/" if receiving or pallet_task or state.has("assigned_jack") else "YSortActors/TransporterSprites/"
	if not jack_path.is_empty() and (not jack_path.begins_with(vehicle_parent) or jack_path.count("/") != 2 or jack_path.contains("..") or jack_path.contains(":") or jack_path.ends_with("/")):
		return false
	var tote_source: Variant = state.get("tote_source", [])
	if not tote_source is Array or tote_source.size() not in [0, 2] or not state.get("totes_delivered", false) is bool:
		return false
	if tote_source.size() == 2:
		for number in tote_source:
			if not (number is int or number is float) or not is_finite(float(number)) or absf(number) > 1000 or number != int(number):
				return false
		if Vector2i(int(tote_source[0]), int(tote_source[1])) not in ReceivingSupplies.STOCK_CELLS:
			return false
	if not receiving and (not tote_source.is_empty() or state.get("totes_delivered", false)):
		return false
	var pallet_source: Variant = state.get("pallet_source", [])
	if not pallet_source is Array or pallet_source.size() not in [0, 2] or not state.get("pallet_delivered", false) is bool:
		return false
	if pallet_source.size() == 2:
		for number in pallet_source:
			if not (number is int or number is float) or not is_finite(float(number)) or absf(number) > 1000 or number != int(number):
				return false
		if Vector2i(int(pallet_source[0]), int(pallet_source[1])) not in PalletStock.STOCK_CELLS:
			return false
	if not pallet_task and (not pallet_source.is_empty() or state.get("pallet_delivered", false)):
		return false
	var pallet_return: Variant = state.get("pallet_return", [])
	if not pallet_return is Array or pallet_return.size() not in [0, 2]:
		return false
	if pallet_return.size() == 2:
		for number in pallet_return:
			if not (number is int or number is float) or not is_finite(float(number)) or absf(number) > 1000 or number != int(number):
				return false
		if Vector2i(int(pallet_return[0]), int(pallet_return[1])) not in PalletStock.STOCK_CELLS:
			return false
	if (state.get("stage", "") in ["report_preparation", "preparation_complete"]) != (pallet_return.size() == 2):
		return false
	if not state.has("stage"):
		return not state.has("free_time_remaining") and not state.has("gate19_open") and jack_path.is_empty() and placed == 0
	if not state.stage is String or not state.get("gate19_open") is bool:
		return false
	var saved_stage: String = LEGACY_STAGES.get(state.stage, state.stage)
	if saved_stage not in STAGES + ORIENTATION_STAGES + ZPH_STAGES + PALLET_PROGRESS_STAGES:
		return false
	if saved_stage in ["check_gate_17", "report_receiving_lead", "zph_complete"] + PALLET_PROGRESS_STAGES and not state.get("zph_assignment", false):
		return false
	var remaining: Variant = state.get("free_time_remaining")
	if not (remaining is float or remaining is int) or not is_finite(float(remaining)) or remaining < 0 or remaining > FREE_TIME_SECONDS:
		return false
	if state.get("zph_assignment", false):
		if pallet_task:
			if not state.completed or not state.gate19_open or placed != Unloading.PALLET_COUNT or remaining != 0 or not state.get("gate17_checked", false) or state.has("assigned_jack"):
				return false
			if saved_stage in PREPARATION_STAGES:
				var totes_placed: bool = saved_stage in ["return_empty_pallet", "report_preparation", "preparation_complete", "blue_totes_complete"]
				var totes_picked: bool = saved_stage == "deliver_blue_totes" or totes_placed
				return not jack_path.is_empty() and pallet_source.size() == 2 and state.get("pallet_delivered", false) == (saved_stage == "retrieve_empty_pallet") and totes_picked == (tote_source.size() == 2) and state.get("totes_delivered", false) == totes_placed and (saved_stage not in ["preparation_complete", "blue_totes_complete"] or not state.hint_enabled)
			var transporting: bool = saved_stage != "find_stock_jack"
			var picked: bool = saved_stage in ["deliver_empty_pallet", "empty_pallet_complete"]
			return transporting == (not jack_path.is_empty()) and picked == (pallet_source.size() == 2) and state.get("pallet_delivered", false) == (saved_stage == "empty_pallet_complete")
		if saved_stage not in ZPH_STAGES or not state.completed or remaining != 0 or receiving or state.has("assigned_jack"):
			return false
		if saved_stage == "open_gate_19":
			return not state.gate19_open and placed == 0 and jack_path.is_empty()
		if not state.gate19_open:
			return false
		if saved_stage in ["check_gate_17", "report_receiving_lead", "zph_complete"]:
			if placed != Unloading.PALLET_COUNT or state.get("gate17_checked", false) != (saved_stage != "check_gate_17"):
				return false
			return saved_stage != "zph_complete" or (jack_path.is_empty() and not state.hint_enabled)
		if (saved_stage in TRANSPORTER_TRAVEL_STAGES) != (not jack_path.is_empty()) or placed >= Unloading.PALLET_COUNT:
			return false
		if saved_stage == "unload_pickup":
			return placed > 0
		return saved_stage not in ["find_free_transporter", "at_gate19_with_transporter"] or placed == 0
	if saved_stage in ORIENTATION_STAGES:
		return state.completed == (saved_stage == "orientation_complete") and not state.gate19_open and placed == 0 and remaining == 0 and jack_path.is_empty() and tote_source.is_empty() and not state.get("totes_delivered", false) and (saved_stage != "orientation_complete" or not state.hint_enabled)
	if receiving:
		if state.has("assigned_jack") or not state.completed or not state.gate19_open or placed != Unloading.PALLET_COUNT or remaining != 0:
			return false
		var transporting: bool = saved_stage in ["find_tote_stock", "deliver_totes", "totes_complete"]
		var picked: bool = saved_stage in ["deliver_totes", "totes_complete"]
		return transporting == (not jack_path.is_empty()) and picked == (tote_source.size() == 2) and state.get("totes_delivered", false) == (saved_stage == "totes_complete") and (saved_stage != "totes_complete" or not state.hint_enabled)
	if saved_stage != "unload_complete" and (saved_stage in TRANSPORTER_TRAVEL_STAGES) != (not jack_path.is_empty()):
		return false
	if saved_stage == "unload_complete":
		# Older saves completed the task after ten pallets, with two still in the truck.
		if int(placed) not in [10, Unloading.PALLET_COUNT] or (int(placed) == 10 and state.hint_enabled):
			return false
	elif saved_stage == "unload_pickup":
		if placed <= 0 or placed >= Unloading.PALLET_COUNT:
			return false
	elif saved_stage == "unload_place":
		if placed >= Unloading.PALLET_COUNT:
			return false
	elif saved_stage in ["find_free_transporter", "bring_transporter_to_gate19"]:
		if placed >= Unloading.PALLET_COUNT:
			return false
	elif placed != 0:
		return false
	if state.completed != (saved_stage != "find_supervisor") or state.gate19_open != (saved_stage == "find_free_transporter" or saved_stage in TRANSPORTER_TRAVEL_STAGES):
		return false
	if saved_stage == "find_supervisor" and remaining != FREE_TIME_SECONDS:
		return false
	if saved_stage == "free_time" and (remaining <= 0 or state.hint_enabled):
		return false
	if saved_stage in ["return_to_supervisor", "open_gate_19", "find_free_transporter"] + TRANSPORTER_TRAVEL_STAGES and remaining != 0:
		return false
	return true

func _refresh_task() -> void:
	match stage:
		"retrieve_empty_pallet":
			_objective.text = "Заберите на выбранную рохлю паллет, который вы привезли к старшему участка приемки."
		"find_blue_tote_stock":
			_objective.text = "Возьмите стопку синих тарников с паллета запаса в зоне складирования."
		"deliver_blue_totes":
			_objective.text = "Привезите стопку синих тарников к столу приемки №5 и поставьте в выделенное место."
		"blue_totes_complete":
			_objective.text = "Стопка синих тарников доставлена к столу приемки №5."
		"return_empty_pallet":
			_objective.text = "Стопка тарников у стола №5. Верните пустой паллет в одну из зон складирования паллет в блоке 3."
		"report_preparation":
			_objective.text = "Паллет возвращен. Подъедьте к старшему участка приемки и сообщите о выполнении."
		"preparation_complete":
			_objective.text = "Стопка тарников доставлена, паллет возвращен. Старший участка поблагодарил вас за работу."
		"find_stock_jack":
			_objective.text = "Найдите свободную рохлю для доставки пустого паллета."
		"find_pallet_stock":
			_objective.text = "Возьмите один паллет из одной из двух зон складирования в блоке 3." if _has_assigned_vehicle(_player) else "Возьмите выбранную рохлю и отправляйтесь в зону складирования паллет в блоке 3."
		"deliver_empty_pallet":
			_objective.text = "Привезите паллет в выделенную зону возле старшего участка приемки и поставьте его."
		"empty_pallet_complete":
			_objective.text = "Паллет доставлен. Поговорите со старшим участка приемки о подготовке рабочего места."
		"check_gate_17":
			_objective.text = "Ворота 19: выгружены, 12 / 12 паллет.\nОткройте ворота 17 и убедитесь, что фура разгружена."
		"report_receiving_lead":
			_objective.text = "Оба поручения выполнены. Подойдите к старшему участка приемки и сообщите: фура на воротах 17 уже выгружена, ворота 19 выгрузили."
		"zph_complete":
			_objective.text = "Старший участка поблагодарил вас. Выгрузка ворот 19 и проверка ворот 17 завершены."
		"find_director":
			_objective.text = "Найдите директора, он введет вас в курс дела"
		"meet_shift_lead":
			_objective.text = "Поговорите со старшим смены приемки и размещения."
		"meet_receiving_lead":
			_objective.text = "Найдите старшего участка приемки и узнайте о ЗПХ и проверке поступившего товара."
		"orientation_complete":
			_objective.text = "Вы познакомились с операционной зоной, приемкой, размещением, подбором и ЗПХ. Рабочих поручений пока нет."
		"find_supervisor":
			_objective.text = "Найдите старшего смены приемки и размещения и поговорите с ним."
		"free_time":
			_objective.text = "Вы познакомились со старшим смены приемки и размещения."
		"return_to_supervisor":
			_objective.text = "Подойдите к старшему смены приемки и размещения, есть поручение"
		"open_gate_19":
			_objective.text = "Прибыл груз на 19 ворота. Откройте ворота для выгрузки товара."
		"find_free_transporter":
			_objective.text = "Найдите свободный паллетовоз"
		"bring_transporter_to_gate19":
			_objective.text = "Подъедьте к воротам №19 на паллетовозе" if _player.get("_carried_vehicle") == _assigned_vehicle() else "Сядьте в выбранный паллетовоз и подъедьте к воротам №19"
		"at_gate19_with_transporter":
			_objective.text = "Подъедьте на паллетовозе к воротам №19 и заберите паллет. Выгрузите фуру полностью."
		"unload_pickup":
			_objective.text = "Заберите следующий паллет у ворот №19. Размещено %d / %d." % [placed_count, Unloading.PALLET_COUNT] if _has_assigned_vehicle(_player) else "Сядьте в выбранный паллетовоз и вернитесь к воротам №19. Размещено %d / %d." % [placed_count, Unloading.PALLET_COUNT]
		"unload_place":
			_objective.text = "Поместите паллет в выделенную разметку №%d. Размещено %d / %d." % [placed_count + 1, placed_count, Unloading.PALLET_COUNT]
		"unload_complete":
			_objective.text = "Фура полностью выгружена. Оставьте паллетовоз и подойдите к старшему смены приемки и размещения."
		"find_receiving_supervisor":
			_objective.text = "Подойдите к старшему участка приемки за следующим поручением."
		"find_receiving_jack":
			_objective.text = "Найдите свободную рохлю для доставки синих тарников к столу приемки №5."
		"find_tote_stock":
			_objective.text = "Возьмите одну стопку с паллета запаса. Отдельные тарники не берите." if _has_assigned_vehicle(_player) else "Возьмите выбранную рохлю и найдите паллет запаса с синими тарниками."
		"deliver_totes":
			_objective.text = "Привезите стопку синих тарников к столу приемки №5 и поставьте в выделенное место."
		"totes_complete":
			_objective.text = "Стопка синих тарников доставлена к столу приемки №5. Первая часть подготовки выполнена."
	if _zph_assignment and stage not in ["check_gate_17", "report_receiving_lead", "zph_complete"] + PALLET_PROGRESS_STAGES:
		match stage:
			"open_gate_19":
				_objective.text = "Подойдите к воротам 19 и откройте их."
			"find_free_transporter":
				_objective.text = "Возьмите свободный паллетовоз для выгрузки ворот 19."
			"bring_transporter_to_gate19":
				_objective.text = "Подъедьте к воротам 19 на выбранном паллетовозе."
			"at_gate19_with_transporter", "unload_pickup":
				_objective.text = "Ворота 19: заберите паллет. Размещено %d / 12." % placed_count if _has_assigned_vehicle(_player) else "Сядьте в выбранный паллетовоз. Размещено %d / 12." % placed_count
			"unload_place":
				_objective.text = "Поставьте паллет в разметку №%d. Размещено %d / 12." % [placed_count + 1, placed_count]
		_objective.text += "\n\nВорота 17: фура разгружена, проверено." if gate17_checked else "\n\nВорота 17: откройте и проверьте, выгружена ли фура."
	_unloading.set_target_visible(stage == "unload_place")
	_supplies.set_target_visible(stage in ["deliver_totes", "deliver_blue_totes"])
	_pallet_stock.set_target_visible(stage == "deliver_empty_pallet", stage == "return_empty_pallet")
	_hint_button.visible = _has_active_target()
	_layout()

func _task_heading(compact: bool) -> String:
	if stage in PREPARATION_STAGES:
		if stage == "return_empty_pallet":
			return "Верните пустой паллет"
		if stage == "report_preparation":
			return "Отчет старшему участка"
		if stage == "preparation_complete":
			return "Поручение выполнено"
		return "Тарники доставлены" if stage == "blue_totes_complete" else "Подготовка стола приемки"
	if stage in PALLET_STAGES:
		return "Паллет доставлен" if stage == "empty_pallet_complete" else "Пустой паллет к старшему участка"
	if _zph_assignment:
		if stage == "report_receiving_lead":
			return "Отчет старшему участка"
		if stage == "zph_complete":
			return "Поручения выполнены"
		return "Выгрузка и проверка фур"
	match stage:
		"find_director":
			return "Найдите директора склада" if compact else "Познакомиться со складом"
		"meet_shift_lead":
			return "Найдите старшего смены" if compact else "Приемка, размещение и подбор"
		"meet_receiving_lead":
			return "Найдите старшего участка приемки" if compact else "ЗПХ и приемка"
		"orientation_complete":
			return "Знакомство со складом завершено"
		"find_supervisor":
			return "Найдите старшего приёмки" if compact else "Знакомство со складом"
		"free_time":
			return "Знакомство завершено"
		"return_to_supervisor":
			return "Найдите старшего смены приёмки" if compact else "Есть поручение"
		"open_gate_19":
			return "Откройте ворота №19" if compact else "Выгрузка товара"
		"bring_transporter_to_gate19":
			return "На паллетовозе к воротам №19" if compact else "Доставка паллетовоза"
		"at_gate19_with_transporter":
			return "Начинаем выгрузку"
		"unload_pickup":
			return "Заберите паллет · %d / %d" % [placed_count, Unloading.PALLET_COUNT] if compact else "Выгрузка товара"
		"unload_place":
			return "Разметка №%d · %d / %d" % [placed_count + 1, placed_count, Unloading.PALLET_COUNT] if compact else "Размещение паллета"
		"unload_complete":
			return "Вернитесь к старшему смены" if compact else "Поручение выполнено"
		"find_receiving_supervisor":
			return "Найдите старшего участка приемки" if compact else "Следующее поручение"
		"find_receiving_jack":
			return "Найдите свободную рохлю"
		"find_tote_stock":
			return "Найдите запас синих тарников"
		"deliver_totes":
			return "Тарники к столу №5" if compact else "Подготовка рабочего места"
		"totes_complete":
			return "Тарники доставлены"
		_:
			return "Найдите свободный паллетовоз" if compact else "Поиск паллетовоза"

func _toggle_hint() -> void:
	if hint_enabled:
		hint_enabled = false
		_route.set_enabled(false)
		_refresh_task()
	else:
		request_hint()

func _create_hud() -> void:
	var layer := CanvasLayer.new()
	layer.name = "DemoHUD"
	layer.layer = 40
	add_child(layer)
	_hud = Control.new()
	_hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_hud.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	layer.add_child(_hud)
	_hud.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial"])
	font.font_weight = 600
	font.oversampling = 1.0
	_hud.theme = Theme.new()
	_hud.theme.default_font = font
	_hud.theme.default_font_size = 16
	_task_panel = PanelContainer.new()
	_task_panel.name = "DemoObjective"
	_task_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_task_panel.add_theme_stylebox_override("panel", _style(Color(0.03, 0.035, 0.04, 0.94), Color("52615b")))
	_hud.add_child(_task_panel)
	_task_box = VBoxContainer.new()
	_task_box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_task_box.add_theme_constant_override("separation", 8)
	_task_panel.add_child(_task_box)
	_task_title = _label("", 14)
	_task_title.add_theme_color_override("font_color", Color("f2cc45"))
	_task_box.add_child(_task_title)
	_objective = _label("", 16)
	_task_box.add_child(_objective)
	var footer := HBoxContainer.new()
	footer.mouse_filter = Control.MOUSE_FILTER_IGNORE
	footer.add_theme_constant_override("separation", 4)
	_task_box.add_child(footer)
	_hint_button = Button.new()
	_hint_button.name = "HintButton"
	_hint_button.focus_mode = Control.FOCUS_NONE
	_hint_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_hint_button.expand_icon = true
	_hint_button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	_hint_button.add_theme_constant_override("icon_max_width", 20)
	_hint_button.custom_minimum_size.y = 36
	_style_button(_hint_button, false)
	_hint_button.pressed.connect(_toggle_hint)
	footer.add_child(_hint_button)
	_task_hide = _hud_icon_button("x", "Скрыть задание", _set_task_collapsed.bind(true))
	_task_hide.name = "HideObjective"
	footer.add_child(_task_hide)
	_task_restore = _hud_icon_button("clipboard-list", "Показать задание", _set_task_collapsed.bind(false))
	_task_restore.name = "ShowObjective"
	_hud.add_child(_task_restore)
	_modal = ColorRect.new()
	_modal.name = "DemoModal"
	_modal.color = Color(0, 0, 0, 0.7)
	_hud.add_child(_modal)
	_modal.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_modal.hide()
	_dialog = PanelContainer.new()
	_dialog.name = "DemoDialog"
	_dialog.add_theme_stylebox_override("panel", _style(Color("202725"), Color("52615b")))
	_modal.add_child(_dialog)
	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	_dialog.add_child(box)
	_dialog_title = _label("", 20)
	box.add_child(_dialog_title)
	_scroll = ScrollContainer.new()
	_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
	box.add_child(_scroll)
	_dialog_text = _label("", 17)
	_dialog_text.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_scroll.add_child(_dialog_text)
	_dialog_counter = _label("", 12)
	_dialog_counter.add_theme_color_override("font_color", Color("b2bcb7"))
	box.add_child(_dialog_counter)
	_buttons = HBoxContainer.new()
	_buttons.add_theme_constant_override("separation", 8)
	box.add_child(_buttons)

func _layout() -> void:
	if _task_panel == null:
		return
	var viewport_size := _hud.get_viewport_rect().size
	var touch := get_tree().get_first_node_in_group("touch_controls") as Control
	var mobile: bool = touch != null and touch.available
	var objective_font_size := 12 if mobile else 16
	if _objective.get_theme_font_size("font_size") != objective_font_size:
		_objective.add_theme_font_size_override("font_size", objective_font_size)
	_task_title.add_theme_font_size_override("font_size", 12 if mobile else 14)
	_task_box.add_theme_constant_override("separation", 4 if mobile else 8)
	var panel_style := _task_panel.get_theme_stylebox("panel") as StyleBoxFlat
	panel_style.content_margin_left = 6 if mobile else 12
	panel_style.content_margin_right = 6 if mobile else 12
	panel_style.content_margin_top = 6 if mobile else 10
	panel_style.content_margin_bottom = 6 if mobile else 10
	_task_hide.visible = mobile
	_hint_button.text = "" if mobile else ("Скрыть путь" if hint_enabled else "Показать путь")
	_hint_button.tooltip_text = "Скрыть путь" if hint_enabled else "Показать путь"
	_hint_button.icon = preload("res://assets/ui/lucide/route.svg") if mobile else null
	_hint_button.custom_minimum_size.y = 44 if mobile else 36
	var portrait := mobile and viewport_size.y > viewport_size.x
	_objective.visible = portrait or viewport_size.y >= (390.0 if mobile else 360.0)
	_task_title.text = _task_heading(not _objective.visible)
	var width := minf(224.0 if mobile else 280.0, maxf(1.0, viewport_size.x - 32.0))
	if portrait:
		width = minf(176.0, maxf(1.0, (viewport_size.x - 108.0) / 2.0))
	_task_panel.size.x = width
	_task_panel.custom_minimum_size.x = width
	_task_panel.reset_size()
	_task_panel.position = Vector2(viewport_size.x - width - 16.0, 16.0)
	_task_restore.position = Vector2(viewport_size.x - 60, 16)
	if viewport_size.x < 1024.0 and not mobile:
		_task_panel.position.y = maxf(16.0, viewport_size.y - _task_panel.size.y - 16.0)
		var controls := get_tree().get_first_node_in_group("controls_hint") as Control
		if controls != null and controls.visible:
			_task_panel.position.y = maxf(16.0, controls.hint_rect().position.y - _task_panel.size.y - 12.0)
	_update_task_visibility()
	if _modal.visible:
		var dialog_width := minf(520.0, maxf(1.0, viewport_size.x - 32.0))
		var content_width := maxf(1.0, dialog_width - 28.0)
		_dialog_title.custom_minimum_size.x = content_width
		_dialog_text.custom_minimum_size.x = content_width
		_dialog_title.size.x = content_width
		_dialog_text.size.x = content_width
		_dialog_title.add_theme_font_size_override("font_size", 16 if viewport_size.y < 360.0 else 20)
		_dialog_text.add_theme_font_size_override("font_size", 14 if viewport_size.y < 360.0 else 17)
		var other_height := _dialog_title.get_combined_minimum_size().y + _buttons.get_combined_minimum_size().y + 56.0
		if _dialog_counter.visible:
			other_height += _dialog_counter.get_combined_minimum_size().y + 12.0
		var text_height := _dialog_text.get_combined_minimum_size().y
		_scroll.custom_minimum_size.y = minf(maxf(32.0, text_height), maxf(32.0, viewport_size.y - 32.0 - other_height))
		_dialog.custom_minimum_size.x = dialog_width
		_dialog.reset_size()
		_dialog.position = ((viewport_size - _dialog.size) / 2.0).floor()

func _label(text: String, font_size: int) -> Label:
	var label := Label.new()
	label.text = text
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", font_size)
	label.add_theme_color_override("font_color", Color("edf2ed"))
	return label

func _set_task_collapsed(collapsed: bool) -> void:
	_mobile_task_collapsed = collapsed
	_update_task_visibility()

func _update_task_visibility() -> void:
	var touch := get_tree().get_first_node_in_group("touch_controls") as Control
	var mobile: bool = touch != null and touch.available
	var block_title: RichTextLabel = _world.get_node("BlockNotifications").get("_banner")
	var show_task := _modal_kind.is_empty() and (mobile or _hud.get_viewport_rect().size.x >= 1024.0 or not block_title.visible)
	_task_panel.visible = show_task and (not mobile or not _mobile_task_collapsed)
	_task_restore.visible = show_task and mobile and _mobile_task_collapsed

func task_hud_rect() -> Rect2:
	if _task_panel.is_visible_in_tree():
		return _task_panel.get_global_rect()
	return _task_restore.get_global_rect() if _task_restore.is_visible_in_tree() else Rect2()

func _hud_icon_button(icon: String, tooltip: String, callback: Callable) -> Button:
	var button := Button.new()
	button.icon = load("res://assets/ui/lucide/%s.svg" % icon)
	button.expand_icon = true
	button.icon_alignment = HORIZONTAL_ALIGNMENT_CENTER
	button.add_theme_constant_override("icon_max_width", 18)
	button.custom_minimum_size = Vector2(44, 44)
	button.focus_mode = Control.FOCUS_NONE
	button.tooltip_text = tooltip
	_style_button(button, false)
	button.pressed.connect(callback)
	return button

func _button(text: String, callback: Callable, primary: bool) -> Button:
	var button := Button.new()
	button.text = text
	button.custom_minimum_size.y = 44 if DisplayServer.is_touchscreen_available() else 40
	button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_style_button(button, primary)
	button.pressed.connect(callback)
	_buttons.add_child(button)
	return button

func _style_button(button: Button, primary: bool) -> void:
	var ink := Color("202725") if primary else Color("edf2ed")
	for key in ["font_color", "font_hover_color", "font_pressed_color", "font_focus_color"]:
		button.add_theme_color_override(key, ink)
	button.add_theme_stylebox_override("normal", _style(Color("f2cc45") if primary else Color("303b37")))
	button.add_theme_stylebox_override("hover", _style(Color("ffe37d") if primary else Color("46514b")))
	button.add_theme_stylebox_override("pressed", _style(Color("d7b333") if primary else Color("52615b")))
	button.add_theme_stylebox_override("focus", _style(Color.TRANSPARENT, Color("f2cc45")))

func _style(color: Color, border := Color.TRANSPARENT) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = border
	style.set_border_width_all(1 if border.a > 0 else 0)
	style.set_corner_radius_all(3)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	return style

func _clear_buttons() -> void:
	for button in _buttons.get_children():
		# Keep the pressed button in the tree until touch dispatch has finished.
		button.hide()
		button.queue_free()
