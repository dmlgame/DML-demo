class_name PickupVehicle
extends Sprite2D

enum VehicleMode {
	PALLET_JACK = 1,
	TRANSPORTER = 2,
}

@export var vehicle_mode: VehicleMode = VehicleMode.PALLET_JACK

@onready var interaction_area: Area2D = $InteractionArea
@onready var solid_shape: Node2D = $StaticBody2D.get_child(0) as Node2D

var is_carried := false


func _ready() -> void:
	interaction_area.body_entered.connect(_on_body_entered)
	interaction_area.body_exited.connect(_on_body_exited)


func set_carried(carried: bool) -> void:
	is_carried = carried
	visible = not carried
	solid_shape.set_deferred("disabled", carried)
	interaction_area.set_deferred("monitoring", not carried)


func get_interaction_text() -> String:
	if vehicle_mode == VehicleMode.TRANSPORTER:
		return "Паллетовоз\nНажмите E или Enter, чтобы сесть в транспорт"
	return "Рохля\nНажмите E или Enter, чтобы взять рохлю"


func _on_body_entered(body: Node2D) -> void:
	if not is_carried and body.has_method("register_pickup_vehicle"):
		body.call("register_pickup_vehicle", self)


func _on_body_exited(body: Node2D) -> void:
	if body.has_method("unregister_pickup_vehicle"):
		body.call("unregister_pickup_vehicle", self)
