extends Area2D

const PLAYER_FOOT_OFFSET := Vector2(0, 25)

@export_multiline var title := ""
@export var player_path := NodePath("../../../Player")

@onready var player: CharacterBody2D = get_node(player_path)
@onready var collision_shape: CollisionShape2D = $CollisionShape2D

func _ready() -> void:
	player.register_workstation_hint(self)

func _exit_tree() -> void:
	if is_instance_valid(player):
		player.unregister_workstation_hint(self)

func contains_actor(actor: Node2D) -> bool:
	if not is_visible_in_tree() or collision_shape.disabled or collision_shape.shape == null:
		return false
	# Use the feet, so an overlapping head or vehicle forks do not select another desk.
	var feet := collision_shape.to_local(actor.global_position + PLAYER_FOOT_OFFSET)
	return collision_shape.shape.get_rect().has_point(feet)

func get_interaction_text(actor: Node2D) -> String:
	return title if contains_actor(actor) else ""
