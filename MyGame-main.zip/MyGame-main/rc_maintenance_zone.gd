@tool
extends Node2D

const FENCE_VERTICAL := Vector2i(0, 3)
const FENCE_HORIZONTAL := Vector2i(1, 3)
const FENCE_CORNER := Vector2i(2, 3)
const PLAYER_FOOT_OFFSET := Vector2(0, 25)

@export var fence_layer_path := NodePath("../WallLayer")
@export var player_path := NodePath("../YSortActors/Player")
@export var message := "Зона РЦ (технические работы)"
@export_range(16, 128, 1) var proximity := 64.0
@export var darkness := Color(0.11, 0.13, 0.15, 0.55):
	set(value):
		darkness = value
		queue_redraw()

var _zone_rect := Rect2()
var _rebuild_queued := false

func _ready() -> void:
	var wall := get_node_or_null(fence_layer_path) as TileMapLayer
	if wall == null:
		return
	wall.changed.connect(_queue_rebuild)
	_rebuild_boundary()
	if not Engine.is_editor_hint():
		var player := get_node_or_null(player_path)
		if player != null:
			player.register_maintenance_zone(self)

func _exit_tree() -> void:
	if Engine.is_editor_hint():
		return
	var player := get_node_or_null(player_path)
	if player != null:
		player.unregister_maintenance_zone(self)

func _queue_rebuild() -> void:
	if _rebuild_queued:
		return
	_rebuild_queued = true
	call_deferred("_rebuild_boundary")

func _rebuild_boundary() -> void:
	_rebuild_queued = false
	_zone_rect = Rect2()
	var wall := get_node_or_null(fence_layer_path) as TileMapLayer
	if wall == null:
		return
	var corners := wall.get_used_cells_by_id(0, FENCE_CORNER)
	var side := wall.get_used_cells_by_id(0, FENCE_VERTICAL)
	var top := wall.get_used_cells_by_id(0, FENCE_HORIZONTAL)
	if corners.is_empty() or side.is_empty() or top.is_empty():
		queue_redraw()
		return
	var corner: Vector2i = corners[0]
	var end_cell := corner
	for cell in top:
		if cell.y == corner.y and cell.x >= corner.x:
			end_cell.x = maxi(end_cell.x, cell.x)
	for cell in side:
		if cell.x == corner.x and cell.y >= corner.y:
			end_cell.y = maxi(end_cell.y, cell.y)
	# Start just inside the mesh, keeping its open-side edge on the lit floor.
	var start := to_local(wall.to_global(wall.map_to_local(corner))) + Vector2.ONE
	var end := to_local(wall.to_global(wall.map_to_local(end_cell) + Vector2(wall.tile_set.tile_size) / 2.0))
	_zone_rect = Rect2(start, end - start)
	queue_redraw()

func _draw() -> void:
	if _zone_rect.has_area():
		draw_rect(_zone_rect, darkness)

func get_interaction_text(actor: Node2D) -> String:
	if actor == null:
		return ""
	var feet := to_local(actor.global_position + PLAYER_FOOT_OFFSET)
	return message if _near_fence(feet) else ""

func _near_fence(feet: Vector2) -> bool:
	if not _zone_rect.has_area():
		return false
	var start := _zone_rect.position
	var end := _zone_rect.end
	var side_point := Vector2(start.x, clampf(feet.y, start.y, end.y))
	var top_point := Vector2(clampf(feet.x, start.x, end.x), start.y)
	return (feet.x <= start.x and feet.distance_to(side_point) <= proximity) or (feet.y <= start.y and feet.distance_to(top_point) <= proximity)
