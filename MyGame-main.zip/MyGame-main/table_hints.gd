extends Node

const NAME_FIELD := "interaction_name"
const PLAYER_FOOT_OFFSET := Vector2(0, 25)

@export_range(16, 96, 1) var proximity := 40.0

@onready var layer: TileMapLayer = $"../YSortActors/ObjectsLayer"
@onready var player: CharacterBody2D = $"../YSortActors/Player"

var _tables: Array[Dictionary] = []
var _labels: Array[Dictionary] = []
var _rebuild_queued := false

func _ready() -> void:
	_rebuild_tables()
	layer.changed.connect(_queue_rebuild)
	layer.connect("cells_changed", _queue_rebuild)
	player.register_table_hints(self)

func _exit_tree() -> void:
	if is_instance_valid(player):
		player.unregister_table_hints(self)

func _queue_rebuild() -> void:
	if _rebuild_queued or not is_inside_tree():
		return
	_rebuild_queued = true
	call_deferred("_rebuild_tables")

func _rebuild_tables() -> void:
	_rebuild_queued = false
	_tables.clear()
	_labels.clear()
	if layer.tile_set == null or layer.tile_set.get_custom_data_layer_by_name(NAME_FIELD) < 0:
		return
	for cell in layer.get_used_cells():
		var data := layer.get_cell_tile_data(cell)
		if data == null:
			continue
		var title := String(data.get_custom_data(NAME_FIELD))
		if title.is_empty():
			continue
		var bounds := Rect2()
		var first := true
		for polygon in data.get_collision_polygons_count(0):
			for point in data.get_collision_polygon_points(0, polygon):
				bounds = Rect2(point, Vector2.ZERO) if first else bounds.expand(point)
				first = false
		if first:
			var source := layer.tile_set.get_source(layer.get_cell_source_id(cell)) as TileSetAtlasSource
			if source == null:
				continue
			# Non-solid signs use the bottom of their graphic as the approach line.
			var size := Vector2(source.get_tile_texture_region(layer.get_cell_atlas_coords(cell)).size)
			bounds = Rect2(Vector2(-size.x * 0.5, size.y * 0.5) - Vector2(data.texture_origin), Vector2(size.x, 0))
		# Detect approach near the table's floor contact, not the elevated monitor/rack.
		bounds.position += layer.map_to_local(cell)
		var label := {"cell": cell, "title": title, "footprint": bounds, "zone": bounds.grow(proximity)}
		_labels.append(label)
		if layer.get_cell_source_id(cell) == 0:
			_tables.append(label)

func get_interaction_text(actor: Node2D) -> String:
	var feet := layer.to_local(actor.global_position + PLAYER_FOOT_OFFSET)
	var nearest := ""
	var nearest_distance := INF
	for table in _labels:
		var zone: Rect2 = table.zone
		if not zone.has_point(feet):
			continue
		var distance := feet.distance_squared_to(table.footprint.get_center())
		if distance < nearest_distance:
			nearest = table.title
			nearest_distance = distance
	return nearest
