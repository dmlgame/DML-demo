extends Node

const Worker := preload("res://assets/npcs/warehouse_worker.tscn")
const FOOT_OFFSET := Vector2(0, 25)
const WORKERS := [
	{"name": "ReceivingWorker", "cell": Vector2i(-96, -76), "skin": preload("res://assets/npcs/lpc_workers/worker_male_curly.png")},
	{"name": "ReceivingWalker", "cell": Vector2i(-48, -76), "skin": preload("res://assets/npcs/lpc_workers/worker_female_bob.png")},
	{"name": "PackingWorker", "cell": Vector2i(63, -73), "skin": preload("res://assets/npcs/lpc_workers/worker_male_blond.png")},
	{"name": "PackingWalker", "cell": Vector2i(94, -57), "skin": preload("res://assets/npcs/lpc_workers/worker_female_ponytail.png")},
	{"name": "SortingWorker", "cell": Vector2i(79, -41), "skin": preload("res://assets/npcs/lpc_workers/worker_male_gray.png")},
	{"name": "SortingWalker", "cell": Vector2i(47, -26), "skin": preload("res://assets/npcs/lpc_workers/worker_female_braid.png")},
	{"name": "ReceivingWorkerParted", "cell": Vector2i(-111, -63), "skin": preload("res://assets/npcs/lpc_workers/worker_male_parted.png")},
	{"name": "ReceivingWorkerFade", "cell": Vector2i(-80, -63), "skin": preload("res://assets/npcs/lpc_workers/worker_male_fade.png")},
	{"name": "ReceivingWalkerBun", "cell": Vector2i(-9, -76), "skin": preload("res://assets/npcs/lpc_workers/worker_female_bun.png")},
	{"name": "SortingWalkerPixie", "cell": Vector2i(109, -26), "skin": preload("res://assets/npcs/lpc_workers/worker_female_pixie.png")},
	{"name": "ReceivingWorkerMessy", "cell": Vector2i(-32, -63), "skin": preload("res://assets/npcs/lpc_workers/worker_male_messy.png")},
	{"name": "ReceivingWorkerBalding", "cell": Vector2i(-64, -76), "skin": preload("res://assets/npcs/lpc_workers/worker_male_balding.png")},
	{"name": "PackingWorkerCowlick", "cell": Vector2i(47, -73), "skin": preload("res://assets/npcs/lpc_workers/worker_male_cowlick.png")},
	{"name": "PackingWalkerWavy", "cell": Vector2i(109, -57), "skin": preload("res://assets/npcs/lpc_workers/worker_female_wavy.png")},
	{"name": "SortingWalkerCurls", "cell": Vector2i(63, -41), "skin": preload("res://assets/npcs/lpc_workers/worker_female_curls.png")},
	{"name": "ReceivingWorkerAfro", "cell": Vector2i(-96, -63), "skin": preload("res://assets/npcs/lpc_workers/worker_male_afro.png")},
	{"name": "ReceivingWalkerPigtails", "cell": Vector2i(-48, -63), "skin": preload("res://assets/npcs/lpc_workers/worker_female_pigtails.png")},
	{"name": "PackingWorkerCurtains", "cell": Vector2i(79, -57), "skin": preload("res://assets/npcs/lpc_workers/worker_male_curtains.png")},
	{"name": "SortingWorkerSpiked", "cell": Vector2i(94, -41), "skin": preload("res://assets/npcs/lpc_workers/worker_male_spiked.png")},
	{"name": "SortingWalkerPage", "cell": Vector2i(79, -26), "skin": preload("res://assets/npcs/lpc_workers/worker_female_page.png")},
]

var workers: Array[CharacterBody2D] = []
var destinations: Array[Dictionary] = []
var initialized := false
var _world: Node2D
var _blocks: Node2D
var _layer: Node2D
var _warmup_frames := 0

func _ready() -> void:
	_world = get_parent()
	_blocks = _world.get_node("BlockNotifications")
	_layer = Node2D.new()
	_layer.name = "WarehouseWorkers"
	_layer.y_sort_enabled = true
	_world.get_node("YSortActors").add_child(_layer)

func _physics_process(_delta: float) -> void:
	# Avoid retaining a coroutine when a saved world is replaced during startup.
	_warmup_frames += 1
	if _warmup_frames >= 2:
		set_physics_process(false)
		call_deferred("_populate")

func _exit_tree() -> void:
	if is_instance_valid(_layer):
		_layer.queue_free()

func _populate() -> void:
	var tables: Array = _world.get_node("TableHints")._tables
	var objects := _world.get_node("YSortActors/ObjectsLayer") as TileMapLayer
	for table in tables:
		var bounds: Rect2 = table.footprint
		var look := objects.to_global(bounds.get_center())
		for offset in [-24, 24]:
			_add_destination(objects.to_global(Vector2(bounds.get_center().x + offset, bounds.end.y + 20)), look, "table")
	_collect_objects(objects, "decor")
	_collect_objects(_world.get_node("YSortActors/UnloadingDockLayer"), "gate")
	for index in WORKERS.size():
		var config: Dictionary = WORKERS[index]
		var home := Vector2.ZERO
		for table in tables:
			if table.cell == config.cell:
				var bounds: Rect2 = table.footprint
				home = objects.to_global(Vector2(bounds.get_center().x - 24, bounds.end.y + 20))
		if home == Vector2.ZERO:
			continue
		var spawn := _clear_point(home)
		if not _spawn_is_clear(spawn):
			continue
		var points: Array[Dictionary] = []
		for point in destinations:
			var distance := home.distance_to(point.point)
			if distance <= (1400 if point.kind == "gate" else 800):
				points.append(point)
		# Clear floor stops keep movement from becoming a fixed workstation loop.
		for offset in [Vector2(-96, 64), Vector2(96, 64), Vector2(0, 128), Vector2(-160, 128), Vector2(160, 128)]:
			var point := _clear_point(home + offset)
			if _spawn_is_clear(point):
				points.append({"point": point, "look_at": home, "kind": "floor"})
		if points.size() < 3:
			continue
		var worker := Worker.instantiate() as CharacterBody2D
		worker.name = config.name
		worker.skin = config.skin
		worker.walk_speed = 62 + (index % 6) * 3
		worker.position = spawn - FOOT_OFFSET
		_layer.add_child(worker)
		worker.configure(_world, points, index * 0.7)
		workers.append(worker)
	initialized = true

func _collect_objects(layer: TileMapLayer, kind: String) -> void:
	for cell in layer.get_used_cells():
		var data := layer.get_cell_tile_data(cell)
		var source := layer.tile_set.get_source(layer.get_cell_source_id(cell)) as TileSetAtlasSource
		if source == null or data == null:
			continue
		var region := source.get_tile_texture_region(layer.get_cell_atlas_coords(cell))
		var center := layer.map_to_local(cell)
		if kind == "gate":
			# Keep the scripted unloading entrances and their buttons clear.
			if cell in [Vector2i(-69, -106), Vector2i(-37, -106)] or region.size.x < 120:
				continue
			# Dock graphics have no physics layer; the wall supplies their collision.
			_add_destination(layer.to_global(center + Vector2(0, region.size.y * 0.5 + 48)), layer.to_global(center), kind)
			continue
		if layer.tile_set.get_physics_layers_count() == 0 or layer.get_cell_source_id(cell) == 0 or region.size.x > 192:
			continue
		var bounds := Rect2(center, Vector2.ZERO)
		var has_collision := false
		for polygon in data.get_collision_polygons_count(0):
			for vertex in data.get_collision_polygon_points(0, polygon):
				bounds = bounds.expand(center + vertex)
				has_collision = true
		if not has_collision:
			continue
		_add_destination(layer.to_global(Vector2(bounds.get_center().x, bounds.end.y + 28)), layer.to_global(center), kind)

func _add_destination(point: Vector2, look: Vector2, kind: String) -> void:
	var clear := _clear_point(point)
	if not _spawn_is_clear(clear):
		return
	for existing in destinations:
		if clear.distance_to(existing.point) < 20:
			return
	destinations.append({"point": clear, "look_at": look, "kind": kind})

func _clear_point(point: Vector2) -> Vector2:
	for offset in [Vector2.ZERO, Vector2(-32, 0), Vector2(32, 0), Vector2(0, 24), Vector2(-32, 24), Vector2(32, 24), Vector2(-64, 24), Vector2(64, 24)]:
		if _spawn_is_clear(point + offset):
			return point + offset
	return point

func can_roam(feet: Vector2) -> bool:
	# Reuse the map's block boundaries, including clearance for the worker's feet.
	return _blocks.get_block_at(feet - Vector2(12, 0)) in [2, 3] and _blocks.get_block_at(feet + Vector2(12, 0)) in [2, 3]

func _spawn_is_clear(feet: Vector2) -> bool:
	if not can_roam(feet):
		return false
	var floor_layer := _world.get_node("FloorLayer") as TileMapLayer
	if floor_layer.get_cell_source_id(floor_layer.local_to_map(floor_layer.to_local(feet))) == -1:
		return false
	var shape := RectangleShape2D.new()
	shape.size = Vector2(24, 14)
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = Transform2D(0, feet)
	query.collision_mask = 1
	return _world.get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()
