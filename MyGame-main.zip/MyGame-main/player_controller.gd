@tool
extends CharacterBody2D

const TouchControls = preload("res://touch_controls.gd")

enum MoveMode {
	ON_FOOT,
	PALLET_JACK,
	TRANSPORTER,
}

enum PreviewDirection {
	DOWN,
	UP,
	LEFT,
	RIGHT,
}

@export_group("Movement")
@export var walk_speed := 120.0
@export var run_speed := 170.0
@export var pallet_jack_speed := 85.0
@export var transporter_speed := 110.0
@export var vehicle_animation_fps := 6.0
@export_range(0, 160, 1) var turn_knockback_limit := 128
@export_enum("On Foot", "Pallet Jack", "Transporter") var move_mode: int = MoveMode.ON_FOOT

@export_group("Editor Preview")
@export_enum("On Foot", "Pallet Jack", "Transporter") var preview_mode: int = MoveMode.ON_FOOT:
	set(value):
		preview_mode = clampi(value, MoveMode.ON_FOOT, MoveMode.TRANSPORTER)
		_request_editor_preview()
@export_enum("Down", "Up", "Left", "Right") var preview_direction: int = PreviewDirection.DOWN:
	set(value):
		preview_direction = clampi(value, PreviewDirection.DOWN, PreviewDirection.RIGHT)
		_request_editor_preview()
@export_range(0, 7, 1) var preview_frame := 0:
	set(value):
		preview_frame = clampi(value, 0, 7)
		_request_editor_preview()

@onready var sprite: AnimatedSprite2D = $Visuals/OnFoot
@onready var on_foot_visual: CanvasItem = $Visuals/OnFoot
@onready var pallet_jack_visual: CanvasItem = $Visuals/PalletJack
@onready var pallet_jack_horizontal: Sprite2D = $Visuals/PalletJack/Horizontal
@onready var pallet_jack_vertical: Sprite2D = $Visuals/PalletJack/Vertical
@onready var transporter_visual: CanvasItem = $Visuals/Transporter
@onready var transporter_sprite: Sprite2D = $Visuals/Transporter/Sprite

@onready var collision_on_foot: CollisionShape2D = $CollisionOnFoot
@onready var collision_pallet_jack_left: CollisionPolygon2D = $CollisionPalletJackLeft
@onready var collision_pallet_jack_right: CollisionPolygon2D = $CollisionPalletJackRight
@onready var collision_pallet_jack_up: CollisionPolygon2D = $CollisionPalletJackUp
@onready var collision_pallet_jack_down: CollisionPolygon2D = $CollisionPalletJackDown
@onready var collision_transporter_left: CollisionPolygon2D = $CollisionTransporterLeft
@onready var collision_transporter_right: CollisionPolygon2D = $CollisionTransporterRight
@onready var collision_transporter_up: CollisionPolygon2D = $CollisionTransporterUp
@onready var collision_transporter_down: CollisionPolygon2D = $CollisionTransporterDown

var last_direction := Vector2.DOWN
var _held_movement_directions: Array[Vector2] = []
var _input_facing_direction := Vector2.DOWN
var _touch_direction := Vector2.ZERO
var _touch_sprinting := false
var _active_collision: Node2D
var _vehicle_frame := 0
var _vehicle_frame_time := 0.0
var _nearby_vehicles: Array[PickupVehicle] = []
var _carried_vehicle: PickupVehicle
var _pickup_offset := Vector2.ZERO
var _gate_interaction: Node
var _door_interaction: Node
var _stair_interaction: Node
var _lift_interaction: Node
var _maintenance_zone: Node
var _table_hints: Node
var _workstation_hints: Array[Area2D] = []
var _demo_tasks: Node
var _interaction_hint: RichTextLabel
var _interaction_locked := false
var transporter_loaded := false
var pallet_jack_loaded := false
var pallet_jack_pallet_loaded := false
var pallet_jack_animation_test := false
var pallet_jack_totes_animation_test := false
var _pallet_test_sprite: Sprite2D
var _tote_sprite: Sprite2D
var _tote_collision: CollisionShape2D
var _tote_direction := ""
var _jack_depth: Node2D
const PalletJackDepth = preload("res://pallet_jack_depth.gd")
const PALLET_JACK_TOTES_TEXTURE = preload("res://assets/objects/pallet_jack_operator/pallet_jack_operator_blue_tote_stack_walk_300.png")
const PALLET_JACK_PALLET_TEXTURE = preload("res://assets/objects/pallet_jack_operator/pallet_jack_operator_pallet_walk_300.png")
const PALLET_VISUAL_OFFSETS := {
	"left": Vector2(45, -7), "right": Vector2(-48, -7),
	"up": Vector2(0, 43), "down": Vector2(0, -38),
}
# The edited horizontal sheets share the empty jack's centered 25-pixel padding.
const TOTE_VISUAL_OFFSETS := {
	"left": Vector2(45, -7), "right": Vector2(-48, -7),
	"up": Vector2(0, 43), "down": Vector2(0, -38),
}
const TOTE_CARGO_BASES := {
	"left": Vector2(87, 40), "right": Vector2(-90, 40),
	"up": Vector2(13, 86), "down": Vector2(-3, -51),
}
var _cargo_collision: CollisionShape2D
var _cargo_direction := ""
const TRANSPORTER_EMPTY_TEXTURE = preload("res://assets/objects/transporter/transporter_walk_208.png")
const TRANSPORTER_LOADED_TEXTURE = preload("res://assets/objects/transporter/transporter_pallet_small_boxes_walk_208.png")
const TRANSPORTER_CARGO_FOOT_OFFSET := Vector2(0, 12)
const TRANSPORTER_CARGO_BASES := {
	"left": Vector2(18, 34), "right": Vector2(-20, 34),
	"up": Vector2(0, 42), "down": Vector2(0, 14),
}


func _ready() -> void:
	if Engine.is_editor_hint():
		_refresh_editor_preview()
		return

	_jack_depth = PalletJackDepth.new()
	_jack_depth.name = "DepthSort"
	pallet_jack_visual.add_child(_jack_depth)
	_apply_mode_visuals()
	_apply_collision_profile(last_direction)
	_update_vehicle_frame(last_direction, 0)
	_create_interaction_hint()


func _process(_delta: float) -> void:
	if not Engine.is_editor_hint():
		_update_interaction_hint()


func _physics_process(delta: float) -> void:
	if Engine.is_editor_hint():
		return
	if _interaction_locked:
		velocity = Vector2.ZERO
		_update_active_visual(false, false, delta)
		return
	var direction := _read_direction()
	_move_with_direction(direction, Input.is_key_pressed(KEY_SHIFT) or _touch_sprinting, delta, _input_facing_direction)


func set_touch_input(direction: Vector2, sprinting: bool) -> void:
	_touch_direction = direction
	_touch_sprinting = sprinting


func _move_with_direction(direction: Vector2, run_pressed: bool, delta: float, facing_direction := Vector2.ZERO) -> void:
	var is_running := move_mode == MoveMode.ON_FOOT and run_pressed
	var is_moving := direction != Vector2.ZERO
	var facing := last_direction
	if is_moving:
		facing = _cardinal_direction(direction) if facing_direction == Vector2.ZERO else facing_direction
	var facing_ready := _try_face_direction(facing)
	if is_moving and facing_ready:
		velocity = direction.normalized() * _movement_speed(is_running)
	else:
		velocity = Vector2.ZERO

	_update_active_visual(is_moving and facing_ready, is_running, delta)
	move_and_slide()


func _unhandled_input(event: InputEvent) -> void:
	if Engine.is_editor_hint() or _interaction_locked or event.is_echo() or not (event.is_action_pressed("interact") or event.is_action_pressed("interact_secondary")):
		return
	if is_instance_valid(_demo_tasks) and _demo_tasks.try_interact(self):
		_update_interaction_hint()
		get_viewport().set_input_as_handled()
		return
	if is_instance_valid(_gate_interaction) and _gate_interaction.call("try_interact", self):
		_update_interaction_hint()
		get_viewport().set_input_as_handled()
		return
	if is_instance_valid(_door_interaction) and _door_interaction.call("try_interact", self):
		_update_interaction_hint()
		get_viewport().set_input_as_handled()
		return
	if is_instance_valid(_stair_interaction) and _stair_interaction.call("try_interact", self):
		_update_interaction_hint()
		get_viewport().set_input_as_handled()
		return
	if is_instance_valid(_lift_interaction) and _lift_interaction.call("try_interact", self, event):
		_update_interaction_hint()
		get_viewport().set_input_as_handled()
		return
	if _interact_with_vehicle():
		_update_interaction_hint()
		get_viewport().set_input_as_handled()


func register_pickup_vehicle(vehicle: PickupVehicle) -> void:
	if not _nearby_vehicles.has(vehicle):
		_nearby_vehicles.append(vehicle)


func unregister_pickup_vehicle(vehicle: PickupVehicle) -> void:
	_nearby_vehicles.erase(vehicle)


func register_gate_interaction(gate: Node) -> void:
	_gate_interaction = gate


func unregister_gate_interaction(gate: Node) -> void:
	if _gate_interaction == gate:
		_gate_interaction = null


func register_door_interaction(door: Node) -> void:
	_door_interaction = door


func unregister_door_interaction(door: Node) -> void:
	if _door_interaction == door:
		_door_interaction = null


func register_stair_interaction(stair: Node) -> void:
	_stair_interaction = stair


func unregister_stair_interaction(stair: Node) -> void:
	if _stair_interaction == stair:
		_stair_interaction = null


func register_lift_interaction(lift: Node) -> void:
	_lift_interaction = lift


func unregister_lift_interaction(lift: Node) -> void:
	if _lift_interaction == lift:
		_lift_interaction = null


func register_maintenance_zone(zone: Node) -> void:
	_maintenance_zone = zone


func unregister_maintenance_zone(zone: Node) -> void:
	if _maintenance_zone == zone:
		_maintenance_zone = null


func set_interaction_locked(locked: bool) -> void:
	_interaction_locked = locked
	if locked:
		velocity = Vector2.ZERO
		set_touch_input(Vector2.ZERO, false)
	_update_interaction_hint()


func register_table_hints(tables: Node) -> void:
	_table_hints = tables


func unregister_table_hints(tables: Node) -> void:
	if _table_hints == tables:
		_table_hints = null


func register_workstation_hint(workstation: Area2D) -> void:
	if not _workstation_hints.has(workstation):
		_workstation_hints.append(workstation)


func unregister_workstation_hint(workstation: Area2D) -> void:
	_workstation_hints.erase(workstation)


func _nearest_workstation_hint() -> Area2D:
	var nearest: Area2D
	var nearest_distance := INF
	var feet := global_position + Vector2(0, 25)
	for workstation in _workstation_hints:
		if not is_instance_valid(workstation) or not workstation.call("contains_actor", self):
			continue
		var distance := feet.distance_squared_to(workstation.global_position)
		if distance < nearest_distance:
			nearest = workstation
			nearest_distance = distance
	return nearest


func _create_interaction_hint() -> void:
	var hud := CanvasLayer.new()
	hud.name = "InteractionHUD"
	hud.layer = 20
	add_child(hud, false, Node.INTERNAL_MODE_FRONT)
	_interaction_hint = RichTextLabel.new()
	_interaction_hint.name = "InteractionHint"
	_interaction_hint.position = Vector2(16, 16)
	_interaction_hint.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_interaction_hint.texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	_interaction_hint.custom_minimum_size = Vector2(300, 0)
	_interaction_hint.bbcode_enabled = true
	_interaction_hint.fit_content = true
	_interaction_hint.scroll_active = false
	_interaction_hint.focus_mode = Control.FOCUS_NONE
	_interaction_hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_interaction_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_LEFT
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Segoe UI", "Arial"])
	font.font_weight = 600
	font.oversampling = 1.0
	_interaction_hint.add_theme_font_override("normal_font", font)
	_interaction_hint.add_theme_font_size_override("normal_font_size", 16)
	var background := StyleBoxFlat.new()
	background.bg_color = Color(0.03, 0.035, 0.04, 0.94)
	background.content_margin_left = 10
	background.content_margin_right = 10
	background.content_margin_top = 7
	background.content_margin_bottom = 7
	_interaction_hint.add_theme_stylebox_override("normal", background)
	_interaction_hint.visible = false
	hud.add_child(_interaction_hint)


func _update_interaction_hint() -> void:
	if _interaction_hint == null:
		return
	var touch := get_tree().get_first_node_in_group("touch_controls")
	var mobile: bool = (touch != null and touch.available) or DisplayServer.is_touchscreen_available()
	var viewport_size := get_viewport_rect().size
	var short_landscape := mobile and viewport_size.x >= 640.0 and viewport_size.y < 450.0
	var hint_width := minf(240.0 if mobile else 300.0, maxf(1.0, viewport_size.x - 32.0))
	var top_hint_position := Vector2.ZERO
	if short_landscape:
		hint_width = minf(hint_width, maxf(1.0, viewport_size.x - 408.0))
	if mobile and viewport_size.x > viewport_size.y and touch != null and is_instance_valid(touch._minimap) and is_instance_valid(_demo_tasks) and is_instance_valid(_demo_tasks._task_panel):
		var minimap_rect: Rect2 = touch._minimap.get_global_rect()
		var task_rect: Rect2 = _demo_tasks._task_panel.get_global_rect()
		var gap_width := task_rect.position.x - minimap_rect.end.x - 32.0
		# Keep long explanations out of the scene when the upper HUD has room.
		if gap_width >= 200.0:
			hint_width = minf(hint_width, gap_width)
			top_hint_position = Vector2(minimap_rect.end.x + 16.0 + (gap_width - hint_width) / 2.0, 16.0)
	if mobile and viewport_size.y > viewport_size.x and touch != null and is_instance_valid(touch._minimap):
		var minimap_rect: Rect2 = touch._minimap.get_global_rect()
		top_hint_position = Vector2(minimap_rect.position.x, minimap_rect.end.y + 12.0)
		hint_width = minimap_rect.size.x
	if not mobile:
		var minimap := get_tree().get_first_node_in_group("desktop_minimap") as Control
		if minimap != null and minimap.is_visible_in_tree() and minimap.player == self:
			var minimap_rect := minimap.get_global_rect()
			top_hint_position = Vector2(minimap_rect.position.x, minimap_rect.end.y + 12.0)
	var width_changed := not is_equal_approx(_interaction_hint.custom_minimum_size.x, hint_width)
	var font_size := 12 if mobile else 16
	var style_changed := _interaction_hint.get_theme_font_size("normal_font_size") != font_size
	if style_changed:
		_interaction_hint.add_theme_font_size_override("normal_font_size", font_size)
		var background := _interaction_hint.get_theme_stylebox("normal") as StyleBoxFlat
		background.content_margin_left = 6 if mobile else 10
		background.content_margin_right = 6 if mobile else 10
		background.content_margin_top = 6 if mobile else 7
		background.content_margin_bottom = 6 if mobile else 7
	_interaction_hint.custom_minimum_size.x = hint_width
	var text := ""
	var highlight_title := false
	if not _interaction_locked and is_visible_in_tree():
		if is_instance_valid(_demo_tasks):
			text = _demo_tasks.get_interaction_text(self)
			highlight_title = text.contains("\n")
		if text.is_empty() and is_instance_valid(_gate_interaction):
			text = _gate_interaction.call("get_interaction_text", self)
		if text.is_empty() and is_instance_valid(_door_interaction):
			text = _door_interaction.call("get_interaction_text", self)
			highlight_title = not text.is_empty()
		if text.is_empty() and is_instance_valid(_stair_interaction):
			text = _stair_interaction.call("get_interaction_text", self)
			highlight_title = not text.is_empty()
		if text.is_empty() and is_instance_valid(_lift_interaction):
			text = _lift_interaction.call("get_interaction_text", self)
			highlight_title = not text.is_empty()
		if text.is_empty() and not is_instance_valid(_carried_vehicle):
			var vehicle := _nearest_pickup_vehicle()
			if vehicle != null:
				text = _demo_tasks.get_vehicle_hint(vehicle) if is_instance_valid(_demo_tasks) and not _demo_tasks.can_use_vehicle(vehicle) else vehicle.get_interaction_text()
				highlight_title = true
		if text.is_empty():
			var workstation := _nearest_workstation_hint()
			if workstation != null:
				text = workstation.call("get_interaction_text", self)
				highlight_title = not text.is_empty()
		if text.is_empty() and is_instance_valid(_table_hints):
			text = _table_hints.call("get_interaction_text", self)
			highlight_title = not text.is_empty()
		if text.is_empty() and is_instance_valid(_maintenance_zone):
			text = _maintenance_zone.call("get_interaction_text", self)
	if mobile:
		text = TouchControls.format_hint(text)
	_interaction_hint.visible = not text.is_empty()
	var hint_text := text
	if highlight_title:
		var lines := text.split("\n", true, 1)
		hint_text = "[color=#ff6868]%s[/color]" % lines[0]
		if lines.size() > 1:
			hint_text += "\n" + lines[1]
	if _interaction_hint.text != hint_text or width_changed or style_changed:
		_interaction_hint.text = hint_text
		_interaction_hint.reset_size()
	_interaction_hint.position = Vector2(160.0 if short_landscape else 16.0, maxf(108.0 if short_landscape else 184.0, viewport_size.y - 208.0 - _interaction_hint.size.y)) if mobile else Vector2(16, 16)
	if not top_hint_position.is_zero_approx():
		_interaction_hint.position = top_hint_position

func interaction_hud_rect() -> Rect2:
	if _interaction_hint != null and _interaction_hint.is_visible_in_tree():
		return _interaction_hint.get_global_rect()
	return Rect2()


func _nearest_pickup_vehicle() -> PickupVehicle:
	var nearest: PickupVehicle
	var nearest_distance := INF
	var allowed: PickupVehicle
	var allowed_distance := INF
	for vehicle in _nearby_vehicles:
		if not is_instance_valid(vehicle) or vehicle.is_carried:
			continue
		var distance := global_position.distance_squared_to(vehicle.interaction_area.global_position)
		if distance < nearest_distance:
			nearest = vehicle
			nearest_distance = distance
		if is_instance_valid(_demo_tasks) and _demo_tasks.can_use_vehicle(vehicle) and distance < allowed_distance:
			allowed = vehicle
			allowed_distance = distance
	return allowed if allowed != null else nearest


func _interact_with_vehicle() -> bool:
	if is_instance_valid(_demo_tasks):
		var selected := _carried_vehicle if is_instance_valid(_carried_vehicle) else _nearest_pickup_vehicle()
		if selected != null and not _demo_tasks.can_use_vehicle(selected):
			return true
	if is_instance_valid(_carried_vehicle):
		var vehicle := _carried_vehicle
		_carried_vehicle = null
		vehicle.global_position = global_position + _pickup_offset
		set_move_mode(MoveMode.ON_FOOT)
		vehicle.set_carried(false)
		if is_instance_valid(_demo_tasks):
			_demo_tasks.on_vehicle_dropped(vehicle)
		return true

	var nearest := _nearest_pickup_vehicle()
	if nearest == null:
		return false

	_pickup_offset = nearest.global_position - global_position
	_carried_vehicle = nearest
	_nearby_vehicles.erase(nearest)
	nearest.set_carried(true)
	set_move_mode(nearest.vehicle_mode)
	if is_instance_valid(_demo_tasks):
		_demo_tasks.on_vehicle_picked_up(nearest)
	return true


func register_demo_tasks(tasks: Node) -> void:
	_demo_tasks = tasks
	_update_interaction_hint()


func unregister_demo_tasks(tasks: Node) -> void:
	if _demo_tasks == tasks:
		_demo_tasks = null


func set_move_mode(new_mode: int) -> void:
	move_mode = clampi(new_mode, MoveMode.ON_FOOT, MoveMode.TRANSPORTER)
	if move_mode != MoveMode.TRANSPORTER:
		set_transporter_cargo(false)
	if move_mode != MoveMode.PALLET_JACK:
		set_pallet_jack_totes(false)
		set_pallet_jack_pallet(false)
	elif pallet_jack_totes_animation_test:
		set_pallet_jack_totes(true, true)
	_reset_vehicle_animation()
	_apply_mode_visuals()
	_update_vehicle_frame(last_direction, 0)


func get_save_state(world: Node) -> Dictionary:
	return {
		"position": [global_position.x, global_position.y],
		"direction": [last_direction.x, last_direction.y],
		"vehicle": str(world.get_path_to(_carried_vehicle)) if is_instance_valid(_carried_vehicle) else "",
		"pickup_offset": [_pickup_offset.x, _pickup_offset.y],
	}


func restore_save_state(state: Dictionary, world: Node) -> void:
	set_transporter_cargo(false)
	set_pallet_jack_totes(false)
	set_pallet_jack_pallet(false)
	global_position = Vector2(state.position[0], state.position[1])
	last_direction = Vector2(state.direction[0], state.direction[1])
	_pickup_offset = Vector2(state.pickup_offset[0], state.pickup_offset[1])
	_carried_vehicle = world.get_node_or_null(NodePath(state.vehicle)) as PickupVehicle if not state.vehicle.is_empty() else null
	_nearby_vehicles.clear()
	_held_movement_directions.clear()
	_input_facing_direction = last_direction
	velocity = Vector2.ZERO
	set_move_mode(_carried_vehicle.vehicle_mode if _carried_vehicle != null else MoveMode.ON_FOOT)
	if _carried_vehicle != null:
		_carried_vehicle.set_carried(true)
	_apply_collision_profile(last_direction)
	_update_active_visual(false, false, 0.0)
	$Camera2D.reset_smoothing()


func _movement_speed(is_running: bool) -> float:
	match move_mode:
		MoveMode.PALLET_JACK:
			return pallet_jack_speed
		MoveMode.TRANSPORTER:
			return transporter_speed
		_:
			return run_speed if is_running else walk_speed


func _update_active_visual(is_moving: bool, is_running: bool, delta: float) -> void:
	if move_mode == MoveMode.ON_FOOT:
		if is_moving:
			_play_move(last_direction, is_running)
		else:
			_play_idle(last_direction)
		return

	if is_moving:
		_vehicle_frame_time += delta
		var frame_duration := 1.0 / vehicle_animation_fps
		while _vehicle_frame_time >= frame_duration:
			_vehicle_frame_time -= frame_duration
			_vehicle_frame = (_vehicle_frame + 1) % 8
	else:
		_reset_vehicle_animation()

	_update_vehicle_frame(last_direction, _vehicle_frame)


func _reset_vehicle_animation() -> void:
	_vehicle_frame = 0
	_vehicle_frame_time = 0.0


func _apply_mode_visuals() -> void:
	_set_visible_mode(move_mode)


func _set_visible_mode(mode: int) -> void:
	on_foot_visual.visible = mode == MoveMode.ON_FOOT
	pallet_jack_visual.visible = mode == MoveMode.PALLET_JACK
	transporter_visual.visible = mode == MoveMode.TRANSPORTER


func _update_vehicle_frame(direction: Vector2, frame: int) -> void:
	var direction_name := _collision_direction_name(direction)
	_set_pallet_jack_frame(direction_name, frame)
	_set_transporter_frame(direction_name, frame)


func _set_pallet_jack_frame(direction_name: String, frame: int) -> void:
	_update_tote_collision(direction_name)
	if _pallet_test_sprite != null:
		_pallet_test_sprite.visible = (pallet_jack_animation_test or pallet_jack_pallet_loaded) and not pallet_jack_loaded
	if _tote_sprite != null:
		_tote_sprite.visible = pallet_jack_loaded
	if pallet_jack_loaded:
		pallet_jack_horizontal.hide()
		pallet_jack_vertical.hide()
		_tote_sprite.position = TOTE_VISUAL_OFFSETS[direction_name]
		_tote_sprite.frame_coords = Vector2i(frame, ["left", "right", "up", "down"].find(direction_name))
		_update_jack_depth(_tote_sprite, direction_name)
		return
	if pallet_jack_animation_test or pallet_jack_pallet_loaded:
		pallet_jack_horizontal.hide()
		pallet_jack_vertical.hide()
		_pallet_test_sprite.position = PALLET_VISUAL_OFFSETS[direction_name]
		_pallet_test_sprite.frame_coords = Vector2i(frame, ["left", "right", "up", "down"].find(direction_name))
		_update_jack_depth(_pallet_test_sprite, direction_name, true)
		return
	var is_horizontal := direction_name == "left" or direction_name == "right"
	pallet_jack_horizontal.visible = is_horizontal
	pallet_jack_vertical.visible = not is_horizontal

	if is_horizontal:
		pallet_jack_horizontal.position = (
			Vector2(45, -7) if direction_name == "left" else Vector2(-48, -7)
		)
		pallet_jack_horizontal.frame_coords = Vector2i(
			frame, 0 if direction_name == "left" else 1
		)
		_update_jack_depth(pallet_jack_horizontal, direction_name)
		return

	pallet_jack_vertical.position = (
		Vector2(0, 43) if direction_name == "up" else Vector2(0, -38)
	)
	pallet_jack_vertical.frame_coords = Vector2i(
		frame, 0 if direction_name == "up" else 1
	)
	_update_jack_depth(pallet_jack_vertical, direction_name)


func set_pallet_jack_animation_test(enabled: bool, blue_totes := false) -> void:
	var was_testing_totes := pallet_jack_totes_animation_test
	pallet_jack_animation_test = enabled
	pallet_jack_totes_animation_test = enabled and blue_totes
	if enabled:
		_ensure_pallet_sprite()
	if move_mode == MoveMode.PALLET_JACK and (pallet_jack_totes_animation_test or was_testing_totes):
		set_pallet_jack_totes(pallet_jack_totes_animation_test, true)
	_set_pallet_jack_frame(_collision_direction_name(last_direction), _vehicle_frame)

func _ensure_pallet_sprite() -> void:
	if _pallet_test_sprite == null:
		_pallet_test_sprite = Sprite2D.new()
		_pallet_test_sprite.name = "PalletAnimationTest"
		_pallet_test_sprite.texture = PALLET_JACK_PALLET_TEXTURE
		_pallet_test_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		_pallet_test_sprite.hframes = 8
		_pallet_test_sprite.vframes = 4
		_pallet_test_sprite.scale = Vector2.ONE * 0.5
		pallet_jack_visual.add_child(_pallet_test_sprite)


func _update_jack_depth(source: Sprite2D, direction_name: String, empty_pallet := false) -> void:
	if _jack_depth != null:
		_jack_depth.update_frame(source, direction_name, pallet_jack_loaded, empty_pallet)


func _set_transporter_frame(direction_name: String, frame: int) -> void:
	_update_transporter_cargo(direction_name)
	var row := 3
	match direction_name:
		"left":
			row = 0
		"right":
			row = 1
		"up":
			row = 2
	transporter_sprite.frame_coords = Vector2i(frame, row)


func _request_editor_preview() -> void:
	if Engine.is_editor_hint() and is_node_ready():
		call_deferred("_refresh_editor_preview")


func _refresh_editor_preview() -> void:
	if not Engine.is_editor_hint() or not is_node_ready():
		return

	var direction := _preview_direction_vector()
	var direction_name := _collision_direction_name(direction)
	_set_visible_mode(preview_mode)
	_set_on_foot_preview(direction, preview_frame)
	_set_pallet_jack_frame(direction_name, preview_frame)
	_set_transporter_frame(direction_name, preview_frame)


func _set_on_foot_preview(direction: Vector2, frame: int) -> void:
	var animation := "move_%s" % _animation_direction_name(direction)
	if not sprite.sprite_frames.has_animation(animation):
		return

	sprite.stop()
	sprite.animation = animation
	var frame_count := sprite.sprite_frames.get_frame_count(animation)
	sprite.frame = clampi(frame, 0, maxi(frame_count - 1, 0))


func _preview_direction_vector() -> Vector2:
	match preview_direction:
		PreviewDirection.UP:
			return Vector2.UP
		PreviewDirection.LEFT:
			return Vector2.LEFT
		PreviewDirection.RIGHT:
			return Vector2.RIGHT
		_:
			return Vector2.DOWN


func _try_face_direction(direction: Vector2) -> bool:
	var previous_collision := _active_collision
	if not _apply_collision_profile(direction):
		if move_mode == MoveMode.ON_FOOT:
			return false
		if not _make_room_for_turn(_collision_for_mode(direction), direction):
			return false
		if not _apply_collision_profile(direction):
			return false
	if direction != last_direction:
		last_direction = direction
		_reset_vehicle_animation()
	return previous_collision == _active_collision


func _apply_collision_profile(direction: Vector2) -> bool:
	var target := _collision_for_mode(direction)
	if target == _active_collision:
		return true
	if _active_collision != null and _collision_profile_overlaps(target):
		return false

	for collision in _all_collisions():
		var operator_feet := move_mode == MoveMode.PALLET_JACK and collision == collision_on_foot
		collision.set_deferred("disabled", collision != target and not operator_feet)
	_active_collision = target
	return true


func _make_room_for_turn(target: Node2D, direction: Vector2) -> bool:
	var push_directions: Array[Vector2] = [
		direction,
		Vector2(-direction.y, direction.x),
		Vector2(direction.y, -direction.x),
		-direction,
	]
	var blocked := [false, false, false, false]
	for distance in range(1, turn_knockback_limit + 1):
		for index in push_directions.size():
			if blocked[index]:
				continue
			var offset: Vector2 = push_directions[index] * float(distance)
			if test_move(global_transform, offset, null, 0.0):
				blocked[index] = true
				continue
			if not _collision_profile_overlaps(target, offset):
				global_position += offset
				return true
	return false


func _collision_profile_overlaps(target: Node2D, offset := Vector2.ZERO) -> bool:
	var shape_transform := target.global_transform
	shape_transform.origin += offset
	for shape in _collision_profile_shapes(target):
		if _shape_overlaps(shape, shape_transform):
			return true
	# The operator walks alongside the jack; turning must clear both footprints.
	if move_mode == MoveMode.PALLET_JACK and target != collision_on_foot:
		var feet_transform := collision_on_foot.global_transform
		feet_transform.origin += offset
		if _shape_overlaps(collision_on_foot.shape, feet_transform):
			return true
	if move_mode == MoveMode.TRANSPORTER and transporter_loaded:
		var direction := _cargo_direction_for_collision(target)
		if _shape_overlaps(_cargo_shape(direction), Transform2D(0, global_position + offset + TRANSPORTER_CARGO_BASES[direction] - TRANSPORTER_CARGO_FOOT_OFFSET)):
			return true
	if move_mode == MoveMode.PALLET_JACK and (pallet_jack_loaded or pallet_jack_pallet_loaded):
		var direction := _cargo_direction_for_collision(target)
		if _shape_overlaps(_tote_shape(), Transform2D(0, global_position + offset + TOTE_CARGO_BASES[direction])):
			return true
	return false


func set_pallet_jack_totes(loaded: bool, restoring := false) -> bool:
	if loaded and (move_mode != MoveMode.PALLET_JACK or (not restoring and not can_load_pallet_jack_totes())):
		return false
	pallet_jack_loaded = loaded
	if loaded:
		pallet_jack_pallet_loaded = false
	if loaded and _tote_sprite == null:
		_tote_sprite = Sprite2D.new()
		_tote_sprite.name = "BlueToteStack"
		_tote_sprite.texture = PALLET_JACK_TOTES_TEXTURE
		_tote_sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		_tote_sprite.hframes = 8
		_tote_sprite.vframes = 4
		_tote_sprite.scale = Vector2.ONE * 0.5
		pallet_jack_visual.add_child(_tote_sprite)
	if loaded:
		_ensure_jack_load_collision()
	_tote_direction = ""
	_set_pallet_jack_frame(_collision_direction_name(last_direction), _vehicle_frame)
	return true

func _ensure_jack_load_collision() -> void:
	if _tote_collision == null:
		_tote_collision = CollisionShape2D.new()
		_tote_collision.name = "CollisionBlueTotes"
		_tote_collision.disabled = true
		_tote_collision.shape = _tote_shape()
		add_child(_tote_collision)

func set_pallet_jack_pallet(loaded: bool, restoring := false, excluded: Array[RID] = []) -> bool:
	if loaded and (move_mode != MoveMode.PALLET_JACK or (not restoring and not can_load_pallet_jack_totes(excluded))):
		return false
	pallet_jack_pallet_loaded = loaded
	if loaded:
		pallet_jack_loaded = false
		_ensure_pallet_sprite()
		_ensure_jack_load_collision()
	_tote_direction = ""
	_set_pallet_jack_frame(_collision_direction_name(last_direction), _vehicle_frame)
	return true


func can_load_pallet_jack_totes(excluded: Array[RID] = []) -> bool:
	var direction := _collision_direction_name(last_direction)
	var query := _shape_query(_tote_shape(), Transform2D(0, global_position + TOTE_CARGO_BASES[direction]))
	var exclusions := query.exclude
	exclusions.append_array(excluded)
	query.exclude = exclusions
	return move_mode == MoveMode.PALLET_JACK and get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()


func _update_tote_collision(direction: String) -> void:
	if _tote_collision == null:
		return
	var loaded := pallet_jack_loaded or pallet_jack_pallet_loaded
	if _tote_collision.disabled == loaded:
		_tote_collision.set_deferred("disabled", not loaded)
	if loaded and direction != _tote_direction:
		_tote_direction = direction
		_tote_collision.position = TOTE_CARGO_BASES[direction]


func _tote_shape() -> RectangleShape2D:
	var shape := RectangleShape2D.new()
	shape.size = Vector2(34, 18)
	return shape


func set_transporter_cargo(loaded: bool, restoring := false) -> bool:
	if loaded and move_mode != MoveMode.TRANSPORTER:
		return false
	var direction := _collision_direction_name(last_direction)
	if loaded and not restoring and not can_load_transporter_cargo():
		return false
	transporter_loaded = loaded
	transporter_sprite.texture = TRANSPORTER_LOADED_TEXTURE if loaded else TRANSPORTER_EMPTY_TEXTURE
	if loaded and _cargo_collision == null:
		_cargo_collision = CollisionShape2D.new()
		_cargo_collision.name = "CollisionSmallBoxesCargo"
		_cargo_collision.disabled = true
		add_child(_cargo_collision)
	_update_transporter_cargo(direction)
	return true


func transporter_cargo_ground_point() -> Vector2:
	return global_position + TRANSPORTER_CARGO_BASES[_collision_direction_name(last_direction)]


func can_load_transporter_cargo() -> bool:
	var direction := _collision_direction_name(last_direction)
	return move_mode == MoveMode.TRANSPORTER and not _shape_overlaps(_cargo_shape(direction), Transform2D(0, transporter_cargo_ground_point() - TRANSPORTER_CARGO_FOOT_OFFSET))


func _update_transporter_cargo(direction: String) -> void:
	if _cargo_collision == null:
		return
	if _cargo_collision.disabled == transporter_loaded:
		_cargo_collision.set_deferred("disabled", not transporter_loaded)
	if not transporter_loaded:
		_cargo_direction = ""
		return
	if _cargo_direction == direction:
		return
	_cargo_direction = direction
	var base: Vector2 = TRANSPORTER_CARGO_BASES[direction]
	_cargo_collision.position = base - TRANSPORTER_CARGO_FOOT_OFFSET
	_cargo_collision.shape = _cargo_shape(direction)


func _cargo_shape(direction: String) -> RectangleShape2D:
	var shape := RectangleShape2D.new()
	shape.size = Vector2(70, 24) if direction in ["left", "right"] else Vector2(50, 24)
	return shape


func _cargo_direction_for_collision(target: Node2D) -> String:
	if target == collision_transporter_left or target == collision_pallet_jack_left:
		return "left"
	if target == collision_transporter_right or target == collision_pallet_jack_right:
		return "right"
	return "up" if target == collision_transporter_up or target == collision_pallet_jack_up else "down"


func _collision_profile_shapes(target: Node2D) -> Array[Shape2D]:
	var shapes: Array[Shape2D] = []
	if target is CollisionShape2D:
		if target.shape != null:
			shapes.append(target.shape)
	if target is CollisionPolygon2D:
		for polygon in Geometry2D.decompose_polygon_in_convex(target.polygon):
			var shape := ConvexPolygonShape2D.new()
			shape.points = polygon
			shapes.append(shape)
	return shapes


func _shape_overlaps(shape: Shape2D, shape_transform: Transform2D) -> bool:
	return not get_world_2d().direct_space_state.intersect_shape(
		_shape_query(shape, shape_transform), 1
	).is_empty()


func _shape_query(shape: Shape2D, shape_transform: Transform2D) -> PhysicsShapeQueryParameters2D:
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = shape
	query.transform = shape_transform
	query.collision_mask = collision_mask
	var excluded: Array[RID] = [get_rid()]
	for body in get_collision_exceptions():
		excluded.append(body.get_rid())
	query.exclude = excluded
	return query


func _collision_for_mode(direction: Vector2) -> Node2D:
	var direction_name := _collision_direction_name(direction)
	match move_mode:
		MoveMode.PALLET_JACK:
			match direction_name:
				"left":
					return collision_pallet_jack_left
				"right":
					return collision_pallet_jack_right
				"up":
					return collision_pallet_jack_up
				_:
					return collision_pallet_jack_down
		MoveMode.TRANSPORTER:
			match direction_name:
				"left":
					return collision_transporter_left
				"right":
					return collision_transporter_right
				"up":
					return collision_transporter_up
				_:
					return collision_transporter_down
		_:
			return collision_on_foot


func _all_collisions() -> Array[Node2D]:
	return [
		collision_on_foot,
		collision_pallet_jack_left,
		collision_pallet_jack_right,
		collision_pallet_jack_up,
		collision_pallet_jack_down,
		collision_transporter_left,
		collision_transporter_right,
		collision_transporter_up,
		collision_transporter_down,
	]


func _collision_direction_name(direction: Vector2) -> String:
	if absf(direction.x) > absf(direction.y):
		return "right" if direction.x > 0.0 else "left"
	return "down" if direction.y >= 0.0 else "up"


func _read_direction() -> Vector2:
	if not _touch_direction.is_zero_approx():
		_held_movement_directions.clear()
		_input_facing_direction = Vector2(signf(_touch_direction.x), 0) if absf(_touch_direction.x) >= absf(_touch_direction.y) else Vector2(0, signf(_touch_direction.y))
		return _touch_direction.normalized()
	var pressed: Array[Vector2] = []
	if Input.is_physical_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
		pressed.append(Vector2.LEFT)
	if Input.is_physical_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
		pressed.append(Vector2.RIGHT)
	if Input.is_physical_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
		pressed.append(Vector2.UP)
	if Input.is_physical_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
		pressed.append(Vector2.DOWN)
	return _update_movement_input(pressed)


func _update_movement_input(pressed: Array[Vector2]) -> Vector2:
	for direction in _held_movement_directions.duplicate():
		if not pressed.has(direction):
			_held_movement_directions.erase(direction)
	# Keys first observed together prefer the horizontal animation.
	for direction in [Vector2.LEFT, Vector2.RIGHT, Vector2.UP, Vector2.DOWN]:
		if pressed.has(direction) and not _held_movement_directions.has(direction):
			_held_movement_directions.append(direction)
	var movement := Vector2.ZERO
	for direction in pressed:
		movement += direction
	_input_facing_direction = last_direction
	for direction in _held_movement_directions:
		if movement.dot(direction) > 0.0:
			_input_facing_direction = direction
			break
	return movement.normalized()


func _cardinal_direction(direction: Vector2) -> Vector2:
	if direction.x != 0.0 and absf(direction.x) >= absf(direction.y):
		return Vector2.RIGHT if direction.x > 0.0 else Vector2.LEFT
	return Vector2.DOWN if direction.y >= 0.0 else Vector2.UP


func _play_move(direction: Vector2, is_running: bool) -> void:
	var name := _animation_direction_name(direction)
	var animation := "move_%s%s" % [name, "_fast" if is_running else ""]
	_play_animation(animation)


func _play_idle(direction: Vector2) -> void:
	_play_animation("idle_%s" % _animation_direction_name(direction))


func _animation_direction_name(direction: Vector2) -> String:
	if absf(direction.x) > absf(direction.y):
		return "right" if direction.x > 0.0 else "left"
	return "down" if direction.y >= 0.0 else "top"


func _play_animation(animation: String) -> void:
	if sprite.sprite_frames.has_animation(animation) and sprite.animation != animation:
		sprite.play(animation)
