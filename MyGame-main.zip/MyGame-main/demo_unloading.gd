extends Node2D

const PALLET_COUNT := 12
const SLOT_CELLS := [
	Vector2i(-78, -103), Vector2i(-75, -103), Vector2i(-65, -103), Vector2i(-68, -103),
	Vector2i(-75, -100), Vector2i(-65, -100), Vector2i(-68, -100),
	Vector2i(-75, -97), Vector2i(-65, -97), Vector2i(-68, -97),
	Vector2i(-68, -94), Vector2i(-65, -94),
]
const SMALL_BOXES_ATLAS := Vector2i(10, 0)
const PALLET_SCALE := 1.0
const PALLET_ORIGIN := Vector2(0, 48)
const SORT_FOOT_OFFSET := Vector2(0, 25)
const PLACEMENT_REACH := 32.0

var placed_count := 0
var target_visible := false
var _floor: TileMapLayer
var _pallets: Node2D
var _texture: AtlasTexture
var _footprint: ConvexPolygonShape2D
var _pulse := 0.0
var _player: CharacterBody2D
var _exit_pallets: Array[StaticBody2D] = []

func _ready() -> void:
	_floor = get_parent() as TileMapLayer
	var actors := _floor.get_parent().get_node("YSortActors")
	_player = actors.get_node("Player")
	var layer := actors.get_node("PalletLayer") as TileMapLayer
	var source := layer.tile_set.get_source(0) as TileSetAtlasSource
	_texture = AtlasTexture.new()
	_texture.atlas = source.texture
	_texture.region = source.get_tile_texture_region(SMALL_BOXES_ATLAS)
	var tile := source.get_tile_data(SMALL_BOXES_ATLAS, 0)
	var points := tile.get_collision_polygon_points(0, 0)
	for index in points.size():
		points[index] = points[index] * PALLET_SCALE - PALLET_ORIGIN
	_footprint = ConvexPolygonShape2D.new()
	_footprint.points = points
	_pallets = Node2D.new()
	_pallets.name = "DemoUnloadedPallets"
	_pallets.y_sort_enabled = true
	actors.add_child(_pallets)

func _exit_tree() -> void:
	_clear_exit_exceptions()
	if is_instance_valid(_pallets):
		_pallets.queue_free()

func _process(delta: float) -> void:
	if target_visible:
		_pulse += delta
		queue_redraw()

func _physics_process(_delta: float) -> void:
	for pallet in _exit_pallets.duplicate():
		if not _overlaps_player(pallet):
			pallet.remove_collision_exception_with(_player)
			_player.remove_collision_exception_with(pallet)
			_exit_pallets.erase(pallet)

func slot_rect(index: int) -> Rect2:
	var corner := _floor.to_global(_floor.map_to_local(SLOT_CELLS[index])) - Vector2(16, 16)
	return Rect2(corner, Vector2(96, 64))

func target_point() -> Vector2:
	return slot_rect(placed_count).get_center()

func set_target_visible(enabled: bool) -> void:
	target_visible = enabled and placed_count < SLOT_CELLS.size()
	queue_redraw()

func can_place(player: Node2D) -> bool:
	if placed_count >= SLOT_CELLS.size() or not player.get("transporter_loaded"):
		return false
	if not slot_rect(placed_count).grow(PLACEMENT_REACH).has_point(player.global_position + SORT_FOOT_OFFSET):
		return false
	if player._collision_profile_overlaps(player._active_collision):
		return false
	# The destination must stay clear of scenery and other pallets, not the placing vehicle.
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = _footprint
	query.transform = Transform2D(0, slot_rect(placed_count).get_center() + Vector2(0, 20))
	query.collision_mask = 1
	query.exclude = [player.get_rid()]
	return get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func set_placed_count(count: int) -> void:
	if placed_count == count and _pallets.get_child_count() == count:
		_refresh_exit_exceptions()
		return
	placed_count = count
	_clear_exit_exceptions()
	for child in _pallets.get_children():
		_pallets.remove_child(child)
		child.free()
	for index in placed_count:
		var pallet := StaticBody2D.new()
		pallet.name = "Pallet%d" % (index + 1)
		pallet.collision_layer = 1
		pallet.collision_mask = 0
		_pallets.add_child(pallet)
		pallet.global_position = slot_rect(index).get_center() + Vector2(0, 20) - SORT_FOOT_OFFSET
		var sprite := Sprite2D.new()
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sprite.texture = _texture
		sprite.scale = Vector2.ONE * PALLET_SCALE
		sprite.position = SORT_FOOT_OFFSET - PALLET_ORIGIN
		pallet.add_child(sprite)
		var collision := CollisionShape2D.new()
		collision.name = "Footprint"
		collision.shape = _footprint
		collision.position = SORT_FOOT_OFFSET
		pallet.add_child(collision)
	_refresh_exit_exceptions()
	queue_redraw()

func _overlaps_player(pallet: StaticBody2D) -> bool:
	var collision := pallet.get_node("Footprint") as CollisionShape2D
	var profiles: Array[Node2D] = [_player._active_collision]
	var facing: Node2D = _player._collision_for_mode(_player.last_direction)
	if facing != _player._active_collision:
		profiles.append(facing)
	if _player.move_mode == _player.MoveMode.PALLET_JACK:
		profiles.append(_player.collision_on_foot)
	if _player.transporter_loaded and is_instance_valid(_player._cargo_collision):
		profiles.append(_player._cargo_collision)
	for profile in profiles:
		for shape in _player._collision_profile_shapes(profile):
			if _footprint.collide(collision.global_transform, shape, profile.global_transform):
				return true
	return false

func _refresh_exit_exceptions() -> void:
	for child in _pallets.get_children():
		var pallet := child as StaticBody2D
		if not _exit_pallets.has(pallet) and _overlaps_player(pallet):
			pallet.add_collision_exception_with(_player)
			_player.add_collision_exception_with(pallet)
			_exit_pallets.append(pallet)

func _clear_exit_exceptions() -> void:
	if is_instance_valid(_player):
		for pallet in _exit_pallets:
			pallet.remove_collision_exception_with(_player)
			_player.remove_collision_exception_with(pallet)
	_exit_pallets.clear()

func _draw() -> void:
	if not target_visible or placed_count >= SLOT_CELLS.size():
		return
	var rect := slot_rect(placed_count)
	rect.position = to_local(rect.position)
	var ink := Color("ffe36b")
	ink.a = 0.75 + sin(_pulse * 3.0) * 0.15
	draw_rect(rect, Color(1, 0.88, 0.25, 0.12))
	draw_rect(rect.grow(-2), ink, false, 2.0)
	draw_string(ThemeDB.fallback_font, rect.position + Vector2(8, -6), "%d / %d" % [placed_count + 1, PALLET_COUNT], HORIZONTAL_ALIGNMENT_LEFT, -1, 14, ink)

static func gate_atlas(remaining: int) -> Vector2i:
	var removed := PALLET_COUNT - remaining
	return Vector2i((removed % 4) * 4, (removed / 4) * 3)
