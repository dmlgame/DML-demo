extends Control

var expanded := true
var _panel: PanelContainer
var _show_button: Button
var _hide_button: Button

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	texture_filter = CanvasItem.TEXTURE_FILTER_LINEAR
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_to_group("controls_hint")
	_panel = PanelContainer.new()
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_theme_stylebox_override("panel", _style(Color(0.03, 0.035, 0.04, 0.94)))
	add_child(_panel)
	var box := VBoxContainer.new()
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_theme_constant_override("separation", 6)
	_panel.add_child(box)
	var header := HBoxContainer.new()
	header.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(header)
	var title := _label("Управление")
	title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	title.add_theme_color_override("font_color", Color("f2cc45"))
	header.add_child(title)
	_hide_button = _button("", "x", "Скрыть подсказку управления")
	_hide_button.custom_minimum_size = Vector2(32, 32)
	_hide_button.pressed.connect(set_expanded.bind(false))
	header.add_child(_hide_button)
	box.add_child(_label("Передвижение: WASD или стрелки"))
	box.add_child(_label("Ускорение: Shift"))
	_show_button = _button("Управление", "settings-2", "Показать подсказку управления")
	_show_button.custom_minimum_size = Vector2(152, 40)
	_show_button.pressed.connect(set_expanded.bind(true))
	add_child(_show_button)
	_panel.minimum_size_changed.connect(func(): _layout.call_deferred())
	resized.connect(_layout)
	set_expanded(expanded)

func set_expanded(value: bool) -> void:
	expanded = value
	if _panel == null:
		return
	_panel.visible = expanded
	_show_button.visible = not expanded
	_layout()

func hint_rect() -> Rect2:
	return (_panel if expanded else _show_button).get_global_rect()

func _layout() -> void:
	if _panel == null:
		return
	var viewport_size := get_viewport_rect().size
	var width := minf(320.0, maxf(1.0, viewport_size.x - 32.0))
	_panel.custom_minimum_size.x = width
	_panel.size.x = width
	_panel.reset_size()
	_panel.position = Vector2(viewport_size.x - width - 16, maxf(16, viewport_size.y - _panel.size.y - 16))
	_show_button.reset_size()
	_show_button.position = viewport_size - _show_button.size - Vector2(16, 16)

func _label(text: String) -> Label:
	var label := Label.new()
	label.text = text
	label.mouse_filter = Control.MOUSE_FILTER_IGNORE
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", 14)
	label.add_theme_color_override("font_color", Color("edf2ed"))
	return label

func _button(text: String, icon: String, tooltip: String) -> Button:
	var button := Button.new()
	button.text = text
	button.tooltip_text = tooltip
	button.focus_mode = Control.FOCUS_NONE
	button.icon = load("res://assets/ui/lucide/" + icon + ".svg")
	button.expand_icon = true
	button.add_theme_constant_override("icon_max_width", 18)
	button.add_theme_constant_override("h_separation", 8)
	button.add_theme_font_size_override("font_size", 14)
	button.add_theme_stylebox_override("normal", _style(Color("303b37"), 6))
	button.add_theme_stylebox_override("hover", _style(Color("46514b"), 6))
	button.add_theme_stylebox_override("pressed", _style(Color("52615b"), 6))
	return button

func _style(color: Color, padding := 12) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = color
	style.border_color = Color("52615b")
	style.set_border_width_all(1)
	style.set_corner_radius_all(3)
	style.content_margin_left = padding
	style.content_margin_right = padding
	style.content_margin_top = padding
	style.content_margin_bottom = padding
	return style
