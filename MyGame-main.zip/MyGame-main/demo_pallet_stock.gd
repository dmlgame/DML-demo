extends Node2D

const FOOT_OFFSET := Vector2(0, 25)
const NO_SOURCE := Vector2i(2147483647, 2147483647)
const PALLET_ATLASES := [Vector2i(2, 0), Vector2i(4, 0), Vector2i(6, 0), Vector2i(2, 3), Vector2i(4, 3), Vector2i(6, 3)]
const STOCK_CELLS := [
	Vector2i(12, -65), Vector2i(14, -66), Vector2i(13, -70), Vector2i(15, -71),
	Vector2i(17, -69), Vector2i(12, -74), Vector2i(15, -75),
	Vector2i(131, -46), Vector2i(128, -46), Vector2i(125, -46),
	Vector2i(131, -44), Vector2i(128, -44), Vector2i(125, -44),
	Vector2i(131, -42), Vector2i(128, -42), Vector2i(125, -42),
	Vector2i(131, -40), Vector2i(128, -40), Vector2i(125, -40),
	Vector2i(131, -38), Vector2i(128, -38), Vector2i(125, -38),
]
const DELIVERY_ORIGIN := Vector2(0, 36)
const DELIVERY_OFFSET := Vector2(96, -96)

var picked_source := NO_SOURCE
var returned_source := NO_SOURCE
var delivered := false
var target_visible := false
var return_target_visible := false
var _world: Node2D
var _stock: TileMapLayer
var _player: CharacterBody2D
var _originals := {}
var _delivery: StaticBody2D
var _footprint: ConvexPolygonShape2D
var _texture: AtlasTexture
var _exit_exception := false

func _ready() -> void:
	_world = get_parent().get_parent()
	_stock = _world.get_node("YSortActors/PalletLayer")
	_player = _world.get_node("YSortActors/Player")
	for cell in STOCK_CELLS:
		if _stock.get_cell_source_id(cell) == 0 and _stock.get_cell_atlas_coords(cell) in PALLET_ATLASES:
			_originals[cell] = {"atlas": _stock.get_cell_atlas_coords(cell), "alternative": _stock.get_cell_alternative_tile(cell)}
	var source := _stock.tile_set.get_source(0) as TileSetAtlasSource
	_texture = AtlasTexture.new()
	_texture.atlas = source.texture
	_texture.region = source.get_tile_texture_region(PALLET_ATLASES[0])
	var points := source.get_tile_data(PALLET_ATLASES[0], 0).get_collision_polygon_points(0, 0)
	for index in points.size():
		points[index] -= DELIVERY_ORIGIN
	_footprint = ConvexPolygonShape2D.new()
	_footprint.points = points

func _exit_tree() -> void:
	_remove_delivery()
	if is_instance_valid(_stock):
		for cell in _originals:
			_stock.set_cell(cell, 0, _originals[cell].atlas, _originals[cell].alternative)

func _physics_process(_delta: float) -> void:
	if _exit_exception and not _overlaps_player():
		_clear_exception()

func is_source_cell(cell: Vector2i) -> bool:
	return _originals.has(cell)

func source_point(cell: Vector2i) -> Vector2:
	var center := _stock.to_global(_stock.map_to_local(cell))
	var nearest := center + Vector2(0, 104)
	var distance := INF
	var shape := RectangleShape2D.new()
	shape.size = Vector2(32, 32)
	# Select a free side of the stack rather than guiding into its neighboring row.
	for offset in [Vector2(0, 104), Vector2(-80, 40), Vector2(80, 40), Vector2(0, -40)]:
		var point: Vector2 = center + offset
		var query := PhysicsShapeQueryParameters2D.new()
		query.shape = shape
		query.transform = Transform2D(0, point)
		query.collision_mask = 1
		query.exclude = [_player.get_rid()]
		var candidate := (_player.global_position + FOOT_OFFSET).distance_squared_to(point)
		if candidate < distance and get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty():
			nearest = point
			distance = candidate
	return nearest

func nearest_source(actor: Node2D) -> Variant:
	var nearest: Variant = null
	var distance := INF
	for cell in _originals:
		if _stock.get_cell_atlas_coords(cell) not in PALLET_ATLASES:
			continue
		var point := _stock.to_global(_stock.map_to_local(cell) + Vector2(0, 40))
		var candidate := (actor.global_position + FOOT_OFFSET).distance_squared_to(point)
		if candidate < distance:
			nearest = cell
			distance = candidate
	return nearest

func nearby_source(actor: Node2D) -> Variant:
	var nearest: Variant = null
	var distance := 92.0 * 92.0
	for cell in _originals:
		if _stock.get_cell_atlas_coords(cell) not in PALLET_ATLASES:
			continue
		var center := _stock.to_global(_stock.map_to_local(cell) + Vector2(0, 40))
		var candidate := (actor.global_position + FOOT_OFFSET).distance_squared_to(center)
		if candidate <= distance:
			nearest = cell
			distance = candidate
	return nearest

func loose_pallet_hint(actor: Node2D) -> String:
	for cell in _stock.get_used_cells():
		if cell in STOCK_CELLS or _stock.get_cell_atlas_coords(cell) not in PALLET_ATLASES:
			continue
		var point := _stock.to_global(_stock.map_to_local(cell) + Vector2(0, 40))
		if (actor.global_position + FOOT_OFFSET).distance_to(point) <= 92:
			return "Паллет\nДля поручения возьмите паллет из зоны складирования в блоке 3. Этот паллет может быть в работе у другого сотрудника."
	return ""

func _remaining_count(cell: Vector2i) -> int:
	if not _originals.has(cell):
		return -1
	return PALLET_ATLASES.find(_originals[cell].atlas) + 1 - (1 if cell == picked_source else 0)

func nearest_return(actor: Node2D) -> Variant:
	var nearest: Variant = null
	var distance := INF
	for cell in _originals:
		if _remaining_count(cell) >= PALLET_ATLASES.size():
			continue
		var candidate := (actor.global_position + FOOT_OFFSET).distance_squared_to(source_point(cell))
		if candidate < distance:
			nearest = cell
			distance = candidate
	return nearest

func can_return(actor: Node2D, cell: Vector2i) -> bool:
	if not actor.get("pallet_jack_pallet_loaded") or returned_source != NO_SOURCE or _remaining_count(cell) not in range(6):
		return false
	var center := _stock.to_global(_stock.map_to_local(cell))
	if (actor.global_position + FOOT_OFFSET).distance_to(center + Vector2(0, 40)) > 92:
		return false
	var source := _stock.tile_set.get_source(0) as TileSetAtlasSource
	var footprint := ConvexPolygonShape2D.new()
	footprint.points = source.get_tile_data(PALLET_ATLASES[_remaining_count(cell)], 0).get_collision_polygon_points(0, 0)
	for profile in [actor._active_collision, actor.collision_on_foot]:
		for shape in actor._collision_profile_shapes(profile):
			if footprint.collide(Transform2D(0, center), shape, profile.global_transform):
				return false
	return true

func nearby_return(actor: Node2D) -> Variant:
	var nearest: Variant = null
	var distance := INF
	for cell in _originals:
		if can_return(actor, cell):
			var candidate := (actor.global_position + FOOT_OFFSET).distance_squared_to(_stock.to_global(_stock.map_to_local(cell) + Vector2(0, 40)))
			if candidate < distance:
				nearest = cell
				distance = candidate
	return nearest

func delivery_point() -> Vector2:
	return _world.get_node("YSortActors/FurnitureSprites/ChairWithNpcRight/InteractionArea").global_position + DELIVERY_OFFSET

func pickup_exclusions() -> Array[RID]:
	var excluded: Array[RID] = []
	if is_instance_valid(_delivery):
		excluded.append(_delivery.get_rid())
	return excluded

func can_take(actor: Node2D) -> bool:
	if not delivered or not is_instance_valid(_delivery) or actor.get("pallet_jack_loaded") or actor.get("pallet_jack_pallet_loaded"):
		return false
	return Rect2(delivery_point() - Vector2(56, 44), Vector2(112, 88)).has_point(actor.global_position + FOOT_OFFSET) and actor.can_load_pallet_jack_totes(pickup_exclusions())

func can_place(actor: Node2D) -> bool:
	if not actor.get("pallet_jack_pallet_loaded") or delivered:
		return false
	if not Rect2(delivery_point() - Vector2(56, 44), Vector2(112, 88)).has_point(actor.global_position + FOOT_OFFSET):
		return false
	if actor._collision_profile_overlaps(actor._active_collision):
		return false
	var query := PhysicsShapeQueryParameters2D.new()
	query.shape = _footprint
	query.transform = Transform2D(0, delivery_point())
	query.collision_mask = 1
	query.exclude = [actor.get_rid()]
	return get_world_2d().direct_space_state.intersect_shape(query, 1).is_empty()

func set_progress(cell: Vector2i, placed: bool, returned := NO_SOURCE) -> void:
	picked_source = cell
	returned_source = returned
	delivered = placed
	for original in _originals:
		var saved: Dictionary = _originals[original]
		var count := _remaining_count(original) + (1 if original == returned else 0)
		if count == 0:
			_stock.erase_cell(original)
		else:
			_stock.set_cell(original, 0, PALLET_ATLASES[count - 1], saved.alternative)
	_stock.update_internals()
	if placed and _delivery == null:
		_delivery = StaticBody2D.new()
		_delivery.name = "DemoReceivingEmptyPallet"
		_delivery.collision_layer = 1
		_delivery.collision_mask = 0
		_world.get_node("YSortActors").add_child(_delivery)
		_delivery.global_position = delivery_point()
		var sprite := Sprite2D.new()
		sprite.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
		sprite.texture = _texture
		sprite.position = -DELIVERY_ORIGIN
		_delivery.add_child(sprite)
		var collision := CollisionShape2D.new()
		collision.shape = _footprint
		_delivery.add_child(collision)
	if not placed:
		_remove_delivery()
	elif not _exit_exception and _overlaps_player():
		_delivery.add_collision_exception_with(_player)
		_player.add_collision_exception_with(_delivery)
		_exit_exception = true
	queue_redraw()

func _overlaps_player() -> bool:
	if not is_instance_valid(_delivery):
		return false
	for profile in [_player._active_collision, _player.collision_on_foot]:
		for shape in _player._collision_profile_shapes(profile):
			if _footprint.collide(Transform2D(0, delivery_point()), shape, profile.global_transform):
				return true
	return false

func _clear_exception() -> void:
	if _exit_exception and is_instance_valid(_delivery) and is_instance_valid(_player):
		_delivery.remove_collision_exception_with(_player)
		_player.remove_collision_exception_with(_delivery)
	_exit_exception = false

func _remove_delivery() -> void:
	_clear_exception()
	if is_instance_valid(_delivery):
		_delivery.free()
	_delivery = null

func set_target_visible(enabled: bool, returning := false) -> void:
	target_visible = enabled
	return_target_visible = returning
	queue_redraw()

func _draw() -> void:
	if return_target_visible:
		for cell in _originals:
			if _remaining_count(cell) < PALLET_ATLASES.size():
				var point := to_local(_stock.to_global(_stock.map_to_local(cell) + Vector2(0, 40)))
				draw_rect(Rect2(point - Vector2(34, 22), Vector2(68, 44)), Color("ffe36b"), false, 2)
	if not target_visible:
		return
	var rect := Rect2(to_local(delivery_point()) - Vector2(34, 22), Vector2(68, 44))
	draw_rect(rect, Color(1, 0.88, 0.25, 0.12))
	draw_rect(rect, Color("ffe36b"), false, 2)
