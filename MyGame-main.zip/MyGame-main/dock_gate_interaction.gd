extends Node

signal transition_finished(opened: bool)

const OPEN_GATE := Vector2i(0, 9)
const CLOSED_GATE := Vector2i(4, 9)
const GREEN_BUTTON := Vector2i(0, 0)
const RED_BUTTON := Vector2i(1, 0)

@export var gate_cell := Vector2i(-37, -106)
@export var button_cell := Vector2i(-35, -106)
@export_range(16, 128, 1) var proximity := 64.0
@export var open_gate_atlas := OPEN_GATE
@export var allow_closing := true
@export var register_with_player := true

@onready var dock: TileMapLayer = $"../YSortActors/UnloadingDockLayer"
@onready var objects: TileMapLayer = $"../YSortActors/ObjectsLayer"
@onready var player: CharacterBody2D = $"../YSortActors/Player"

var is_open := false
var _busy := false
var _closed_gate := CLOSED_GATE
var _closed_button := RED_BUTTON
var _gate_source := 0
var _button_source := 0
var _gate_alternative := 0
var _button_alternative := 0
var _transition_layer: CanvasLayer
var _shade: ColorRect
var _transition: Tween

func _ready() -> void:
	_gate_source = dock.get_cell_source_id(gate_cell)
	_button_source = objects.get_cell_source_id(button_cell)
	if _gate_source < 0 or _button_source < 0:
		push_error("Dock gate or its control button is missing at " + str(gate_cell))
		return
	_gate_alternative = dock.get_cell_alternative_tile(gate_cell)
	_button_alternative = objects.get_cell_alternative_tile(button_cell)
	is_open = dock.get_cell_atlas_coords(gate_cell) == open_gate_atlas
	if not is_open:
		_closed_gate = dock.get_cell_atlas_coords(gate_cell)
	if objects.get_cell_atlas_coords(button_cell) != GREEN_BUTTON:
		_closed_button = objects.get_cell_atlas_coords(button_cell)
	objects.set_cell(button_cell, _button_source, GREEN_BUTTON if is_open else _closed_button, _button_alternative)
	_create_transition_layer()
	if register_with_player:
		player.register_gate_interaction(self)

func _exit_tree() -> void:
	if _transition != null and _transition.is_valid():
		_transition.kill()
	if is_instance_valid(player):
		if register_with_player:
			player.unregister_gate_interaction(self)
		if _busy:
			player.set_interaction_locked(false)

func can_interact(actor: Node2D) -> bool:
	if _busy or _shade == null or (is_open and not allow_closing):
		return false
	var feet := actor.global_position + Vector2(0, 25)
	var button_position := objects.to_global(objects.map_to_local(button_cell))
	return feet.distance_to(button_position) <= proximity

func get_interaction_text(actor: Node2D) -> String:
	if not can_interact(actor):
		return ""
	return "Нажмите E или Enter, чтобы закрыть ворота" if is_open else "Нажмите E или Enter, чтобы открыть ворота"

func try_interact(actor: Node2D) -> bool:
	if not can_interact(actor):
		return false
	return play_transition(_swap_tiles, true)

func play_transition(action: Callable, gate_changed := false) -> bool:
	if _busy or _shade == null:
		return false
	_busy = true
	player.set_interaction_locked(true)
	_transition_layer.visible = true
	_transition = create_tween()
	_transition.tween_property(_shade, "color:a", 1.0, 0.12)
	_transition.tween_callback(action)
	_transition.tween_interval(0.04)
	_transition.tween_property(_shade, "color:a", 0.0, 0.12)
	_transition.tween_callback(_finish_transition.bind(gate_changed))
	return true

func _swap_tiles() -> void:
	# Both tile replacements happen while the screen is fully black.
	is_open = not is_open
	dock.set_cell(gate_cell, _gate_source, open_gate_atlas if is_open else _closed_gate, _gate_alternative)
	objects.set_cell(button_cell, _button_source, GREEN_BUTTON if is_open else _closed_button, _button_alternative)
	dock.update_internals()
	objects.update_internals()

func _finish_transition(gate_changed := true) -> void:
	_transition_layer.visible = false
	_busy = false
	player.set_interaction_locked(false)
	if gate_changed:
		transition_finished.emit(is_open)

func restore_save_state(opened: bool) -> void:
	is_open = opened
	dock.set_cell(gate_cell, _gate_source, open_gate_atlas if is_open else _closed_gate, _gate_alternative)
	objects.set_cell(button_cell, _button_source, GREEN_BUTTON if is_open else _closed_button, _button_alternative)
	dock.update_internals()
	objects.update_internals()

func _create_transition_layer() -> void:
	_transition_layer = CanvasLayer.new()
	_transition_layer.name = "GateTransition"
	_transition_layer.layer = 100
	_transition_layer.visible = false
	add_child(_transition_layer, false, Node.INTERNAL_MODE_FRONT)
	_shade = ColorRect.new()
	_shade.color = Color(0, 0, 0, 0)
	_shade.mouse_filter = Control.MOUSE_FILTER_STOP
	_transition_layer.add_child(_shade)
	_shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
