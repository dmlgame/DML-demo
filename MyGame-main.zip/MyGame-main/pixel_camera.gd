extends Camera2D

@onready var _visuals := get_parent().get_node("Visuals") as Node2D
@onready var _visual_origin := _visuals.position

func _ready() -> void:
	RenderingServer.frame_pre_draw.connect(_align_pixels)

func _align_pixels() -> void:
	_visuals.position = _visual_origin
	if not is_current():
		return
	force_update_scroll()
	var viewport := get_viewport()
	var canvas := viewport.canvas_transform
	var correction := canvas.origin.round() - canvas.origin
	# Move the entire warehouse on one screen-pixel grid, not each object separately.
	canvas.origin += correction
	viewport.canvas_transform = canvas
	# Cancel only that rounding for the player artwork; physics and Y-sort stay precise.
	var visual_parent := _visuals.get_parent() as Node2D
	var screen_to_parent := (canvas * visual_parent.global_transform).affine_inverse()
	_visuals.position = _visual_origin - screen_to_parent.basis_xform(correction)
