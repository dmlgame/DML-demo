extends Node2D


const PLAYER_FOOT_OFFSET := 25.0
const WORKSTATION_CENTRAL_MONITOR_DEPTH_OFFSET := 20.0
const WORKSTATION_SIDE_MONITOR_DEPTH_OFFSET := 8.0
const FootprintSortGeometry = preload("res://footprint_sort_geometry.gd")

var _visuals: Array[Dictionary] = []
var _player: Node2D


func _ready() -> void:
	for child in get_children():
		if child is Sprite2D and child.texture != null:
			_add_sorted_visual(child)
	_find_player()


func _process(_delta: float) -> void:
	if _player == null:
		_find_player()
	if _player == null:
		return
	for entry in _visuals:
		var sprite: Sprite2D = entry.sprite
		var x := sprite.to_local(_player.global_position).x
		var contact_y := FootprintSortGeometry.front_y(entry.polygons, x, entry.fallback)
		var scale_y := sprite.global_transform.y.length()
		var sort_y := contact_y - PLAYER_FOOT_OFFSET / maxf(scale_y, 0.001)
		sort_y += _monitor_depth_offset(sprite) / maxf(scale_y, 0.001)
		var anchor: Node2D = entry.anchor
		if not is_equal_approx(anchor.position.y, sort_y):
			anchor.position.y = sort_y
			var visual: Sprite2D = entry.visual
			visual.position.y = -sort_y


func _add_sorted_visual(sprite: Sprite2D) -> void:
	var polygons := _collision_polygons(sprite)
	var contact_y := -INF
	for polygon in polygons:
		for point in polygon:
			contact_y = maxf(contact_y, point.y)
	if not is_finite(contact_y):
		contact_y = sprite.offset.y + sprite.texture.get_height() * (0.5 if sprite.centered else 1.0)
	var scale_y := sprite.global_transform.y.length()
	var sort_y := contact_y - PLAYER_FOOT_OFFSET / maxf(scale_y, 0.001)
	sort_y += _monitor_depth_offset(sprite) / maxf(scale_y, 0.001)
	var anchor := Node2D.new()
	anchor.name = "SortVisual"
	anchor.position.y = sort_y
	sprite.add_child(anchor)
	var visual := Sprite2D.new()
	visual.texture = sprite.texture
	visual.texture_filter = sprite.texture_filter
	visual.centered = sprite.centered
	visual.offset = sprite.offset
	visual.region_enabled = sprite.region_enabled
	visual.region_rect = sprite.region_rect
	visual.flip_h = sprite.flip_h
	visual.flip_v = sprite.flip_v
	visual.hframes = sprite.hframes
	visual.vframes = sprite.vframes
	visual.frame = sprite.frame
	visual.position.y = -sort_y
	visual.self_modulate = sprite.self_modulate
	anchor.add_child(visual)
	sprite.texture_changed.connect(func(): visual.texture = sprite.texture)
	_visuals.append({"sprite": sprite, "anchor": anchor, "visual": visual, "polygons": polygons, "fallback": contact_y})
	sprite.y_sort_enabled = true
	sprite.z_index = 0
	var tint := sprite.self_modulate
	tint.a = 0.0
	sprite.self_modulate = tint


func _collision_polygons(sprite: Sprite2D) -> Array[PackedVector2Array]:
	var polygons: Array[PackedVector2Array] = []
	var body := sprite.get_node_or_null("StaticBody2D") as Node2D
	if body == null:
		return polygons
	for shape in body.get_children():
		if shape is CollisionPolygon2D:
			var polygon := PackedVector2Array()
			for point in shape.polygon:
				polygon.append(sprite.to_local(shape.to_global(point)))
			polygons.append(polygon)
		elif shape is CollisionShape2D and shape.shape != null:
			var collision_shape := shape as CollisionShape2D
			var rect: Rect2 = collision_shape.shape.get_rect()
			var polygon := PackedVector2Array()
			for point in [rect.position, Vector2(rect.end.x, rect.position.y), rect.end, Vector2(rect.position.x, rect.end.y)]:
				polygon.append(sprite.to_local(shape.to_global(point)))
			polygons.append(polygon)
	return polygons


func _find_player() -> void:
	var ancestor := get_parent()
	while ancestor != null:
		_player = ancestor.get_node_or_null("Player") as Node2D
		if _player != null:
			return
		ancestor = ancestor.get_parent()


func _monitor_depth_offset(sprite: Sprite2D) -> float:
	if name != "FurnitureSprites" or not sprite.name.begins_with("Monitor"):
		return 0.0
	if sprite.name.begins_with("MonitorLeft") or sprite.name.begins_with("MonitorRight"):
		return WORKSTATION_SIDE_MONITOR_DEPTH_OFFSET
	return WORKSTATION_CENTRAL_MONITOR_DEPTH_OFFSET
