extends Control

const CONVEYOR_Z := 1.9
const CONVEYOR_TOP := 1.42
const CONVEYOR_LENGTH := 56.0
const CONVEYOR_SPEED := 0.85
const PIXEL_RENDER_WIDTH := 640.0
const FLOOR_ATLAS = preload("res://assets/tiles/warehouse_floor_tileset_32.png")

# This miniature is independent of the playable warehouse and its pixel assets.
var animated := true
var elapsed := 4.0:
	set(value):
		elapsed = value
		if is_instance_valid(_camera):
			_animate_scene()
			_request_frame()

var viewport: SubViewport
var _display: SubViewportContainer
var containers: Array[Node3D] = []
var truck: Node3D
var _dock: Node3D
var _scene: Node3D
var _camera: Camera3D
var _rollers: Array[Node3D] = []
var _scanner: MeshInstance3D
var _scan_material: StandardMaterial3D
var _materials: Dictionary = {}
var _mesh_cache: Dictionary = {}
var _label_materials: Array[StandardMaterial3D] = []

func _ready() -> void:
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	_display = SubViewportContainer.new()
	_display.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_display.texture_filter = CanvasItem.TEXTURE_FILTER_NEAREST
	_display.stretch = true
	var pixel_treatment := Shader.new()
	pixel_treatment.code = """
shader_type canvas_item;
void fragment() {
	vec2 pixel_uv = (floor(UV / TEXTURE_PIXEL_SIZE) + vec2(0.5)) * TEXTURE_PIXEL_SIZE;
	vec4 image = texture(TEXTURE, pixel_uv);
	float edge = smoothstep(0.2, 0.72, length(pixel_uv - vec2(0.5)));
	vec3 color = image.rgb * (1.0 - edge * 0.18);
	color = floor(clamp(color, vec3(0.0), vec3(1.0)) * 47.0 + 0.5) / 47.0;
	COLOR = vec4(color, image.a);
}
"""
	var treatment := ShaderMaterial.new()
	treatment.shader = pixel_treatment
	_display.material = treatment
	add_child(_display)
	_display.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	viewport = SubViewport.new()
	viewport.own_world_3d = true
	viewport.gui_disable_input = true
	viewport.msaa_3d = Viewport.MSAA_DISABLED
	viewport.positional_shadow_atlas_size = 1024
	_display.add_child(viewport)
	_scene = Node3D.new()
	viewport.add_child(_scene)
	_materials = {
		"floor": _material("ffffff"),
		"joint": _material("454d53"),
		"wall": _material("8c969e"),
		"blue": _material("235777", 0.08),
		"tote": _material("245471"),
		"tote_edge": _material("356580"),
		"steel": _material("a2afb8", 0.12),
		"dark": _material("293239"),
		"card": _material("b58b56"),
		"tape": _material("d4b57c"),
		"paper": _material("d6dce0"),
		"yellow": _material("e9bc36"),
		"red": _material("bc3834"),
		"rubber": _material("1c252c"),
		"trailer": _material("b8c3cb", 0.05),
		"glass": _material("27495e"),
		"goods_red": _material("d85b4c", 0.0, 0.55),
		"goods_green": _material("57986f", 0.0, 0.58),
		"goods_white": _material("ece9df", 0.0, 0.65),
	}
	# Reuse the same concrete pixels as the playable warehouse, not a new surface style.
	_materials.floor.albedo_texture = ImageTexture.create_from_image(FLOOR_ATLAS.get_image().get_region(Rect2i(0, 0, 32, 32)))
	_materials.floor.uv1_scale = Vector3(70.0 / 2.6, 70.0 / 2.6, 1.0)
	_build_label_materials()
	_lighting()
	_build_room()
	_build_conveyor()
	_build_workstation()
	_build_truck()
	_build_storage_decor()
	_build_pallet_jack(Vector3(8.1, 0, 6.8))
	_camera = Camera3D.new()
	_camera.keep_aspect = Camera3D.KEEP_WIDTH
	_camera.fov = 68
	_camera.near = 0.1
	_camera.far = 80
	_scene.add_child(_camera)
	_camera.current = true
	visibility_changed.connect(_request_frame)
	resized.connect(_request_frame)
	_animate_scene()
	_request_frame()

func _process(delta: float) -> void:
	if animated and is_visible_in_tree():
		elapsed += delta

func _request_frame() -> void:
	if not is_instance_valid(viewport):
		return
	_display.stretch_shrink = maxi(2, roundi(size.x / PIXEL_RENDER_WIDTH))
	viewport.render_target_update_mode = SubViewport.UPDATE_ONCE if is_visible_in_tree() else SubViewport.UPDATE_DISABLED

func _material(color: String, metal := 0.0, roughness := 0.8) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = Color(color)
	material.metallic = metal
	material.roughness = roughness
	material.specular_mode = BaseMaterial3D.SPECULAR_DISABLED
	material.texture_filter = BaseMaterial3D.TEXTURE_FILTER_NEAREST
	return material

func _lighting() -> void:
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("7e8991")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("dae2ea")
	environment.ambient_light_energy = 0.55
	var world := WorldEnvironment.new()
	world.environment = environment
	_scene.add_child(world)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-55, -34, 0)
	sun.light_color = Color("edf2f7")
	sun.light_energy = 0.85
	sun.shadow_enabled = true
	sun.shadow_blur = 0.0
	sun.directional_shadow_max_distance = 45
	_scene.add_child(sun)
	var fill := DirectionalLight3D.new()
	fill.rotation_degrees = Vector3(-28, 148, 0)
	fill.light_color = Color("ccd9e5")
	fill.light_energy = 0.20
	_scene.add_child(fill)

func _build_label_materials() -> void:
	for variant in range(4):
		var print_image := Image.create(32, 24, false, Image.FORMAT_RGBA8)
		print_image.fill(Color("d6dce0"))
		var ink := Color("293239")
		var accent := Color(["235777", "bc3834", "57986f", "c09b40"][variant])
		print_image.fill_rect(Rect2i(2, 2, 7, 5), accent)
		for row in range(3):
			print_image.fill_rect(Rect2i(12, 2 + row * 2, 15 - row * 3, 1), ink)
		for stripe in range(13):
			var width := 2 if (stripe + variant) % 3 == 0 else 1
			print_image.fill_rect(Rect2i(3 + stripe * 2, 10, width, 8), ink)
		for column in range(4):
			print_image.fill_rect(Rect2i(3 + column * 7, 20, 4 + (column + variant) % 2, 1), ink)
		var material := _material("ffffff")
		material.albedo_texture = ImageTexture.create_from_image(print_image)
		_label_materials.append(material)

func _printed_label(parent: Node3D, at: Vector3, dimensions: Vector2, seed: int, top := false) -> MeshInstance3D:
	var label := MeshInstance3D.new()
	var quad := QuadMesh.new()
	quad.size = dimensions
	label.mesh = quad
	label.material_override = _label_materials[posmod(seed, _label_materials.size())]
	label.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(label)
	label.position = at
	if top:
		label.rotation.x = -PI / 2
	return label

func _box(parent: Node3D, dimensions: Vector3, at: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	if not _mesh_cache.has(dimensions):
		if minf(dimensions.x, minf(dimensions.y, dimensions.z)) >= 0.15:
			_mesh_cache[dimensions] = _beveled_box(dimensions)
		else:
			var box := BoxMesh.new()
			box.size = dimensions
			_mesh_cache[dimensions] = box
	var instance := MeshInstance3D.new()
	instance.mesh = _mesh_cache[dimensions]
	instance.material_override = material
	if minf(dimensions.x, minf(dimensions.y, dimensions.z)) < 0.025:
		instance.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
	parent.add_child(instance)
	instance.position = at
	return instance

func _beveled_box(dimensions: Vector3, bevel := 0.025) -> ArrayMesh:
	var half := dimensions * 0.5
	var inset := half - Vector3.ONE * bevel
	var surface := SurfaceTool.new()
	surface.begin(Mesh.PRIMITIVE_TRIANGLES)
	for axis in range(3):
		var u := (axis + 1) % 3
		var v := (axis + 2) % 3
		for sign_axis in [-1, 1]:
			var normal := Vector3.ZERO
			normal[axis] = sign_axis
			var points: Array[Vector3] = []
			for corner in [Vector2(-1, -1), Vector2(1, -1), Vector2(1, 1), Vector2(-1, 1)]:
				var point := Vector3.ZERO
				point[axis] = half[axis] * sign_axis
				point[u] = inset[u] * corner.x
				point[v] = inset[v] * corner.y
				points.append(point)
			_mesh_face(surface, points, normal)
	for a in range(3):
		for b in range(a + 1, 3):
			var c := 3 - a - b
			for sa in [-1, 1]:
				for sb in [-1, 1]:
					var normal := Vector3.ZERO
					normal[a] = sa
					normal[b] = sb
					var points: Array[Vector3] = []
					for edge in [Vector2(0, -1), Vector2(1, -1), Vector2(1, 1), Vector2(0, 1)]:
						var point := Vector3.ZERO
						point[a] = (half[a] if edge.x == 0 else inset[a]) * sa
						point[b] = (inset[b] if edge.x == 0 else half[b]) * sb
						point[c] = inset[c] * edge.y
						points.append(point)
					_mesh_face(surface, points, normal.normalized())
	for sx in [-1, 1]:
		for sy in [-1, 1]:
			for sz in [-1, 1]:
				var sign_corner := Vector3(sx, sy, sz)
				var points: Array[Vector3] = []
				for axis in range(3):
					var point := inset * sign_corner
					point[axis] = half[axis] * sign_corner[axis]
					points.append(point)
				_mesh_face(surface, points, sign_corner.normalized())
	return surface.commit()

func _mesh_face(surface: SurfaceTool, points: Array[Vector3], normal: Vector3) -> void:
	for triangle in range(1, points.size() - 1):
		var vertices := [points[0], points[triangle], points[triangle + 1]]
		if (vertices[1] - vertices[0]).cross(vertices[2] - vertices[0]).dot(normal) > 0:
			vertices.reverse()
		for point in vertices:
			surface.set_normal(normal)
			surface.add_vertex(point)

func _cylinder(parent: Node3D, radius: float, height: float, at: Vector3, material: StandardMaterial3D) -> MeshInstance3D:
	var mesh := CylinderMesh.new()
	mesh.top_radius = radius
	mesh.bottom_radius = radius
	mesh.height = height
	mesh.radial_segments = 16
	var instance := MeshInstance3D.new()
	instance.mesh = mesh
	instance.material_override = material
	parent.add_child(instance)
	instance.position = at
	return instance

func _build_room() -> void:
	var floor_mesh := PlaneMesh.new()
	floor_mesh.size = Vector2(70, 70)
	var floor_surface := MeshInstance3D.new()
	floor_surface.mesh = floor_mesh
	floor_surface.material_override = _materials.floor
	floor_surface.position.y = -0.01
	_scene.add_child(floor_surface)
	for tile in range(-12, 13):
		_box(_scene, Vector3(0.09, 0.005, 44), Vector3(tile * 2.6, 0, 0), _materials.joint)
		_box(_scene, Vector3(44, 0.005, 0.09), Vector3(0, 0, tile * 2.6), _materials.joint)
	_box(_scene, Vector3(40, 10, 0.25), Vector3(0, 5, -10), _materials.wall)
	for x in range(-16, 18, 4):
		_box(_scene, Vector3(0.22, 9, 0.22), Vector3(x, 4.5, -9.8), _materials.steel)
		_box(_scene, Vector3(0.44, 1.05, 0.44), Vector3(x, 0.52, -9.6), _materials.yellow)
		for y in [0.22, 0.58, 0.94]:
			_box(_scene, Vector3(0.46, 0.13, 0.46), Vector3(x, y, -9.6), _materials.dark)
	for x in [-4.6, 0.0, 4.6, 9.2]:
		_build_rack(Vector3(x, 0, -5.7))
	for z in [0.45, 3.45]:
		_box(_scene, Vector3(56, 0.008, 0.065), Vector3(0, 0.01, z), _materials.yellow)
	for x in [-9, -5, -1, 3, 7, 11]:
		_box(_scene, Vector3(0.4, 0.008, 0.055), Vector3(x, 0.012, 3.9), _materials.yellow)
		for direction in [-1, 1]:
			var arrow := _box(_scene, Vector3(0.2, 0.008, 0.05), Vector3(x + 0.12, 0.012, 3.9 + direction * 0.06), _materials.yellow)
			arrow.rotation.y = direction * 0.65
	var pallet := _pallet(_scene, Vector3(5.9, 0, 6.25))
	pallet.name = "LoadedPallet"
	for layer in range(2):
		for x in [-0.45, 0.45]:
			for z in [-0.38, 0.38]:
				_parcel(pallet, Vector3(0.78, 0.58, 0.66), Vector3(x, 0.52 + layer * 0.58, z), layer + 1)

func _pallet(parent: Node3D, at: Vector3, dimensions := Vector2(1.8, 1.6)) -> Node3D:
	var pallet := Node3D.new()
	parent.add_child(pallet)
	pallet.position = at
	for x in [-dimensions.x * 0.38, 0.0, dimensions.x * 0.38]:
		_box(pallet, Vector3(dimensions.x * 0.095, 0.16, dimensions.y), Vector3(x, 0.07, 0), _materials.card)
	for i in range(5):
		_box(pallet, Vector3(dimensions.x, 0.08, dimensions.y * 0.1375), Vector3(0, 0.19, (i - 2) * dimensions.y * 0.203), _materials.tape)
	return pallet

func _build_rack(at: Vector3) -> void:
	var rack := Node3D.new()
	_scene.add_child(rack)
	rack.position = at
	for x in [-2.08, 2.08]:
		for z in [-0.72, 0.72]:
			_box(rack, Vector3(0.12, 5.4, 0.12), Vector3(x, 2.7, z), _materials.blue)
			_box(rack, Vector3(0.28, 0.08, 0.28), Vector3(x, 0.05, z), _materials.dark)
	for level in range(4):
		var y := 0.35 + level * 1.45
		_box(rack, Vector3(4.22, 0.1, 1.55), Vector3(0, y, 0), _materials.steel)
		for z in [-0.79, 0.79]:
			_box(rack, Vector3(4.28, 0.18, 0.09), Vector3(0, y - 0.025, z), _materials.blue)
		_printed_label(rack, Vector3(-1.50, y - 0.025, 0.839), Vector2(0.29, 0.12), level)
		for x in [-2.08, 2.08]:
			_box(rack, Vector3(0.07, 0.12, 0.018), Vector3(x, y - 0.025, 0.843), _materials.steel)
			for offset in [-0.30, 0.30]:
				_box(rack, Vector3(0.04, 0.07, 0.005), Vector3(x, y + offset, 0.785), _materials.dark)
		if level % 2 == 0:
			var brace := _box(rack, Vector3(0.055, Vector2(4.16, 1.45).length(), 0.055), Vector3(0, y + 0.725, -0.72), _materials.steel)
			brace.rotation.z = atan2(4.16, 1.45) * (1 if level == 0 else -1)
		for item in range(4):
			var x := -1.52 + item * 1.02
			if (item + level + int(at.x)) % 3 == 0:
				_tote(rack, Vector3(x, y + 0.31, 0), item + level * 4)
			else:
				_parcel(rack, Vector3(0.83, 0.65, 1.04), Vector3(x, y + 0.38, 0), item)

func _parcel(parent: Node3D, dimensions: Vector3, at: Vector3, label_seed: int) -> Node3D:
	var parcel := Node3D.new()
	parent.add_child(parcel)
	parcel.position = at
	parcel.set_meta("top_height", dimensions.y * 0.5)
	_box(parcel, dimensions, Vector3.ZERO, _materials.card)
	_box(parcel, Vector3(dimensions.x + 0.008, 0.009, dimensions.z * 0.17), Vector3(0, dimensions.y / 2 + 0.005, 0), _materials.tape)
	_printed_label(parcel, Vector3(dimensions.x * 0.16, dimensions.y / 2 + 0.017, dimensions.z * 0.24), Vector2(0.26, 0.21), label_seed, true)
	_printed_label(parcel, Vector3(-dimensions.x * 0.16, 0, dimensions.z / 2 + 0.006), Vector2(0.32, 0.21), label_seed + 1)
	_box(parcel, Vector3(0.055, dimensions.y * 0.88, 0.008), Vector3(0, 0, dimensions.z / 2 + 0.004), _materials.tape)
	for x in [-dimensions.x * 0.34, dimensions.x * 0.34]:
		_box(parcel, Vector3(0.022, 0.09, 0.008), Vector3(x, -dimensions.y * 0.29, dimensions.z / 2 + 0.005), _materials.dark)
	return parcel

func _tote(parent: Node3D, at: Vector3, label_seed := 0) -> Node3D:
	var tote := Node3D.new()
	parent.add_child(tote)
	tote.position = at
	tote.set_meta("cargo_kind", "blue_tote")
	tote.set_meta("top_height", 0.2925)
	tote.set_meta("fill_level", "empty")
	_box(tote, Vector3(0.9, 0.08, 1.07), Vector3(0, -0.22, 0), _materials.tote)
	for x in [-0.44, 0.44]:
		_box(tote, Vector3(0.055, 0.5, 1.08), Vector3(x, 0, 0), _materials.tote)
	for z in [-0.51, 0.51]:
		# Split the upper wall around a real handle opening.
		_box(tote, Vector3(0.93, 0.30, 0.055), Vector3(0, -0.10, z), _materials.tote)
		for x in [-0.3025, 0.3025]:
			_box(tote, Vector3(0.325, 0.20, 0.055), Vector3(x, 0.15, z), _materials.tote)
		_box(tote, Vector3(0.28, 0.05, 0.055), Vector3(0, 0.225, z), _materials.tote)
		_box(tote, Vector3(0.95, 0.045, 0.08), Vector3(0, 0.27, z), _materials.blue)
		for x in [-0.3, 0.3]:
			_box(tote, Vector3(0.035, 0.43, 0.025), Vector3(x, -0.01, z * 1.065), _materials.tote_edge)
	var details := Node3D.new()
	details.name = "ShellDetails"
	tote.add_child(details)
	for x in [-0.44, 0.44]:
		_box(details, Vector3(0.08, 0.045, 1.07), Vector3(x, 0.27, 0), _materials.blue)
		for z in [-0.35, 0.0, 0.35]:
			_box(details, Vector3(0.025, 0.43, 0.035), Vector3(x * 1.087, -0.015, z), _materials.tote_edge)
		for y in [-0.17, 0.18]:
			_box(details, Vector3(0.027, 0.035, 1.07), Vector3(x * 1.087, y, 0), _materials.blue)
	_printed_label(details, Vector3(-0.17, -0.075, 0.552), Vector2(0.28, 0.13), label_seed)
	return tote

func _fill_tote(tote: Node3D, index: int) -> void:
	var variant := index % 8
	if variant == 0 or variant == 4:
		return
	var full := variant == 1 or variant == 3 or variant == 6
	var assortment: String = {1: "mixed", 2: "bottles", 3: "cartons", 5: "packs", 6: "bottles", 7: "mixed"}[variant]
	tote.set_meta("fill_level", "full" if full else "sparse")
	tote.set_meta("assortment", assortment)
	var goods := Node3D.new()
	goods.name = "Goods"
	tote.add_child(goods)
	for slot in range(6):
		if not full and slot not in [0, 3, 5]:
			continue
		var kind := assortment
		if kind == "mixed":
			kind = ["cartons", "packs", "bottles"][(slot + index) % 3]
		var layer_height: float = {"cartons": 0.21, "packs": 0.135, "bottles": 0.427}[kind]
		var layers := 1
		if full and kind != "bottles":
			layers = 2 if kind == "cartons" else 3
		for layer in range(layers):
			var at := Vector3(-0.175 + (slot % 2) * 0.35, -0.18 + layer * layer_height, -0.30 + (slot / 2) * 0.30)
			_tote_product(goods, kind, at, index + slot + layer)

func _tote_product(parent: Node3D, kind: String, at: Vector3, seed: int) -> void:
	var product := Node3D.new()
	parent.add_child(product)
	product.position = at
	product.set_meta("goods_kind", kind)
	var color: StandardMaterial3D = [_materials.goods_red, _materials.goods_green, _materials.goods_white][seed % 3]
	match kind:
		"cartons":
			_box(product, Vector3(0.30, 0.20, 0.25), Vector3(0, 0.10, 0), color)
			_box(product, Vector3(0.27, 0.007, 0.025), Vector3(0, 0.205, 0), _materials.paper)
			_printed_label(product, Vector3(0, 0.11, 0.134), Vector2(0.18, 0.075), seed)
			_printed_label(product, Vector3(0, 0.208, -0.025), Vector2(0.18, 0.13), seed, true)
			_box(product, Vector3(0.012, 0.19, 0.005), Vector3(0.125, 0.10, 0.128), _materials.paper)
		"packs":
			_box(product, Vector3(0.31, 0.125, 0.265), Vector3(0, 0.0625, 0), color)
			_printed_label(product, Vector3(-0.015, 0.130, 0), Vector2(0.18, 0.16), seed, true)
			_box(product, Vector3(0.05, 0.005, 0.27), Vector3(0.105, 0.130, 0), _materials.tape)
			for z in [-0.12, 0.12]:
				_box(product, Vector3(0.30, 0.016, 0.012), Vector3(0, 0.025, z), _materials.paper)
		"bottles":
			_cylinder(product, 0.085, 0.30, Vector3(0, 0.15, 0), color)
			_cylinder(product, 0.087, 0.09, Vector3(0, 0.16, 0), _materials.paper)
			var shoulder := _cylinder(product, 0.085, 0.055, Vector3(0, 0.3275, 0), color)
			shoulder.mesh.top_radius = 0.047
			_cylinder(product, 0.047, 0.045, Vector3(0, 0.3775, 0), color)
			_cylinder(product, 0.052, 0.027, Vector3(0, 0.4135, 0), _materials.yellow if seed % 2 == 0 else _materials.red)
			_printed_label(product, Vector3(0, 0.16, 0.089), Vector2(0.055, 0.065), seed)
			_cylinder(product, 0.05, 0.007, Vector3(0, 0.392, 0), _materials.paper)

func _build_conveyor() -> void:
	var conveyor := Node3D.new()
	conveyor.name = "Conveyor"
	_scene.add_child(conveyor)
	conveyor.position.z = CONVEYOR_Z
	for z in [-0.93, 0.93]:
		var rail := _box(conveyor, Vector3(CONVEYOR_LENGTH, 0.3, 0.13), Vector3(0, 1.28, z), _materials.blue)
		rail.name = "FrontRail" if z > 0 else "BackRail"
		_box(conveyor, Vector3(CONVEYOR_LENGTH, 0.045, 0.075), Vector3(0, 1.45, z), _materials.steel)
		for x in range(-26, 28, 4):
			_box(conveyor, Vector3(0.15, 1.18, 0.15), Vector3(x, 0.59, z), _materials.dark)
			_box(conveyor, Vector3(0.32, 0.08, 0.32), Vector3(x, 0.04, z), _materials.steel)
	_box(conveyor, Vector3(CONVEYOR_LENGTH, 0.09, 1.7), Vector3(0, 1.17, 0), _materials.dark)
	for i in range(182):
		var roller := Node3D.new()
		conveyor.add_child(roller)
		roller.position = Vector3(-27.6 + i * 0.305, 1.31, 0)
		var drum := _cylinder(roller, 0.108, 1.72, Vector3.ZERO, _materials.steel)
		drum.rotation.x = PI / 2
		_box(roller, Vector3(0.016, 0.007, 1.65), Vector3(0, 0.109, 0), _materials.joint)
		_rollers.append(roller)
	for i in range(16):
		var tote := _tote(conveyor, Vector3(0, CONVEYOR_TOP + 0.26, 0), i)
		tote.name = "MovingBlueTote_" + str(i + 1)
		_fill_tote(tote, i)
		containers.append(tote)
	# Scan head and the narrow light sweep belong to the conveyor, not the game.
	for z in [-1.14, 1.14]:
		_box(conveyor, Vector3(0.17, 2.7, 0.17), Vector3(4.2, 1.35, z), _materials.dark)
	_box(conveyor, Vector3(0.28, 0.17, 2.44), Vector3(4.2, 2.73, 0), _materials.dark)
	_scan_material = _material("ef6255")
	_scan_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_scan_material.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	_scan_material.albedo_color.a = 0.48
	_scanner = _box(conveyor, Vector3(0.025, 0.013, 1.75), Vector3(4.2, 1.44, 0), _scan_material)
	var screen_material := _material("53cec0")
	screen_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_box(conveyor, Vector3(0.52, 0.34, 0.15), Vector3(4.2, 2.18, 1.23), _materials.dark)
	_box(conveyor, Vector3(0.42, 0.24, 0.016), Vector3(4.2, 2.18, 1.315), screen_material)
	_box(conveyor, Vector3(0.7, 0.4, 0.42), Vector3(2, 0.85, 1.03), _materials.blue)
	for x in [1.75, 2.25]:
		_box(conveyor, Vector3(0.07, 0.28, 0.07), Vector3(x, 1.1, 1.03), _materials.steel)
	_build_conveyor_details(conveyor)

func _build_conveyor_details(conveyor: Node3D) -> void:
	var details := Node3D.new()
	details.name = "ServiceDetails"
	conveyor.add_child(details)
	for x in range(-26, 28, 4):
		_box(details, Vector3(0.12, 0.08, 1.72), Vector3(x, 0.45, 0), _materials.steel)
	for x in [-18, -10, -2, 6, 14, 22]:
		for side in [-1, 1]:
			_box(details, Vector3(0.34, 0.20, 0.022), Vector3(x, 1.28, side * 1.006), _materials.steel)
			for offset in [-0.11, 0.11]:
				var bolt := _cylinder(details, 0.027, 0.016, Vector3(x + offset, 1.28, side * 1.025), _materials.dark)
				bolt.rotation.x = PI / 2
	for y in [0.74, 0.86, 0.98]:
		_box(details, Vector3(0.34, 0.035, 0.016), Vector3(2, y, 1.249), _materials.dark)
	_box(details, Vector3(0.64, 0.23, 0.12), Vector3(6, 1.28, 1.06), _materials.dark)
	_printed_label(details, Vector3(6.13, 1.28, 1.124), Vector2(0.22, 0.14), 2)
	var stop := _cylinder(details, 0.057, 0.045, Vector3(5.82, 1.28, 1.137), _materials.red)
	stop.rotation.x = PI / 2

func _build_truck() -> void:
	_dock = Node3D.new()
	_dock.name = "TruckUnloadingDock"
	_scene.add_child(_dock)
	_dock.position = Vector3(-10.5, 0, -1.8)
	_dock.rotation.y = 1.45
	truck = Node3D.new()
	truck.name = "UnloadingTruck"
	_dock.add_child(truck)
	truck.position = Vector3(0, 0, -3.9)
	_box(truck, Vector3(3.55, 0.18, 7.9), Vector3(0, 1.18, 0), _materials.steel)
	_box(truck, Vector3(2.8, 0.3, 8.2), Vector3(0, 0.85, -0.1), _materials.dark)
	for x in [-1.72, 1.72]:
		_box(truck, Vector3(0.13, 3.8, 7.85), Vector3(x, 3.15, 0), _materials.trailer)
		_box(truck, Vector3(0.035, 0.4, 7.65), Vector3(x * 1.044, 2.32, 0), _materials.red)
		_box(truck, Vector3(0.035, 0.08, 7.65), Vector3(x * 1.044, 1.43, 0), _materials.yellow)
		for z in range(-3, 4):
			_box(truck, Vector3(0.04, 3.6, 0.04), Vector3(x * 1.047, 3.2, z), _materials.steel)
		_box(truck, Vector3(0.025, 0.30, 7.68), Vector3(signf(x) * 1.643, 1.48, 0), _materials.steel)
		_box(truck, Vector3(0.025, 0.10, 7.68), Vector3(signf(x) * 1.643, 2.5, 0), _materials.dark)
		for z in [0.0, 1.2, 2.4, 3.3]:
			_box(truck, Vector3(0.03, 0.10, 0.12), Vector3(signf(x) * 1.614, 2.5, z), _materials.steel)
	_box(truck, Vector3(3.55, 0.12, 7.95), Vector3(0, 5.05, 0), _materials.trailer)
	_box(truck, Vector3(3.5, 3.8, 0.12), Vector3(0, 3.15, -3.91), _materials.trailer)
	for x in [-1.68, 1.68]:
		_box(truck, Vector3(0.13, 3.9, 0.15), Vector3(x, 3.14, 3.95), _materials.dark)
	_box(truck, Vector3(3.55, 0.13, 0.17), Vector3(0, 5.05, 3.95), _materials.dark)
	_box(truck, Vector3(3.55, 0.16, 0.2), Vector3(0, 1.18, 3.82), _materials.dark)
	for i in range(8):
		_box(truck, Vector3(0.23, 0.1, 0.022), Vector3(-1.57 + i * 0.44, 1.18, 3.94), _materials.yellow)
	for side in [-1, 1]:
		var door := Node3D.new()
		door.name = "OpenRearDoor_" + str(side)
		truck.add_child(door)
		door.position = Vector3(side * 1.73, 0, 3.96)
		door.rotation.y = side * deg_to_rad(102)
		_box(door, Vector3(1.67, 3.64, 0.1), Vector3(-side * 0.835, 3.15, 0), _materials.trailer)
		for x in [-side * 0.45, -side * 1.22]:
			_cylinder(door, 0.026, 3.3, Vector3(x, 3.15, 0.075), _materials.steel)
			for y in [2.1, 3.9]:
				_box(door, Vector3(0.10, 0.09, 0.035), Vector3(x, y, 0.103), _materials.dark)
			_box(door, Vector3(0.18, 0.06, 0.07), Vector3(x, 2.6, 0.13), _materials.steel)
		for y in [1.75, 3.15, 4.55]:
			_cylinder(door, 0.045, 0.18, Vector3(0, y, 0), _materials.steel)
		_printed_label(door, Vector3(-side * 0.85, 1.9, 0.057), Vector2(0.32, 0.23), side + 2)
	for x in [-1.72, 1.72]:
		for z in [1.1, 2.1, 3.1, -4.9]:
			var tire := _cylinder(truck, 0.5, 0.28, Vector3(x, 0.51, z), _materials.rubber)
			tire.rotation.z = PI / 2
			var hub := _cylinder(truck, 0.24, 0.3, Vector3(x, 0.51, z), _materials.steel)
			hub.rotation.z = PI / 2
	_box(truck, Vector3(3.25, 2.1, 2.25), Vector3(0, 1.73, -5.1), _materials.red)
	_box(truck, Vector3(3.13, 0.85, 0.16), Vector3(0, 2.14, -6.27), _materials.glass)
	_box(truck, Vector3(3.05, 0.4, 1.55), Vector3(0, 1.33, -6.15), _materials.red)
	_box(truck, Vector3(3.35, 0.19, 0.25), Vector3(0, 0.86, -6.85), _materials.steel)
	for x in [-1.66, 1.66]:
		_box(truck, Vector3(0.025, 0.8, 1.06), Vector3(x, 2.15, -5.55), _materials.glass)
		_box(truck, Vector3(0.18, 0.26, 0.12), Vector3(x * 1.13, 2.05, -6), _materials.dark)
		_box(truck, Vector3(0.48, 0.24, 0.025), Vector3(x * 0.69, 1.28, -6.94), _materials.paper)
	var cargo := Node3D.new()
	cargo.name = "PalletCargo"
	truck.add_child(cargo)
	for x in [-1.10, 1.10]:
		for z in [-2.8, -1.45, -0.1]:
			var pallet := _pallet(cargo, Vector3(x, 1.28, z), Vector2(1.05, 1.2))
			for level in range(3):
				_parcel(pallet, Vector3(0.86, 0.65, 1.08), Vector3(0, 0.555 + level * 0.65, 0), level)
	var ramp := Node3D.new()
	ramp.name = "UnloadingRamp"
	_dock.add_child(ramp)
	ramp.position = Vector3(0, 0.64, 2)
	ramp.rotation.x = atan2(1.28, 4.0)
	var length := Vector2(1.28, 4.0).length()
	_box(ramp, Vector3(2.8, 0.09, length), Vector3(0, -0.045, 0), _materials.dark)
	for x in [-1.34, 1.34]:
		_box(ramp, Vector3(0.07, 0.08, length), Vector3(x, 0.025, 0), _materials.yellow)
	for step in range(18):
		_box(ramp, Vector3(2.55, 0.025, 0.035), Vector3(0, 0.012, -length * 0.5 + 0.14 + step * 0.225), _materials.steel)

func _decor_root(name: String, at: Vector3, reference: String) -> Node3D:
	var item := Node3D.new()
	item.name = name
	_scene.get_node("WarehouseDecor").add_child(item)
	item.position = at
	item.set_meta("reference_asset", reference)
	return item

func _build_storage_decor() -> void:
	var decor := Node3D.new()
	decor.name = "WarehouseDecor"
	_scene.add_child(decor)
	var stack := _decor_root("PalletStack", Vector3(-7.6, 0, 5.2), "res://assets/tiles/warehouse_decor_tileset_32.png")
	for layer in range(4):
		_pallet(stack, Vector3(0, layer * 0.24, 0))
	var totes := _decor_root("ToteStack", Vector3(-0.4, 0, 5.0), "res://assets/tiles/pallet_edit_sources/warehouse_blue_tote_stack_10.png")
	for layer in range(3):
		_tote(totes, Vector3(0, 0.26 + layer * 0.5525, 0), layer)
	var cart := _decor_root("MeshCart", Vector3(-4.2, 0, 5.0), "res://assets/tiles/warehouse_mesh_carts_tileset_32.png")
	_box(cart, Vector3(1.5, 0.12, 1.14), Vector3(0, 0.25, 0), _materials.blue)
	for x in [-0.70, 0.70]:
		for z in [-0.53, 0.53]:
			_box(cart, Vector3(0.07, 1.90, 0.07), Vector3(x, 1.18, z), _materials.blue)
	for y in [0.36, 1.18, 2.12]:
		for z in [-0.53, 0.53]:
			_box(cart, Vector3(1.47, 0.045, 0.045), Vector3(0, y, z), _materials.blue)
		for x in [-0.70, 0.70]:
			_box(cart, Vector3(0.045, 0.045, 1.10), Vector3(x, y, 0), _materials.blue)
	for z in [-0.53, 0.53]:
		for column in range(9):
			_box(cart, Vector3(0.014, 1.74, 0.014), Vector3((column - 4) * 0.155, 1.23, z), _materials.steel)
		for row in range(10):
			_box(cart, Vector3(1.40, 0.014, 0.014), Vector3(0, 0.45 + row * 0.17, z), _materials.steel)
	for x in [-0.70, 0.70]:
		for column in range(7):
			_box(cart, Vector3(0.014, 1.74, 0.014), Vector3(x, 1.23, (column - 3) * 0.16), _materials.steel)
		for row in range(10):
			_box(cart, Vector3(0.014, 0.014, 1.06), Vector3(x, 0.45 + row * 0.17, 0), _materials.steel)
	for x in [-0.57, 0.57]:
		for z in [-0.43, 0.43]:
			var wheel := _cylinder(cart, 0.12, 0.09, Vector3(x, 0.12, z), _materials.rubber)
			wheel.rotation.z = PI / 2
	var charger := _decor_root("ChargingStation", Vector3(-3.8, 0, -2.3), "res://assets/objects/charging_station/charging_station.png")
	for x in [-0.24, 0.24]:
		_box(charger, Vector3(0.16, 0.18, 0.36), Vector3(x, 0.09, 0), _materials.dark)
	_box(charger, Vector3(0.68, 1.40, 0.50), Vector3(0, 0.88, 0), _materials.dark)
	_box(charger, Vector3(0.52, 0.96, 0.035), Vector3(0, 0.94, 0.27), _materials.steel)
	for y in [0.45, 0.52, 0.59]:
		_box(charger, Vector3(0.32, 0.025, 0.014), Vector3(0, y, 0.295), _materials.dark)
	_box(charger, Vector3(0.08, 0.055, 0.018), Vector3(0.13, 1.30, 0.30), _materials.goods_green)
	for x in [-0.23, 0.23]:
		for y in [0.29, 1.40]:
			_box(charger, Vector3(0.13, 0.10, 0.045), Vector3(x, y, 0.30), _materials.yellow)
	var bolt := SurfaceTool.new()
	bolt.begin(Mesh.PRIMITIVE_TRIANGLES)
	_mesh_face(bolt, [Vector3(0.09, 1.28, 0.295), Vector3(-0.15, 0.92, 0.295), Vector3(-0.02, 0.92, 0.295)], Vector3.BACK)
	_mesh_face(bolt, [Vector3(-0.02, 0.92, 0.295), Vector3(0.11, 0.92, 0.295), Vector3(-0.11, 0.65, 0.295)], Vector3.BACK)
	var symbol := MeshInstance3D.new()
	symbol.mesh = bolt.commit()
	symbol.material_override = _materials.yellow
	charger.add_child(symbol)
	for z in [-0.85, 0.85]:
		_box(charger, Vector3(2.7, 0.01, 0.08), Vector3(1.65, 0.012, z), _materials.yellow)
	for x in [0.30, 3.0]:
		_box(charger, Vector3(0.08, 0.01, 1.7), Vector3(x, 0.012, 0), _materials.yellow)
	for y in [0.48, 0.71, 0.94, 1.17]:
		_box(charger, Vector3(0.15, 0.055, 0.055), Vector3(0.39, y, 0.08), _materials.rubber)
	_box(charger, Vector3(0.055, 0.69, 0.055), Vector3(0.49, 0.82, 0.08), _materials.rubber)
	var fire := _decor_root("FireCabinet", Vector3(-7.4, 0, -5.1), "res://assets/tiles/warehouse_decor_tileset_32.png")
	_box(fire, Vector3(1.36, 0.10, 0.50), Vector3(0, 0.05, 0), _materials.dark)
	_box(fire, Vector3(1.30, 2.10, 0.45), Vector3(0, 1.15, 0), _materials.red)
	_box(fire, Vector3(1.12, 1.86, 0.028), Vector3(0, 1.15, 0.244), _materials.dark)
	_box(fire, Vector3(0.055, 1.86, 0.035), Vector3(0.13, 1.15, 0.263), _materials.red)
	var hose := _cylinder(fire, 0.27, 0.05, Vector3(-0.24, 1.60, 0.29), _materials.tape)
	hose.rotation.x = PI / 2
	var hub := _cylinder(fire, 0.18, 0.055, Vector3(-0.24, 1.60, 0.32), _materials.dark)
	hub.rotation.x = PI / 2
	_cylinder(fire, 0.09, 0.62, Vector3(0.34, 0.95, 0.31), _materials.red)
	_box(fire, Vector3(0.17, 0.07, 0.10), Vector3(0.34, 1.29, 0.31), _materials.steel)
	_box(fire, Vector3(0.13, 0.16, 0.02), Vector3(0.34, 0.98, 0.40), _materials.paper)

func _build_workstation() -> void:
	var desk := Node3D.new()
	desk.name = "PackingWorkstation"
	_scene.add_child(desk)
	desk.position = Vector3(6.4, 0, -1.35)
	_box(desk, Vector3(3.6, 0.12, 1.45), Vector3(0, 1.2, 0), _materials.paper)
	for x in [-1.6, 1.6]:
		for z in [-0.58, 0.58]:
			_box(desk, Vector3(0.1, 1.15, 0.1), Vector3(x, 0.59, z), _materials.steel)
	_box(desk, Vector3(1.0, 0.64, 0.1), Vector3(-0.95, 1.69, -0.35), _materials.dark)
	var screen := _material("148fb4")
	screen.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	_box(desk, Vector3(0.87, 0.51, 0.012), Vector3(-0.95, 1.69, -0.294), screen)
	var details := Node3D.new()
	details.name = "WorkstationDetails"
	desk.add_child(details)
	_box(details, Vector3(0.70, 0.035, 0.006), Vector3(-0.95, 1.86, -0.284), _materials.paper)
	for row in range(4):
		var y := 1.78 - row * 0.08
		_box(details, Vector3(0.33, 0.027, 0.006), Vector3(-1.09, y, -0.284), _materials.paper)
		_box(details, Vector3(0.15, 0.027, 0.006), Vector3(-0.72, y, -0.284), _materials.goods_green if row == 3 else _materials.steel)
	_box(desk, Vector3(0.09, 0.23, 0.09), Vector3(-0.95, 1.34, -0.35), _materials.dark)
	_box(desk, Vector3(0.65, 0.03, 0.22), Vector3(-0.95, 1.29, 0.31), _materials.dark)
	for row in range(3):
		for key in range(9):
			_box(details, Vector3(0.048, 0.006, 0.039), Vector3(-1.205 + key * 0.064, 1.309, 0.255 + row * 0.055), _materials.steel)
	_box(details, Vector3(0.095, 0.033, 0.15), Vector3(-0.46, 1.2765, 0.31), _materials.dark)
	_box(details, Vector3(0.008, 0.01, 0.075), Vector3(-0.46, 1.294, 0.27), _materials.steel)
	_box(details, Vector3(0.035, 0.31, 0.035), Vector3(-0.46, 1.09, 0.59), _materials.rubber)
	_box(details, Vector3(0.49, 0.035, 0.035), Vector3(-0.705, 0.95, 0.59), _materials.rubber)
	_cylinder(details, 0.14, 0.07, Vector3(-0.08, 1.295, 0.29), _materials.tape)
	_cylinder(details, 0.065, 0.008, Vector3(-0.08, 1.333, 0.29), _materials.dark)
	_box(details, Vector3(0.32, 0.014, 0.24), Vector3(0.08, 1.267, -0.50), _materials.card)
	_printed_label(details, Vector3(0.08, 1.275, -0.50), Vector2(0.27, 0.19), 3, true)
	_parcel(desk, Vector3(0.85, 0.65, 0.8), Vector3(0.47, 1.59, 0), 2)
	var shelf := _box(desk, Vector3(3.2, 0.08, 1.24), Vector3(0, 0.23, 0), _materials.steel)
	shelf.name = "LowerShelf"
	var tote := _tote(desk, Vector3(0.7, 0.53, 0))
	tote.name = "WorkstationTote"

func _build_pallet_jack(at: Vector3) -> void:
	var jack := Node3D.new()
	jack.name = "ParkedPalletJack"
	_scene.add_child(jack)
	jack.position = at
	jack.rotation.y = -0.55
	for x in [-0.33, 0.33]:
		_box(jack, Vector3(0.24, 0.16, 2.05), Vector3(x, 0.2, 0.35), _materials.red)
		var wheel := _cylinder(jack, 0.14, 0.16, Vector3(x, 0.15, 1.18), _materials.rubber)
		wheel.rotation.z = PI / 2
	_box(jack, Vector3(1, 0.52, 0.52), Vector3(0, 0.37, -0.63), _materials.red)
	for x in [-0.47, 0.47]:
		var wheel := _cylinder(jack, 0.21, 0.14, Vector3(x, 0.23, -0.7), _materials.rubber)
		wheel.rotation.z = PI / 2
	var stem := _cylinder(jack, 0.055, 1.25, Vector3(0, 1.24, -0.76), _materials.dark)
	stem.rotation.x = -0.18
	for x in [-0.28, 0.28]:
		_cylinder(jack, 0.05, 0.38, Vector3(x, 1.96, -0.9), _materials.rubber)
	for y in [1.78, 2.15]:
		var handle := _cylinder(jack, 0.055, 0.56, Vector3(0, y, -0.9), _materials.rubber)
		handle.rotation.z = PI / 2
	_printed_label(jack, Vector3(0, 0.46, -0.364), Vector2(0.29, 0.14), 1)
	for x in [-0.33, 0.33]:
		_box(jack, Vector3(0.16, 0.018, 0.70), Vector3(x, 0.287, 0.72), _materials.steel)

func _animate_scene() -> void:
	# Containers wrap only beyond the camera at the ends of the long conveyor.
	for i in containers.size():
		containers[i].position.x = fposmod(elapsed * CONVEYOR_SPEED + i * 3.5, CONVEYOR_LENGTH) - CONVEYOR_LENGTH * 0.5
	for roller in _rollers:
		roller.rotation.z = -elapsed * 3.2
	_scanner.position.x = 4.2 + sin(elapsed * 4.2) * 0.22
	_scanner.position.y = CONVEYOR_TOP + 0.02
	for tote in containers:
		if absf(tote.position.x - _scanner.position.x) < 0.55:
			_scanner.position.y = tote.position.y + float(tote.get_meta("top_height")) + 0.018
	_scan_material.albedo_color.a = 0.26 + (sin(elapsed * 6) + 1.0) * 0.13
	# A fixed camera keeps static pixel edges from shimmering while totes move.
	_camera.position = Vector3(10.8, 8.4, 15.15)
	_camera.look_at(Vector3(0, 1.1, -0.9))
